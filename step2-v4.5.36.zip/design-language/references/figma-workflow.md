# Figma 页面写入工作流

本文件只在用户要求写入Figma或形成H5/Figma双端页面交付时读取。先完成 `workflow.md` 的公共主干、
H5产出与自查，再按本文件把已确认H5映射为真实Figma组件实例；新增或修改组件本身时改读
`component-maintenance.md`。

前置：已有通过自查的 H5；已读 `references/v9-figma-map.md`。
核心原则：**必须优先使用组件库实例，禁止手动拼装已有库组件。**
当前页面的完整组件映射表只在本分支生成；仅交付 H5 时不提前制作。

## 写入步骤概览

1. 解析 H5：识别正式 `<v9-*>` 组件、非正式身份元素和页面本地组合。
2. 生成当前页面组件映射表：逐模块记录 H5 标签、`V9_COMPONENTS.kind`、Figma组件、Component / Set Key、
   变体属性与未映射项处理方式；只有 `component` 且 `v9-figma-map.md` 映射有效时才进入组件导入清单，
   `pending/primitive/internal/h5-only` 不计为正式组件。
3. 正式组件导入实例（`importComponentByKeyAsync` / `importComponentSetByKeyAsync`），禁止手动重画；
   页面本地组合按 Step 7 使用实例、Token 与 Auto Layout 搭建。
4. 设属性：先改 VARIANT/BOOLEAN，再 replaceFonts，再改 characters（顺序不可乱）。
5. 套页面规范（margin/卡片/间距/surface；文字按实际行数使用“单行=字号、多行=字号×1.5”，数据组合见 components.md）。
6. 自查：所有文字节点 `Math.round(node.x)===0`；无占位文残留；App bar 顶部系统状态区未重复，底部 Home Indicator 主题正确。

## 标准流程

### Step 1：检查目标文件
```js
const pages = figma.root.children.map(p => `${p.name} id=${p.id}`);
return pages;
```

### Step 2：搜索并导入组件库（强制，不可跳过）
先查 `components.md` 的 Component Key 索引，缺失再用 `search_design_system`：
```
search_design_system(query: "组件名", fileKey: "目标文件Key",
  includeLibraryKeys: ["lk-2da8834b5155e15c43aaff36eb3d6dfd723be0037508c3655ce7ee6ff6915f7514fbedede0db3112d0b39eec678b7cb800311cfbc5084939677f5fa9b42fff39"])
```
**一次性导入所有需要的组件，不要边写边导入。** 遇到 Action Button Group 这类组合组件，
优先导入组合组件本身；不得只导入其内部 Button Full-width 后手动重建排列。

### Step 3：导入组件
```js
const compSet = await figma.importComponentSetByKeyAsync("component_key");
const variant = compSet.children.find(c => c.name.includes("Flat"));
const instance = variant.createInstance();
```

### Step 4：创建页面框架
```js
const phone = figma.createFrame();
phone.resize(375, 812);
phone.fills = [{ type:'SOLID', color:{ r:240/255, g:241/255, b:245/255 } }]; // #F0F1F5
phone.layoutMode = 'VERTICAL'; phone.clipsContent = true;
```
所有 Frame 用 `createAutoFrame()` 封装创建，禁止裸 `figma.createFrame()`：
```js
function createAutoFrame(name, layoutMode='VERTICAL'){
  const f = figma.createFrame(); f.name=name; f.layoutMode=layoutMode;
  f.primaryAxisSizingMode='AUTO'; f.counterAxisSizingMode='FIXED'; f.fills=[]; return f;
}
```

### Step 5：放置库组件实例（App bars 内已含顶部系统状态区）

不要在 App bar 之外再拼一个44px顶部状态栏。Figma `Status Bar`（Node `1:1545`）是
375×34px的底部 Home Indicator，可按页面底部结构独立放置，不属于上述重复项。

操作区存在一至两个主次按钮组合时，使用 Action Button Group Set Key
`af44df67d9d41c12a1b3a2a875305fa4fc58711b`，设置 `layout` 后再修改内部按钮文案；
禁止 detach。其直接依赖的 Button Full-width 当前 Set Key 为
`c5d57a72c624a7978ef5fdec6e2010171ebbb0ae`，属性为 `variant/state`。不要从 `layout`
推断子按钮 `state`：Primary / Secondary 单按钮布局继承对应角色的有效状态；Inline / Stacked
固定保留 Primary + Subtle，两个子按钮可分别设置状态，也可同时为 `Default`。

底部模态弹窗的可见内容使用已发布 Dialog Component Key `60b7ce0dfb77bae12d0fcc9afd9845dc982328ef`；
不要手动拼内容面板、Agreement 和按钮组。`Head Media#53:2`、`Content image#53:4` 只控制槽位显隐：
有真实媒体时打开 Boolean 并覆盖实例内对应图片填充/内容；无内容时保持关闭。替换不得 detach、
删除槽位或改变 Header Media 100×100、Content Image 335×150 的结构规格。
遮罩、底部定位、焦点管理和背景滚动锁定属于运行层，不作为新的 Figma 子组件拼进 Dialog 实例。
内部 Action Button Group 根据最终按钮文案设置 `layout`：1个按钮用 `Primary`；2个按钮都不超过4个字
用 `Inline`；任意一个超过4个字用 `Stacked`。Dialog 不使用 `Secondary`；`Close button#53:1`
只在没有“取消/暂不选择/稍后”等非决策退出路径时设为 `true`。

信息提示、加载和数量调整分别导入 info-icon、Tooltip、Loading 与 Quantity Stepper 的当前 Set Key；
不要手动重画其图形。info-icon 只设置 M/S 尺寸；Loading 三个 type 均保留内部 `加载/加载` 组件实例；Quantity Stepper 的 default 才写入
`value#149:4`，max/min 使用源组件固定99/1；Tooltip 只写 `Text#295:0` 并设置 `arrow`。

数据组件的执行顺序：

1. 按 `v9-figma-map.md` 导入正式组件；跨文件导入前检查发布状态。导入失败时停止并推动发布或启用组件库，不得改用手工 Frame。
2. 创建 Metric Group 后先设置顶层 Container 与 Count，再遍历嵌套 Metric Item，按
   `components.md` 统一设置 Size、Trend、ValueType 和内容；不得从 Count 推断字号。
3. 创建 Scrollable Metrics 后设置 Container，并通过嵌套 Metric Item 修改业务内容和趋势；
   18px紧凑数字样式由组件主件提供，调用层不得用通用 Size 覆盖。
4. 设置 Up/Down 后先检查 Trend 可见值；包含中文时停止写入并要求提供非中文值，不得自动删除或
   翻译。校验通过后定位暴露的嵌套 `_Metric/Trend`，按 `v9-figma-map.md` 写入可见趋势属性。
5. 所有顶层变体与嵌套内容写入完成后，回读组件属性和可见文本；只以写入请求成功为依据不算完成。

### Step 6：定制实例内容
```js
const titleNode = instance.findOne(n => n.type==='TEXT' && n.name==='header');
try { await figma.loadFontAsync(titleNode.fontName); }
catch(e){ await figma.loadFontAsync({family:"Noto Sans SC",style:"Bold"});
          titleNode.fontName={family:"Noto Sans SC",style:"Bold"}; }
titleNode.characters = "新标题";
```

### Step 7：页面本地组合（最后手段）

只有在库中不存在对应组件，且已有组件的变体、属性、Slot、嵌套均不能满足时，才能手动组合：

1. Frame 只承担页面业务组合，不复制正式组件内部图层；
2. 可复用部分继续放置真实组件实例；
3. 间距、颜色、圆角、阴影必须绑定正式 Variable；
4. 固定宽高必须来自已确认的 PRD、Figma 画板或正式组件合同；没有来源时使用 Hug、Fill 或父级约束，
   不得为视觉居中凭截图硬编码尺寸；
5. 图层/Frame 名称使用 `Local Composition / <业务名>`，不得使用正式组件名或伪造 Component Key；
6. 在交付记录中与“正式组件”分栏列出；
7. 稳定重复后按 `component-maintenance.md` 发起组件维护事务，同时补齐 Figma 主件、H5 封装与映射。

`pending` 和 `h5-only` 不能作为双端正式组件直接转换。遇到这两类身份时，保持真实状态并完成缺失的
Figma发布、H5封装或映射；不得用旧组件Key、手工Frame或普通图层转换冒充正式组件。

### Step 8：截图验证 + 数据层 x/y 自查（`Math.round(node.x)===0` 才是可靠验证）

## 字体回退策略（Figma 侧）

| 规范字体 | 回退字体 |
|---------|---------|
| PingFang SC Semibold | Noto Sans SC Bold |
| PingFang SC Regular | Noto Sans SC Regular |
| Barlow Semi Condensed | Barlow Semi Condensed（通常可用） |

先 `loadFontAsync({family:"PingFang SC"...})`，失败转 Noto Sans SC；对实例 TEXT 先设 `fontName` 再改 `characters`。

## 常见错误清单（Figma 执行专属）

| 错误做法 | 正确做法 |
|---------|---------|
| 看到 H5 自定义标签就假设 Figma 有组件 | 先查 `V9_COMPONENTS.kind` 与映射表；只有 `component` 才导入组件 |
| 把页面本地组合创建成伪组件或登记虚假 Key | 保持 Local Composition 身份；稳定重复后按 `component-maintenance.md` 走双端组件维护事务 |
| 手动用 Frame 拼装 App bars / Button / Badge / arrow / Home Indicator | 导入库组件实例 |
| App bars 之外再拼44px顶部状态区 | App bars 已内嵌顶部系统状态区；底部 Status Bar/Home Indicator 另按需放置 |
| 页面层给 App bars 补底部分割线或阴影 | 所有 Appbar 类型底部均无分割线；直接使用组件，不在页面层补线 |
| 组件 Key 失效/报错就改手动拼装 | 继续排查：Key 是否过期、属性值大小写、可选值枚举 |
| `visible=false` 认为不占布局 | AutoLayout 中仍占位，检查 `layoutPositioning` |
| 展开/收起用 `Actiontype=Link` | 必须用 `Actiontype=Expand`（ExpandStated=Expand 展开/Collapsed 收起） |
| 需图片时 CardContent 沿用默认 Editorial | 显式设 `ContentLayout=Media, Media size=Large` |
| 切换实例变体后不 `resetOverrides()` 直接填文案 | 先 `resetOverrides()` 再 `setProperties` 再填文案 |
| 假设 setProperties 写入即生效 | 回读 `instance.componentProperties['xxx'].value` 验证 |
| 把 Legacy CellCard Key 当作 Slot 版 Shell，或向其塞入新的自由组合 | 新页面导入正式 CellCard / Shell Set Key；Legacy 只维护固定 Cardheader + CardContent + Button 结构 |
| 仅凭截图判断对齐 | 数据层 `Math.round(node.x)===0` 才可靠，截图作辅助 |
| 手动拼 Selection Control / Agreement / Dialog | 导入当前组件 Key；Dialog 继续保留 Agreement、Action Button Group 与 Button Full-width 的嵌套依赖 |
| Action Button Group 双按钮都设为 Primary 或都设为 Subtle，或把 layout 当成 state | 保持 Inline/Stacked 的 Primary + Subtle 主次结构；交互状态在两个 Button Full-width 子实例上分别设置 |
| 替换 Dialog 媒体时 detach、删除槽位或把图片叠在实例外 | 打开对应 Boolean 后覆盖槽位内部图片填充/内容，保持实例与槽位尺寸 |
| Dialog 一律保留源实例的 Stacked 操作区，或为了单次操作改成 Secondary | 根据按钮数量与4字边界修改内部 Action Button Group `layout`；单按钮只能用 Primary |
| 手动拼 info-icon / Tooltip / Loading / Quantity Stepper | 导入当前 Component Set Key，设置源属性；Loading 保持 `加载/加载` 直接依赖 |
| Quantity Stepper 在 max/min 继续覆盖 `value#149:4` | 只有 default 写 value；max/min 保留固定99/1，并让禁用方向与 state 一致 |
| 数据组件跨文件导入失败后手工重画 | 保留源映射并推动组件发布或启用组件库；不得牺牲实例关系 |
| Metric Group 只设置 Count 后直接使用源默认字号 | 遍历嵌套 Metric Item，按业务统一设置 Size、Trend、ValueType 和内容 |
| 为实现 Embedded 而 detach Standalone 或手工删除背景/Padding | 直接设置数据组 `Container=Embedded`；由父级 Card 提供 Surface、圆角和外层 Padding |
| 导入 Scrollable Metrics 后用普通 Item Size 覆盖紧凑数字 | 保留主件提供的18px Number 字体，只修改 Container、内容和趋势 |
| 修改嵌套趋势后不回读可见结果 | 按 `v9-figma-map.md` 写入当前有效属性，并回读组件属性与可见文本 |
| 在 Trend 中显示“环比/同比/上升/下降”等中文，或自动删字后继续写入 | Trend 只接受非中文可见值；中文说明移到指标名称或正文，含中文时停止写入 |

## setProperties 操作规范

```js
// ❌ TEXT key 易因字体不可用报错
instance.setProperties({ 'TitleText#1137:0': '文案' });
// ✅ 找 TEXT 节点直接赋值（先 loadFont）
const t = instance.findOne(n => n.type==='TEXT' && n.name==='header');
try { await figma.loadFontAsync(t.fontName); } catch(e){}
t.fontName={family:"Noto Sans SC",style:"Bold"}; t.characters='文案';

// 切换变体前必须 resetOverrides
header.resetOverrides();
header.setProperties({ 'ShowTag':'true','Actiontype':'Expand','ExpandStated':'Expand' });

// 写入后回读验证
const v = header.componentProperties['ShowSubtitle#578:18']?.value;
if (v !== true) { /* 检查变体组合是否合法 */ }
```

## 修复后全量排查

修复任一类问题后，必须在**所有页面/画板**扫描同类问题，重点关注不同批次/单独创建的元素。
```js
for (const pgId of allPages){
  const page = figma.getNodeById(pgId);
  const container = page.findOne(n => n.name==='Content' || n.name==='ScrollArea');
  for (const card of container.children){
    const title = card.findOne(n => n.type==='TEXT' && n.name==='header');
    if (title && Math.round(title.x)!==0) problems.push(`${page.name}: 标题 x=${Math.round(title.x)}`);
  }
}
```

---
