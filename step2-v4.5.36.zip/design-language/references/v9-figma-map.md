# v9 ↔ Figma 映射清单

> **用途**：PRD→组件化 H5→Figma 流程中的核心桥接表。
> AI 读取一个 H5 组件（`<v9-*>` 标签 + 属性），按此表导入**对应 Figma 组件实例**并设置**对应变体/文本**，
> 而不是手动用 Frame 拼装。这样 Figma 端仍是真实组件实例，改源组件全局生效。
>
> **数据主来源**：组件 Key 来自 9.0 规范 `components.md`（fileKey `KKuaHEUNwnenHwumr4a3Ta`）。
> Tabs的Line与Card统一使用主规范库Node `274:2175`的发布Set；Rounded 暂不接入。
> H5 属性命名已在 `v9-components.js` 中对齐 Figma 变体，内部视觉由 `v9-core.css` 实现，
> 故下表多为「标签属性 → Figma 属性」直映。

---

## 一、映射总表

| H5 组件 | H5 属性 | → Figma 组件 | 导入 Key | Figma 变体属性 | 文本节点 key |
|---------|---------|--------------|----------|----------------|--------------|
| `<v9-option-tile>` | `content` `state` `label` `description` | Draft / Option Tile | `82721d3fe1471e5052d7346b0470293b482d7317` (set) | `Content`=Title/Description；`State`=Unselected/Selected/Warning | `Title#10:9`；`Description#10:10` |
| `<v9-warning-count>` | `label` `count` | Draft / Warning Item · Count | `3064873b46f0f7f7d36b6f7064e3722e4fb5d2f2` (component) | 无变体；静态警示 | `Title#10:14`；`Count#10:15` |
| `<v9-background-focus>` | 无；宽度随页面、高度370px | background/Focus | `f422b4ea2accd5a8c0c6e8ef715a793ef3be9c69` (component) | 无变体 | — |
| `<v9-button size="full">` | `variant` `state`；宽度Fill父级 | Button Full-width | `c5d57a72c624a7978ef5fdec6e2010171ebbb0ae` (set) | `variant`=Primary/Subtle；`state`=Default/Visited/Disabled | `text#1094:3` |
| `<v9-action-group>` | `layout`；自身Fill、无背景/内边距 | Action Button Group | `af44df67d9d41c12a1b3a2a875305fa4fc58711b` (set) | `layout`=Primary/Stacked/Inline/Secondary | 内部 Button Full-width `text#1094:3` |
| `<v9-button size="large|medium|small">` | `variant`=primary/subtle/weak、`state`、`size` | Button | `224026a8170761826d4fa9f6b9471e931a58a35d` (set) | `mode`=Primary/Subtle/Weak；`statue`=Default/Vistited/Disabled；`size`=Large/Medium/Small | `Button Text#1115:178` |
| `<v9-tag>` | `variant` `status` `size` | tag | `c98fb3fcc4effbb025029bd2b6c047ff6bb8df25` (set) | `Variant`=outline/light/solid；`Status`=Default/success/error/tertiary；`size`=Default/S | （characters 直填） |
| `<v9-alert>` | `variant` `mode` `action` `size` `position` `show-icon/button` | Alert | `e6ca9c4ca52c7057d33ed4fb958331f12f4863b2` (set) | `variant`、`mode`、`action`、`size`、`position`；BOOLEAN显隐 | （characters 直填） |
| `<v9-card>` | `slot=header/content/footer` | CellCard / Shell | `98c23ccd985a334de8197701fa1d02ead7c910e0` (set) | `Header`/`Content`/`Footer`=true/false；对应 Instance Swap Slot | 见下「CellCard Slot 映射」 |
| `<v9-task-sheet>` | `content-boundary="auto|single|multiline"` `show-action`；`header/content/action` Slot | Task Sheet / Shell | `3e5a87efceded0f91bcb4fa4472ff1799aebd8c2` (set) | `Content Boundary`=Single/Multiline；`Show Action#61:0`；三个 Instance Swap | Slot内组件负责自身文本 |
| Legacy 页面现有 CellCard 结构 | `title` `subtitle` `action` | CellCard（Legacy） | `c126d13cbbf9959f76f29ebd2494aa32da4fcdfd` (set) | 固定内部 Cardheader/CardContent/Button | 仅兼容既有页面，不新增 H5 class |
| `<v9-appbar>` | `type` `title` `show-back`；Icon默认显示黑色返回 | App bars | `9e8e0bc5b08337e2e67bb26d1f26d97419349c11` (set) | `类型`=Flat/Text/None/Icon/Flat white/Text white/None white/None black | `Tittle Text#1115:197` |
| `<v9-home-indicator>` | `theme` | Status Bar | `5ae52e4d10b33a143c0442c40b046dd4142f6f9c` (set) | `theme`=light/dark | — |
| `<v9-cardheader>` | `action-type` `expand-state` `subtitle` `show-tag`；Link直接依赖TextLink M/Secondary | Cardheader | `fea3a0eced02f3bbf3bc9475e82141c3f814ce99` (set) | `Actiontype`/`ExpandStated`/`Show Tag`；`subtitle`存在性→`ShowSubtitle#578:18` | `header Text#1114:0`；`SubtitleText#1114:155` |
| `<v9-cardcontent>` | `layout` `surface` `media-size` `action` `description-tone`；标题/描述/悬浮按钮显隐；`media-overlay` Slot | CardContent | `de76d55616005615dfed5df6425a12d6c53b4125` (set) | `surface`；`ContentLayout`；`Media size`；`Action`；对应BOOLEAN属性 | `TitleText#1137:0`；`DescriptionText #1114:132`；List可见文字 |
| `<v9-entry-item>` | `orientation` `surface` `icon-size` `interaction` `show-description`；标题、说明、Icon Slot | Entry Item | `b3a6aadac84920a3275e0abe8c484f25febab0c9` (set) | `Orientation`；`Surface`；`Icon Size`；`Interaction`；`Description` | `Title#27:0`；`Description Text#27:12`；`Icon#27:36` |
| `<v9-entry-group>` | `layout` `count` `item-surface` `icon-size` + 嵌套Entry Item | Entry Group | `92e4ea0fe8817c2103b977f0e8833f14ac18cd0e` (set) | `Layout`；`Count`；`Item Surface`；`Icon Size` | 写入内部 `_Entry/Item N` |
| `<v9-accent-card mode="single">` | `title` `description` `expiry` `show-description/expiry/decoration`；主信息Slot | Accent Card / Single | `7164d71177a5006524fbeff88a0cb17f8b58e614` (component) | 无变体；三个BOOLEAN与 `Main information` Slot | `Title#19:0`；`Expiry#19:2`；说明写入Slot内容 |
| `<v9-accent-card mode="split">` | 橙色语境与白色详情Slot | Accent Card / Split | `e8c552655e0ae8ffa1f446550d9a6934fb66d635` (component) | 无变体 | `Orange context#22:3`；`White content#19:3` Slot |
| `<v9-accent-card mode="grouped">` | `direction` `header-spacing`；Header与同级子项Slot | Accent Card / Grouped | `728fffcdfc89a48f1d7cd8830c0aff105630889f` (set) | `Direction`；`HeaderSpacing` | `Header#21:8`；`Peer items#21:9` Slot |
| `<v9-pill-option>` | `selected` `context` `show-icon` `label`；Icon Slot | Pill Option | `73ea26bf053cde1706bb4bf3fbc6b932c3704300` (set) | `State`；`Context`；`Icon` | `Label#61:1`；业务Icon写入Icon实例入口 |
| `<v9-pill-option-group interaction="select">` | `selection=required/optional` `active` + 嵌套Option | Pill Option Group / Select | `a089cc889c9548ca8c0e83316abb41a90a952b7e` (set) | `Selection=Required/Optional` | 写入Options Slot；Active落实到内部Option State |
| `<v9-pill-option-group interaction="action">` | 嵌套Option；无持续Active | Pill Option Group / Action | `0e779e851ee3c531adb1775457c4a031e3bc5042` | 无变体 | 写入 `Options#62:2` Slot |
| `<v9-form-item interaction="input|select">` | `content` `state` `label` `placeholder` `value` `show-info` `error-message` | Form Item / Textual | `330f6f5aad5bd6c37aa868638e36f26c5a30229a` (set) | `Interaction`；`Content`；`State` | Textual公开TEXT/BOOLEAN属性，见下详表 |
| `<v9-form-item interaction="radio|checkbox">` | `checked` `state` `label` `show-info` `error-message` | Form Item / Control | `b209337c26cc7df60b10d56df59381ab693fd5e4` (set) | `Control`；`Checked`；`State` | Control公开TEXT/BOOLEAN属性，见下详表 |
| `<v9-form-item-group>` | 嵌套任意数量 `<v9-form-item>` | Form Item Group | `23d8858fea9d0034c1671b66ecf52671f595258f` | 无变体 | 保留子Item真实实例；0间距、无外层Padding |
| `<v9-form-card>` | `header` + Cardheader公开属性；嵌套Group | CellCard / Form Mode | `0b91e870ccc0502bb91ae7f95b1bf6c71d389ecc` (set) | `Header=True/False` | Header写入Cardheader；Group写入表单内容区 |
| `<v9-address-group>` | `size` `start-text` `end-text` | Address Group | `146e09239141aba3be4a34a393db834e0e67653a` (set) | `Size`=Default/Large | `StartText#2144:0`；`EndText#2144:3` |
| `<v9-status-overlay>` | `state` `text` | StatusOverlay | `782146985226886d1e121f8d6095e8713c821bc5` (set) | `State`=Success/failed/None | — |
| `<v9-empty>` | `text` | empty | `cf091b39ec48ac5e170b726d6c0f1670b9621dab` (component) | 无变体；父容器负责居中 | `Text#67:15` |
| `<v9-textlink>` | `importance` `size` | TextLink | `9b5dff35ea49a2a3fe1ee92f717df9b9e6ed2263` (set) | `Importance`=Important/Secondary/Theme/Error；`Size`=L/M/S；内部 Arrow 始终 `size=L` | `TextLinkText#1114:69` |
| `<v9-expandlink>` | `importance` `size` `state` | ExpandLink | `1bceaf94e775b40b0136862d9524acb5a011ed41` (set) | `Importance`；`Size`=L/M/S；`State`=Expand/Collapse | `Expand Text#1114:82` / `Collapse Text#1114:107` |
| `<v9-arrow>` | `color` `size` `icon` | arrow | `039a24a1cd5b5668c8fbb594cd3215fd900cd167` (set) | `arrow icon`=grey/white/orange/red；`size`=L/M/S；`icon`=arrow/down/up/close button | — |
| `<v9-badge>` | `type` `label` | Badge | `0212f7d9033e2c87eae8adee18c0dac1cb1e44a2` (set) | `type`=count/overflow/dot/label-new | count：`Text#192:12`；其余固定内容 |
| `<v9-selection-control>` | `type` `checked` `disabled` | Selection Control | `f2b2b67087429cf42a14334ffcfcea6b420a82cc` (set) | `type`=checkbox/radio；`state`=unchecked/checked/unchecked disable/checked disable | — |
| `<v9-agreement>` | `state` `text` | Agreement | `078cc511ceec8f47b82e413d1c57513f0f5603e9` (set) | `state`=detail/checked/unchecked | `Text#1980:0`（仅checked/unchecked） |
| `<v9-dialog>` | `open` `title` `body` `show-close/body/agreement` `agreement-*`；媒体/协议/操作 Slot | Dialog | `60b7ce0dfb77bae12d0fcc9afd9845dc982328ef` (component) | 见下「Dialog 属性、操作区与槽位映射」 | `Tittle Text#53:5`；`Content Text2#53:6` |
| `<v9-info-icon>` | `size` | info-icon | `8d2dd490e80649720116077901d32424b01aa2d3` (set) | `size`=M/S | — |
| `<v9-tooltip>` | `arrow` `text` | Tooltip | `a84674c3788dbf7127dad3d0188c7b06ac53e532` (set) | `arrow`=top-right/top-left/bottom-right/bottom-left | `Text#295:0` |
| `<v9-toast-icon>` | `type` | Toast.Icon | `ee5ed6f07d3efde40ab7fd90620400aeb03f4413` (set) | `type`=warning/success/loading/error | — |
| `<v9-toast>` | `text` `icon-type` | Toast / Container | `aca48e84f8f65fdf013efd4074e95be185c5b5e1` (component) | `icon-type=none`→`icon#67:13=false`；其他值→`true`并设置内部 `Toast.Icon.type` | `Text#67:14` |
| `<v9-loading>` | `type` | Loading | `64b3b6a365d2f40f48ba3d4af93ae7f712dd9c14` (set) | `type`=normal/pull-up/pull-down；图标固定存在 | 固定状态文案 |
| `<v9-quantity-stepper>` | `value` `min` `max` | Quantity Stepper | `113641d4e06fbbd3e6adb4018b07a73830189ea2` (set) | 运行时根据值映射 `state`=default/max/min | `value#149:4`（仅default） |
| `<v9-metric-item trend="up|down">` 内部趋势 | `trend-value` | `_Metric/Trend` | `eaf83aa21f6ea003b10f9230832e3477758184cb` (set) | `Direction`=Up/Down | `Value#103:0` |
| `<v9-metric-item>` | `size` `trend` `value-type` + 内容 | Metric Item | `325f62a22400f8b48bc4152ab0a9630d1a13050b` (set) | `Size`=XL/L/M/S；`Trend`=None/Up/Down；`ValueType`=Number/English | 见下「Metric Item 属性映射」 |
| `<v9-metric-group>` | `container` `count` `size` + 嵌套 Item | Metric Group | `dfce934231c846e5b5a0a4b4d1a8f8e1c03a82fb` (set) | `Container`=Standalone/Embedded；`Count`=1/2/3/4 | 内容写入嵌套 Metric Item |
| `<v9-metric-scroll>` | `container` + 嵌套 Item 列表 | Scrollable Metrics | `3a60277975447586bdcb6dc06178968c7c675404` (set) | `Container`=Standalone/Embedded | 内容写入嵌套 Metric Item；数字样式由主件固定为18px |
| `<v9-tabs variant="line">` | `items` `active` `distribution` `show-background` | Tabs | `a681c138c3d45ba5171ab72ca575931f4aefa65d` (set) | `variant`=line；`amount`=items数量；`Active`=active；`Distribution`=Equal/Start；`Show Background#110:0` | `Label 1#119:0`、`Label 2#119:1`、`Label 3#119:2`；第4项定向覆盖可见文字层 |
| `<v9-tabs variant="card">` | `items` `active` + `panel-1/2/3` Slot | Tabs | `a681c138c3d45ba5171ab72ca575931f4aefa65d` (set) | `variant`=card；`amount`=2/3；`Active`=1..amount | 三个Label属性；当前面板→`Content Area / Adaptive#125:0` |

> 数据组件 Key 来自 `9.0规范 一致性测试`；本表只记录当前有效映射。跨文件导入、失败处理和
> 实例写入顺序统一按 `figma-workflow.md` 执行。

### Page Background 映射

- `Default`与`Immersive`是页面Frame的固定背景样式，不是正式组件，不建立Component Key映射。
- `Focus`必须导入主规范库 `background/Focus` 真实组件实例，Node `175:3045`，Component Key
  `f422b4ea2accd5a8c0c6e8ef715a793ef3be9c69`；不得用普通Frame、手写渐变或拆散Atmosphere图层替代。
- Focus实例宽度跟随页面Frame，组件高度保持370px并裁切；页面内容图层位于其上方。
- H5 `.v9-page--background-focus` 与 `.v9-background-content` 只负责页面叠放关系；真正映射对象是
  `<v9-background-focus>`。`.v9-page--background-immersive` 映射为页面Frame上的固定180°渐变。
- 一个页面只允许一种Background模式；Default、Focus、Immersive不得在同一页面叠加。

### Tabs Line 几何与字体映射

- Line使用375×42px容器。Equal为上12px/下2px/左右8px，选项等宽；Start为上12px/下2px/
  左右12px，选项按内容Hug并保持24px视觉间距。
- `distribution="equal|start"`映射`Distribution=Equal/Start`；默认Equal。H5分别使用
  `.v9-tabs--distribution-equal`与`.v9-tabs--distribution-start`。
- `show-background="true|false"`映射`Show Background#110:0`；默认true。H5分别使用
  `.v9-tabs--background-visible`与`.v9-tabs--background-transparent`。该BOOLEAN只对Line生效，
  Card调用时忽略。
- Tab文字固定16px字号、16px行高；选中态 Semibold，未选中态 Regular。文字层固定16px高，H5 Shadow DOM不得以 `font` 简写覆盖字族。
- Item内部使用16px文字层 + 8px间隔 + 4px独立Indicator层；选中线固定32×4px、圆角2px，并保留下方2px容器Padding。不得用绝对定位把Indicator叠入文字层或用负向bottom贴到容器边缘。
- Rounded仍按本次范围暂不接入；`items`数量继续映射Line的 `amount=2/3/4`。

### Tabs Card 正式映射

- Figma主源：`KKuaHEUNwnenHwumr4a3Ta` / Node `274:2175` / Set Key
  `a681c138c3d45ba5171ab72ca575931f4aefa65d`；2026-10-13已回读为CURRENT。
- 只消费 `variant=card` 的5个组合：`amount=3, active=1/2/3` 与
  `amount=2, active=1/2`。Distribution与Show Background只服务Line，Card忽略，Rounded 暂不接入。
- `items`按顺序写入三个Label属性；标签等宽，Noto Sans SC Medium 16/16，
  单行、超出省略。参考文件 `jyRbxjgs3FqNBi9Bhftsh7` Node `31:5168` 仅作为三段超长文案极限用例，
  不新增Figma变体。
- H5 `panel-1` / `panel-2` / `panel-3`分别保存各Tab内容；映射Figma时只把当前 `active` 对应面板写入
  `children` / `Content Area / Adaptive` Slot。四周Padding 16px；不同Tab内容高度不同时，同一使用组
  按最高内容统一高度。H5由Runtime测量全部面板并自动保持最高高度。
- Card固定宽351px、Header 43px、圆角16px；内容区高度随Slot内容自适应。曲面固定资产来自
  `assets/components/tabs/inactive-wing.svg` 与 `inactive-wide.svg`，不得用CSS临摹替代。
- 全部Card Active状态统一使用Level 1阴影。当前Figma源仅 `amount=3, active=1` 保留该Effect，
  其余4个变体在源组件修正发布前，映射实例必须补齐同值Effect
  `0 4px 12px rgba(15,40,77,0.06)`；不得让切换Active改变卡片层级。
- H5实现点击、左右方向键、Home/End、`aria-selected`、tabpanel显隐与
  `v9-change.detail.active`；页面不得复制Shadow DOM内部结构。

### Tag 宿主与视觉节点映射

Figma 的 Tag 实例边界对应 H5 Shadow DOM 内 `.v9-tag` 的可见边界。H5 公开宿主 `<v9-tag>` 继续负责
属性和组件身份，但必须使用 `display:inline-flex; line-height:0; vertical-align:middle` 贴合内部视觉节点；
测量、对齐和点击区域不得采用继承父级行高后产生的额外宿主行盒。
Tag 文案固定12px / 12px；Default四周Padding 4px，S四周Padding 2px。CardHeader 内标题与Tag使用
8px局部间距，其他通用“文字 + Tag”组合仍按4px规则处理。

### H5 组件身份审计

正式组件采用“三项齐全”标准：Figma 已发布组件 + H5 封装组件 + 本文件显式映射。
当前 `V9_COMPONENTS` 共登记45个可运行自定义元素。以下身份按本次维护后的实际发布状态记录：

| 身份 | 数量 | 元素 | 使用限制 |
|---|---:|---|---|
| `component` | 41 | 已满足 Figma发布 + H5封装 + 显式映射的公开组件，含 `<v9-option-tile>`、`<v9-warning-count>` | 可计为双端正式组件 |
| `primitive` | 2 | `<v9-number>`、`<v9-option-group>` | 数字原语／Option Tile布局组合，不建立独立 Figma Component Key |
| `internal` | 2 | `<v9-back>`、`<v9-list-row>` | 内部/组合辅助结构，不独立计数 |

`<v9-back>` 对应的 Figma Node 当前为 Group，并由 Appbar 内部维护；不能因为 H5 有封装标签就
虚构独立 Figma 组件。`<v9-toast-icon>` 与 `<v9-toast>` 已补齐 Figma 发布组件、H5 封装和本文件映射，
从旧 `h5-only` 状态升级为正式组件。

`<v9-pill-option>`、`<v9-pill-option-group>`、`<v9-entry-item>`、`<v9-entry-group>`、`<v9-address-group>`、`<v9-empty>` 与
`<v9-dialog>` 均已回读发布Key，三项门槛齐全，登记为正式组件。

`<v9-form-item>`、`<v9-form-item-group>` 与 `<v9-form-card>` 已补齐正式H5 Runtime和显式映射；其中
一个 `<v9-form-item>` 按 `interaction` 分流到两个Figma Set，不把Textual与Control虚报为两个H5标签。

Tabs已统一为一个Figma发布Set并复用既有 `<v9-tabs>` 标签，因此身份数量保持不变。Line与Card均具备
正式H5 Runtime、交互与显式映射。

`.v9-stack--group`、`.v9-stack--module`、`.v9-stack--section` 是4/8/16px通用布局辅助 class，
不对应 Figma 组件或 Component Key。Figma 自由组合使用 Auto Layout 与现有 Space Variable 实现。

### TextLink H5 对齐映射

TextLink 的 L / M / S 只切换文字字号，嵌套 Arrow 始终设置 `size=L`。Figma 可见内容保持18px高；
H5 `.v9-textlink` 同样使用18px行盒且无额外上下Padding，文字行高分别为16/14/12px；宿主与
嵌套Arrow均使用 `inline-flex` 垂直居中，不再做22px调用层补偿。

ExpandLink 使用相同的18px可见行盒与固定 Arrow L；L/M/S只切换16/14/12px文字字号，
`state=expand|collapse` 只切换文案与down/up方向。H5必须为文案建立明确行盒，并让宿主、文字与Arrow
使用中心对齐，不得按文字尺寸把Arrow降为M或S。

### Button Full-width 容器宽度映射

`<v9-button size="full">` 的运行时宿主与内部按钮均使用 `width:100%`。映射到不同容器时保持同一 Button Full-width
组件身份并使用父级可用宽度：

| 上下文 | H5 结果 | Figma 结果 |
|--------|---------|------------|
| Action Button Group Primary / Stacked | 由父容器提供 | 组内 Button Fill 父级可用宽度 |
| CellCard Footer | 319px | Button实例在319px Footer Slot内使用Fill |

CellCard本身仍固定351px，左右Padding仍各16px。Header/Content到Footer的16px由Shell Region间距提供；
不得把源参考宽度写回按钮宿主，也不得在按钮上附加 `margin-top:16px`。

### Button Weak 正式映射

- Figma `Button` Set 已发布 `mode=Weak`，并与既有 `statue`、`size` 组成9个合法组合。
- Weak的Figma视觉绑定：背景=`surface default`；Default文字=`on-surface default primary`；
  Vistited文字=`on-surface default secondary`；Disabled文字=`text disabled`；全部无描边。
- Weak Large使用16px / 16px、Medium与Small使用14px / 14px；三种尺寸均为 PingFang SC Regular / 400。
- 映射前必须检查实例的直接视觉承载面：白色背景不得使用Weak。该限制由页面组合层判断，不通过修改
  Figma变体样式、临时添加描边或阴影规避。
- H5正式使用 `<v9-button variant="weak" size="large|medium|small" state="default|visited|disabled">`；
  运行时、CSS与验证脚本均已接入。
- `size=full` 对应独立的 `Button Full-width` Set，仅允许 `variant=primary|subtle`；不得把Weak映射到该Set。

### Cardheader Link 依赖映射

`<v9-cardheader action-type="link">` 内部必须实例化 `<v9-textlink importance="secondary" size="m"
icon="arrow">`。映射到Figma时选择Cardheader的Link变体，并核对其可见操作区等价于TextLink M /
Secondary：文字14px、18px行盒、内部Arrow固定L/18px。不得在H5或Figma实例中改回独立文字+
S Arrow的旧拼装方式。

Cardheader 的 Expand 变体同样使用 Arrow L / 18px；`expand-state=expand|collapsed` 只切换 down/up 与
“展开/收起”文案，不改变箭头尺寸。H5 Expand操作区固定为18px行盒，按钮继承中文字体，14px / 14px
文字与18×18px、`line-height:0` 的Arrow宿主在该行盒内垂直居中；不得依赖button默认Arial或基线对齐。

H5 Cardheader 根据 `data-show-subtitle` 切换根容器对齐：`false` 使用 `align-items:center`，使标题、
Default Tag与Link/Expand可见盒中心一致；`true` 使用 `align-items:flex-start`，使操作区顶边与标题行顶边
一致。不得对子组件分别追加位移补偿。

### CardContent Media 与 StatusOverlay 映射

`<v9-cardcontent layout="media" media-size="large|medium">` 分别映射
`ContentLayout=Media` 与 `Media size=Large|Medium`。当H5存在
`<v9-status-overlay slot="media-overlay">` 时，定位CardContent内置StatusOverlay并写入`State`；
H5省略该Slot时映射`State=None`。未传 `media-src` 时保留源组件灰色媒体占位，不写入图片填充；
只有H5显式提供业务图片时才替换媒体内容。占位框、图片、圆角和蒙层均属于CardContent结构，
不得以页面私有图片框替代。

StatusOverlay Node `1026:3723` 的 Success / failed 图标分别固化为
`assets/components/status-overlay/success.svg` 与 `failed.svg`。H5运行时必须通过资产路径加载，不得使用
内联SVG路径重画。进入 `Media size=Large` 时，85px媒体宽度与35px Overlay高度共同形成85×35px结果，
蒙层左右、底部均贴合媒体框；映射不新增尺寸变体。

CardContent 只映射源组件集当前存在的10个变体：Pure/Subtle Editorial None、Pure/Subtle Editorial
Floating、Pure/Subtle List None、Pure/Subtle Media Medium None、Pure/Subtle Media Large None。
`action=floating` 映射 `Action=Floating`，内部直接使用 Button Medium；`show-title`、
`show-description`、`show-floating-button` 只映射现有BOOLEAN属性，不创建新的变体组合。
List 与 Media 的 H5 调用即使误传 `action=floating`，运行时也必须归一化为 `Action=None`。

CardContent 的组件内间距保持以下映射：标题↔描述由语义色控制，Default固定10px、Error固定8px，
适用于Editorial、Floating与Media文字区；Floating文案区↔按钮4px；List行↔行16px；Media图片↔文字区12px。`subtle +
Editorial + None` 四周Padding固定12px。标题、描述和列表文字单行14/14，实际折为多行时由H5
运行时切换为14/21。

### Task Sheet / Shell 正式映射

Task Sheet主源为 `KKuaHEUNwnenHwumr4a3Ta` / Node `202:2121` / Set Key
`3e5a87efceded0f91bcb4fa4472ff1799aebd8c2`。Figma源已发布，H5四种结构状态与视觉结果已确认，
`V9_COMPONENTS.kind=component`，可作为正式双端组件使用。

| H5 | Figma |
|---|---|
| `content-boundary="single"` | `Content Boundary=Single` |
| `content-boundary="multiline"` | `Content Boundary=Multiline` |
| `content-boundary="auto"` | 先按H5终态描述实际行数解析为Single/Multiline，再选择对应Figma变体 |
| `show-action="true|false"` | `Show Action#61:0=True/False` |
| `slot="header"` | `Header Slot#61:3` |
| `slot="content"` | `Content Slot#61:6` |
| `slot="action"` | `Action Slot#61:9` |

`auto`不得按字符串长度、业务文案类型或设计稿预估换行；必须在335px内容宽、最终字体和文案落定后，
测量Description实际渲染行数。描述为一行时使用Single；实际超过一行时使用Multiline。

Shell固定宽375px、顶部圆角30px、Level 4阴影与白色Surface；主内容左右Padding 20px、顶部Padding
20px，Header→Content固定16px。Single状态的Main→Action为20px，Multiline为16px；Show Action关闭
时Action Region连同其间距一起移除。Home Indicator使用Light变体并归Shell所有。

Task Sheet继续嵌套真实Cardheader与CardContent，不复制内部DOM。其上下文覆盖为：Cardheader标题
20/20 Semibold、`#222222`；CardContent标题16/16 Medium、`#444444`；Description单行14/14、
多行14/21、`#757575`；标题→描述Single 10px、Multiline 8px。20/16与10/8是为补偿多行行盒后
维持相邻信息组视觉等距的组件合同，不得扩展成全局“多行统一减4px”公式。

直接依赖：

- Cardheader Set Key `fea3a0eced02f3bbf3bc9475e82141c3f814ce99`；默认实例Key
  `f49d321e50352d0ee238f7bbc99f1a5c5edb423f`；
- CardContent Set Key `de76d55616005615dfed5df6425a12d6c53b4125`；默认实例Key
  `1f24807550d8fa18e82d35bf8c7e9517ca801566`；
- Action Button Group Set Key `af44df67d9d41c12a1b3a2a875305fa4fc58711b`；默认实例Key
  `b451ff16909fadaeae450b10d9a64f5b3819c59b`；
- Status Bar / Home Indicator Set Key `5ae52e4d10b33a143c0442c40b046dd4142f6f9c`；Light实例Key
  `bf4076c281a3612ab07cf2f9d2d47104fb956703`。

Figma库搜索结果中的Description仍写有旧的“Header→Content 12px”和12/24分组文案，与
`202:2121` 当前实例几何及本合同不一致。该Description属于源描述元数据漂移；正式映射以可回读实例
几何、已确认的四状态结果和本节合同为准，后续维护Figma源组件时同步修正文案。

### CardContent Description 映射

同一业务对象的多条说明继续写入一个 `DescriptionText #1114:132`，以换行保留内容顺序，不在实例外
新建原因列表或多个TEXT节点。`description-tone=default` 保持源组件描述色；`description-tone=error`
不是新变体，映射时对现有DescriptionText应用既有Error Variable / `--v9-error` 对应色并回读可见文字、
换行与颜色。只有每条内容具有独立操作、状态或图标时，才评估其他公开Slot或页面本地组合。

### Entry Item / Entry Group 映射

#### Entry Item

H5属性按下表直映；枚举值只做大小写与连字符转换：

| H5 | Figma |
|-----|-------|
| `orientation="horizontal|vertical"` | `Orientation=Horizontal|Vertical` |
| `surface="pure|subtle"` | `Surface=Pure|Subtle` |
| `icon-size="30|40|50"` | `Icon Size=30|40|50` |
| `interaction="whole-item|trailing-button"` | `Interaction=Whole Item|Trailing Button` |
| `show-description="true|false"` | `Description=True|False` |
| `title` | `Title#27:0` |
| `description` | `Description Text#27:12` |
| `slot="icon"` | `Icon#27:36` INSTANCE_SWAP |

Entry Item Set Key为 `b3a6aadac84920a3275e0abe8c484f25febab0c9`。写入前先选择精确发布变体，
再写TEXT与INSTANCE_SWAP属性；不得从默认变体切换出源组件不存在的 Vertical + Trailing Button 或
Vertical + Subtle + Icon Size 50。

Vertical在H5中必须让Icon、Title与Description共享水平中轴线。由于Whole Item根节点是`button`，
实现时需要用 `button.v9-entry-item--vertical` 和Vertical子文本规则显式覆盖通用Button左对齐；
Horizontal仍保持左对齐。

默认Icon视觉是占位色块，不是需要固化的图标资产。Pure使用正式局部填充色 `#F6F8FB`；Subtle内部
占位块使用组件私有值 `#E4E8EC`，只在 `.v9-entry-item--subtle .v9-entry-item__placeholder` 中实现，
不得登记为全局Token。H5有 `slot="icon"` 时用传入内容替换占位；Figma有真实业务Icon时设置
`Icon#27:36`。

直接依赖：

- 当前占位实例 Component Key：`ac2a9155d039d7c6e4cf126901d1cd674fd9d6f5`；
- Trailing Button 使用 Button Set Key：`dca4a53b0ef6207ca79fe5c0cd26ccb1aace01e2`，目标为Medium。

#### Entry Group

Entry Group Set Key为 `92e4ea0fe8817c2103b977f0e8833f14ac18cd0e`，直接依赖Entry Item Set Key
`b3a6aadac84920a3275e0abe8c484f25febab0c9`。先用Group顶层属性选择发布变体，再按DOM顺序定位
`_Entry/Item 1…N`，把每个H5子 `<v9-entry-item>` 的标题、说明、Icon与链接语义写入对应嵌套实例；
不得detach Group或Entry Item后用Frame重排。

| H5 | Figma |
|-----|-------|
| `layout="list"` | `Layout=List` |
| `layout="grid-2|grid-3|grid-4|grid-5"` | `Layout=Grid 2|Grid 3|Grid 4|Grid 5` |
| `count`或实际子Item数量 | `Count` |
| `item-surface="pure|subtle"` | `Item Surface=Pure|Subtle` |
| `icon-size="30|40|50"` | `Icon Size=30|40|50` |

H5运行时把List子项统一为Horizontal + Description True，把Grid子项统一为Vertical +
Description False，Interaction均为Whole Item。List Pure/Subtle的Item间距分别为0/8px；所有Grid列间距8px；
Grid 2行间距8px，Grid 3和Grid 5多行间距16px。奇数项按源组件保持最后一项左对齐。

当前发布Count为1/2/3/4/5/6/10，且只有 `components.md` 列出的30个组合可直映。H5可以按Grid 2规则
继续增加行，但实际数量未命中发布变体时必须停止Figma转换并扩展源组件；不得自动选择近似Count、
拆散实例或把普通Frame标记为正式Entry Group。

### Accent Card 映射

一个 H5 标签按 `mode` 分流到三个已发布 Figma 主件；三者不是通用 CellCard 的变体。

| H5 | Figma | 关键写入 |
|---|---|---|
| `mode="single"` | `Accent Card / Single` Component Key `7164d71177a5006524fbeff88a0cb17f8b58e614` | `title`→`Title#19:0`，`expiry`→`Expiry#19:2`；`show-description/expiry/decoration`→同名 BOOLEAN；`slot="main-information"`→`Main information#23:0`。普通 `description` 写入Slot内默认说明层，不存在独立TEXT属性。未提供说明或期限时分别关闭 Show Description、Show Expiry。 |
| `mode="split"` | `Accent Card / Split` Component Key `e8c552655e0ae8ffa1f446550d9a6934fb66d635` | `slot="orange-context"`→`Orange context#22:3`；`slot="white-content"`→`White content#19:3`。Slot内容保持真实嵌套组件或可编辑节点。 |
| `mode="grouped"` | `Accent Card / Grouped` Set Key `728fffcdfc89a48f1d7cd8830c0aff105630889f` | `direction`→`Direction=Vertical/Horizontal`；`header-spacing`→`HeaderSpacing=Comfortable/Compact`；`title`或`slot="header"`→`Header#21:8`；全部`slot="peer-item"`按顺序进入`Peer items#21:9`。 |

Grouped 的 Peer items 是容器 Slot，不存在可独立导入的固定 `Group Item`。子项若本身是正式组件，
保留其真实实例；不得从源稿的白色入口/奖励示例推断统一的子项外观，也不得 detach Grouped 后重排。
Single 的装饰圆环和分割线渐变由 H5 组件局部 CSS 绘制，不作为独立 Figma Component Key 或 SVG。

### Pill Option / Group 映射

#### Pill Option

`<v9-pill-option>` 映射到主规范库 Pill Option Set Key
`73ea26bf053cde1706bb4bf3fbc6b932c3704300`：

| H5 | Figma |
|-----|-------|
| `selected=true/false` | `State=Selected/Unselected` |
| `context=default/white` | `Context=Default/White` |
| `show-icon=true/false` | `Icon=True/False` |
| `label` | `Label#61:1` TEXT |
| `slot="icon"` | 业务Icon替换入口；当前灰色块仅为占位 |

`Context=White` 只用于纯白父背景下的未选中态，并映射0.5px Outline Default内描边。Selected的业务Icon
使用On Primary；Unselected业务Icon颜色不由组件强制覆盖。H5灰色方块是组件私有占位，不是资产、
不登记Token，也不写回Figma为新的Icon组件。

#### Select / Action / Horizontal Scroll Frame

| H5条件 | Figma资产 | Key | 写入规则 |
|--------|-----------|-----|----------|
| `interaction=select selection=required` | Pill Option Group / Select | `a089cc889c9548ca8c0e83316abb41a90a952b7e` | `Selection=Required`；至少一个内部Option为Selected，不能回到0 |
| `interaction=select selection=optional` | Pill Option Group / Select | `a089cc889c9548ca8c0e83316abb41a90a952b7e` | `Selection=Optional`；允许全部Unselected和取消回0 |
| `interaction=action` | Pill Option Group / Action | `0e779e851ee3c531adb1775457c4a031e3bc5042` | 写入 `Options#62:2` Slot；全部静态Unselected，点击语义为即时Action |
| 实际Option数量 `>4` | Pill Option / Horizontal Scroll Frame | `de1adea3af9f7f1b450370cdb6804e7ae56ecc36` | Group写入 `Scrollable Content#63:0` Slot；默认视口351px，可按页面内容宽调整 |

Group内部Option固定8px、单行且不折行；数量通过Options Slot增删实例，不再由 `amount` 变体穷举。
H5的横滑Frame属于 `<v9-pill-option-group>` 内部结构，没有第三个公开标签；Figma转换时仍必须在超过4项时
使用正式Horizontal Scroll Frame实例。

Legacy Set `Pill Option Group / Legacy Amount Presets`
（Key `668cd2db2c698d375fec32b01bb0398305ea29a6`）只用于识别旧稿。新页面不得导入、不得扩展
`amount=5/6/7`，也不得把Legacy实例计入正式映射结果。

### Option Tile / Warning Count 映射

2026-11-04源件发布状态均为`CURRENT`，测试文件`DfD1vfZ2k91kjlRqpHGqgR`跨文件导入通过。
源件名称保留普通文字前缀`Draft /`（已无隐藏前缀`_`），不影响正式发布身份；以下记录真实源名称。

| H5 | Figma源 | Key | 身份 |
|---|---|---|---|
| `<v9-option-tile>` | `Draft / Option Tile`，Node `303:2188` | `82721d3fe1471e5052d7346b0470293b482d7317` | component |
| `<v9-warning-count>` | `Draft / Warning Item · Count`，Node `303:2204` | `3064873b46f0f7f7d36b6f7064e3722e4fb5d2f2` | component |
| `<v9-option-group>` | 等宽Auto Layout组合，内部为Option Tile实例 | 无独立Key | primitive |

| H5属性 | Figma属性 | 默认／说明 |
|---|---|---|
| `content="title\|description"` | `Content=Title\|Description` | 默认title |
| `state="unselected\|selected\|warning"` | `State=Unselected\|Selected\|Warning` | 默认unselected；单一枚举，无独立selected布尔属性 |
| `label`（Option Tile） | `Title#10:9` | 默认选项标题 |
| `description` | `Description#10:10` | H5默认空；只在content=description时显示，业务需提供内容 |
| `label`（Warning Count） | `Title#10:14` | 不写死业务标签 |
| `count`（Warning Count） | `Count#10:15` | TEXT属性，不伪造业务数量 |
| `value` / `aria-label` | 不映射视觉变体 | H5业务值／可访问名称 |

```html
<!-- 正式组件；Group是布局与交互原语 -->
<v9-option-group columns="2" content="description" aria-label="选项示例">
  <v9-option-tile value="a" label="选项一" description="补充说明" state="selected"></v9-option-tile>
  <v9-option-tile value="b" label="选项二" description="补充说明"></v9-option-tile>
</v9-option-group>
<v9-warning-count label="业务警示" count="2"></v9-warning-count>
```

- Group的`content`统一下发给直接Option Tile子项；`columns`默认2。Title有效2–5，Description有效2–3。
  非整数回退2，越界钳制至合法范围（请求1→2、有副标题请求5→3）；不引入单列模式或新Figma变体。
- 每个可选项使用原生button与`aria-pressed`，Tab聚焦、空格／回车切换；Warning使用静态note，
  不创建button、tabindex或选择事件。选择切换保留焦点。
- 单项用户操作派发`v9-change.detail={value,state,selected}`；Group消费子事件后仅派发一次
  `v9-change.detail={value,state,selected,values}`，`values`为所有已选直接子项的业务值，排除Warning。
  外部通过`state`设置状态不派发用户操作事件；Group的只读`values`可查询当前选择。
- `.v9-option-tile--title/--description`映射Content，`.is-unselected/.is-selected/.is-warning`映射State。
  Title字号用`--v9-fz-body-m`；副标题用`--v9-fz-body-s`；计数用`--v9-fz-headline-s`数值配合
  `--v9-font-num`和700字重，不继承Headline中文字族。
- 复用`--v9-radius-md`、`--v9-space-md/sm/xs`、`--v9-surface-inset`、`--v9-primary`、
  `--v9-warning-bg`、`--v9-error`和文字色Token。选中背景用Primary的6%透明度，不新增全局Token。
- Description标题用运行时实际行数检测；仅此组件多行覆盖为18px，副标题固定16px行高。
  无副标题固定45px；Description内容自适应，组合只做同排等高，不绑定示例高度。
- 源描述仍残留临时字体说明，但实际源文字为PingFang SC；维护字体以真实节点值为准。

### Form Item / Group / Form Mode 映射

#### 统一 `<v9-form-item>` 分流

| H5条件 | Figma组件 | Set Key | 变体写入 |
|--------|-----------|---------|----------|
| `interaction=input|select` | Form Item / Textual | `330f6f5aad5bd6c37aa868638e36f26c5a30229a` | `Interaction=Input/Select`；`Content=Empty/Filled`；`State=Default/Error/Disabled` |
| `interaction=radio|checkbox` | Form Item / Control | `b209337c26cc7df60b10d56df59381ab693fd5e4` | `Control=Radio/Checkbox`；`Checked=False/True`；`State=Default/Error/Disabled` |

Textual文本属性：`label→Label#32:0`、`placeholder→Placeholder#32:19`、`value→Value#32:38`、
`show-info→Show info#32:57`、`error-message→Error message#32:76`；连续Error间距属性为
`Bottom Space#200:0`。Control文本属性：`label→Label#35:0`、`show-info→Show info#35:21`、
`error-message→Error message#35:42`；连续Error间距属性为 `Bottom Space#200:13`。
Control不接收 `content`、`placeholder` 或 `value`；Textual不接收 `checked`。Focus和Readonly均无合法变体，
不得近似映射。

标题与Info固定4px；标题区与右侧内容或Selection Control至少20px，不足时仅Textual内容整体换行。
Input普通Field Row高14px，Select与Control因正式Arrow/Selection Control高18px；Error条高28px并横向
STRETCH，Field Row到Error条固定12px。输入内容最多两行；Select Arrow固定L，Control固定居右。

`Bottom Space`不映射为H5公开属性。H5的 `<v9-form-item-group>` 按直属Item顺序自动识别连续Error段；
Figma转换时对段内非末项写入 `Bottom Space=False`，对最后一项或独立Error写入 `True`。默认True时
Input/Select/Control Error高度分别为86/90/90px；False时分别为70/74/74px。Default与Disabled保持默认值，
不得借该属性改写普通Item高度。

#### Group与Form Mode

| H5 | Figma | Key | 结构规则 |
|-----|-------|-----|----------|
| `<v9-form-item-group>` | Form Item Group | `23d8858fea9d0034c1671b66ecf52671f595258f` | 子Item可混合且按需增删；纵向0间距，无Surface/Radius/Shadow/Padding |
| `<v9-form-card header="true|false">` | CellCard / Form Mode | `0b91e870ccc0502bb91ae7f95b1bf6c71d389ecc` | `Header=True/False`；True时Cardheader到Group 8px，内部Cardheader副标题覆盖为Body Small 12px、主副标题间距12px；False时完全移除Header和间距 |

Form Item Group必须保留Textual/Control真实实例，Item自身承担左右16px；不得给Group重复加左右Padding。
连续Error只修改各真实Item实例的 `Bottom Space`；Group继续保持纵向HUG、0间距和无外层Padding，
不得建立Amount或Error Count变体。Form Mode只随Group实际高度HUG，不额外补偿被收拢的16px。
Form Mode只允许 `Cardheader（可选） + Form Item Group`，不得嵌套到通用CellCard / Shell，也不得把
多个Form Item手拼为普通Frame后冒充Group。当前发布节点：Textual `156:1970`、Control `156:2079`、
Group `161:2626`、Form Mode `161:2645`。

Form Mode的12px副标题和12px主副标题间距是父组合对嵌套Cardheader实例的上下文覆盖，不修改
Cardheader源组件的14px副标题与10px间距默认值，也不映射为新的Cardheader变体。写入Figma时必须
保留真实Cardheader实例，并在Form Mode内部应用这两项覆盖。

### Empty 映射

`<v9-empty text="暂无新任务">` 使用
`importComponentByKeyAsync("cf091b39ec48ac5e170b726d6c0f1670b9621dab")` 导入真实 `empty` 实例，
把 `text` 直接写入公开属性 `Text#67:15` 并回读可见文字。组件没有变体、状态或 Slot，不得把父容器的
居中方式登记为 Empty Variant，也不得在实例内部新增 Frame、背景、按钮或副标题。

Figma 中由实例的父级 Auto Layout / Grid 区域设置水平、垂直居中；H5 中由调用容器使用
`.v9-empty-container` 或等价的正式布局关系完成。组件本身保持100×126px，100×100px插图与文字之间
固定12px；H5复用 `--v9-space-md`，不得新增专属间距Token。H5把源插图的可见裁切固化为单一
`assets/components/empty/illustration.svg`，运行时不得再依赖PNG或独立mask；页面层不得替换、拆分或
复制该资产。文案继续使用源 `Body/Body Medium` Text Style 与 `Color/辅助信息` Variable。

Empty不包含Surface。业务场景要求白色卡片时，H5使用 `<v9-card>` 的Content Slot承载并居中Empty；
Figma映射为 `CellCard / Shell` 的 `Content=true`，再把Empty实例写入Content Slot。卡片白底、16px Padding、
16px圆角和阴影均由Shell提供，不得写入Empty内部；父区域已有Surface时不得重复嵌套Card。

### Address Group 映射

源记录：页面「控件」，Node `67:5956`，Component Set Key
`146e09239141aba3be4a34a393db834e0e67653a`，最后核对 2026-08-19。

| H5 | Figma |
|-----|-------|
| `size="default"` | `Size=Default` |
| `size="large"` 或省略 | `Size=Large` |
| `start-text` | `StartText#2144:0` |
| `end-text` | `EndText#2144:3` |

- 创建实例后先设置 `Size`，再写入两个TEXT属性；写入后回读公开属性和可见文字。
- 地址必须保留完整业务字符串；当前Figma源固定宽度裁切且不显示省略号，H5保留单行末尾省略。
  不得提前把业务字符串裁短或手工附加“…”作为截断实现。
- H5宿主按父容器Fill；Figma源参考宽326px。进入CellCard时跟随319px Content Slot，不改变圆点、字号和行距。
- H5 Default的6px使用 `calc(var(--v9-space-xs) + var(--v9-space-2xs))`，Large圆点↔文字使用
  `--v9-space-sm`，两行间距使用 `--v9-space-lg`；不得新增 Address 专属 Gap Token。
- 起点 `#05AC7E` 是组件局部值，终点和文字分别使用正式 `primary` / `text primary`。只有规范库未来
  增加可跨组件复用的起点语义色时，才允许迁移为正式 Token。

### 数据组件映射

源记录：文件 `9.0规范`（fileKey `KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`，
最后核对 2026-08-13。

`DataValue` 是 Metric Item 内部逻辑层，没有独立 Component Key。H5 使用 `.v9-number` 表达
前缀、整数、小数和单位；Figma 端由 Metric Item 的文字属性与 Boolean 共同控制。

#### `_Metric/Trend`

源 Node `1:2466`，Set Key `eaf83aa21f6ea003b10f9230832e3477758184cb`，直接依赖
`icon/气泡上升`（Component Key `96d7519a7ccfdd0a4669e4e833d856653ab1f5fe`）。

| H5 class / 内容 | Figma 属性 |
|---|---|
| `.v9-metric-trend--up` | `Direction=Up` |
| `.v9-metric-trend--down` | `Direction=Down` |
| `.v9-metric-trend__value` 文案 | `Value#103:0` |

`Value#103:0` 不支持中文，只可映射数字、英文与必要符号。写入前检查可见值；一旦包含中文，
停止写入并要求调用方提供非中文值，不得自动删除、翻译或把中文说明塞入其他 Trend 图层。
“环比”“同比”等中文说明应由 Trend 外部的指标名称或正文组件承载。H5 的 `trend-value`
采用同一约束：含中文时不渲染 Trend，也不保留对应尺寸的组件级趋势间距。

源组件为15px高，方向图形容器14×15，文字使用 Barlow Semi Condensed Bold 13/12。H5 将
`Value#103:0` 映射到独立 `.v9-metric-trend__value`，固定使用 `padding:1px 5px 2px 0`；
图形不接收这组 Padding。`.v9-metric-trend` 的左下角固定为 `border-bottom-left-radius:0`，
其余三个角保持 Full 圆角。Up 背景使用组件局部 `#D6FFEE`，只写入 Trend 实现，不进入 Token 或
Figma Variable；Down 保留既有 Error 浅色背景。方向图形固化为
`assets/components/metric-trend/up.svg` 与 `down.svg`；两种方向直接使用对应源资产，不再由
页面临时绘制或旋转同一图形。

#### Metric Item 属性映射

源 Node `1:2189`，Set Key `325f62a22400f8b48bc4152ab0a9630d1a13050b`，共24个变体。

| H5 | Figma 属性 / Key | 说明 |
|---|---|---|
| `.v9-metric-item--xl/l/m/s` | `Size=XL/L/M/S` | 同组统一设置；数量不决定 Size |
| 数字值 | `ValueType=Number` | 使用 Prefix / Integer / Decimal / Unit |
| 英文值 | `ValueType=English` | 使用 `English Value#61:25` |
| 无趋势 | `Trend=None` | 不渲染趋势实例 |
| 上升/下降 | `Trend=Up/Down` | 使用嵌套 `_Metric/Trend` |
| 指标名称 | `Label#61:20` | 默认“指标名称” |
| 货币前缀 | `Prefix#61:21` + `Show Prefix#61:27` | 前缀与核心整数同字号 |
| 整数 | `Integer#61:22` | 支持千分位字符 |
| 小数 | `Decimal#61:23` + `Show Decimal#61:28` | 小数按 Size 映射降级 |
| 单位 | `Unit#61:24` + `Show Unit#61:29` | 与Label同字号、与数字同色、横向间距2px；H5光学校正见下 |
| 英文值 | `English Value#61:25` | 只允许英文，不写中文状态 |

16个 Up/Down 变体中的 `_Metric/Trend` 均为暴露嵌套实例；写入时先设置 Metric Item 的
`Trend`，再定位该嵌套实例并设置 `Value#103:0`，最后回读可见值确认。名称↔DataValue在
XL/L/M/S统一为6px；完整值块↔Trend分别为9/9/8/9px。H5 Number单位与数字保持2px横向间距，
并按Size应用光学校正：XL/L向上2px，M/S向上1px；Metric Item内部必须带相同的Number Size class，
使独立Number与Metric Item结果一致。以上都是组件局部结构值，不新增全局Token。

H5 直接调用：

```html
<v9-metric-item size="l" label="营收" prefix="¥"
  integer="128" decimal=".55" unit="元"
  trend="up" trend-value="0.5">
</v9-metric-item>
```

#### Metric Group

源 Node `1:2130`，Set Key `dfce934231c846e5b5a0a4b4d1a8f8e1c03a82fb`。顶层暴露
`Container=Standalone/Embedded` 与 `Count=1/2/3/4`，共8个变体；内容、Size、Trend 和
ValueType 都保留在嵌套 Metric Item。

| H5 属性 | Figma 属性 |
|---|---|
| `<v9-metric-group container="standalone" count="1">` | `Container=Standalone, Count=1` |
| `container="embedded"` | `Container=Embedded` |
| `count="2"` | `Count=2` |
| `count="3"` | `Count=3` |
| `count="4"` | `Count=4` |

源实例中 Count1/2/3 使用L、Count4使用S只是示例默认。创建 Group 后必须遍历直接嵌套的
Metric Item，按业务规则统一设置 `Size`，再写入各项内容；不得由 Count 推断字号。

#### DataGroup Container

| Container | H5 属性 | Figma 属性 |
|---|---|---|
| `Standalone` | `container="standalone"` | `Container=Standalone` |
| `Embedded` | `container="embedded"` | `Container=Embedded` |

`Embedded` 只移交外层 Surface、圆角和 Padding，不改变内部 Grid gap、Size、Trend、ValueType 或
Pure/Subtle 规则。Figma 与 H5 必须直接映射同一 Container 值；不得 detach Standalone 后删除
背景和 Padding，也不得在父级 Card 内手工重拼 Metric Item 冒充 Embedded。

375px页面中将 Group 外层宽度设为351px，并按下式等分嵌套 Item：

```text
itemWidth = (351 - 16×2 - 16×(Count-1)) / Count
```

只改变 Group 外层和嵌套 Item 的等分宽度，不改变16px内边距、16px gap、16px圆角与白色 Surface。
源文件中的343px是16px演示页边距下的样例宽度，不覆盖当前12px页面 margin。

#### Scrollable Metrics

源 Set Node `1:2107`，Set Key `3a60277975447586bdcb6dc06178968c7c675404`，
顶层暴露 `Container=Standalone/Embedded` 共2个变体。两者内部均为5个100px Subtle tile，每个 tile 继续嵌套新版
Metric Item。

H5 使用 `<v9-metric-scroll>` 作为351px可视容器，运行时在内部提供100px滚动项。
Standalone 外层16px内边距、`scroll-padding-inline:16px`、tile间8px；tile使用12px内边距、
12px圆角和 Subtle Surface，内部指标名称与数据整体居中，高度由内容自然撑开。Embedded 追加对应
修饰类并由父级 Card 提供边缘间距。Figma 的564px表示滚动内容宽；页面调用层负责裁切和横滑。

Scrollable 主件对每个嵌套 Metric Item 的 `Prefix`、`Integer`、`Decimal` 与 `English Value`
统一覆盖为18px Barlow Semi Condensed Bold、18px行高、0字距；`Unit` 保持14px Text Bold。
H5 运行时在 Scrollable Metrics 内部把 `--v9-metric-number-size` 与
`--v9-metric-decimal-size` 映射为既有 `--v9-fz-headline-m` 的18px值，字体继续由
`.v9-number` / `.v9-metric-item__english` 映射为 `--v9-font-num`。不新增18px Number Token，
也不把该局部覆盖映射成 Metric Item 的第五个 Size。

源中的5项文案不是固定组件内容。Figma 写入时遍历 tile 内的 Metric Item 修改属性；当前主件固定
提供5个 tile，业务需要其他数量时应先扩展源组件槽位。

### Action Button Group 布局映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`
（Page `0:1`），Node `53:4557`，Component Set Key
`af44df67d9d41c12a1b3a2a875305fa4fc58711b`，最后核对 2026-08-19。
它直接依赖 Button Full-width（Node `53:2650`；Set Key
`c5d57a72c624a7978ef5fdec6e2010171ebbb0ae`）。

| H5 layout class | Figma `layout` | 内部按钮角色 | `state` 处理 |
|------------------|----------------|--------------|----------------|
| `.v9-action-group--primary` | `Primary` | 单个 Primary，填满父级可用宽度 | 继承 Primary Button Full-width 的有效状态 |
| `.v9-action-group--stacked` | `Stacked` | Primary 在上、Subtle 在下，间距10px | 两个子按钮分别继承状态，可同时为 Default |
| `.v9-action-group--inline` | `Inline` | Primary 在左、Subtle 在右，等分父级宽度 | 两个子按钮分别继承状态，可同时为 Default |
| `.v9-action-group--secondary` | `Secondary` | 单个 Subtle，162.5px右对齐 | 继承 Subtle Button Full-width 的有效状态 |

只登记 Component Set Key、`layout` 属性与 H5 class 的映射。四个布局可通过有效的 Set Key
导入后设置 `layout` 获得，因此不登记、也不直接导入单个 Variant Key。

写入时导入 Action Button Group 组件集并在顶层实例设置 `layout`；修改文案时继续设置内部
Button Full-width 的 `text#1094:3`。`layout` 不代替子按钮的 `variant/state`：Primary 与 Secondary
单按钮布局保留对应角色并继承其有效状态；Stacked 与 Inline 必须保持 Primary + Subtle，状态可分别设置，
也允许两者同时为 `Default`。禁止把双按钮设置为两个 Primary 或两个 Subtle。不要 detach，也不要改成
两个独立按钮实例手动排列。

H5 直接调用 `<v9-action-group>`，子节点调用 `<v9-button size="full">`：

```html
<v9-action-group layout="inline">
  <v9-button size="full" variant="primary">确认</v9-button>
  <v9-button size="full" variant="subtle">取消</v9-button>
</v9-action-group>
```

组件自身使用 Fill，不提供背景与内边距。只有吸底使用时由外层 `v9-footer` 提供上下20px、左右12px
Padding；普通页面流、CellCard Footer 与 Dialog 均不自动增加20px。CellCard Footer由Shell提供16px
Padding并形成319px可用宽度。H5只保留 `--v9-space-10` 对应源组件10px `itemSpacing`，不得在组件上
重复添加20px，也不新增专属Gap Variable。

---

### arrow 变体映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `53:3541`，Component Set Key `039a24a1cd5b5668c8fbb594cd3215fd900cd167`，
最后核对 2026-08-19。旧属性名 `arrowIcon` 不再使用。

| H5 修饰类 | Figma 属性 | 可选值 |
|------------|------------|--------|
| `.v9-arrow--grey/white/orange/red` | `arrow icon` | grey / white / orange / red |
| `.v9-arrow--l/m/s` | `size` | L / M / S |
| `.v9-arrow--arrow/down/up/close` | `icon` | arrow / down / up / close button |

H5 使用独立图形蒙版并通过 `currentColor` 着色，不使用键盘字符占位。Figma 写入时直接设置
包含空格的 `arrow icon` 属性；不得自动改写为 camelCase。

### Badge 变体映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `1:1536`，Component Set Key `0212f7d9033e2c87eae8adee18c0dac1cb1e44a2`，
最后核对 2026-08-19。

| H5 class | Figma `type` | 内容写入 |
|-----------|--------------|----------|
| `.v9-badge--count` | `count` | 设置 `Text#192:12`；默认“9” |
| `.v9-badge--overflow` | `overflow` | 固定“99+”，不覆盖文本 |
| `.v9-badge--label-new` | `label-new` | 固定“新”，不覆盖文本 |
| `.v9-badge--dot` | `dot` | 无文本 |

Badge 没有嵌套组件依赖。颜色、2px/4px间距和 Full 圆角复用现有变量；12px窄体斜体与
10px“新”字样是组件局部字形规格，不新建 Badge/Metric Token。

H5 的 Barlow Condensed 数字在14px高容器内存在偏上的浏览器字形差异，因此 count / overflow
将 Figma 源组件的垂直 `0/2px` 内边距等量改为 `1/1px`，使数字向下光学校正1px。外框高度、
12px行高与总垂直内边距均不变；该1px仅属于组件实现补偿，不新增全局间距 Token。

数字型`count`与`overflow`在H5中使用左2px、右4px内边距，复用既有2XS与XS Token；中文
`label-new`仍保持左右各4px。该差异是数字字形的组件级实现补偿，不回写为新的全局Token。

Figma Badge实例边界对应H5 Shadow DOM内 `.v9-badge` 的可见边界。H5公开宿主 `<v9-badge>` 使用
`display:inline-flex; line-height:0; vertical-align:top` 消除继承正文行高产生的额外行盒；测量与附着定位
必须采用14/24/18/10px实际变体边界，不得采用父级22.5px或24px文字行盒。

### info-icon 变体映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `1:2015`，Component Set Key `8d2dd490e80649720116077901d32424b01aa2d3`，
最后核对 2026-08-19。

| H5 属性 | Figma 属性 |
|-----------|------------|
| `<v9-info-icon size="m">` | `size=M` |
| `<v9-info-icon size="s">` | `size=S` |

Figma 当前源的 `status` 只有固定单值 `disabled`，它是遗留属性名，不构成 Disabled 状态，也不向
H5 暴露。H5 统一使用 `assets/components/info-icon/default.svg`；S 变体将14px源图形等比缩放为12px，
保持 Figma 的线宽比例。不得使用字符“i”或临时圆形替代。

### Tooltip 变体映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `1:2072`，Component Set Key `a84674c3788dbf7127dad3d0188c7b06ac53e532`，
最后核对 2026-08-13。

| H5 属性 | Figma `arrow` | 箭头位置 |
|-----------|---------------|----------|
| `arrow="top-right"` | `top-right` | 气泡上方、距右20px |
| `arrow="top-left"` | `top-left` | 气泡上方、距左20px |
| `arrow="bottom-right"` | `bottom-right` | 气泡下方、距右20px |
| `arrow="bottom-left"` | `bottom-left` | 气泡下方、距左20px |

提示文案写入 `Text#295:0`。H5 的 `.v9-tooltip__arrow` 保持15×8外层区域，内部使用 Figma
7.07577px源矢量蒙版：`bottom-*` 固定贴区域顶部，`top-*` 垂直翻转后贴区域底部，使可见图形始终
贴向气泡一侧，透明余量只留在组件外缘。浏览器中 SVG mask 与气泡是独立合成层，方向贴边后仍需
向气泡侧重叠1px，消除抗锯齿产生的设备像素白缝；15×8布局占位不变，该1px为组件局部光学校正，
不新增间距 Token。背景和箭头均复用 `--v9-text-primary`；气泡最大宽度288px，显隐与定位由调用层处理。

```html
<v9-tooltip id="help-tip" arrow="top-right" text="在这里修改文案"></v9-tooltip>
```

### Toast.Icon 与 Toast 映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
最后核对 2026-08-13。

#### Toast.Icon

Node `53:4338`，Component Set Key `ee5ed6f07d3efde40ab7fd90620400aeb03f4413`。

| H5 属性 | Figma `type` | 资产 |
|---|---|---|
| `type="warning"` | `warning` | `assets/components/toast/warning.svg` |
| `type="success"` | `success` | `assets/components/toast/success.svg` |
| `type="error"` | `error` | `assets/components/toast/error.svg` |
| `type="loading"` | `loading` | `assets/components/toast/loading.png` |

warning/success/error 使用源SVG。Figma生成的 loading SVG 含 `foreignObject + conic-gradient`，
部分浏览器不绘制可见圆环，因此H5固化同一变体直接导出的18×18透明PNG；不手绘或近似重建。
loading 只在运行层增加旋转，并在 `prefers-reduced-motion:reduce` 时停止。
四种图标固定18×18px，不接受业务颜色或尺寸覆盖。

#### Toast

Node `67:5896`，Component Key `aca48e84f8f65fdf013efd4074e95be185c5b5e1`。

| H5 属性 / 行为 | Figma 写入 | 说明 |
|---|---|---|
| `text` | `Text#67:14` | 业务反馈文案 |
| `icon-type="none"` | `icon#67:13=false` | 不显示图标 |
| `icon-type="warning/success/error/loading"` | `icon#67:13=true`，再设置内部 `Toast.Icon.type` | 不在主组件虚构 Variant |
| `open` | 无 | H5运行层显隐 |
| `duration` | 无 | H5自动关闭时长；默认2000ms，0表示不自动关闭 |

导入 Toast 后先写顶层 Boolean/TEXT，再定位内部 `Toast.Icon` 实例设置 `type`，并回读顶层属性和
嵌套类型验证。禁止 detach 或把图标在实例外另行叠加。Toast 没有 Slot，文案不得通过额外文本节点覆盖。

warning / error 映射 `role=alert` 与 assertive live region；success / loading / none 映射
`role=status` 与 polite live region。loading 不自动关闭，其余类型按 `duration` 关闭并派发 `v9-close`。
固定居中属于 H5 运行层；气泡内部严格保持最大188px、12/16px Padding、8px gap、8px圆角与无阴影。

Figma 主组件与 Toast.Icon 均已发布并回读为 `CURRENT`。

```html
<v9-toast-icon type="success"></v9-toast-icon>
<v9-toast open icon-type="success" text="操作成功"></v9-toast>
```

### Loading 变体与依赖映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `1:2097`，Component Set Key `64b3b6a365d2f40f48ba3d4af93ae7f712dd9c14`，
最后核对 2026-08-13。直接依赖
`加载/加载`（Node `1819:1375`，Component Key `d44e92e0421b43e0512c0d5515e0e3a4e758c0c6`）。

| H5 属性 | Figma `type` | 固定文案 |
|-----------|--------------|----------|
| `type="normal"` | `normal` | 正在加载 |
| `type="pull-up"` | `pull-up` | 上滑刷新 |
| `type="pull-down"` | `pull-down` | 下拉刷新 |

三个 type 均保留内部 `加载/加载` 实例，不存在无图标状态。H5 必须渲染 `.v9-loading__icon`，使用
`assets/components/loading/spinner.svg` 的源路径作为蒙版，并在运行层增加旋转；不得把 Loading
拆成纯文字或手绘圆环。

```html
<v9-loading type="normal"></v9-loading>
```

### Quantity Stepper 状态映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `1:2026`，Component Set Key `113641d4e06fbbd3e6adb4018b07a73830189ea2`，
最后核对 2026-08-13。

| H5 调用状态 | Figma `state` | 数字写入 | 禁用按钮 |
|-----------|---------------|----------|----------|
| `min < value < max` | `default` | `value#149:4` | 无 |
| `value >= max` | `max` | 固定99，不覆盖文本 | 加号 |
| `value <= min` | `min` | 固定1，不覆盖文本 | 减号 |

Figma 写入 default 时设置 `value#149:4`；max/min 使用源组件固定值。H5 使用
`assets/components/quantity-stepper/` 中的四个源 SVG，并同步原生按钮 `disabled`，不得只换灰色而保留可点击。
Stepper 外层保持透明，不设置白色或其他背景色；背景由调用容器提供。

```html
<v9-quantity-stepper value="20" min="1" max="99"></v9-quantity-stepper>
```

### Alert 变体与资产映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `53:2872`，Component Set Key `e6ca9c4ca52c7057d33ed4fb958331f12f4863b2`，共12个正式变体。

| H5 组合 | Figma 组合 | 尺寸 | 默认显隐 |
|---------|------------|------|----------|
| `mode=standard size=default` | standard / Default / top | 375×42px、圆角0 | link图标+箭头；pure仅图标 |
| `mode=contained size=default` | contained / Default / top | 355×42px、圆角12 | link图标+箭头；pure仅图标 |
| `mode=contained size=small action=link` | contained / small / default / link | 355×42px、圆角12 | 图标显示、箭头隐藏 |
| `mode=contained size=small action=pure` | contained / small / default / pure | 355×36px、圆角12 | 图标与箭头均隐藏 |

info 文案、图标与箭头映射主色；warning 映射错误色。H5 固化并调用
`assets/components/alert/info.svg`、`warning.svg`、`arrow-info.svg`、`arrow-warning.svg`；
不得把左侧图标实现为字符或把类型箭头降级为 grey。`show-icon`、`show-button` 对应源 Boolean 属性，
显式值覆盖表中默认显隐。

### Appbar 运行时资产映射

`<v9-appbar>` 自身输出375×88结构：顶部44px系统状态区 + 底部44px导航区。下列文件是从
App bars 源组件提取并随 Skill 固化的资产，页面不得改用字符、占位图标或临时 SVG：

- `assets/components/appbar/back-black.svg` / `back-white.svg`
- `assets/components/appbar/cellular-black.svg` / `cellular-white.svg`
- `assets/components/appbar/wifi-black.svg` / `wifi-white.svg`
- `assets/components/appbar/battery-black.svg` / `battery-white.svg`
- `assets/components/appbar/action-1.svg` / `action-2.svg`

运行时固定保持时间左侧10px、系统图标组右侧26px、返回按钮40×40且无原生 button 边框/背景。
全部类型底部均不绘制分割线或 inner shadow；Text/Text white 的右侧操作是无下划线纯文字；Icon
默认调用 `back-black.svg` 显示黑色返回按钮。`type` 只选择 App bars 变体，不允许调用层重写状态区或
返回按钮的内部结构；确需隐藏返回时只能显式设置 `show-back="false"`。

`None black` 映射为透明Appbar背景 + 黑色状态栏资产 + 黑色返回资产，适用于浅色背景图或
`background/Focus`之上的无标题导航。H5直接调用 `<v9-appbar type="none-black" show-back>`；
透明背景由组件运行时提供，页面不得额外覆盖内部背景色。

### Status Bar / Home Indicator 映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `1:1545`，Component Set Key `5ae52e4d10b33a143c0442c40b046dd4142f6f9c`，
最后核对 2026-08-13。

| H5 属性 | Figma `theme` | 指示条颜色 |
|-----------|---------------|------------|
| `<v9-home-indicator theme="light">` | `light` | `on-surface default primary` (#222222) |
| `<v9-home-indicator theme="dark">` | `dark` | `on primary` (#FFFFFF) |

该源组件虽然命名为 `Status Bar`，实际结构是375 × 34px的页面底部 Home Indicator。
`.v9-statusbar` 仅保留为 App bar 顶部44px系统状态区的 H5 兼容结构，不与此 Set Key 建立映射。

### Selection Control 变体映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `53:3858`，Component Set Key `f2b2b67087429cf42a14334ffcfcea6b420a82cc`，
最后核对 2026-08-13。

| H5 class | Figma `type` | Figma `state` |
|-----------|--------------|---------------|
| `.v9-selection-control--checkbox` | `checkbox` | 由状态 class 决定 |
| `.v9-selection-control--radio` | `radio` | 由状态 class 决定 |
| 无状态 class | — | `unchecked` |
| `.is-checked` | — | `checked` |
| `.is-disabled` | — | `unchecked disable` |
| `.is-checked.is-disabled` | — | `checked disable` |

H5 使用 `assets/components/selection-control/` 中随 Skill 固化的 Figma 原始矢量资产；不得用字符、
emoji 或临时 CSS 图形替代。Figma 的禁用态继续属于 `state` 枚举，不转换成新的 Boolean 属性。

### Agreement 变体映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `53:3901`，Component Set Key `078cc511ceec8f47b82e413d1c57513f0f5603e9`，
最后核对 2026-09-03，发布状态为 `CURRENT`。

| H5 class | Figma `state` | 内容写入 |
|-----------|---------------|----------|
| `.v9-agreement--detail` | `detail` | 固定详情文案 + arrow；不设置 `Text#1980:0` |
| `.v9-agreement--checked` | `checked` | 设置 `Text#1980:0`；内部 Selection Control 为 checked checkbox |
| `.v9-agreement--unchecked` | `unchecked` | 设置 `Text#1980:0`；内部 Selection Control 为 unchecked checkbox |

Agreement 直接依赖 Selection Control 当前 Set Key；不得把 checkbox 以手工图层重新绘制。
H5 `detail` 必须将14/14文案与18px灰色右箭头放在同一个链接中，保持2px间距和18px总高。
`checked` / `unchecked` 文案使用14/14；`text`中的 `《协议名称》`（含书名号）映射为Primary高亮范围，
其余前后文保持Secondary。写入自定义协议名时先更新 `Text#1980:0`，再把书名号范围恢复为Primary；
不得在Agreement实例外另建橙色Text图层。

### Dialog 属性、操作区与槽位映射

源记录：文件 `9.0规范`（`KKuaHEUNwnenHwumr4a3Ta`），页面 `控件`（Page `0:1`），
Node `53:5759`，Component Key `60b7ce0dfb77bae12d0fcc9afd9845dc982328ef`，
最后核对 2026-08-19。源组件已发布并回读为 `CURRENT`，正式身份为 `component`。

Dialog 是单一 COMPONENT，使用 `importComponentByKeyAsync` 导入。Figma 属性名按当前源原样映射，
不在 H5→Figma 转换时自动改写大小写、连字符或尾部空格。

H5 中 `.v9-modal` 是全屏运行层，负责遮罩、背景阻断、底部定位、焦点和关闭行为；`.v9-dialog`
才映射到上述 Figma Component。运行层不创建新的 Figma Component Key，也不拼入 Dialog 实例内部。

| H5 结构 / 属性 | Figma 属性或操作 | 默认值 |
|-----------------|-------------------|--------|
| `.v9-dialog__header-media` 是否有内容 | `Head Media#53:2` | 由调用内容决定 |
| `.v9-dialog__close` 是否显示 | `Close button#53:1` | `false` |
| `.v9-dialog__body` 是否显示 | `Content Text#53:3` | 由 `show-body` 决定 |
| `.v9-dialog__content-image` 是否有内容 | `Content image#53:4` | 由调用内容决定 |
| `.v9-dialog__agreement` 是否显示 | 无顶层公开属性 | H5兼容能力；Figma以嵌套实例显隐覆盖 |
| `.v9-dialog__title` | `Tittle Text#53:5` | 源组件默认标题 |
| `.v9-dialog__body` | `Content Text2#53:6` | 源组件默认正文 |
| `.v9-dialog__actions` | 固定直接依赖 | H5 actions 必填；Figma主件中操作区不可省略 |

| H5 公开 API | Figma / 运行层处理 |
|-------------|-------------------|
| `show-close` | `Close button#53:1` |
| `show-body` | `Content Text#53:3` |
| `show-agreement` | H5兼容开关；Figma无顶层Boolean，必要时隐藏嵌套Agreement实例 |
| `agreement-state/text/href` | 修改内部 Agreement 实例，不提升为 Dialog Figma 顶层属性 |
| `slot="agreement"` | 用正式 Agreement 实例替换默认协议入口，保持所在层级 |
| `slot="actions"` | 必须提供正式 Action Button Group，且至少包含1个可见 Button；Figma主件固定保留操作区 |
| `close-on-scrim` | 仅H5运行层；默认false，不创建Figma属性或组件Key |

#### 可替换槽位合同

| H5 槽位 | Figma 槽位 | 替换方式 | 必须保持 |
|----------|------------|----------|----------|
| `.v9-dialog__header-media` | Header Media | 打开 `Head Media#53:2`，覆盖内部图片填充/内容 | 100×100px、水平居中；H5 默认 `object-fit:contain` |
| `.v9-dialog__content-image` | Content Image | 打开 `Content image#53:4`，覆盖图片填充/内容 | 335×150px、12px圆角；H5 默认 `object-fit:cover` |

槽位没有真实内容时保持 Boolean 为 `false`，不得显示 Figma 示例图片。替换必须在 Dialog 实例内部
完成，禁止 detach、删除槽位、改变槽位尺寸或把媒体节点叠加到实例外。H5 通过槽位的子 `<img>`
或等价媒体节点传入内容，`.v9-dialog` 本身不写死业务图片。

Dialog 直接依赖 Agreement（`078cc5…`）与 Action Button Group（`af44df…`）。Agreement 状态/文案、
Action Button Group `layout` 与内部 Button Full-width 文案没有提升为 Dialog 顶层属性，需要时修改
对应嵌套实例，保持组件依赖关系。

Dialog 的内容、Agreement 与 Action Button Group 位于同一白色面板：面板左右20px、下20px，
操作区宽335px；内容↔Agreement、Agreement↔操作区、操作区↔面板底部均为20px。标题与正文都按
实际渲染结果为单行时使用16px间距，只要其中一项为多行即使用10px；Figma主件暂时固定10px。

H5 `<v9-dialog>` 运行时还必须维护唯一标题/正文ID、`role=dialog`、`aria-modal`、初始焦点、
Tab/Shift+Tab循环、Esc关闭、关闭后焦点恢复和页面滚动锁。`v9-close.detail.reason` 使用
`escape / close-button / action / scrim` 区分关闭来源；这些行为不产生新的Figma图层或属性。
请求打开但缺少有效 actions 时，H5 必须拒绝打开并触发
`v9-invalid.detail.reason="missing-actions"`；Figma 端不存在 `Button=false` 的正式组合。

#### Dialog 操作区决策映射

| 最终按钮内容 | H5 `layout` | 嵌套 Figma `layout` | Close |
|--------------|-----------|----------------------|-------|
| 1个按钮 | `primary` | `Primary` | 默认隐藏；仅无非决策退出路径时显示 |
| 2个按钮，两个文案都≤4字 | `inline` | `Inline` | 按退出路径判断 |
| 2个按钮，任意一个文案>4字 | `stacked` | `Stacked` | 按退出路径判断 |

- Dialog 不映射 `.v9-action-group--secondary` / `layout=Secondary`。
- Dialog 不存在无按钮状态；每个实例至少保留1个 Primary 操作。
- 如果按钮中已有“取消”“暂不选择”“稍后”等不作选择即可关闭的语义，设置 `Close button#53:1=false`。
- 只有全部按钮都要求用户明确选择、没有非决策退出路径时，才设置 `Close button#53:1=true`。
- Close 按语义而不是关键词机械判断；先确认最终按钮文案与行为，再选择布局和显隐。

```html
<v9-dialog open title="标题" body="正文">
  <img slot="header-media" src="header-media.png" alt="">
  <img slot="content-image" src="content-image.png" alt="内容说明">
  <v9-action-group slot="actions" layout="stacked">
    <v9-button size="full" variant="primary">同意并继续</v9-button>
    <v9-button size="full" variant="subtle">暂不使用</v9-button>
  </v9-action-group>
</v9-dialog>
```

不使用某个媒体槽时，直接不渲染对应节点或添加 `hidden`；不要保留空 `<img>` 或默认示例图。

---

## 二、Tabs 统一 Set 导入

Tabs不再按目标变体维护单独Component Key。统一调用
`importComponentSetByKeyAsync("a681c138c3d45ba5171ab72ca575931f4aefa65d")`，再设置
`variant`、`amount`、`Active`、`Distribution`与Line背景属性；Card只设置其适用属性。
旧Line单变体Key不得继续写入新页面映射。

---

## 三、CellCard Slot 映射

### Slot 版 CellCard / Shell

9.0规范库 `CellCard / Shell`（Node `53:4359`）已正式发布，Component Set Key
`98c23ccd985a334de8197701fa1d02ead7c910e0`。组件有8个 `Header × Content × Footer` 变体，
并暴露三个 Instance Swap 属性：

| H5 Slot | Figma Boolean / Variant | Figma Instance Swap |
|---------|--------------------------|---------------------|
| `slot="header"` | `Header=true/false` | `Header Slot#2043:4` |
| `slot="content"` | `Content=true/false` | `Content Slot#2043:5` |
| `slot="footer"` | `Footer=true/false` | `Footer Slot#2043:6` |

映射时根据H5中实际存在且未隐藏的Slot设置三个变体值，再把兼容实例写入对应Instance Swap。
空Slot映射为 `false`，不得保留隐藏占位实例导致高度或间距残留。

Shell中Header Region到Content Region固定12px；最后可见信息Region到Footer固定16px。H5与Figma
均保持这两组Region关系，隐藏任一Slot后对应间距必须随Region一起收拢。

写入顺序固定为：先设置 Shell 的 `Header`、`Content`、`Footer` 与对应 Instance Swap，再进入
嵌套的 Cardheader、CardContent 或 Footer 正式组件，设置其自身变体、Boolean、文本和 Slot。
子组件属性不得提升为 Shell 顶层属性；Shell 也不得为子组件状态新增业务 Variant。

H5 与未来 Figma Slot 的职责对应如下：

| H5 结构 | Figma 目标 |
|---------|------------|
| `<v9-cardheader slot="header">` | Header Slot：正式 Cardheader 实例或其他兼容 Header |
| `[slot="content"]` | Content Slot：单一兼容组件、自由组合或 Content Pattern |
| `[slot="footer"]` | Footer Slot：319px可用宽度；正式操作组件Fill，且与上方可见Region保持16px |
| `.v9-stack--group/module/section` | Figma Auto Layout，分别绑定4/8/16px现有 Space Variable |

### Legacy CellCard

Legacy Set Key `c126d13cbbf9959f76f29ebd2494aa32da4fcdfd` 固定包含 Cardheader + CardContent +
Button Full-width，只用于维护既有页面：

| H5 Legacy 写法 | Figma 操作 |
|----------------|------------|
| `title="…"` | Cardheader `header Text#1114:0` |
| `subtitle="…"` | Cardheader `SubtitleText#1114:155` + `ShowSubtitle#578:18` |
| `action="…"` | Cardheader `Actiontype=Link` + ActionText |
| 固定列表/图文 | 继续使用内部 CardContent 变体 |
| 无底部按钮 | 隐藏内部 Button Full-width |

Legacy 组件不得承载新的自由组合、Content Pattern 或 Card Pattern。

---

## 四、写入时的规范红线（务必遵守，摘自 9.0 custom-rules）

1. **禁止手动拼装已有库组件** —— 表中有 Key 的一律 `importComponentByKeyAsync` / `importComponentSetByKeyAsync` 导入实例。
2. **CellCard / Shell 必须使用正式发布 Key**；当前 Slot 版未发布，不得用 Legacy Key 冒充。
3. **Cardheader 必须用目标变体直接创建**，禁止先建 None 再 setProperties 切 Actiontype（高度会塌成 19px）。
4. **App bars 内已含顶部系统状态区**，不要再拼一个44px顶部状态栏；底部 `Status Bar` / Home Indicator 是独立组件，可按页面底部结构使用。
5. **surface 取值规则**：Surface 只区分结构，不根据副标题、语义或数据数量推断。固定单层内容优先 pure；横向滚动或多层仍难区分时使用 subtle；数据组件详见 `components.md`。
6. **PRD 没写的不加**：H5 里没有的内容，Figma 端也不补；占位文案放置后立即填或隐藏。
7. **字体兜底**：PingFang SC 不可用时先对实例内 TEXT 替换为 Noto Sans SC，再改 characters。

---

## 五、维护约定

- 本表是 H5 与 Figma 的**唯一实现映射真相**。新增组件时：先在 `v9-core.css` 加样式 + 在壳子加属性 → 再在此表补一行 Key/变体/文本 key，并同步 `components.md` 的组件级来源索引。
- 若 Figma 源组件 Key 变更，更新本表与 `components.md` 的组件级 Key 索引；H5 class 不因 Key 变化而改名。
- 属性命名永远与 Figma 变体保持同名/可直映，避免引入翻译层。
