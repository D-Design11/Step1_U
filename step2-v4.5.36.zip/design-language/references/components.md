# 组件规范

## 目录

- 一至四：Button、Action Button Group、App bar、CellCard
- 五至九：Alert、arrow、Badge、Status Bar（Home Indicator）、返回、pic
- 十至十四：TextLink、ExpandLink、Tag、Tabs、StatusOverlay
- 十五至十七：Selection Control、Agreement、Dialog
- 十八至二十二：info-icon、Tooltip、Toast、Loading、Quantity Stepper
- 二十三至二十九：数据组件（`DataValue → DataItem → DataGroup`）、Address Group、Empty、Entry、Pill Option、Form Item、Page Background
- 三十：Task Sheet / Shell（任务型底部容器）
- 三十一：Accent Card（Single / Split / Grouped 橙色结构卡）
- 三十二：Option Tile / Warning Count（多选与警示展示）
- 末尾索引：Figma Node ID、Component Key 与关键属性

## H5 组件运行时合同

采用9.0的区域把 `assets/v9-components.js` 提供的 `<v9-*>` 自定义元素作为正式调用入口，
`assets/v9-core.css` 负责其内部视觉实现。调用层只设置公开属性、文字内容与命名 Slot，不接触
组件内部 DOM、SVG、行盒补偿或固定对齐关系。

```html
<link rel="stylesheet" href="assets/v9-core.css">
<script type="module" src="assets/v9-components.js"></script>
```

正式组件必须同时具备：已发布 Figma Component / Component Set、封装好的 H5 `<v9-*>`、
以及 `v9-figma-map.md` 中的显式映射。运行时导出的 `V9_COMPONENTS` 是 H5 身份登记表：

| `kind` | 身份 | 是否计为正式组件 |
|---|---|---|
| `component` | Figma、H5、映射三项齐全 | 是 |
| `pending` | 一侧为草案、未发布或映射未完成 | 否 |
| `primitive` | 组件内部逻辑/视觉原语 | 否 |
| `internal` | 内部辅助结构 | 否 |
| `h5-only` | 仅保留H5兼容实现，没有正式Figma映射 | 否 |

`.v9-*` 内部 class、BEM Element、Modifier 和页面布局辅助 class 都不因此自动成为正式组件。
旧页面可继续使用已有 class 结构；9.0新建区域不得手拼组件内部节点来替代同名 `<v9-*>`。

原设计保留／继承范围允许复用源组件或按已确认基准重建，标为“原设计继承实现”；
不强制用外观不匹配的9.0组件替换，不登记为9.0正式组件。无论处于什么范围，实际调用的`<v9-*>`
均须遵守公开属性、Slot和内部合同，不能为匹配旧样式修改内部DOM或覆盖规格。
范围判断、来源标记与验收只查`workflow.md`，此处不重复模式流程。

### 组件不能满足时

1. 先使用正式组件的变体、属性、Slot 和嵌套能力；
2. 不能满足时，在页面层以正式组件 + Token + Stack 建立“页面本地组合”；
3. 可以手动组合业务结构，但不得复制正式组件的内部 DOM、SVG 或状态实现；
4. 本地组合不登记 Component Key、不进入正式组件索引，也不在交付说明中计为组件；
5. 稳定且重复使用后，必须同时建设 Figma 组件、H5 封装与映射，才能升级为正式组件。

## 一、Button Full-width（通栏按钮）

通栏按钮，高度 50px，胶囊形圆角 (`radius: Full/1000px`)。横向尺寸采用 **Fill Container**：
335px 只是 Button Full-width 源组件的默认参考宽度，不是按钮宿主可跨场景写死的固定宽度。
放入 Action Button Group 或 CellCard Footer 后均跟随父级可用宽度 Fill。

**Figma 当前源**：页面「控件」，Node `53:2650`，Component Set Key
`c5d57a72c624a7978ef5fdec6e2010171ebbb0ae`。这是 Action Button Group 的直接依赖；
旧 Key `6b621371…` 不再作为当前映射入口。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| variant (类型) | `Primary` / `Subtle` | 填充按钮 / 描边按钮 |
| state (状态) | `Default` / `Visited` / `Disabled` | 默认 / 完成态 / 禁用；当前组件集共5个实际组合 |
| text (文字内容) | TEXT 属性 | 按钮文字，默认值 "默认文案" |

### 视觉与状态

| 类型 | 状态 | 背景 | 文字色 | 边框 |
|------|------|------|--------|------|
| Primary | Default | `--primary` (#FF6435) | `--on-primary` (白) | 无 |
| Primary | Visited | `--secondary` (#FFB19A) | `--on-secondary` (白) | 无 |
| Primary | Disabled | `--disable` (#CCCCCC) | `--on-disable` (白) | 无 |
| Subtle | Default | 透明 | `--primary` (#FF6435) | 1px `--primary` |
| Subtle | Visited | 透明 | `--secondary` (#FFB19A) | 1px `--secondary` |

### 文字规格

- 字体: PingFang SC Semibold
- 字号: 18px
- 行高: 18px（单行 = 字号）
- 对齐: 居中

### 横向尺寸合同

| 使用容器 | 父级可用宽度 | Button Full-width 结果 |
|---------|-------------|------------------------|
| Action Button Group `Primary` / `Stacked` | 由父容器提供 | 填满父级可用宽度 |
| 351px CellCard Footer（左右16px Padding） | 319px | 319px |
| 其他兼容 Footer / 操作容器 | 由父级提供 | 填满父级可用宽度 |

- H5 `<v9-button size="full">` 的宿主和内部按钮都必须 `width:100%`，禁止在组件运行时写死335px。
- 页面层不得再用负 margin、裁切或覆盖组件 Shadow DOM 修正溢出；容器负责可用宽度，按钮负责 Fill。
- 50px高度、圆角、视觉类型和状态不随容器宽度变化。

---

### 1.1 Action Button Group（操作按钮组）

用于页面、卡片或弹窗中的操作区，统一管理一至两个 `Button Full-width` 的排列方式。
该组件只负责按钮组合结构；按钮视觉类型、状态和文字仍由内部 `Button Full-width` 承担。

**Figma 当前源**：页面「控件」，Node `53:4557`，Component Set Key
`af44df67d9d41c12a1b3a2a875305fa4fc58711b`，共4个 `layout` 变体。

#### 职责模型

| 层级 | 属性 | 职责 |
|------|------|------|
| 组合排列 | Action Button Group `layout` | 决定按钮数量、方向、宽度与对齐，不代表按钮交互状态 |
| 视觉主次 | Button Full-width `variant` | `Primary` / `Subtle`，决定主按钮与次按钮角色 |
| 交互状态 | Button Full-width `state` | 继承对应按钮类型的有效状态，如 `Default` / `Visited` / `Disabled` |

不得用 `layout` 推断或冻结内部按钮的 `state`，也不得用相同视觉角色替代主次结构。

#### 布局变体

| layout | 尺寸 | 内部结构 | 对齐 |
|--------|------|----------|------|
| `Primary` | 源参考 375×50 | 1个 Primary | 填满父级可用宽度 |
| `Stacked` | 源参考 375×110 | Primary 在上、Subtle 在下 | 纵向堆叠，间距10px |
| `Inline` | 源参考 375×50 | Primary 在左、Subtle 在右 | 横向等分，间距10px |
| `Secondary` | 源参考 375×50 | 1个 Subtle | 162.5px、右对齐 |

#### 结构规格

| 项目 | 规范 | 来源 |
|------|------|------|
| 容器宽度 | Fill；Figma 源参考宽375px | 由调用容器提供 |
| 容器背景 | 无 | 继承父容器 |
| 容器内边距 | 0 | 页面或 Card 自己提供边距与 Padding |
| 按钮间距 | 10px | Figma 源组件值 |
| 按钮高度 | 50px | 由 `Button Full-width` 保持，不在按钮组重复定义 |
| 按钮圆角 | Full / 1000px | 由 `Button Full-width` 保持 |

#### 使用规则

1. `Primary` 放一个 Primary 角色按钮；`Secondary` 放一个右对齐 Subtle 角色按钮。两种单按钮布局都继承对应 `Button Full-width` 的有效交互状态，不固定为 `Default`。
2. `Stacked` 与 `Inline` 固定为一个 Primary + 一个 Subtle，必须保持视觉主次；禁止两个按钮都使用 Primary 或都使用 Subtle。
3. 双按钮可以同时处于相同交互状态，例如 `Primary / Default` + `Subtle / Default`；`state` 相同不等于视觉角色相同。两个按钮的状态可按交互分别设置。
4. 按钮组只控制排列；内部按钮的高度、圆角、视觉类型和状态继续由 `Button Full-width` 统一维护，不在父组件重复定义。
5. `Secondary` 的单个 Subtle 保持源组件162.5px宽并右对齐；不得按父容器宽度自动推导为半宽。
5. 横排按钮必须等宽，不得根据文案长度单独伸缩；文案过长时先优化文案，再评估是否改用 `Stacked`。
6. 组件自身始终保持 `padding:0`，不提供页面背景。只有作为页面吸底操作区时，外层
   `v9-footer` 才提供上下20px、左右12px Padding；普通页面流、CellCard Footer 与 Dialog 内均不得
   因使用 Action Button Group 自动增加20px。放在 CellCard Footer 时直接 Fill 319px可用宽度。

---

## 二、Button（常规按钮）

常规按钮，3 种尺寸 × 3 种类型 × 3 种状态，共27个变体。

**Figma 当前源**：页面「控件」，Node `53:2666`，Component Set Key
`224026a8170761826d4fa9f6b9471e931a58a35d`。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| mode (类型) | `Primary` / `Subtle` / `Weak` | 高强调填充按钮 / 中强调描边按钮 / 低强调 Surface 按钮 |
| statue (状态) | `Default` / `Vistited` / `Disabled` | 默认 / 完成态 / 禁用 |
| size (尺寸) | `Large` / `Medium` / `Small` | 大 / 中 / 小 |
| Button Text (文字内容) | TEXT 属性 | 按钮文字，默认值 "默认文案" |

### 尺寸规格

| 尺寸 | 宽度 | 高度 | 字号 | 水平内边距 | 垂直内边距 |
|------|------|------|------|-----------|-----------|
| Large | 100px | 40px | 16px | 18px | 8~10px |
| Medium | 88px | 35px | 14px | 16px | 7~8px |
| Small | 88px | 28px | 14px | 16px | 4~5px |

### 视觉与状态

| 类型 | 状态 | 背景 | 文字色 | 边框 |
|------|------|------|--------|------|
| Primary | Default | `--primary` (#FF6435) | 白 (#FFFFFF) | 无 |
| Primary | Vistited | `--secondary` (#FFB19A) | 白 (#FFFFFF) | 无 |
| Primary | Disabled | `--disable` (#CCCCCC) | 白 (#FFFFFF) | 无 |
| Subtle | Default | 透明 | `--primary` (#FF6435) | 1px `--primary` |
| Subtle | Vistited | 透明 | `--secondary` (#FFB19A) | 1px `--secondary` |
| Subtle | Disabled | `--disable` (#CCCCCC) | `--on-disable` (白) | 无 |
| Weak | Default | `surface default` (#FFFFFF) | `on-surface default primary` (#222222) | 无 |
| Weak | Vistited | `surface default` (#FFFFFF) | `on-surface default secondary` (#757575) | 无 |
| Weak | Disabled | `surface default` (#FFFFFF) | `text disabled` (#CCCCCC) | 无 |

### 文字规格

- `Primary` / `Subtle`: PingFang SC Semibold / 600。
- `Weak`: PingFang SC Regular / 400；不得沿用其他两种类型的加粗字重。
- Large: 16px，行高 16px。
- Medium / Small: 14px，行高 14px。
- 圆角: Full (1000px) 胶囊形。

### 强调层级与使用规则

1. `Primary` 用于推动当前区域核心任务；`Subtle` 用于仍需明确注意的次要、替代或并列操作；
   `Weak` 用于需要保留可发现性、但不应打断主体阅读的低强调操作。
2. `Weak` 表达视觉层级弱化，不绑定 Cardheader、卡片、工具区或某个固定位置；不得用组件所在位置
   直接推导类型。
3. `Weak` 通过白色 Surface、中性色文字与 Regular 字重共同降低视觉重量，不使用品牌色与描边。
4. `Weak` 的白色 Surface 必须由浅灰、有色或其他非白承载面建立可见边界；禁止直接放在白色
   背景上。若所在区域为白色，必须改用其他正式按钮类型或调整承载关系；不得通过临时加描边、阴影
   或品牌色修补 `Weak` 的识别度。
5. 同一区域出现多个重复辅助操作时，应结合数量、面积、对比和业务关系判断是否使用 `Weak`，不能只按
   文案关键词匹配。

### 当前双端状态

- Figma Button Set 已发布 `Weak` 的9个变体，Set Key保持
  `224026a8170761826d4fa9f6b9471e931a58a35d`。
- H5正式运行时支持
  `<v9-button variant="weak" size="large|medium|small" state="default|visited|disabled">`，三种状态与
  Figma变体一一对应。
- `size="full"` 映射独立的 `Button Full-width` Set，该Set仍只支持Primary/Subtle；Weak不得与Full组合。
- H5生成与Figma写入都必须先检查按钮的直接承载面；白色背景禁止使用Weak。

---

## 三、App bar（导航栏）

固定高度 88px，宽度 375px (iPhone 标准宽度)。

**Figma 当前源**：页面「控件」，Node `1:714`，Component Set Key
`9e8e0bc5b08337e2e67bb26d1f26d97419349c11`。

H5 直接调用：

```html
<v9-appbar type="flat" title="数据看板" show-back></v9-appbar>
```

Appbar 自身封装44px系统状态区、44px导航区、返回按钮与右侧操作；调用层不得在组件外再拼状态栏，
也不得用字符或页面 SVG 替换内部图标。状态区与返回图形使用随 Skill 固化的 Figma 源 SVG。
所有8种类型底部均不绘制灰色分割线或 inner shadow；调用层也不得自行补线。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| 类型 | `Flat` / `Text` / `None` / `Icon` / `Flat white` / `Text white` / `None white` / `None black` | 8 种导航栏变体 |
| icon1 | Boolean | 右侧图标 1 显示 |
| icon2 | Boolean | 右侧图标 2 显示 |

### 变体详情

#### Flat（无底线）
- 背景: 白色 (#FFFFFF)
- 底部: 无分割线、无 inner shadow
- 标题: PingFang SC Semibold 18px / 18px，居中，`--text-primary` (#222)
- 左侧返回按钮区域
- 顶部状态栏 (44px)

#### Text（纯文字）
- 背景: 白色，无底线
- 标题: PingFang SC Semibold 18px / 18px，居中，`--text-primary` (#222)
- 右侧操作文字: PingFang SC Regular 16px / 16px，`--text-primary` (#222)，纯文字且无下划线

#### None（无标题）
- 背景: 白色，无底线
- 无标题文字
- 仅显示状态栏 + 返回按钮

#### Icon（带图标）
- 背景: 白色，无底线
- 标题: PingFang SC Semibold 18px，居中
- 左侧默认显示40×40黑色返回按钮
- 右侧可配置 icon1/icon2 图标按钮

#### Flat white（白色主题无底线）
- 与 Flat 相同布局，使用白色/浅色配色
- 底部无分割线、无 inner shadow

#### Text white（白色主题纯文字）
- 与 Text 相同布局，使用白色/浅色配色

#### None white（白色主题无标题）
- 与 None 相同布局，使用白色/浅色配色

#### None black（深色系统图标、无标题）
- 背景透明；用于Appbar后方存在浅色背景图、Focus氛围背景或其他浅色页面背景的场景
- 无标题导航内容；顶部系统状态区与返回能力使用深色资产
- H5必须使用 `type="none-black"`，调用层不得通过覆盖Appbar背景色模拟该状态

### 通用结构
```
┌─────────────────────────────────┐ 88px
│  状态栏 (44px)                    │
│  ┌─────────────────────────────┐│
│  │ [返回]    标题文案    [操作] ││ 44px
│  └─────────────────────────────┘│
└─────────────────────────────────┘
```

---

## 四、CellCard（信息卡片）

CellCard 是统一的卡片容器。它定义页面级 Surface、圆角、阴影、Padding，以及 Header、Content、
Footer 三个区域的排列和显隐收拢；不规定 Content 必须是 CardContent，也不规定 Footer 必须是
Button Full-width。

```text
CellCard / Shell
├─ Header Slot
├─ Content Slot
└─ Footer Slot
```

### 4.0.1 职责边界

**CellCard 负责：**

- 页面级白色 Surface、16px 圆角、Level 1 阴影和16px外层 Padding；
- Header、Content、Footer 区域的纵向排列；
- Slot 的显隐、替换，以及隐藏后的高度和间距自动收拢；
- 标准信息卡默认 Header ↔ Content 12px、Content ↔ Footer 16px。

**CellCard 不负责：**

- 将具体业务结构固化为 CellCard Variant；
- 把 Metric、Address、Tag 等通用组件归为 Content 专属组件；
- 为嵌入组件重复增加背景、圆角、阴影和外层 Padding；
- 规定所有卡片必须具有 Header、Content 或 Footer。

### 4.0.2 Slot 兼容合同

Header、Content、Footer 表示组件在卡片中的**使用位置**，不是组件所属分类。进入 Slot 的组件应满足：

| 项目 | 规则 |
|------|------|
| 横向尺寸 | 支持 Fill，跟随卡片内容宽度 |
| 纵向尺寸 | Hug，由内容决定高度 |
| 容器模式 | 嵌入完整 CellCard 时使用 Embedded；不得重复提供卡片级 Surface、圆角、阴影或外层 Padding |
| 显隐 | 隐藏后不得保留空高度或相邻间距；H5 省略节点或使用原生 `hidden` 属性。已挂载的直接 Slot 子节点切换 `hidden` 时，CellCard 必须同步显示/隐藏对应区域，并重新计算相邻间距 |
| 内部职责 | 组件自身管理内部结构、状态、内容属性和 Token |

Metric Group、Address Group、Tag Group 等组件继续按数据、位置、状态等自身职责分类。它们可以进入
Content Slot，也可以用于页面、列表、Dialog 等其他场景；规范不建立 `Content Modules` 所属目录。

### 4.0.3 间距关系

间距按信息关系判断，不按 Slot 名称机械决定：

| 关系 | 间距 | Token |
|------|------|-------|
| 同一内容组 | 4px | `space/space/xs` |
| 同一信息模块 | 8px | `space/space/sm` |
| 不同结构区域 | 16px | `space/space/lg` |

标准信息卡中 Header 与 Content 共同表达一组信息，固定使用12px；Footer 通常是独立操作区域，
与 Content 默认使用16px。具体 Card Pattern 若建立了不同的信息关系，应在该 Pattern 中明确，
不得反向改变所有 CellCard 的默认值。数据内部0–2px由数据组件自身定义，不进入 CellCard 间距规则。

### 4.0.4 内容与整卡组合层级

| 场景 | 处理方式 |
|------|----------|
| 单一组件 | 直接放入对应 Slot |
| 组件自由增减、顺序不稳定 | 在 Slot 内按4/8/16px关系组合，不建立业务组件 |
| Content Slot 内部组合稳定且会重复使用 | 建立 `Content Pattern` |
| Header + Content + Footer 整卡组合稳定且会重复使用 | 建立 `Card Pattern` |

`Content Pattern` 与 `Card Pattern` 是组合层，不改变内部 Metric、Address、Tag 等组件的原有分类。
Pattern 不得做成 CellCard 的业务类型 Variant；一次性或顺序不稳定的组合保留为页面本地组合。

### 4.0.5 当前实现状态

- `CellCard / Shell` 已在 9.0 规范库正式发布：Node `53:4359`，Component Set Key
  `98c23ccd985a334de8197701fa1d02ead7c910e0`，共8个 `Header × Content × Footer` 显隐组合。
- H5 使用正式 `<v9-card>`，通过 `slot="header|content|footer"` 传入区域内容；运行时检测空 Slot，
  自动隐藏 Region 并收拢相邻间距。该组件已登记为 `kind=component`。
- 正式库中的旧 CellCard（Component Set Key `c126d13cbbf9959f76f29ebd2494aa32da4fcdfd`）
  固定包含 Cardheader + CardContent + Button Full-width，只用于既有页面兼容，标记为 **Legacy**。

```html
<v9-card>
  <v9-cardheader slot="header" title="任务标题" subtitle="补充说明"></v9-cardheader>
  <div slot="content">业务内容</div>
  <v9-button slot="footer" size="full">去处理</v9-button>
</v9-card>
```

调用层不得复制 `<v9-card>` 的三个 Region 节点，也不得在 Footer 按钮上额外添加顶部 margin；
Header ↔ Content 12px、最后可见信息 Region ↔ Footer 16px由 Shell 统一维护。

### 4.0.6 状态归属与展示边界

CellCard / Shell 的8个变体只控制 Header、Content、Footer 三个 Region 的显隐与对应 Slot 是否存在，
不控制嵌套组件内部的变体、公开属性或交互状态。Cardheader、CardContent 与进入 Footer 的正式组件
分别维护自身状态合同；这些状态不得提升为新的 Shell Variant。

当需要展示 CellCard 组件族的完整能力时，应按层级分别展示 Shell 的合法 Region 组合、Cardheader、
CardContent，以及实际进入 Footer 的正式组件。不得把 Shell、Header、Content 与 Footer 的状态生成
不存在于 Figma 源组件中的笛卡尔积组合。

### 页面边距与对齐基准（重要）

组件库上传的填充/对齐方式即为正确设定，**禁止擅自修改组件的 `layoutSizing`**。常见的对齐误区与正确做法：

| 项目 | 正确值 |
|------|--------|
| 页面内容左右边距 | **12px**（容器 `paddingLeft/Right = 12`）|
| 卡片宽度 | **351px**（= 375 − 12×2），`layoutSizingHorizontal = 'FIXED'`，**不要用 FILL** |
| 卡片填充方式 | 保持组件默认 FIXED，不改成 FILL |

**通栏元素不参与内容边距对齐**：

- Tab、导航栏等**通栏元素**铺满整个屏幕宽度（屏幕 375 就 375，410 就 410），其内部 padding（如 tab 的 `px-8`）是组件自带的，**不是页面内容边距**。
- 通栏元素的内部内容（tab 文字、下划线）与卡片内容**本就不需要左边缘对齐**——卡片走 12px 内容边距，tab 走通栏 + 内部平分，两套对齐逻辑互不迁就。
- ❌ 错误：把卡片宽度/padding 改成迁就 tab 的 8px 内边距
- ✅ 正确：卡片固定 12px 边距，tab 保持通栏，各自正确

**Tab 内部规则**：通栏容器内，多个 tab 用 `flex-[1_0_0]` 等分；选中态下划线（underline）是**固定宽度**（amount=3 时为 32px），靠 `constraints: CENTER` 跟随文字居中，**宽度不随文字变化**。



---

### 4.1 CardHeader（卡片头部）

**生产组件，直接使用。**

Card 的标题区必须使用正式 Cardheader 组件；通用 Card 容器只负责 Surface、圆角、Padding 和内容承载。

H5 直接调用：

```html
<v9-cardheader
  title="今日经营概览"
  subtitle="更新于 09:30"
  action-type="link"
  action-text="明细"
  action-href="#detail">
</v9-cardheader>
```

Cardheader 无副标题时，标题区、Tag 与右侧 Link/Expand 按各自可见盒的中心垂直对齐；存在副标题时，
右侧操作改为与标题行顶边对齐，不得相对整个“标题+副标题”内容块垂直居中。
标题、操作、箭头和副标题的内部节点由运行时生成，页面不再手拼。
不得在容器内另建外观相似的标题、操作或副标题结构。

#### Figma 信息

| 属性 | 值 |
|------|-----|
| Node ID | `53:3382` |
| 类型 | COMPONENT_SET |
| 变体数量 | 8 个 |
| Component Set Key | `fea3a0eced02f3bbf3bc9475e82141c3f814ce99` |

#### 属性定义

| 属性 | 类型 | 可选值 | 说明 |
|------|------|--------|------|
| `ShowSubtitle#578:18` | BOOLEAN | `true` / `false` | 是否显示副标题 |
| `header Text#1114:0` | TEXT | 文本内容 | 标题文字，默认 "卡片标题" |
| `SubtitleText#1114:155` | TEXT | 文本内容 | 副标题文字 |
| `ShowTag#1276:0` | BOOLEAN | `true` / `false` | 嵌套Tag的公开显隐属性；顶层结构仍由 `Show Tag` 变体决定 |
| `Actiontype` | VARIANT | `Expand` / `None` / `Link` | 右侧操作类型 |
| `ExpandStated` | VARIANT | `Expand` / `Collapsed` / `None` | 展开/收起状态（仅 Actiontype=Expand 时生效） |
| `Show Tag` | VARIANT | `true` / `false` | 是否显示状态标签（Tag） |

H5 使用 `action-type="none|link|expand"`、`expand-state="expand|collapsed"` 与 `show-tag` 映射上述
变体；`subtitle` 属性存在时映射 `ShowSubtitle=true`，省略时映射 `false`。`tag-text`、`tag-status`、
`action-text` 与 `action-href` 只写入对应嵌套组件的公开内容，不改变变体身份。

Link 与 Expand 的操作行都必须使用18px固定行盒，并在行盒内垂直居中文字与18px Arrow L。Expand
按钮显式继承 `--v9-font-cn`，不得使用浏览器默认 Arial；文字使用14px / 14px，Arrow宿主使用
18×18px、`line-height:0`。不得依赖表单控件默认字体、默认行高或内联基线完成对齐。

无副标题时，Cardheader 根容器使用中心对齐，使16px标题、22px Default Tag与18px操作盒的中心一致；
有副标题时恢复顶部对齐，使操作区顶边与第一行顶边一致。不得给Tag、TextLink或Expand分别添加
`margin` / `transform` 位移补偿。

#### 变体组合

| Actiontype | ExpandStated | Show Tag | 右侧显示 | Tag 位置 |
|-----------|-------------|---------|---------|---------|
| `None` | `none` | `false` | 无操作 | — |
| `None` | `none` | `true` | 无操作 | 右上角（SPACE_BETWEEN） |
| `Link` | `none` | `false` | 文字链接 + 右箭头 | — |
| `Link` | `none` | `true` | 文字链接 + 右箭头 | 标题后行内 |
| `Expand` | `Expand` | `false` | "展开" + 向下箭头 | — |
| `Expand` | `Expand` | `true` | "展开" + 向下箭头 | 标题后行内 |
| `Expand` | `Collapsed` | `false` | "收起" + 向上箭头 | — |
| `Expand` | `Collapsed` | `true` | "收起" + 向上箭头 | 标题后行内 |

**Tag 位置规则**：
- `Actiontype=None` + `Show Tag=true` → Tag 放右上角（标题左，Tag 右，SPACE_BETWEEN）
- `Actiontype=Link/Expand` + `Show Tag=true` → Tag 紧跟标题文字后（行内），右侧保留操作区

**⚠️ 标题 sizing 必须按变体区分（HUG 用错会导致偏移）**：

标题 TEXT 的 `textAutoResize` 设置**取决于 Cardheader 变体**，用错会导致折行或 localX 偏移：

| 场景 | 标题 sizing | 原因 |
|------|------------|------|
| `Show Tag=true`（标题+tag 行内紧挨，如历史反馈卡片） | **HUG**（`WIDTH_AND_HEIGHT`）| 行内布局 TitleWithTag 会给标题分配固定宽度（如 w=66px）导致折行，HUG 让标题按内容宽度紧挨 tag |
| `Actiontype=Link/None`（标题独占一行，右侧 ActionText 或无） | **FILL**（`layoutGrow=1` + `layoutSizingHorizontal='FILL'`）| 这类变体用 grid 布局，标题设 HUG 会被 `place-items-start` 推到 localX=128 **反而偏移**；FILL 时标题 localX=0 左对齐且不折行（右侧 ActionText 占位） |

```js
const titleNode = header.findOne(n => n.type === 'TEXT' && n.name === 'header');
const showTag = header.componentProperties?.['Show Tag']?.value === 'true';
if (showTag) {
  titleNode.textAutoResize = 'WIDTH_AND_HEIGHT'; // HUG：行内标题+tag
} else {
  titleNode.textAutoResize = 'HEIGHT';
  titleNode.layoutGrow = 1;
  titleNode.layoutSizingHorizontal = 'FILL'; // FILL：独占行标题，localX=0
}
```

**同理，CardContent 内的 `Tittle medium` / `Body medium` 也须保持 FILL**（`layoutGrow=1` + `FILL`），否则 grid 布局下会出现 x=62/22/68 等偏移。出图后务必用 `Math.round(node.x) === 0` 全量自查所有文字节点。

#### Actiontype 语义规范

**两者都有箭头，不能以"有没有箭头"判断，应以交互行为为准。**

| 变体 | 箭头样式 | 正确使用场景 |
|------|---------|------------|
| `Actiontype=Link` | 向右灰色 arrow 图标（固定，不随状态变化） | 卡片级跳转入口：「全部」「查看」「更多」；点击后**页面跳转** |
| `Actiontype=Expand` | down/up arrow 图标（随 ExpandStated 变化） | 展开/收起交互；点击后**当前卡片内容展开或收起** |
| `Actiontype=None` | 无 | 纯标题展示，无交互操作 |

**Link 使用注意：**
- `Actiontype=Link` 的操作区必须复用正式 **TextLink M / Secondary**，并继承 TextLink 的18px Arrow L
  与18px行盒；不得在 Cardheader 内再次手拼文字和小号 Arrow。
- `ActionText` 内文案通过 `findOne(n => n.name === '文案')` 找到后直接赋值
- **禁止隐藏 `arrow` 节点**，`>` 箭头是规范的一部分，不可省略
- 文案只写目标操作名，不含箭头符号；箭头由组件自动提供

**Expand 使用注意：**
- `ExpandStated=Expand` → 显示「展开」+ down 图标（卡片当前为折叠态，点击可展开）
- `ExpandStated=Collapsed` → 显示「收起」+ up 图标（卡片当前为展开态，点击可收起）
- ⚠️ ExpandStated 命名与视觉**方向相反**：`Expand` 是展开按钮（折叠态），`Collapsed` 是收起按钮（展开态）
- 是否支持展开、默认是否展开、展开后展示哪些内容必须由业务状态矩阵分别定义；不得根据 Tag、
  StatusOverlay、失败原因或其他可选字段是否存在来推断可展开性。
- Link 与 Expand 的箭头均使用正式 Arrow `size=L`（18px）；不得因操作文字为14px而降为 S。

#### 样式规格

| 元素 | 字体 | 字号 / 行高 | 字重 | 颜色 |
|------|------|-------------|------|------|
| 标题 | PingFang SC | 16px / 16px | Semibold | `--text-primary` (#222) |
| 副标题 | PingFang SC | 14px / 14px | Regular | `--text-secondary` (#757575) |
| 操作文字 | PingFang SC | 14px / 14px | Regular | `--text-secondary` (#757575) |

- 标题行与副标题的间距固定为10px。
- 标题与行内 Tag 的间距固定为8px；这是 CardHeader 的局部组合值，不覆盖其他“文字 + Tag”场景的4px规则。
- 无副标题时标题、Tag和右侧操作按可见盒中心垂直对齐；有副标题时右侧操作与标题行顶边对齐。
- 标题或副标题实际折行为多行时，由 H5 运行时把对应行高切换为字号 × 1.5。

---

### 4.2 CardContent（卡片内容）

**生产组件，直接使用。** CardContent 是用于标准图文、列表和媒体内容的一种独立组件，
是 Content Slot 的可选内容之一；它不等同于 Content Slot，也不是其他内容组件的父级或所属分类。

#### 辅助入口选型

当入口同时满足以下条件时，使用 `CardContent / Subtle / Editorial / Floating`：它不是完成当前页面
主任务的必要步骤；移除后原主流程仍可完成；内容由标题、说明和一个只作用于当前内容块的局部操作组成。
这类入口通常表达补充方案、替代方案或辅助服务，不得升级为页面级高强调主按钮，也不得在现有
CardContent能够承载时建立页面私有入口卡片。

- 提交当前页面、确认当前选择或决定主流程是否继续：使用页面级 `Action Button Group`。
- 多个同等级功能菜单或导航入口：使用 `Entry Item / Group`。
- 是否“低强调”由操作依赖和页面任务判断，不由按钮文案、颜色或入口所在位置单独推断。

#### Figma 信息

| 属性 | 值 |
|------|-----|
| Node ID | `53:3274` |
| 类型 | COMPONENT_SET |
| 变体数量 | 10 个 |
| Component Set Key | `de76d55616005615dfed5df6425a12d6c53b4125` |

#### 属性定义

| 属性 | 类型 | 可选值 | 说明 |
|------|------|--------|------|
| `surface` | VARIANT | `pure` / `subtle` | 内容区底色（pure=透明，subtle=灰底 #F6F8FB） |
| `ContentLayout` | VARIANT | `Editorial` / `list` / `Media` | 内容布局类型 |
| `Media size` | VARIANT | `None` / `Medium` / `Large` | 图片尺寸（仅 Media 布局） |
| `Action` | VARIANT | `None` / `Floating` | 浮动操作类型 |
| `Show Title Medium#578:20` | BOOLEAN | `true` / `false` | 是否显示加粗正文标题 |
| `  ShowDescription#1146:21` | BOOLEAN | `true` / `false` | 是否显示描述文字；保留源属性前导空格 |
| `ShowFloatingButton#578:22` | BOOLEAN | `true` / `false` | 是否显示悬浮按钮 |
| `TitleText#1137:0` | TEXT | 文本内容 | 正文标题 |
| `DescriptionText #1114:132` | TEXT | 文本内容 | 描述文字 |

#### H5 属性映射

| H5 属性 | Figma 属性 / 内容 |
|---------|-------------------|
| `surface="pure|subtle"` | `surface` |
| `layout="editorial|list|media"` | `ContentLayout=Editorial/list/Media` |
| `media-size="none|medium|large"` | `Media size=None/Medium/Large` |
| `media-src` / `media-alt` | 可选业务图片及替代文本；未传 `media-src` 时保留灰色占位框，不创建 `<img>` |
| `action="none|floating"` | `Action=None/Floating` |
| `title` / `description` | `TitleText#1137:0` / `DescriptionText #1114:132` |
| `description-tone="default|error"` | 描述文字语义色；`error` 使用既有 `--v9-error`，不是新的 Figma Variant |
| `show-title="false"` | `Show Title Medium#578:20=false` |
| `show-description="false"` | `  ShowDescription#1146:21=false` |
| `show-floating-button="false"` | `ShowFloatingButton#578:22=false` |
| `action-text` | Floating 状态内嵌 Button Medium 文案 |
| `list-label/list-value`、`list-label-2/list-value-2` | List 两行可见文字；保持 CardContent 内部行结构 |

H5 只允许选择下方列出的10个源变体组合；不得仅因为公开属性存在，就生成 Figma 中不存在的组合。

#### Description 内容承载规则

- `description` 可以承载同一业务对象的一条或多条说明，多条内容通过换行保留，不拆成 CardContent
  外部的原因区、独立列表或多个重复段落。
- 多条原因属于同一业务对象，且每条没有独立操作、状态或图标时，统一写入一个 `description`。
- 原因需要警示语义时设置 `description-tone="error"`；组件复用既有 `--v9-error`，不新增颜色 Token。
- 只有内容具备独立交互或独立状态，且现有公开属性和 Slot 确实不能承载时，才按 workflow 评估
  页面本地组合；不得仅因 PRD 使用项目符号就创建新模块。

```html
<v9-cardcontent
  layout="media"
  media-size="large"
  title="车辆外观-右前"
  description="• 照片不清晰；作弊；非甄选物料照片。&#10;• 张贴非平台制作的标识、广告。"
  description-tone="error">
</v9-cardcontent>
```

#### ContentLayout 类型说明

**Editorial（编辑式内容）**
- 特征: 标题 + 正文段落 + 辅助说明
- 适用: 非结构化自然语言内容
- 结构: 垂直堆叠的文本块

**List（列表式内容）**
- 特征: 左右对齐的键值对 (Label: Value)
- 适用: 结构化信息展示
- 结构: 左黑字、右灰字成对排列

**Media（媒体式内容）**
- 特征: 灰色媒体占位或业务图片 + 文字横向布局
- 适用: 需要预留缩略图位置，或显式传入业务图片的内容展示
- 结构: 图左文右，水平 Flex

Media 的默认状态是复用 `--v9-surface-inset` 的灰色占位框，不做图片填充。只有业务明确提供图片时，
H5 才传 `media-src` / `media-alt` 并在占位框内创建 `<img>`；不得用示例图代替默认占位状态。

#### 布局选型规范

**需要展示图片时必须显式切换，不可沿用默认 Editorial。**

| 场景 | ContentLayout | Media size | 说明 |
|------|--------------|-----------|------|
| 纯文字（标题 + 描述） | `Editorial` | `None` | 默认布局，无图片 |
| 图片 + 状态蒙层 | `Media` | `Large` | 内置 StatusOverlay，无需额外引入 |

**Media Large 内置 StatusOverlay**，设置方式：
```js
cc.setProperties({
  'ContentLayout': 'Media',
  'Media size': 'Large',
  'surface': 'pure',        // Media Large 大图自带层级区分，不需要灰底
  'Action': 'None',         // 当前发布的 Media Medium / Large 变体固定使用 None
});
// StatusOverlay 已内置，直接 findOne 后设置 State
const overlay = cc.findOne(n => n.type === 'INSTANCE' && n.name === 'StatusOverlay');
overlay.setProperties({ 'State': 'failed' }); // failed / Success / None
```

H5 使用 `media-size="large"` 选择对应媒体结构，并通过命名 Slot 复用正式 StatusOverlay；
以下默认示例不传 `media-src`，组件显示灰色占位框且不创建图片节点。无蒙层状态直接省略该 Slot，
不得用页面私有 `.photo-frame` 重画占位框、图片、圆角或蒙层：

```html
<v9-cardcontent
  layout="media"
  media-size="large"
  surface="pure"
  description="质检地点">
  <v9-status-overlay slot="media-overlay" state="failed"></v9-status-overlay>
</v9-cardcontent>
```

业务明确提供图片时，再增加 `media-src="inspection.jpg"` 与有效 `media-alt`；灰色占位框本身不需要
替代文本。Media Medium / Large 当前都必须保持 `action="none"`，不得生成 Media + Floating。

#### MediaSize 规格

| 尺寸 | 宽×高 | 比例 | 使用场景 |
|------|-------|------|---------|
| `None` | 无 | - | 纯文字内容 |
| `Medium` | 40×40px | 1:1 | 图标展示，辅助理解 |
| `Large` | 85×65px | 约 4:3 | 大图展示，可叠加 StatusOverlay |

#### Surface 规格

| Surface | 背景色 | 内边距 | 圆角 | 使用场景 |
|---------|--------|--------|------|---------|
| `pure` | 透明 | 无 | 无 | 页面一级内容，无需视觉分割 |
| `subtle` | `--surface-inset` (#F6F8FB) | 12px | 12px | 卡片内部需要区分不同信息区域、多个卡片紧密排列时区分内容区 |

#### Surface 选择规则

**核心作用**：用灰底区分 Header 和 Content 的视觉层级

**使用 `subtle` 的条件**（同时满足）：
1. Header 中有副标题（`ShowSubtitle=true`）
2. **且不是** Media Large 模式

**使用 `pure` 的条件**（任一满足）：
1. Header 没有副标题（`ShowSubtitle=false`）
2. Media Large 模式（大图本身能区分层级，不需要灰底）

**判断流程**：
```
Header 是否有副标题？
├─ 否 → pure
└─ 是 → 是否 Media Large？
         ├─ 是 → pure（大图自带区分效果）
         └─ 否 → subtle（需要灰底区分层级）
```

**示例**：
- Header 有副标题 + Editorial → `subtle`
- Header 有副标题 + List → `subtle`
- Header 有副标题 + Media Large → `pure`（例外）
- Header 无副标题 + 任何布局 → `pure`

> **注意**：Surface 选择与 ContentLayout 类型无关，仅由 Header 副标题和 Media Large 决定。

#### 间距规格

**Content 内部多个平行内容的间距规则**：

| Surface | MediaSize | 间距 (gap) | 原因 |
|---------|-----------|-----------|------|
| `pure` | `None` / `Medium` | **16px** | 透明背景，需要间距区分内容块 |
| `pure` | `Large` | **8px** | 大图本身起到分割作用，缩小间距 |
| `subtle` + `Floating` | 任意 | **8px** | 灰底包裹已提供视觉分割，使用紧凑间距 |
| `subtle` + `None` | 任意 | **12px** | 灰底包裹已提供视觉分割 |

**其他间距**：

| 场景 | gap |
|------|-----|
| Header ↔ Content | 12px |
| Content ↔ Footer | 16px |
| Editorial 标题 ↔ 描述 | Default 10px；Error 8px；`pure` 与 `subtle` 一致 |
| Floating 文案区标题 ↔ 描述 | Default 10px；Error 8px |
| Floating 文案区 ↔ 按钮 | 4px |
| List 行 ↔ 行 | 16px |
| Media 图片 ↔ 文字区 | 12px |
| Media 文字区标题 ↔ 描述 | Default 10px；Error 8px |

- Editorial `subtle + Action=None` 保持四周12px Padding；标题与描述均为14px，单行行高14px。
- CardContent 的标题、描述或列表文字实际折行为多行时，行高切换为字号 × 1.5；不得用固定高度裁切。

**规则总结**：
- **Pure + 无大图** → 16px
- **Pure + Large 图** → 8px（图片提供分割）
- **Subtle + Floating** → 8px（灰底提供分割）
- **Subtle + None** → 12px

#### ✅ 实现 CardContent 前必须检查

1. 找到对应的 CardHeader，确认 `ShowSubtitle` 是 `true` 还是 `false`
2. 确认 `contentLayout` 是否为 `Media Large`
3. 按下方 Surface 选择规则得出 `surface` 值，**不得默认使用 `pure`**

#### ✗ 禁止添加（Web/HTML 实现时）

| 位置 | 禁止项 | 原因 |
|------|--------|------|
| `CardContent / list` 行与行之间 | 分割线（border-bottom 等） | 规范未描述，不得自行补充 |
| `CardHeader` 与 `CardContent` 之间 | 分割线（.divider、border-bottom 等） | 规范未描述，不得自行补充 |
| `CardContent` 与 `CardFooter` 之间 | 分割线 | 规范未描述，不得自行补充 |

---

### 4.3 CardFooter（卡片底部）

Footer 是 CellCard 的操作区域 Slot，不限定为某一个组件。单个主操作可以复用
**Button Full-width**（Node ID: `1094:4049`）；其他符合 Footer Slot 合同的正式操作组件也可以使用。
Footer 内部组件负责自身状态和排列，CellCard 只负责 Content ↔ Footer 的结构关系。

- Footer 可用宽度为319px（351px卡片减去左右各16px Padding）；其中的 Button Full-width 必须 Fill，
  不得继续保持Action Button Group场景下的335px结果。
- Header + Footer 且无 Content 时，Header → Footer 固定16px；存在 Content 时，Content → Footer固定16px。
- 16px由 CellCard Shell 使用既有 `space/space/lg` / `--v9-space-lg` 提供，不得再给按钮增加
  `margin-top`，避免间距叠加。

---

### 4.4 组合使用规范

#### 完整卡片结构

```
┌─────────────────────────────────┐  351px
│  Header Slot                     │
│  ┌─────────────────────────────┐│
│  │ Cardheader 或其他兼容组件     ││
│  └─────────────────────────────┘│
├─────────────────────────────────┤
│  Content Slot                    │
│  ┌─────────────────────────────┐│
│  │ 单一组件 / 自由组合 / Pattern ││
│  └─────────────────────────────┘│
├─────────────────────────────────┤
│  Footer Slot                     │
│  ┌─────────────────────────────┐│
│  │ 正式操作组件（按需）          ││
│  └─────────────────────────────┘│
└─────────────────────────────────┘
```

#### 组件间距

| 信息关系 | 默认 gap |
|----------|----------|
| 同一内容组 | 4px |
| 同一信息模块 | 8px |
| 不同结构区域 | 16px |

标准 CellCard 的 Header ↔ Content 默认12px，Content ↔ Footer默认16px；省略 Content 时
Header ↔ Footer仍为16px。Slot 名称本身不决定间距；若具体 Card Pattern 的信息关系不同，
由该 Pattern 明确覆盖。

#### 容器规格

CellCard Shell 的外层容器规格：

| 属性 | 值 |
|------|-----|
| 宽度 | **351px** |
| 圆角 | `Radius/Large` **16px**（页面级卡片） |
| 内边距 | 16px |
| 阴影 | Level 1 — `0px 4px 12px rgba(15, 40, 77, 0.06)` |
| 背景 | `--surface-default` (#FFFFFF) |

**圆角层级规则**：

| 层级 | 圆角 | Token | 说明 |
|------|------|-------|------|
| 页面级卡片（外层容器） | **16px** | `Radius/Large` | 直接放置在页面内容区的卡片 |
| 卡片内子卡片 | **12px** | `Radius/Medium` | 嵌套在卡片内的子块，如 CardContent `subtle` 模式下的内容区 |

#### 非穷举组合示例

以下示例只展示正式组件如何进入 Slot，**不是 CellCard 内置模式、属性枚举或业务 Variant**。
只有组合稳定、会重复使用且已有正式组件时，才升级为 Card Pattern 并登记映射。

**示例 1: 信息展示卡片（无操作）**
- Header: Actiontype=None
- Content: surface=subtle, contentLayout=list

**示例 2: 带链接的内容卡片**
- Header: Actiontype=Link, ShowSubtitle=true
- Content: surface=pure, contentLayout=Editorial

**示例 3: 可展开的列表卡片**
- Header: Actiontype=Expand
- Content: surface=subtle, contentLayout=list

**示例 4: 带底部按钮的操作卡片**
- Header: Actiontype=None, ShowSubtitle=true
- Content: surface=pure, contentLayout=Editorial
- Footer: Button Full-width (Primary, Default)

**示例 5: 媒体卡片（带大图和状态蒙层）**
- Header: Actiontype=None
- Content: surface=pure, contentLayout=Media, mediaSize=Large
- StatusOverlay: 叠加在图片上

**示例 6: 带悬浮按钮的内容卡片**
- Header: Actiontype=None
- Content: surface=subtle, showFloatingButton=true

---

### 4.5 自由组合、Content Pattern 与 Card Pattern

#### 自由组合

当组件只在当前页面使用，或其数量、顺序和业务关系不稳定时，在对应 Slot 内按4/8/16px关系组合。
自由组合可以使用 Auto Layout / H5 Stack 辅助结构，但不得为了组合而复制已有组件内部节点。

#### Content Pattern

只有 Content Slot 内部的组件组合稳定且会重复使用时，才建立 Content Pattern。Pattern 负责模块顺序、
显隐合同和模块间距；内部组件仍按自身分类复用，不迁入 `Content` 所属目录。

#### Card Pattern

只有 Header、Content、Footer 的整卡组合稳定且会重复使用时，才建立 Card Pattern。Card Pattern 必须
以 CellCard Shell 为容器，不得复制 CellCard 的 Surface、圆角、阴影和 Padding。

#### Pattern 升级边界

| 情况 | 处理 |
|------|------|
| 只统一间距和隐藏收拢，组合不重复、顺序不稳定 | 自由组合 |
| Content 内模块组合稳定且重复 | Content Pattern |
| Header + Content + Footer 整体稳定且重复 | Card Pattern |
| 只是 Surface、显隐、状态或尺寸变化，骨架不变 | 组件属性或 Variant |
| 业务模块数量、顺序或类型改变 | 不增加 CellCard 业务 Variant |

---

### 4.6 命名约定

| 组件 | 属性名 | 用途 |
|------|--------|------|
| CellCard | `Content Slot` | 承载任意符合 Slot 合同的单一组件、自由组合或 Content Pattern |
| CardHeader | `SubtitleText` | 标题下方的副标题（灰色小字） |
| CardContent | `descriptionText` | 正文标题下方的描述文字 |

**注意**：Content Slot 是卡片区域，CardContent 是一种标准图文组件；两者不得混用。
Header 的 `SubtitleText` 和 CardContent 的 `descriptionText` 仍是不同层级的内容。

---

## 五、Alert（提示条）

全宽或卡片内提示条，支持信息/警告两种类型，两种尺寸。

**Figma 当前源**：页面「控件」，Node `53:2872`，Component Set Key
`e6ca9c4ca52c7057d33ed4fb958331f12f4863b2`。

Alert 作为独立模块嵌入351px CellCard 内容区时使用 `small`；这是 Alert 的嵌入尺寸规则，
不属于 CellCard 的整体组合规则。

> ⚠️ **Alert 是独立模块升级项，非警示信息的默认样式。** 使用前先查 `custom-rules.md`「模块复用优先级规则（警示信息：副标题槽 vs Alert）」：副标题/描述槽空闲时，应优先复用该槽位 + 警示色（`--error` #FF1930）承载警示，**不要默认新增 Alert**；仅当槽位已占用且需独立强调时才升级为 Alert。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| variant (类型) | `info` / `warning` | 信息提示 / 警告提示 |
| mode (模式) | `standard` / `contained` | 全宽(375px) / 卡片内(355px, 圆角12px) |
| action (操作) | `link` / `pure` | 带链接操作 / 纯展示 |
| size (尺寸) | `Default` / `small` | 默认42px / 小型Link 42px、Pure 36px |
| position (位置) | `top` / `default` | 顶部 / 默认 |
| 展示图标 | Boolean | 控制左侧图标显示 |
| 展示按钮 | Boolean | 控制右侧箭头按钮显示 |
| 展示图标2 | Boolean | 控制左侧图标显示（备用） |
| 展示按钮2 | Boolean | 控制右侧箭头按钮显示（备用） |

### 默认显隐

| 组合 | 左侧图标 | 右侧箭头 |
|------|----------|----------|
| Default + link | 显示 | 显示 |
| Default + pure | 显示 | 隐藏 |
| small + link | 显示 | 隐藏 |
| small + pure | 隐藏 | 隐藏 |

`show-icon` 与 `show-button` 可显式覆盖上述默认值。info 使用14px喇叭图形置于18px槽位，warning
使用18px圆形感叹号；箭头固定18px并跟随类型色。H5 必须复用 `assets/components/alert/` 中从
Figma 固化的原始 SVG，不得使用字符 `i`、`!` 或灰色通用箭头代替。

### 样式

| 类型 | 背景色 | 文字强调色 | 图标色 |
|------|--------|-----------|--------|
| info | `#FFF5E8` | `--primary` (#FF6435) | `--primary` (#FF6435) |
| warning | `#FFEAE8` | `--错误色` (#FF1930) | `--错误色` (#FF1930) |

### 规格

| 模式 | 宽度 | 圆角 | 内边距 | 使用场景 |
|------|------|------|--------|---------|
| standard | 375px | 0 | 默认上下12px、左右10px | 通栏使用，贴边全宽，无圆角 |
| contained | 355px | 12px | Default上下12px、左右10px；small依action为左10/16px、右16px | 非通栏使用，有页边距，有圆角 |

### 内部布局

- 内容容器 (Frame 26/27): **FILL 宽度**，自适应父容器宽度
- 文案文字: **FILL 宽度 + HEIGHT 自适应**，多行时在容器内折行，保持右侧固定间距
- info 变体内容帧: `Frame 26`，warning 变体内容帧: `Frame 27`

### 尺寸与文字规格

| 尺寸 | 高度 | 字体 | 字号 | 字重 | 使用场景 |
|------|------|------|------|------|---------|
| Default | 42px | PingFang SC | 14px / 14px | Semibold | 独立模块使用，作为页面级提示条 |
| small + link | 42px | PingFang SC | 12px / 12px | Regular | 卡片内部带链接提示 |
| small + pure | 36px | PingFang SC | 12px / 12px | Regular | 卡片内部纯展示提示 |

- 操作链接 (`action=link`): 右侧显示 Arrow L；`action=pure` 不显示操作
- `show-icon` / `show-button` 只映射源 Boolean 显隐，不创建新的 Variant
- 图标间距: 8px (图标与文字之间)

---

## 六、arrow（图标按钮）

通用图标组件，支持多种颜色/尺寸/图标组合。

**Figma 当前源**：页面「控件」，Node `53:3541`，Component Set Key
`039a24a1cd5b5668c8fbb594cd3215fd900cd167`。当前组件集为48个变体，3种尺寸、
4种图标与4种颜色完整组合；旧 Node `376:1043` 不再作为当前源。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| arrow icon (颜色) | `grey` / `white` / `orange` / `red` | 4 种颜色；属性名包含空格，以当前源组件为准 |
| size (尺寸) | `L` / `M` / `S` | 大(18px) / 中(14px) / 小(10px) |
| icon (图标) | `arrow` / `down` / `up` / `close button` | 右箭头 / 向下 / 向上 / 关闭按钮 |

### 尺寸规格

| 尺寸 | 图标大小 |
|------|---------|
| L | 18px |
| M | 14px |
| S | 10px |

### 颜色映射

| 颜色 | 色值 |
|------|------|
| grey | `text secondary` (#757575) |
| white | `text Inverted` (#FFFFFF) |
| orange | `primary` (#FF6435) |
| red | `error` (#FF1930) |

### 图标类型

| 图标 | 说明 | 用途 |
|------|------|------|
| arrow | 右向折线图标 | 链接跳转、更多操作 |
| down | 向下折线图标 | 展开状态 |
| up | 向上折线图标 | 收起状态 |
| close button | 交叉关闭图标 | 关闭、删除操作 |

---

### 6.1 Badge（角标）

用于数量、溢出、新内容与未读点提示。Badge 是紧凑的附着型状态组件，不承担 Tag 的分类或长状态文案。

**Figma 当前源**：页面「控件」，Node `1:1536`，共4个 `type` 变体。

#### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| type | `count` / `overflow` / `dot` / `label-new` | 数量 / 溢出 / 未读点 / 新内容 |
| Text | 文本 | 仅 `count` 开放数量文字，默认“9” |

#### 尺寸与结构

| type | 尺寸 | 内部结构 | 字体 |
|------|------|----------|------|
| `count` | 最小14 × 14px | 数字左2px、右4px；H5上下各1px光学校正；Full圆角 | Barlow Condensed Bold Italic 12/12 |
| `overflow` | 24 × 14px | 固定“99+”；数字左2px、右4px；H5上下各1px光学校正；Full圆角 | Barlow Condensed Bold Italic 12/12 |
| `label-new` | 18 × 14px | 固定“新”；水平4px、垂直2px内边距；Full圆角 | PingFang SC Semibold 10/10 |
| `dot` | 10 × 10px | 2px白色外环包裹6 × 6px主色圆点 | 无文字 |

#### 视觉规则

- `count`、`overflow`、`label-new` 使用 `primary` 背景与 `on primary` 文字。
- `dot` 外层使用 `on primary`，内点使用 `primary`。
- 14px高的数字角标使用组件本地的窄体斜体字形；该值不升级为全局 Number 字阶或字体 Token。
- 数量超过两位时使用 `overflow`，不得继续拉长 `count`；新内容只使用固定 `label-new` 文案。
- H5宿主边界必须贴合Badge可见边界，不得继承父级文字行高形成额外上下空间。
- 数字型`count`与`overflow`使用左2px、右4px内边距；中文`label-new`保持左右各4px，不套用数字校正。
- Badge附着在文字右上角时，以可见边界计算：左侧与文字右边缘重叠2px，顶部高于24px文字行盒2px；
  该定位属于“文字 + Badge”的组合规则，不改变Badge单体尺寸，也不把Badge伪装成Tabs自身的变体或Slot。

---

## 七、Status Bar（底部 Home Indicator）

iPhone 底部手势指示器组件，2 种主题。它不是 App bar 内部的顶部系统状态区；两者名称相近，
但结构、位置与用途不同。

**Figma 当前源**：页面「控件」，Node `1:1545`。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| theme | `light` / `dark` | 浅色背景主题 / 深色背景主题 |

### 规格

| 属性 | 值 |
|------|-----|
| 组件尺寸 | 375 × 34px |
| 指示横条 | 134 × 5px，Full圆角，水平居中 |
| 横条位置 | 顶部20px、底部9px |
| `theme=light` | `on-surface default primary` (#222222) |
| `theme=dark` | `on primary` (#FFFFFF) |

### 使用规则

- 无底部操作区时，组件作为页面底部的34px区域正常占位。
- 有底部操作区（Bottom Area）时，将组件覆盖在该区域的背景上，不额外增加一行34px结构。
- 使用 App bar 时仍可按页面底部结构放置本组件；不要把它误判为重复的顶部状态栏。
- App bar 内部的44px顶部系统状态区继续由 App bar 自身维护，不从本组件替换或拼装。

---

## 八、返回（返回按钮）

导航返回按钮，固定尺寸。

当前 Figma Node `200:1537` 是 Group，不是已发布 Component；H5 `<v9-back>` 因此登记为
`kind=internal`，主要供 Appbar 和非标准容器内部复用，不得作为双端正式组件单独计数。

### 规格

| 属性 | 值 |
|------|-----|
| 尺寸 | 40 × 40px |
| 内含图标 | 返回箭头 |

---

## 九、pic（图片占位）

图片占位组件。

### 规格

| 属性 | 值 |
|------|-----|
| 尺寸 | 224 × 120px |
| 用途 | 卡片内图片占位 |

---

## 十、TextLink（文字链接）

文字链接组件，支持 4 种重要性等级和 3 种尺寸。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| importance (重要性) | `Important` / `Secondary` / `Theme` / `Error` | 主要 / 次要 / 主题 / 错误 |
| size (尺寸) | `L` / `M` / `S` | 大 / 中 / 小 |

### 尺寸规格

| 尺寸 | 宽度 | 高度 | 字号 |
|------|------|------|------|
| L | 50px | 18px | 16px |
| M | 46px | 18px | 14px |
| S | 42px | 18px | 12px |

### 颜色映射

| 重要性 | 文字色 | 图标色 |
|--------|--------|--------|
| Important | `--primary` (#FF6435) | `--primary` (#FF6435) |
| Secondary | `--text-secondary` (#757575) | `--text-secondary` (#757575) |
| Theme | `--text-inverted` (白色) | `--text-inverted` (白色) |
| Error | `--error` (#FF1930) | `--error` (#FF1930) |

### 文字规格

- 字体: PingFang SC Regular
- L: 16px，行高 100%
- M: 14px，行高 100%
- S: 12px，行高 100%
- 对齐: 右对齐

### 结构

```
┌──────────────────┐
│  文案  [arrow]   │
└──────────────────┘
```

- 文案 + 右侧箭头图标
- 箭头图标颜色与文字颜色一致
- L / M / S 三种文字尺寸均固定使用 Arrow 的 L 尺寸（18px）；TextLink 的 `size`
  只控制文字字号，不得据此缩小内部箭头。
- Figma 与 H5 都使用18px行盒，文字按字号等高（16/14/12px），与18px箭头垂直居中；
  组件不再额外增加上下 Padding，也不得依靠基线空白补偿。

---

## 十一、ExpandLink（展开/收起链接）

可切换展开/收起状态的文字链接组件，支持 4 种重要性等级和 3 种尺寸。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| importance (重要性) | `Important` / `Secondary` / `Theme` / `Error` | 主要 / 次要 / 主题 / 错误 |
| size (尺寸) | `L` / `M` / `S` | 大 / 中 / 小 |
| state (状态) | `Expand` / `Collapse` | 展开态 / 收起态 |

### 尺寸规格

| 尺寸 | 宽度 | 高度 | 字号 |
|------|------|------|------|
| L | 50px | 18px | 16px |
| M | 46px | 18px | 14px |
| S | 42px | 18px | 12px |

### 颜色映射

| 重要性 | 文字色 | 图标色 |
|--------|--------|--------|
| Important | `--primary` (#FF6435) | `--primary` (#FF6435) |
| Secondary | `--text-secondary` (#757575) | `--text-secondary` (#757575) |
| Theme | `--text-inverted` (白色) | `--text-inverted` (白色) |
| Error | `--error` (#FF1930) | `--error` (#FF1930) |

### 文字规格

- 字体: PingFang SC Regular
- L: 16px，行高 100%
- M: 14px，行高 100%
- S: 12px，行高 100%
- 对齐: 右对齐

### 状态说明

| 状态 | 文案 | 图标方向 |
|------|------|---------|
| Expand | "展开" | down arrow 图标 |
| Collapse | "收起" | up arrow 图标 |

### 结构

```
┌──────────────────┐
│  展开/收起 [arrow]│
└──────────────────┘
```

- 文案根据状态切换："展开" / "收起"
- 箭头图标根据状态切换方向
- 图标颜色与文字颜色一致
- L / M / S 三种文字尺寸均固定使用 Arrow L（18px）；`size` 只控制文字字号。
- 组件可见行盒固定18px，文字与Arrow在行盒内垂直居中，不增加上下Padding或基线补偿。

---

## 十二、Tag（标签）

标签组件，用于状态标记、分类展示，支持多种样式变体。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| size (尺寸) | `Default` / `S` | 默认 / 小 |
| status (状态) | `Default` / `success` / `error` / `tertiary` | 主色 / 成功 / 错误 / 次要 |
| variant (变体) | `outline` / `light` / `solid` | 描边 / 浅色填充 / 实心填充 |

### 尺寸规格

| 尺寸 | 内边距 | 字号 |
|------|--------|------|
| Default | 四周 4px | 12px |
| S | 四周 2px | 12px |

### 样式变体

#### outline（描边）

| 状态 | 边框色 | 文字色 | 背景 |
|------|--------|--------|------|
| Default | `--primary` (#FF6435) | `--primary` (#FF6435) | 透明 |
| success | `--success` (#00B42A) | `--success` (#00B42A) | 透明 |
| error | `--error` (#FF1930) | `--error` (#FF1930) | 透明 |
| tertiary | `--text-tertiary` (#999) | `--text-secondary` (#757575) | 透明 |

#### light（浅色填充）

| 状态 | 背景色 | 文字色 |
|------|--------|--------|
| Default | #FFF0EB | `--primary` (#FF6435) |
| success | #DBFFD7 | `--success` (#00B42A) |
| error | #FFF0EB | `--error` (#FF1930) |
| tertiary | `--surface-canvas` (#F0F1F5) | `--text-secondary` (#757575) |

#### solid（实心填充）

| 状态 | 背景色 | 文字色 |
|------|--------|--------|
| Default | `--primary` (#FF6435) | `--text-inverted` (白) |
| success | `--success` (#00B42A) | `--text-inverted` (白) |
| error | `--error` (#FF1930) | `--text-inverted` (白) |
| tertiary | `--text-tertiary` (#999) | `--text-inverted` (白) |

### 文字规格

- 字体: PingFang SC Regular
- 字号: 12px
- 行高: 100%
- 对齐: 居中
- 圆角: 4px

### 默认使用规范

| 属性 | 默认值 | 说明 |
|------|--------|------|
| variant | `light` | 默认使用浅色填充样式 |
| size | `Default` | 默认使用标准尺寸 |

### 与文字组合间距

当 Tag 与文字横向组合使用时，间距为 **4px**。

H5 的 `<v9-tag>` 自定义元素是公开组件宿主，Shadow DOM 内的 `.v9-tag` 是实际视觉节点。宿主必须使用
`inline-flex` 并消除自身文字行盒，使宿主宽高与内部视觉节点完全一致；不得因继承父级字号或行高，
在 Tag 外部额外产生2px高度、基线空隙或点击区域偏差。

```
┌────────────────────────────┐
│  文字内容 ←4px→ [Tag]       │
└────────────────────────────┘
```

### 通用位置规则

Tag 的摆放位置由**语义**决定，与所在容器（Cardheader / 列表行 / 自定义内容区）无关：

| 语义类型 | 说明 | 布局方式 |
|---------|------|---------|
| **状态指示** | 表达该条内容的整体状态（如审核中、已通过） | 放右侧，与左侧内容 `SPACE_BETWEEN` |
| **内容修饰** | 标注文字本身的属性（如类型、来源） | 紧跟文字，inline，间距 4px |

- 同一行内只有一种语义时直接按上表选择
- 若同时存在状态指示和内容修饰，状态指示优先走右侧，修饰 Tag 跟随对应文字

### 状态语义

| 状态 | 语义 | 使用场景 |
|------|------|---------|
| `Default` | 无特定功能含义 | 常规标签、分类标记 |
| `success` | 成功 | 完成、通过、已生效 |
| `error` | 失败 | 错误、拒绝、异常 |
| `tertiary` | 弱化 | 不需关注、已过期、次要信息 |

---

## 十三、Tabs（标签页）

同一 Tabs 语义下保留 Line 与 Card 两种形式，但二者切换范围不同：Line负责页面级或大区域内容切换；
Card只负责同一卡片内部2–3组同级内容切换。Rounded不在当前Skill范围内。

**Figma 当前统一源**：主规范库 Node `274:2175`，Component Set Key
`a681c138c3d45ba5171ab72ca575931f4aefa65d`，共23个变体。Line与Card不再分别引用旧源。

> Line的 `Distribution=Equal/Start` 与 `Show Background=true/false` 已完成Figma、正式H5 Runtime、
> 显式映射和自动校验，可直接通过同一个 `<v9-tabs>` 调用。
> 当前源中 `variant=line, amount=2, Active=2, Distribution=Equal` 为375×40px，与统一42px合同不一致；
> 正式接入前须在Figma修正并重新发布，不为该单一异常增加H5特例。

### 形式与选型

| 形式 | 数量 | 使用范围 | 禁止用途 |
|------|------|---------|---------|
| Line | 2 / 3 / 4 | 页面级分类、大区域内容切换 | 不用于卡片内部的局部内容切换 |
| Card | 2 / 3 | 同一卡片内同级内容切换 | 不承担页面导航，不嵌套第二层Tabs |

### Line 规格

| 属性 | 值 |
|------|-----|
| 宽度 / 高度 | 375×42px；使用时充满屏幕宽度 |
| Distribution | `Equal` / `Start`；默认`Equal` |
| 背景 | `Show Background=true`为白色 (#FFFFFF，默认)；`false`为透明 |
| Equal布局 | 上12px、下2px、左右8px；选项占据等宽点击区，内容居中 |
| Start布局 | 上12px、下2px、左右12px；选项内容左对齐，视觉项间距固定24px |
| 选中文字 | PingFang SC Semibold，16px（单行 = 字号），主色 (#FF6435) |
| 未选中文字 | PingFang SC Regular，16px（单行 = 字号），次要文字色 (#757575) |
| Indicator | 32×4px，圆角2px；与文字层间隔8px，下方保留2px容器 Padding |

Line共18个结构变体：Equal与Start各覆盖9个Active状态；`Show Background`是Line布尔属性，
不增加结构变体。切换Active时只改变文字状态与Indicator位置，禁止detach后手工移动选中线。

### Line 模式选择

先判断分布方式，再独立判断是否需要背景；对齐方式与背景没有绑定关系，四种组合均可成立。

| 判断维度 | 使用条件 | 不应使用 |
|---------|---------|---------|
| `Distribution=Equal` | 2–4个选项同层级、同重要度，需要占满容器并获得相同点击区域；文案长度接近 | 仅因为选项少就强制均分；文案差异过大仍压入等宽栏 |
| `Distribution=Start` | 局部筛选、浏览维度或次级分类；文案长度差异明显，页面更重视信息效率和自然留白 | 用于制造随意疏密；把24px改成页面私有间距 |
| `Show Background=true` | Tabs自身形成独立导航带、需要与页面底色分层、存在吸顶/覆盖滚动内容，或底层对比度不稳定 | 父级已经提供完整Surface且白底会制造重复横条 |
| `Show Background=false` | Tabs嵌入已有明确Surface或连续背景，需要与父级形成一个整体，且文字和Indicator对比度稳定 | 复杂图像、低对比背景、吸顶后直接覆盖滚动内容 |

- Equal表达结构上的同权与稳定分栏，不等于整个组件在页面中居中摆放。
- Start表达内容驱动的横向占用；项宽随文案，项与项之间的视觉距离固定24px。
- 透明背景只移除Tabs自身Surface，不改变42px高度、内边距、文字、Indicator或交互。
- 背景不足以保证对比度时，必须改用白底，不得给透明模式临时增加描边、阴影或文字特效补救。

### Line 公开属性与交互

| 属性 | 合同 |
|------|------|
| `items` | 逗号或竖线分隔的2–4项文案，顺序对应Figma的`amount`与Label属性 |
| `active` | 从1开始，自动限制在当前项数范围内；更新时只切换选中态与Indicator位置 |
| `distribution` | `equal` / `start`，默认`equal` |
| `show-background` | `true` / `false`，默认`true`；属性缺省、空值或`true`均显示白底 |
| 交互 | 点击、左右方向键、Home与End均更新Active，并派发`v9-change.detail.active` |

Card调用时忽略`distribution`与`show-background`，不得用两个Line专属属性改变Card外观。

### Card 规格

| 属性 | 值 |
|------|-----|
| 宽度 | 固定351px |
| Header | 固定43px；2项或3项等宽分栏 |
| 外层 | 白色Surface，16px圆角；全部Active状态统一使用Level 1阴影 |
| 标签 | Noto Sans SC Medium，16/16；选中为主文字色，未选中为次要文字色 |
| 文案行为 | 单行、不折行；超出各自展示宽度时末尾省略 |
| Content | 自适应Slot，四周Padding 16px；默认内容为Entry Item |
| 高度 | 随Slot内容自适应；同一使用组的不同Tab内容按最高内容统一高度，切换时容器不跳动 |

### Card 公开内容边界

| 能力 | 合同 |
|------|------|
| 标签 | `items`提供2或3项；`active`从1开始控制当前项 |
| 内容 | 使用 `panel-1`、`panel-2`、`panel-3` 命名Slot，分别对应各标签内容 |
| 默认内容 | 未提供某个面板Slot时，使用该标签对应的Entry Item占位内容 |
| 切换 | 点击、左右方向键、Home与End均更新Active，并派发包含当前序号的变更事件 |

Card共5个正式Figma状态：2项的Active 1/2，以及3项的Active 1/2/3。三段超长标签同时出现时，
仍必须保持等宽、单行与省略；该场景是极限校验，不新增第6个组件变体。

### Card 结构与交互

```
┌────────── Header 43px ──────────┐
│       选项一   选项二   选项三   │  2或3项等宽
├─────────────────────────────────┤
│  16px                           │
│      Content Area / Adaptive    │  内容Slot
│                           16px  │
└─────────────────────────────────┘
```

- 选中形状、非选中底色与分割关系跟随Active状态，不允许只换文字颜色而保留错误曲线。
- 点击标签只切换当前Card内对应内容；键盘操作、选中语义和内容显隐必须同步。
- 内容高度不一致时，H5按同组面板实际最大高度自动统一；Figma实例由使用者按最高内容设置同组高度。
- Card已完成Figma发布回读、正式H5 Runtime、固定资产与显式映射，可作为正式组件能力使用。

---

## 十四、StatusOverlay（状态蒙层）

叠加在图片上的状态指示组件，用于表达图片所代表条目的状态。

**Figma 当前源**：页面「控件」，Node `53:3251`，Component Set Key
`782146985226886d1e121f8d6095e8713c821bc5`。H5 成功、失败图标必须使用该源组件导出的
`assets/components/status-overlay/success.svg` 与 `failed.svg`，不得改用字符、CSS图形或运行时内联近似路径。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| State (状态) | `Success` / `failed` | 成功 / 失败 |

### 规格

| 属性 | 值 |
|------|-----|
| 高度 | 35px |
| 宽度 | 与图片宽度一致 |
| 圆角 | 底部左右 12px（与图片圆角保持一致） |

进入 CardContent `Media size=Large` 的85×65px媒体框时，StatusOverlay 最终尺寸必须为 **85×35px**，
左右贴齐媒体框、底部间距为0。该尺寸是父级媒体宽度与组件35px固定高度共同形成的结果，不新增尺寸变体。

### 样式

| 状态 | 渐变背景 | 图标 | 文案 |
|------|---------|------|------|
| Success | 从透明到 `#222222` | Figma源 `success.svg` | "已通过" |
| failed | 从透明到 `#DE4545` | Figma源 `failed.svg` | "未通过" |

- 渐变方向: 从上到下 (top → bottom)
- 上方透明，下方实色

### 内部布局

| 属性 | 值 |
|------|-----|
| 图标尺寸 | 12 × 12px |
| 图标与文字间距 | 4px |
| 文字颜色 | `--surface-variant` (白色) |
| 字体 | PingFang SC Regular 12px / 12px |

### 使用规范

| 规则 | 说明 |
|------|------|
| 最小图片宽度 | 70px（宽度小于 70px 的图片不可使用） |
| 对齐方式 | 与图片底部对齐 |
| 宽度 | 与图片宽度保持一致 |

### 结构

```
┌─────────────────────────┐
│                         │  图片区域
│                         │
│  ┌───────────────────┐  │
│  │ 渐变蒙层           │  │  35px
│  │   [图标] 状态文案   │  │
│  └───────────────────┘  │
└─────────────────────────┘
```

---

## 十五、Selection Control（选择控件）

18×18px 的基础选择控件，用于复选和单选。组件保留 Figma 当前两条属性轴；禁用状态继续作为
`state` 的取值，不拆分为新的 Boolean 属性。

**Figma 当前源**：页面「控件」，Node `53:3858`，Component Set Key
`f2b2b67087429cf42a14334ffcfcea6b420a82cc`，共8个有效变体。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| `type` | `checkbox` / `radio` | 复选 / 单选 |
| `state` | `unchecked` / `checked` / `unchecked disable` / `checked disable` | 未选、已选及两种禁用态；属性值按源组件原样保留 |

### 视觉与使用规则

- 组件固定18×18px，不拉伸；默认使用 `type=checkbox, state=unchecked`。
- 可用已选态使用 `primary`；禁用态使用 `text muted`；未选态保留源组件环形轮廓。
- `checkbox` 用于多选或协议确认，`radio` 用于互斥单选；不得仅为视觉差异互换语义。
- H5 必须复用随 Skill 提供的源图形资产，不用键盘字符或临时 CSS 图形重画。

---

## 十六、Agreement（协议入口）

协议详情入口与阅读确认组合，直接依赖 `Selection Control` 的 checkbox 变体。

**Figma 当前源**：页面「控件」，Node `53:3901`，Component Set Key
`078cc511ceec8f47b82e413d1c57513f0f5603e9`，共3个状态；2026-08-19 回读为 `CURRENT`。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| `state` | `detail` / `checked` / `unchecked` | 详情入口 / 已阅读 / 未阅读 |
| `Text` | TEXT 属性 | 仅 `checked`、`unchecked` 使用，默认“我已阅读《协议名称》”；`detail` 文案按源组件固定 |

### 结构规格

| state | 内部结构 | 间距 |
|-------|----------|------|
| `detail` | 14/14协议详情文案 + 18px灰色右箭头 | 2px |
| `checked` | 18px已选 checkbox + 14/14协议文案 | 8px |
| `unchecked` | 18px未选 checkbox + 14/14协议文案 | 8px |

- 文案使用 PingFang SC Regular 14/14，默认文字颜色为 `on-surface default secondary`。
- `checked` / `unchecked` 中，每一个 `《协议名称》`整段（含书名号）都使用Primary高亮并作为协议链接；
  “我已阅读”等前后文保持Secondary。H5 `text` 可以包含一个或多个 `《…》`，运行时必须逐段识别，
  不得只处理第一段，也不得在页面层手拼其余协议文字。当前公开接口只有一个 `href`，多个协议名称
  共用该地址；需要不同目标时先扩展组件合同与双端映射。
- H5 中 Selection Control 使用18px固定视觉盒，14px文字行盒与其以Flex中心对齐；不得依赖内联元素
  baseline 或父级行高对齐，checked/unchecked 的两个视觉盒中心点必须一致。
- 多协议或长文案实际折行时，文案区允许自然换行并使用14px×1.5行高；Selection Control保持18px固定盒，
  与文案第一行对齐，不因折行缩放或重复渲染。
- H5 的 `detail` 将文案与18px右箭头放入同一个可点击链接，二者保持2px间距；不得只渲染文案、
  不得把箭头放在链接点击区域之外。
- `detail` 只表达查看协议；需要用户明确同意时使用 `checked` / `unchecked`。
- 修改 `Text` 时保持“我已阅读《…》”语义，不在组件外叠加重复协议文案。

---

## 十七、Dialog（底部模态弹窗）

Dialog 是375px宽的底部模态弹窗，不是页面中的普通内容面板。打开时使用遮罩覆盖并阻断背景页面，
弹窗从视口底部对齐。Figma 组件表示可见弹窗内容，由同一白色面板内的内容、Agreement 和
Action Button Group 组成；遮罩、焦点管理与页面滚动锁定属于 H5 / 客户端运行层。高度随标题、
正文及可选媒体内容自适应；完整参考组合高度为653.5px。

**Figma 当前源**：页面「控件」，Node `53:5759`，Component Key
`60b7ce0dfb77bae12d0fcc9afd9845dc982328ef`。2026-08-19 已发布并回读为 `CURRENT`，H5 与映射齐全，
登记为 `kind=component`。

### 属性

| 属性 | 类型 / 默认值 | 说明 |
|------|---------------|------|
| `Close button#53:1` | BOOLEAN / `false` | 显示右上角关闭按钮 |
| `Head Media#53:2` | BOOLEAN / `true` | 显示顶部媒体槽；正式使用仍以是否有真实槽位内容决定 |
| `Content Text#53:3` | BOOLEAN / `true` | 显示正文 |
| `Content image#53:4` | BOOLEAN / `true` | 显示正文图片槽；正式使用仍以是否有真实槽位内容决定 |
| `Tittle Text#53:5` | TEXT | 标题文字；属性拼写按源组件保留 |
| `Content Text2#53:6` | TEXT | 正文文字 |

Agreement 与 Action Button Group 是当前主件中的固定直接依赖，不再暴露顶层显隐 Boolean；Dialog
不存在无按钮正式状态。

H5 公开属性与 Slot：

| H5 API | 默认值 | 对应能力 |
|--------|--------|----------|
| `open` | `false` | 打开/关闭模态层 |
| `title` / `body` | 空 | 标题与正文 |
| `show-close` | `false` | `Close button#53:1` |
| `show-body` | `true` | `Content Text#53:3` |
| `show-agreement` | `true` | H5兼容开关；Figma无顶层Boolean，跨端转换时以嵌套实例显隐实现 |
| `agreement-state` | `detail` | 内部 Agreement 的 detail/checked/unchecked |
| `agreement-text` / `agreement-href` | 组件默认值 | 内部 Agreement 内容 |
| `close-on-scrim` | `false` | 运行层可选策略；默认遮罩只阻断背景，不作为退出入口 |
| `slot=header-media` | 空 | Header Media 可替换内容 |
| `slot=content-image` | 空 | Content Image 可替换内容 |
| `slot=agreement` | 默认 Agreement | 以正式 Agreement 实例替换默认协议入口 |
| `slot=actions` | 必填 | 正式 Action Button Group，且至少包含1个可见 Button；Figma主件中操作区固定存在 |

### 结构规格

| 项目 | 规范 |
|------|------|
| 组件宽度 | 375px |
| 内容面板 | 白色；顶部圆角30px；上15px、左右20px、下20px内边距；内容、协议、操作区纵向间距20px |
| 标题 | PingFang SC Semibold 24/36，`on-surface default primary` |
| 正文 | PingFang SC Regular 18/27，`on-surface default secondary`；H5标题与正文均为实际单行时相距16px，否则10px；Figma主件固定10px |
| 协议 | 默认 `Agreement state=detail`；整行高18px |
| 操作区 | 面板内335px宽；直接复用 `Action Button Group`，按按钮数量与最终文案选择 `Primary` / `Inline` / `Stacked`；不得手动重拼按钮 |

### 呈现与交互语义

- H5 使用 `.v9-modal` 作为全屏模态层，内部放置 `.v9-dialog`；不得把 `.v9-dialog` 当作普通页面卡片直接插入内容流。
- 模态层底部对齐，使用 Overlay / Level 4 阴影；遮罩覆盖背景并阻断背景点击与滚动。
- 弹窗节点使用 `role="dialog"` 与 `aria-modal="true"`，打开后焦点进入弹窗，关闭后焦点回到触发按钮；支持 Esc 关闭。
- 打开后 Tab / Shift+Tab 必须在弹窗内循环；正文可见时通过唯一 `aria-describedby` 关联，页面存在多个
  Dialog 时不得复用固定标题 ID。
- 默认点击遮罩不关闭。只有业务明确允许且设置 `close-on-scrim` 时，才把遮罩作为退出入口；Close、Esc、
  Action 和 Scrim 关闭分别通过 `v9-close.detail.reason` 回传原因。
- `.v9-dialog` 对应 Figma 源组件，遮罩不是该 Component 的子图层，不建立新的 Figma Component Key。
- H5 请求打开时必须存在 `slot="actions"` 的 Action Button Group，且至少包含1个可见 Button；缺失时
  不得打开，并触发 `v9-invalid.detail.reason="missing-actions"`。

### 操作区与退出路径

| 按钮内容 | Action Button Group `layout` | 说明 |
|----------|------------------------------|------|
| 1个按钮 | `Primary` | 只显示一个 Primary 按钮 |
| 2个按钮，两个文案都不超过4个字 | `Inline` | Primary 在左、Subtle 在右，横向等分 |
| 2个按钮，任意一个文案超过4个字 | `Stacked` | Primary 在上、Subtle 在下，避免横排拥挤 |

- Dialog 中不存在只有 Secondary / Subtle 按钮的场景，不使用 Action Button Group `Secondary`。
- Dialog 不存在无按钮状态；Figma主件固定保留 Action Button Group，H5 actions Slot必须包含至少1个可见按钮。
- `close-button` 默认关闭。已有“取消”“暂不选择”“稍后”等不作选择即可退出的按钮时，不显示 Close，避免重复出口。
- 仅当现有按钮都要求用户作出明确选择、没有“不作选择并关闭”的出口时，才显示右上角 Close。
- Close 按钮按操作语义判断，不只匹配固定关键词；确定按钮布局和 Close 显隐前，必须先拿到最终按钮文案与交互含义。

### 可替换媒体槽

`Header Media` 与 `Content Image` 都是**可替换内容槽位**，不是固定插画或默认业务图片。

| 槽位 | 默认状态 | 尺寸与对齐 | 替换规则 |
|------|----------|------------|----------|
| `Header Media` | 隐藏 | 内容100×100px，在335px内容区水平居中 | 可替换为业务插画、图标或图片；保持100×100槽位与居中关系，建议 `contain` |
| `Content Image` | 隐藏 | 335×150px，圆角12px | 可替换为业务图片；保持槽位尺寸、圆角与所在顺序，建议 `cover` |

- 没有真实媒体内容时保持对应 Boolean 为 `false`，不得展示默认占位图。
- Figma 中先打开对应 Boolean，再覆盖槽位内部的图片填充或可替换内容；保持 Dialog 实例，禁止 detach、删除槽位或改槽位尺寸。
- H5 中通过槽位子元素传入真实媒体内容，不把示例图片写死进 `.v9-dialog`；图片需提供有效 `alt`，纯装饰图使用空 `alt`。
- 两个槽位只负责承载和裁切内容，不改变标题、正文、Agreement 与 Action Button Group 的现有结构。

### 默认组合

正式调用默认不传媒体槽，因此映射 `Head Media#53:2=false`、`Content image#53:4=false`；同时设置
`Close button#53:1=false`、`Content Text#53:3=true`，协议为 `detail`。actions Slot 必须存在且至少包含
1个可见按钮，操作区根据按钮数量与最终文案选择 `Primary` / `Inline` / `Stacked`；
不提升 Agreement 状态或内部按钮文案为 Dialog 顶层属性，需要修改时进入对应嵌套实例。

---

## 十八、info-icon（信息图标）

12/14px 的紧凑信息图标，用于在标题、标签或说明文字旁提供补充信息入口。

**Figma 当前源**：页面「控件」，Node `1:2015`，Component Set Key
`8d2dd490e80649720116077901d32424b01aa2d3`，共2个有效尺寸变体。

### 属性与视觉

| 属性 | 可选值 | 说明 |
|------|--------|------|
| `size` | `M` / `S` | 14×14px / 12×12px；默认 `M` |

| 元素 | 颜色 |
|------|------|
| 外环 / “i”字形 | `text tertiary` (#999999) |

- info-icon 没有 Disabled 状态，也不定义其他交互状态；M/S 只表示尺寸。
- 图标作为纯提示装饰时使用 `aria-hidden="true"`；承担交互时由外层按钮提供可访问名称和触发逻辑，不把14px图形本身当作完整点击热区。
- info-icon 是 Tooltip 的常见触发入口，但不是唯一触发器。Tooltip 保持独立，箭头对齐当前触发元素的锚点，不与 info-icon 写死绑定。
- H5 使用随 Skill 固化的源 SVG，不用字符“i”或 CSS 圆形重画。

---

## 十九、Tooltip（文字提示）

用于在触发元素附近展示短补充说明；箭头位置由触发点相对气泡的位置决定。

**Figma 当前源**：页面「控件」，Node `1:2072`，Component Set Key
`a84674c3788dbf7127dad3d0188c7b06ac53e532`，共4个变体。

### 属性

| 属性 | 可选值 | 说明 |
|------|--------|------|
| `arrow` | `top-right` / `top-left` / `bottom-right` / `bottom-left` | 箭头所在边与左右位置；默认 `top-right` |
| `Text` | TEXT 属性 | 提示文案，默认“在这里修改文案” |

### 结构规格

| 项目 | 规范 |
|------|------|
| 气泡最大宽度 | 288px，内容自适应并允许换行 |
| 气泡内边距 | 上下12px、左右16px |
| 气泡圆角 | 8px |
| 背景 / 文字 | `on-surface default primary` / `on primary` |
| 文字 | PingFang SC Medium 16/16 |
| 箭头 | 15×8px；距对应左右边20px；与气泡无额外间距 |

- `top-*` 表示箭头位于气泡上方，`bottom-*` 表示箭头位于气泡下方；`left/right` 控制箭头靠近哪一侧。
- 箭头可见图形必须贴合对应气泡边缘；不得保留 SVG 画布透明余量形成视觉间距。
- Tooltip 只承载辅助说明，不替代必须持续可见的字段标签、错误提示或关键操作文案。
- H5 使用 `role="tooltip"`，触发元素通过 `aria-describedby` 关联；显隐、延时和焦点退出属于运行层。

---

## 二十、Toast（轻提示）

用于在页面中央短暂反馈操作结果或持续展示进行中状态。Toast 是非模态反馈，不阻断背景操作，
也不承载需要用户决策的按钮。

**Figma 当前源**：页面「控件」。

- `Toast.Icon`：Node `53:4338`，Component Set Key
  `ee5ed6f07d3efde40ab7fd90620400aeb03f4413`，4个18×18px变体。
- `Toast / Container`：Node `67:5896`，Component Key
  `aca48e84f8f65fdf013efd4074e95be185c5b5e1`，单一主组件。

### Toast.Icon

| `type` | 说明 |
|---|---|
| `warning` | 警示反馈 |
| `success` | 成功反馈 |
| `error` | 失败反馈 |
| `loading` | 进行中反馈；H5 连续旋转 |

- 图标固定18×18px、反白显示，H5 必须使用随 Skill 固化的 Figma 原始导出资产。
- Toast.Icon 是可独立调用、也可作为 Toast 直接依赖的正式组件；不得用字符、emoji 或临时 CSS 图形重画。
- 图标本身不承担交互语义，H5 使用空 `alt` 与 `aria-hidden=true`，状态由外层 Toast 宣告。

### Toast 主组件

| 属性 | Figma 来源 | 说明 |
|---|---|---|
| 文案 | `Text#67:14` | 默认“在这里修改文案” |
| 图标显隐 | `icon#67:13` | `false` 时只显示文案 |
| 图标类型 | 内部 `Toast.Icon.type` | warning / success / error / loading |

主组件没有 Variant、Slot 或 Prototype Reaction。H5 将图标显隐与嵌套类型统一暴露为
`icon-type=none/warning/success/error/loading`，精确写入方式见 `v9-figma-map.md`。

| 项目 | 规范 |
|---|---|
| 尺寸 | 高42px；宽度 Hug，最大188px |
| 内边距 / 间距 | 上下12px、左右16px；图标与文字8px |
| 圆角 | 8px |
| 背景 / 文字 | `on-surface default primary` / `on primary` |
| 文字 | PingFang SC Medium 16/16，允许换行 |
| 阴影 | 无 |

### 状态、交互与可访问性

- warning / success / error / none 默认展示2000ms后关闭；`duration` 可覆盖，`0` 表示不自动关闭。
- loading 不自动关闭，由调用方在任务完成后移除 `open`。
- 自动关闭派发 `v9-close`，`detail.reason=timeout`。
- warning / error 使用 `role=alert`、`aria-live=assertive`；success / loading / none 使用
  `role=status`、`aria-live=polite`。
- H5 的页面居中属于运行层定位，不改变 Figma 气泡组件内部结构；不增加源组件不存在的阴影。
- Toast 不开放任意内容 Slot，业务文案通过 `text` 写入，避免破坏固定图标、间距与最大宽度。

```html
<v9-toast-icon type="success"></v9-toast-icon>
<v9-toast open icon-type="success" text="操作成功"></v9-toast>
```

---

## 二十一、Loading（加载提示）

14px高的加载状态组合，由固定旋转图标与固定状态文案组成。

**Figma 当前源**：页面「控件」，Node `1:2097`，Component Set Key
`64b3b6a365d2f40f48ba3d4af93ae7f712dd9c14`，共3个变体。直接依赖图标组件
`加载/加载`（Node `1819:1375`，Component Key `d44e92e0421b43e0512c0d5515e0e3a4e758c0c6`）。

### 属性与文案

| `type` | 固定文案 | 用途 |
|--------|----------|------|
| `normal` | 正在加载 | 常规请求或内容加载 |
| `pull-up` | 上滑刷新 | 列表底部上滑加载 |
| `pull-down` | 下拉刷新 | 列表顶部下拉刷新 |

### 结构规格

- 三种 type 均固定显示图标，不存在无图标状态；Loading 一共只有3种状态，不按 icon 有无扩展为6种。
- 整体默认76×14px：14×14px图标 + 6px间距 + 56×14px文字。
- 文案使用 PingFang SC Regular 14/14，颜色为 `on-surface default secondary`。
- Figma 中保留内部 `加载/加载` 实例，不 detach；H5 使用源图形蒙版并增加连续旋转，减少动态效果时停止旋转。
- 使用 `role="status"` 与 `aria-live="polite"`；同一区域只保留一个活动 Loading，完成后移除或隐藏。
- 6px gap 与14px局部行高仅属于本组件，不新增全局间距或行高 Token。

---

## 二十二、Quantity Stepper（数量步进器）

用于在1–99范围内递增或递减整数数量；由减号按钮、固定宽度数字和加号按钮组成。

**Figma 当前源**：页面「控件」，Node `1:2026`，Component Set Key
`113641d4e06fbbd3e6adb4018b07a73830189ea2`，共3个变体。

### 属性与状态

| 属性 | 可选值 | 说明 |
|------|--------|------|
| `state` | `default` / `max` / `min` | 中间值 / 最大值 / 最小值；默认 `default` |
| `value` | TEXT 属性 | 仅 `default` 开放，默认“20” |

| state | 数字 | 减号 | 加号 |
|-------|------|------|------|
| `default` | 业务值 | 可用 | 可用 |
| `max` | 固定99 | 可用 | 禁用 |
| `min` | 固定1 | 禁用 | 可用 |

### 结构与使用规则

- 组件固定77×22px；两侧图标18×18px，中间数字区41×22px，无额外 gap；外层背景透明，由所在容器提供背景。
- 数字使用 Barlow Condensed Bold 22/22、0字距、居中，颜色为 `on-surface default primary`。这是步进器局部字号，不纳入 Number/XL-L-M-S 数据字阶。
- 可用按钮使用 `on-surface default secondary`，边界禁用按钮使用 `text muted`；H5 复用源 SVG。
- H5 使用原生 `<button>`、明确的“减少数量/增加数量”可访问名称，并同步 `disabled`、`aria-valuemin="1"`、`aria-valuemax="99"` 与当前值。
- 只有位于边界时使用 `min/max`，不得让视觉状态与实际可操作范围不一致。

---

## 二十三、数据组件

数据组件采用三层组合结构，避免按数据数量分别维护多套组件：

```text
DataValue → DataItem → DataGroup
```

Figma 正式源位于 `9.0规范`（fileKey `KKuaHEUNwnenHwumr4a3Ta`）的数据组件区。
其中 `DataValue` 是 `Metric Item` 内部的逻辑层，
不单独发布公共 Figma 组件；`Metric Item` 对应 `DataItem`，`Metric Group` 与
`Scrollable Metrics` 对应两种 `DataGroup`。

### 23.1 DataValue

`DataValue` 负责完整的数据值组合：

```text
[可选前缀] + 核心值 + [可选单位]
```

- 核心值只允许数字或英文，不提供中文值类型。
- 按业务重要性、页面层级、密度、最长值和空间选择 Number/XL、L、M、S。
- 数量不决定字号；1–4 项数据均可按需使用任一核心字阶。
- 位于数字前的货币符号与核心整数同字号；小数按字阶降级。颜色、字重、单行行高等于字号和基线规则统一读取 `typography.md`。
- 单位使用指标名称字号、Text Bold 700，并继承核心数据颜色。
- 核心数字与单位直接复用 2XS：Figma 使用 `space/space/2xs`，H5 使用 `--v9-space-2xs`；不得创建数据专用或 Metric 间距变量。
- Number单位采用组件级光学校正：XL/L相对基线向上2px，M/S向上1px；Metric Item必须复用相同Size的
  Number结构，不得再叠加独立位移，因此同尺寸Number与Metric Item的数字/单位高度差保持一致。
- `Number/Auxiliary/M` 18px 与 `Number/Auxiliary/S` 16px 只复用现有18/16字号值；实际字族仍为 Barlow Semi Condensed Bold 700。

### 23.2 Metric Item（DataItem）

`Metric Item` 由以下槽位组成：

```text
指标名称 + DataValue + [可选趋势信息]
```

H5 直接调用：

```html
<v9-metric-item
  size="l"
  label="营收"
  prefix="¥"
  integer="128"
  decimal=".36"
  unit="万"
  trend="up"
  trend-value="12.8%">
</v9-metric-item>
```

运行时把指标名称、完整 DataValue 与 Trend 封装为单一组件根。调用层不得再加未定义的行内包装、
`vertical-align`、固定高度或额外 margin；名称到数值、完整值块到 Trend 的尺寸级间距由组件自身保持。

| 维度 | 可选值 | 规则 |
|---|---|---|
| Size | XL / L / M / S | 只表达业务层级与密度，不由同组数量决定 |
| Trend | None / Up / Down | None 不渲染趋势；Up/Down 使用暴露的嵌套 `_Metric/Trend` 实例 |
| ValueType | Number / English | Number 支持前缀、整数、小数和单位；English 只显示英文值 |

- 共24个变体：4种 Size × 3种 Trend × 2种 ValueType。
- 指标名称使用 Body Medium 14/14、Regular、辅助文字色；实际折为多行时切换为14/21。
- 名称 ↔ DataValue：XL/L/M/S统一为6px。
- 无趋势时不增加尾部间距；Up/Down 时完整值块 ↔ 15px趋势胶囊：XL=9px、L=9px、M=8px、S=9px。
  这些都是组件局部结构值，不新增全局 Token，也不推广为所有数据节点的默认值。
- 趋势胶囊使用 Barlow Semi Condensed Bold、13/12，方向图形和文案同色；数字区域 Padding 固定为
  上1px、右5px、下2px、左0，方向图形继续保持14×15px，胶囊总高保持15px；左下角固定为0圆角的
  尖直角，其余三个角保持 Full 圆角。以上都属于组件局部规格，不新增全局 Token。
- Trend 可见值不支持中文；`trend-value` / `_Metric/Trend.Value#103:0` 只写数字、英文和必要符号
  （如 `+`、`-`、`.`、`%`）。方向由 Up/Down 图形表达；“环比”“同比”“上升”“下降”等中文说明
  必须放在 Trend 之外的指标名称或正文中。H5 收到含中文的 `trend-value` 时不渲染整个 Trend，
  同时不保留趋势间距；不得自动删字、翻译或显示半截内容。
- Up 使用正式 Success 文字/图形色，背景使用本组件局部 `#D6FFEE`；该色不进入全局 Token 或 Figma Variable。
  Down 继续复用正式 Error 色和既有浅色背景。页面不得覆盖两种方向的组件内部颜色。
- 源变体参考宽度为220px；进入 Group 后按可用宽度等分，不把220px固定为页面中的最终宽度。
- Metric Item 高度由内容、行盒与所在容器的规范 Padding 共同决定；调用层不得用无规范来源的固定高度或
  `min-height` 修正对齐。需要同组等高时由 Group 的布局容器统一拉伸，不逐项覆盖 Metric Item。
- 不为指标名称、数据颜色、单位字号或趋势颜色新建 `Metric Tokens`；复用正式 Token。

### 23.3 数据组容器模式（DataGroup Container）

给数据组增加一种容器模式：

**Container = Standalone / Embedded**

- **Standalone**：保留背景、圆角和16px Padding，可以独立放在页面上。
- **Embedded**：只保留数据排列和 Grid gap，去掉背景、圆角和外层 Padding，由父级 Card 提供容器。

Container 只决定数据组是否自带外层容器，不改变内部 Size、Trend、ValueType、Pure/Subtle 或
8/12/16px Grid gap 规则。

- 当 Cardheader 与数据组共同构成一个卡片模块时，使用同一个父级 Card：Cardheader 位于卡片内，
  数据组使用 Embedded；不得把标题放在卡片外、内容单独成卡。
- 一个视觉层级只能由一个容器负责 Surface、圆角和 Padding；不得把 Standalone 数据组直接嵌入
  已具有完整卡片外观的 Card，形成双层背景、双圆角或重复内边距。
- Figma 的 Metric Group 与 Scrollable Metrics 均已暴露 `Container=Standalone/Embedded`。
  使用父级 Card 组合标题与数据时，直接选择 Embedded 变体；不得 detach Standalone 或用
  Cardheader + Metric Item 手工重拼已有数据组。

### 23.4 Metric Group（固定 DataGroup）

`Metric Group` 负责组合 1–4 个 `Metric Item`。Figma 顶层暴露
`Container=Standalone/Embedded` 与 `Count=1/2/3/4`；Container 只控制外层容器，
Count 只控制数量和列结构，二者都不控制内部 Size、Trend、ValueType 或内容。

```html
<v9-metric-group container="embedded" count="2" size="l">
  <v9-metric-item label="完成订单" integer="3,286" unit="单"></v9-metric-item>
  <v9-metric-item label="服务用户" integer="24,891" unit="人"></v9-metric-item>
</v9-metric-group>
```

`size` 是对同组嵌套 Metric Item 的统一传递入口；`count` 只控制列数，不能推断 `size`。

| 结构 | Surface | DataItem 间距 |
|---|---|---:|
| 固定单行 1–4 项 | 优先 Pure | 16px（`space/lg`） |
| 同一 Subtle 容器内并列 | Subtle | 12px（`space/md`） |
| 多个独立 Subtle 数据卡 | Subtle | 8px（`space/sm`） |
| 横向滚动 | Subtle | 卡片间 8px（`space/sm`） |

Surface 只用于区分结构，不表达“语义是否独立”：

- 固定单行 1、2、3、4 项优先 Pure；4 项不会自动触发 Subtle。
- 横向滚动的独立数据卡使用 Subtle，帮助识别卡片边界。
- 多层数据先使用留白、对齐或分割线建立层次；仍不清晰时，再给其中一层使用 Subtle。
- 不得根据是否有副标题、数据语义或数据数量机械选择 Surface。

- Figma 源实例中的 Count1/2/3 默认使用 L、Count4 默认使用 S，只是演示初始值，不构成组件规则。
- 使用 Group 时必须为同组嵌套的 Metric Item 统一设置 Size；不得直接依赖 Count 的源默认值。
- Size、Trend、ValueType 与业务内容都属于嵌套 Metric Item；Group 顶层只负责 Container 与 Count。
- 375px 页面仍使用左右各12px margin，Group 跟随351px内容宽。源探索文件中的343px宽度来自16px演示边距，不形成页面 margin 例外。
- Standalone 使用16px内边距、16px Pure gap、白色 Surface 和16px圆角；Embedded 保留
  16px Pure gap，但移除外层背景、圆角和 Padding。两种 Container 的内部列均等宽。

### 23.5 Scrollable Metrics（横滑 DataGroup）

`Scrollable Metrics` 用于固定布局无法容纳数据时的横向滚动：

- 外层使用白色 Surface、16px内边距、8px卡片间距和16px圆角。
- Standalone 初始状态及每次滚动吸附后，首项与可视容器左侧保持16px；末项与右侧同样保持16px。
  Embedded 的边缘间距由父级 Card 提供，不在数据组内部重复增加。
- 每个独立 Subtle tile 参考宽100px，使用12px内边距、12px圆角和 Subtle Surface；内部继续复用 Metric Item。
- tile 内指标名称与数据整体居中；高度由 Metric Item 内容与上下12px Padding 自然撑开，不设置无来源固定高度。
- Scrollable Metrics 采用组件级紧凑数字合同：前缀、整数、小数与英文值固定为18px，
  使用 Barlow Semi Condensed Bold 700、18px行高和0字距；单位仍使用指标名称的14px字号、
  Text Bold 700，并与数字保持2px和基线对齐。
- 这里的18px复用辅助字号值，不是第五级核心数字字阶，也不改变通用 Metric Item 的
  `Size=XL/L/M/S`。调用方只修改嵌套 Item 的内容和趋势，不以 Count 或普通 Size 覆盖该紧凑呈现。
- 源组件的564px宽度表示可滚动内容总宽，不是375页面的可视宽；调用层使用351px视口裁切并启用横向滚动。
- 源组件中的5项业务文案只是实例示例，不是固定内容。使用时修改嵌套 Metric Item，不复制或重画数据结构。

H5 直接调用 `<v9-metric-scroll container="standalone|embedded">`，子项仍使用
`<v9-metric-item>`。运行时负责100px Subtle tile、8px tile gap、18px Number 字体与居中规则；
调用层只提供子项内容，不复制 tile 容器。

### 23.6 同组一致性与溢出

- 同一行或同一对比组保持同一核心字阶、阅读顺序和对齐轴。
- 不因某项位数更长而单独缩小；最长真实值放不下时整组降一级。
- 宽度测量必须包含前缀、整数、小数和单位，不只测整数。
- 375px 屏幕以左右各 12px 页面 margin 为基准，可用内容宽度为 351px。
- 固定布局无法在 S 字阶容纳最长值时，改用正式 Scrollable Metrics。其18px数字由组件紧凑合同提供；
  不得据此给通用 Metric Item 新增第五级 Size。

### 23.7 Figma 源状态

| 组件 | Node ID | 类型 | 变体 |
|---|---|---|---:|
| `_Metric/Trend` | `1:2466` | COMPONENT_SET | 2 |
| `Metric Item` | `1:2189` | COMPONENT_SET | 24 |
| `Metric Group` | `1:2130` | COMPONENT_SET | 8 |
| `Scrollable Metrics` | `1:2107` | COMPONENT_SET | 2 |

最后核对：2026-08-13。精确 Key、属性名、嵌套写入方式和 H5 class 统一见
`v9-figma-map.md`；跨文件导入与失败处理按 `figma-workflow.md` 执行。

---

## 二十四、Address Group（起终点地址组）

Address Group 是可独立复用的两行地址组件，不归属于 CellCard Content 专属分类；它可以进入
CellCard Content Slot，也可以用于列表、页面或其他兼容容器。

**Figma 当前源**：页面「控件」，Node `67:5956`，Component Set Key
`146e09239141aba3be4a34a393db834e0e67653a`，共2个尺寸变体；发布状态 `CURRENT`。

### 属性

| 属性 | 可选值 / 类型 | 说明 |
|------|---------------|------|
| `Size` | `Default` / `Large` | 默认值为 `Large` |
| `StartText` | TEXT | 起点地址，只展示一行 |
| `EndText` | TEXT | 终点地址，只展示一行 |

H5 直接调用：

```html
<v9-address-group
  size="default"
  start-text="北京市海淀区唐家岭路"
  end-text="中关村软件园一期东门">
</v9-address-group>
```

### 尺寸与视觉

| Size | 组件参考尺寸 | 文字 | 圆点到文字 | 两行间距 |
|------|--------------|------|------------:|---------:|
| Default | 326px宽、内容自适应 | PingFang SC Regular 14/14 | 6px | 16px |
| Large | 326px宽、内容自适应 | PingFang SC Semibold 18/18 | 8px | 16px |

- 起点与终点标记均为6×6px圆点；终点使用正式 `primary`，文字使用 `text primary`。
- 起点标记的 `#05AC7E` 是本组件局部颜色；当前9.0变量库没有对应可复用语义色，因此不新增 Token。
- 两行间距16px复用 `space/space/lg`；Default 的6px是组件局部结构值，不新增6px Token。H5 以既有4px + 2px
  Token组合实现。
- 两行都必须保留完整业务字符串。当前Figma源使用固定宽度裁切且不添加省略号；H5为浏览器可读性保留
  单行末尾省略。页面不得自行截字或把省略号写进业务字符串。
- 宿主宽度跟随父容器，Figma 的326px是源组件参考宽；进入 CellCard 时由319px Content Slot提供可用宽度。
- H5 使用 `role=group`，分别为起点和终点提供完整可访问名称；屏幕阅读器读取完整地址，不读取视觉省略结果。

---

## 二十五、Empty（空状态）

Empty 用于页面、列表或业务区域没有可展示内容时的统一反馈。组件只负责空状态插图和一行文案；
组件在容器中的水平、垂直居中由父容器负责，不新增居中变体，也不在组件内部推断可用区域高度。
父容器的可用高度必须来自已确认的页面结构，不得为了让 Empty 看起来居中而临时制造固定高度。

**Figma 当前源**：页面「控件」，Node `67:5952`，Component Key
`cf091b39ec48ac5e170b726d6c0f1670b9621dab`。当前为单一 Component，发布状态 `CURRENT`；
组件直接保持100×126px结构。

### 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| H5 `text` | TEXT | 写入主件公开属性 `Text#67:15` |

H5 直接调用：

```html
<v9-card>
  <div slot="content" class="v9-empty-container">
    <v9-empty text="暂无新任务"></v9-empty>
  </div>
</v9-card>
```

### 尺寸与视觉

| 项目 | 规格 |
|------|------|
| 组件尺寸 | 100×126px |
| 插图可见区域 | 100×100px；H5固定使用单一 `assets/components/empty/illustration.svg`，裁切已封装在SVG内部 |
| 插图到文案 | 12px，复用 `--v9-space-md` |
| 文案 | PingFang SC Regular 14px / 14px；H5使用 Body Medium Token |
| 文案颜色 | Figma `Color/辅助信息`；H5 `--v9-text-secondary` |

### 使用规则

- Empty 表达“当前区域没有内容”，不替代加载中、错误提示或权限受限状态。
- 源组件只有一个TEXT属性；不得自行增加副标题、按钮、图标状态或图片替换Slot。
- 父容器必须提供可用区域，并使用居中对齐；H5可使用布局辅助类 `.v9-empty-container`。
- `.v9-empty-container` 只负责 `display:grid` 与 `place-items:center`，不是独立组件，也没有 Component Key；
  默认不得设置固定 `height`、`min-height` 或额外 Padding。
- 空状态区域的高度应由父级 Card Content Slot、列表可用区、剩余视口或其他已确认的页面结构自然提供。
  只有 PRD、Figma 画板或正式组件合同明确给出固定高度时，页面层才可设置，并应能说明数值来源。
  不得为了视觉居中、与有内容状态看起来等高，或复刻单张截图，凭观察新增固定 `height` / `min-height`。
- `319×224px` 等结果只可能是某个页面场景的父级可用区域，不是 Empty 组件尺寸、Variant 或通用容器规格；
  Empty 自身始终保持100×126px。
- H5 页面必须真实调用 `<v9-empty>`；禁止用 `.empty-state`、普通 `<div>`、文字加Padding或背景模拟空状态。
  仅视觉相似不构成组件调用，页面层不得省略组件内部插图节点。
- 页面只传业务文案，不复制组件内部插图或文字结构。Empty 的H5固定资产必须保持为单一SVG；禁止拆成
  PNG与mask、额外加载遮罩或在页面层重做裁切。Empty 自身不带Surface；设计要求白色卡片时，
  由父级正式 `<v9-card>` 的 Content Slot提供白底、圆角、Padding与阴影，并在Slot内居中；父区域已经
  提供Surface时不得重复包Card。
- 文案保持单行；当前组件适用于与默认文案相近的短文本，长文案应先优化内容，不单独缩放插图或字号。

---

## 二十六、Entry（功能入口）

Entry 由可单独调用的 Entry Item 和负责列表/宫格编排的 Entry Group 组成。它承载带占位图或业务图标的
中等尺寸功能入口；不得继续用普通色块、CardContent Media Medium 或页面私有卡片模拟同类入口。
CardContent Media Medium 当前仍在主规范库发布，只有源组件删除并重新发布后才执行正式迁移。

### 26.1 Entry Item

**Figma 当前源**：Node `88:966`，Component Set Key
`b3a6aadac84920a3275e0abe8c484f25febab0c9`，共26个发布变体。

| 属性 | 可选值 / 类型 | 默认值 | 说明 |
|------|---------------|--------|------|
| `Orientation` | `Horizontal` / `Vertical` | `Horizontal` | 横向列表项或纵向宫格项 |
| `Surface` | `Pure` / `Subtle` | `Pure` | 透明或局部填充底 |
| `Icon Size` | `30` / `40` / `50` | `30` | 占位块或替换内容尺寸 |
| `Interaction` | `Whole Item` / `Trailing Button` | `Whole Item` | 整项操作或右侧Button；Vertical只支持Whole Item |
| `Description` | `True` / `False` | `True` | 是否显示说明 |
| `Title#27:0` | TEXT | 功能入口 | 标题 |
| `Description Text#27:12` | TEXT | 说明文案 | 说明；与 `Description=True/False` 变体轴区分 |
| `Icon#27:36` | INSTANCE_SWAP | 当前占位实例 | 后续可替换为正式业务图标 |

H5 直接调用：

```html
<v9-entry-item
  orientation="horizontal"
  surface="pure"
  icon-size="40"
  interaction="trailing-button"
  title="超声波洁牙"
  description="洗牙低至39元"
  action-text="去洗牙">
</v9-entry-item>
```

#### 发布变体边界

| Orientation | Surface | Icon Size | Interaction | Description |
|-------------|---------|-----------|-------------|-------------|
| Horizontal | Pure / Subtle | 30 / 40 | Whole Item / Trailing Button | True / False |
| Vertical | Pure | 30 / 40 / 50 | Whole Item | True / False |
| Vertical | Subtle | 30 / 40 | Whole Item | True / False |

不得生成 Vertical + Trailing Button 或 Vertical + Subtle + Icon Size 50；这两类组合不在发布源中。

#### 视觉与间距

- 标题与说明固定8px；有说明时标题为 PingFang SC Semibold 14/14，说明为 Regular 12/12。
- Vertical 且无说明时标题改为 Body Medium：PingFang SC Regular 14/14；Horizontal 标题保持Semibold。
- Vertical 的Icon、标题和说明共享同一水平中轴线并全部居中对齐；Horizontal继续保持左对齐。
- Horizontal 的占位块到文字固定12px。
- Vertical 的 Icon Size 30/40 到标题固定8px；Icon Size 50 固定12px。
- Pure Horizontal：Whole Item上下Padding 8px，Trailing Button上下Padding 12px；横向无左右Padding。
- Subtle：四周Padding 12px、圆角12px、背景使用局部填充色 `#F6F8FB`。
- 占位块尺寸跟随30/40/50，圆角17.28px。Pure占位块使用 `#F6F8FB`；Subtle占位块使用
  组件私有颜色 `#E4E8EC`。后者只在Entry Item内部使用，不进入全局Token。
- 色块只是缺少正式业务图标时的默认占位，不是Icon资产。H5默认画出同样色块，并保留 `slot="icon"`
  替换入口；不得把占位块导出成SVG或PNG。
- Trailing Button 直接依赖正式 Button Medium；不得重新实现按钮形态。

直接依赖：占位实例 Component Key `ac2a9155d039d7c6e4cf126901d1cd674fd9d6f5`；
Button Component Set Key `dca4a53b0ef6207ca79fe5c0cd26ccb1aace01e2`。

### 26.2 Entry Group

**Figma 当前源**：Node `88:1107`，Component Set Key
`92e4ea0fe8817c2103b977f0e8833f14ac18cd0e`，共30个发布变体。全部直接依赖同一
Entry Item Set Key `b3a6aadac84920a3275e0abe8c484f25febab0c9`。

| 属性 | 可选值 | 默认值 | 说明 |
|------|--------|--------|------|
| `Layout` | `List` / `Grid 2` / `Grid 3` / `Grid 4` / `Grid 5` | `List` | 列表或每行列数 |
| `Count` | `1` / `2` / `3` / `4` / `5` / `6` / `10` | `1` | 当前发布的代表数量 |
| `Item Surface` | `Pure` / `Subtle` | `Pure` | 传递给内部Entry Item |
| `Icon Size` | `30` / `40` / `50` | `40` | 传递给内部Entry Item |

```html
<v9-entry-group layout="grid-3" count="3" item-surface="subtle" icon-size="40">
  <v9-entry-item title="超声波洁牙"></v9-entry-item>
  <v9-entry-item title="感冒用药"></v9-entry-item>
  <v9-entry-item title="特惠体检"></v9-entry-item>
</v9-entry-group>
```

Entry Group 会统一内部Item：List使用Horizontal、保留说明；Grid使用Vertical、隐藏说明；
Interaction固定Whole Item。调用方只提供业务标题、说明、链接与可选Icon内容，不覆盖内部编排。

#### 30个发布变体

| Layout | Item Surface | Icon Size | Count |
|--------|--------------|-----------|-------|
| List | Pure / Subtle | 40 | 1 / 2 / 3 / 4 |
| Grid 2 | Subtle | 30 / 40 | 2 / 3 / 4 / 5 / 6 |
| Grid 3 | Pure | 50 | 3 / 4 / 5 / 6 |
| Grid 3 | Subtle | 30 / 40 | 3 |
| Grid 4 | Pure | 30 / 40 | 3 / 4 |
| Grid 5 | Pure | 50 | 5 / 10 |

#### 选型与排列规则

- List：Pure Item之间0px；Subtle Item之间8px。
- Grid列间距统一8px；Grid 2行间距8px；Grid 3和Grid 5出现上下两行时行间距16px。
- Grid 2不得只有1项；Grid 3不得只有1或2项。
- 3项短文案优先A：`Grid 3`，一行三项。
- A中任一标题在三列宽度内无法保持清晰单行时使用B：`Grid 2`，第一行两项、第二行一项并左对齐。
- 4项及以上Subtle入口使用C：`Grid 2`，每行两项；奇数项最后一项左对齐，不限制H5总行数。
- Pure入口按内容密度选择Grid 3/4/5，一行最多5项；Grid 3的4/5/6项分别为3+1、3+2、3+3。
- H5布局允许按上述规则继续增加行；映射到Figma时，Count必须命中当前发布枚举。超出发布Count时，
  先扩展并发布Entry Group，不得detach或用普通Frame冒充同一组件。

---

## 二十七、Pill Option（胶囊选项）

Pill Option用于紧凑筛选、单选和输入区上方的快捷操作。它由单个 `Pill Option`、负责选择逻辑的
`Pill Option Group / Select`、无持续选中态的 `Pill Option Group / Action`，以及超过4项时承载裁切与
横滑的 `Pill Option / Horizontal Scroll Frame` 组成。旧 `amount=2/3/4` 预设已归档为Legacy，
新页面不得使用。

### 27.1 Pill Option

**Figma 当前源**：Node `134:2555`，Component Set Key
`73ea26bf053cde1706bb4bf3fbc6b932c3704300`，共8个发布变体。

| 属性 | 可选值 | 默认值 | 说明 |
|------|--------|--------|------|
| `State` | `Selected` / `Unselected` | `Unselected` | 单项选中状态；由Select Group统一维护 |
| `Context` | `Default` / `White` | `Default` | `White`只影响白底下未选中态的0.5px描边 |
| `Icon` | `True` / `False` | `True` | 是否显示16px Icon Slot |
| `Label#61:1` | TEXT | 选中选项 | 单行短文案 |

视觉合同：

- 高度30px，Full圆角；PingFang SC Regular 12/12，文案不折行。
- Icon为16×16px，Icon与文字间距4px；有Icon时左Padding 8px、右Padding 12px，无Icon时左右Padding均12px。
- Selected使用Primary背景，文字与真实业务Icon使用On Primary白色。
- Unselected使用白底与Text Primary文字；业务Icon颜色不由组件强制设置。
- 只有父背景为纯白时使用 `Context=White`，未选中态增加Outline Default 0.5px内描边；其他背景使用Default。
- 当前灰色方块只是缺少业务Icon时的组件私有占位，不是图标资产，不新增全局Token；H5保留
  `slot="icon"`，Figma保留Icon替换入口。

H5直接调用：

```html
<v9-pill-option label="15分钟后" value="15m" context="white" show-icon="false"></v9-pill-option>
```

### 27.2 Pill Option Group

Group固定8px项间距、单行且不折行，数量不通过 `amount` 变体穷举；直接增加或删除Pill Option实例。

| H5设置 | Figma资产 | 行为 |
|--------|-----------|------|
| `interaction="select" selection="required"` | Pill Option Group / Select，`Selection=Required` | 初始必须有选中项；点击当前项不能回到0 |
| `interaction="select" selection="optional"` | Pill Option Group / Select，`Selection=Optional` | 允许 `active=0`；再次点击当前项可取消到0 |
| `interaction="action"` | Pill Option Group / Action | 点击立即执行操作，不保留选中态，静态Active始终为0 |

```html
<v9-pill-option-group interaction="select" selection="optional" active="0" aria-label="到达时间">
  <v9-pill-option label="当前热力" value="now"></v9-pill-option>
  <v9-pill-option label="15分钟后" value="15m" show-icon="false"></v9-pill-option>
  <v9-pill-option label="30分钟后" value="30m" show-icon="false"></v9-pill-option>
  <v9-pill-option label="更多时间" value="more" show-icon="false"></v9-pill-option>
</v9-pill-option-group>
```

- `active`使用1开始的项序号；Optional允许0，Required会把缺省或非法值归一为第1项。
- Select点击后派发 `v9-change.detail={active,value}`；Action点击后派发
  `v9-action.detail={index,value}`。
- Select支持方向键、Home、End和Radio语义；Action中的每个Option保持独立Button语义。
- 1–4项直接展示；超过4项时使用Horizontal Scroll Frame，默认可视宽351px，也可随页面内容宽缩放；
  仍保持一行、8px间距与横向滚动，不截成多行。
- H5把横滑Frame作为 `<v9-pill-option-group>` 内部实现，不再注册第三个公开自定义元素。

### 27.3 Figma发布资产与依赖

| 资产 | Key | 类型 | 说明 |
|------|-----|------|------|
| Pill Option | `73ea26bf053cde1706bb4bf3fbc6b932c3704300` | COMPONENT_SET | State × Context × Icon，共8变体 |
| Pill Option Group / Select | `a089cc889c9548ca8c0e83316abb41a90a952b7e` | COMPONENT_SET | Selection=Required/Optional；Options Slot任意数量 |
| Pill Option Group / Action | `0e779e851ee3c531adb1775457c4a031e3bc5042` | COMPONENT | Options Slot任意数量；无持续选中态 |
| Pill Option / Horizontal Scroll Frame | `de1adea3af9f7f1b450370cdb6804e7ae56ecc36` | COMPONENT | 超过4项时的351px默认视口与横滑裁切 |

Select与Action均直接依赖正式Pill Option；Horizontal Scroll Frame承载Group或Option实例，不复制单项视觉。
`Pill Option Group / Legacy Amount Presets` Key
`668cd2db2c698d375fec32b01bb0398305ea29a6` 只用于识别旧稿，禁止导入新页面、计入正式映射或继续扩展
`amount=5/6/7`。

---

## 二十八、Form Item（表单项体系）

Form Item用于移动端表单填写与选择。Figma保留 `Form Item / Textual` 和 `Form Item / Control`
两个正式Set，H5统一为一个 `<v9-form-item>`，通过 `interaction` 分流，避免页面维护两套近似接口。
不支持Focus或Readonly变体；浏览器自身的键盘焦点能力不登记为组件视觉状态。

选型只在本组件规范维护：单字段使用 `<v9-form-item>`；连续字段使用 `<v9-form-item-group>`；
卡片内连续表单使用 `<v9-form-card>`。Workflow只要求按内容归属查询本文件，不重复维护组件清单。

### 28.1 `<v9-form-item>` 统一接口

| H5属性 | 可选值 | 默认值 | Figma映射 |
|--------|--------|--------|-----------|
| `interaction` | `input` / `select` / `radio` / `checkbox` | `input` | Input/Select→Textual；Radio/Checkbox→Control |
| `content` | `empty` / `filled` | `empty` | 仅Textual使用，映射 `Content=Empty/Filled` |
| `state` | `default` / `error` / `disabled` | `default` | 两个Set均映射 `State=Default/Error/Disabled` |
| `checked` | 布尔 | `false` | 仅Control使用，映射 `Checked=False/True` |
| `label` | 文本 | 字段名称 | `Label#32:0` 或 `Label#35:0` |
| `placeholder` | 文本 | 请输入 | Textual `Placeholder#32:19` |
| `value` | 文本 | 示例内容 | Textual `Value#32:38` |
| `show-info` | 布尔 | `true` | `Show info#32:57` 或 `Show info#35:21` |
| `error-message` | 文本 | 请检查填写内容 | `Error message#32:76` 或 `Error message#35:42` |

```html
<v9-form-item interaction="input" content="empty" label="字段名称"></v9-form-item>
<v9-form-item interaction="select" content="filled" value="示例内容"></v9-form-item>
<v9-form-item interaction="radio" checked state="error" error-message="请选择一个选项"></v9-form-item>
```

结构与视觉合同：

- 标题与Info固定4px；Info复用正式 `v9-info-icon`。
- 标题组与右侧内容/控件的水平间距不得小于20px；不足20px时内容整体换到下一行，内容最多两行。
- Input普通Field Row自然高度14px；Select和Control因18px Arrow/Selection Control自然高度18px。
- Default与Disabled的Form Item最小高度50px；独立Error或连续Error的最后一项中，Input总高86px、
  Select/Control总高90px。
- Error状态中Field Row与错误条间距12px；错误条高28px并在可用宽度内横向拉伸，不得保留固定宽度实例。
- Select右侧Arrow固定使用正式 `v9-arrow size=L`；Radio/Checkbox复用正式 `v9-selection-control`，控件固定居右。
- Disabled只使用正式Disabled视觉并禁止交互；Error不改变已填写内容或Checked值。

### 28.2 Form Item Group

`<v9-form-item-group>`承载连续的两个及以上Form Item，也允许业务需要时承载单个Item；子项可混合
Textual与Control。Group只负责纵向组合：Item间距0、无Surface、无圆角、无阴影、无外层Padding，
左右16px内容边距继续由每个Form Item自己承担。数量通过增删Item实例表达，不建立Amount变体。

连续Error采用“只收拢非末项”的规则：同一Group内相邻的Error构成一个连续段；段内每个非末项取消
错误条下方16px，最后一项保留16px。由此，连续段非末项的Input Error高70px，Select/Control Error高74px，
前一项错误条底部到后一项Field Row顶部保持16px。被Default或Disabled隔开的Error属于不同连续段，分别按
独立Error处理。每个Item仍保留自己的错误条，不得把多字段错误合并为Toast。

H5由 `<v9-form-item-group>` 根据直属Item顺序和 `state` 自动计算，不提供公开 `bottom-space` 属性，也不得
由页面写入运行时内部标记。Figma的Textual与Control Set均提供布尔属性 `Bottom Space`：默认 `True`；
连续Error段的非末项设为 `False`，最后一项或独立Error保持 `True`。

```html
<v9-form-item-group aria-label="证件信息">
  <v9-form-item interaction="input" label="姓名" state="error" error-message="请输入姓名"></v9-form-item>
  <v9-form-item interaction="input" label="证件号码" state="error" error-message="请输入证件号码"></v9-form-item>
  <v9-form-item interaction="checkbox" label="长期有效"></v9-form-item>
</v9-form-item-group>
```

### 28.3 CellCard / Form Mode

`<v9-form-card>`映射 `CellCard / Form Mode`，只用于卡片内连续表单。它是
`Cardheader（可选） + Form Item Group` 的专用结构，不是通用CellCard Shell的新Variant，也不得再嵌套
一层 `<v9-card>`。

- `header=true`：复用正式Cardheader；卡片顶部/左右Padding 16px，Cardheader与Group固定8px。
  仅在Form Mode内部将Cardheader副标题覆盖为Body Small 12px：单行行高12px，实际折行后18px；
  主标题与副标题间距覆盖为12px。通用Cardheader副标题仍为Body Medium 14px、主副标题间距仍为10px，
  不新增Cardheader变体。
- `header=false`：完全移除Header与8px间距，不保留空白；Group从卡片顶部开始，首尾Item自己的
  16px内部间距形成卡片上下留白。
- Form Mode无Footer；需要卡片外操作时使用页面级Action Button Group，不在Form Mode内部临时加Footer。
- 卡片宽351px、白色Surface、16px圆角、Level 1阴影；高度随Group实际Item数量与状态变化。

```html
<v9-form-card header="true" title="卡片标题" subtitle="副标题信息">
  <v9-form-item-group>…</v9-form-item-group>
</v9-form-card>
```

### 28.4 Figma发布资产与直接依赖

| 资产 | Node | Key | 类型 / 变体 |
|------|------|-----|-------------|
| Form Item / Textual | `156:1970` | `330f6f5aad5bd6c37aa868638e36f26c5a30229a` | COMPONENT_SET；Interaction×Content×State，共12变体 |
| Form Item / Control | `156:2079` | `b209337c26cc7df60b10d56df59381ab693fd5e4` | COMPONENT_SET；Control×Checked×State，共12变体 |
| Form Item Group | `161:2626` | `23d8858fea9d0034c1671b66ecf52671f595258f` | COMPONENT；子Item按需增删 |
| CellCard / Form Mode | `161:2645` | `0b91e870ccc0502bb91ae7f95b1bf6c71d389ecc` | COMPONENT_SET；Header=True/False |

Form Item / Textual直接依赖正式Info Icon与Arrow；Form Item / Control直接依赖正式Info Icon与
Selection Control。Form Item Group的Input、Select与Control Error实例均已替换为上述最新Set；
两个Set的 `Bottom Space` 均属于Error连续段的终止间距控制，不增加变体数量。发现旧Key、缺少该属性或
普通Frame重拼时必须停止映射并修复源组件。

### 28.5 表单与提交反馈选型

反馈组件按“能否定位到具体字段”和“是否阻断流程并要求决策”选择，不按文案中是否出现“错误”二字判断：

| 问题性质 | 使用方式 |
|---------|---------|
| 能明确定位到一个字段或一个选项，用户可在原处修正 | 对应 `Form Item state=error`，错误原因写入 `error-message` |
| 多个字段各自存在独立错误 | 每个相关Form Item分别显示自己的Error，不合并为Toast |
| 提交后的组合业务校验失败，无法归属单个字段 | `Toast` |
| 系统异常、网络异常等无需立即选择处理路径的短暂反馈 | `Toast` |
| 当前流程被阻断，且用户必须选择处理方式才能继续 | `Dialog`，并提供至少一个明确操作 |
| 卡片自身的状态或失败原因 | 优先使用该组件已有描述槽和错误语义；只有确需独立强调时再升级反馈组件 |

同一问题不得同时以字段Error和Toast重复提示。业务接口返回的错误如果带有明确字段归属，仍回落到对应
Form Item；只有无法定位字段时才使用页面级反馈。

---

## 二十九、Page Background（页面背景模式）

Page Background负责页面整体视觉基底，不是内容组件的Surface属性。每个页面只能使用
`Default`、`Focus`、`Immersive`中的一种；不得叠加两种特殊背景，也不得根据文案临时生成新的颜色或渐变。
选型、参数与实现统一维护在本节，不另建 `backgrounds.md`，也不把选型规则复制到Workflow。

### 29.1 模式选择

| 模式 | 适用场景 | 信息效率与密度 | 实现身份 |
|------|----------|----------------|----------|
| `Default` | 多模块、列表、进度、连续表单、状态管理等效率型页面 | 优先屏效和模块辨识，通常为中高密度 | 页面样式；不是正式组件 |
| `Focus` | 输入验证码、上传单项材料、单次确认等单一核心任务 | 低至中密度，首屏只突出一个主要任务 | 正式组件 `<v9-background-focus>` |
| `Immersive` | 成长、等级、身份、荣誉、权益等需要连续氛围的页面 | 内容可以较多，但必须围绕同一身份/成长主题 | 固定页面渐变；不是正式组件 |

判断顺序：先看页面业务结构与信息密度，再看情绪表达。仅“想让页面更好看”不能成为使用Focus或
Immersive的理由；高密度效率页即使有主任务也优先Default。

### 29.2 Default

- 使用全局页面底色 `--v9-surface-canvas`（当前 `#F0F1F5`）。
- H5使用默认 `.v9-page`，也可显式增加 `.v9-page--background-default`。
- 不建立Figma组件、不登记Component Key、不计入正式组件数量。

### 29.3 Focus

**Figma当前源**：页面「控件」，Node `175:3045`，Component Key
`f422b4ea2accd5a8c0c6e8ef715a793ef3be9c69`，名称 `background/Focus`；2026-09-03已发布并通过库搜索回读。

- 源参考宽375px，实际宽度跟随页面可用宽度；高度固定370px，超出范围裁切。
- Base使用组件私有值 `#F6F8FB`，不复用Surface Token，也不新增全局Token。
- Base竖向渐变：`#FFFFFF 1.355% → #F6F8FB 100%`。
- Atmosphere使用固定不规则图形资产 `assets/components/background-focus/atmosphere.svg`，整体饱和度160%。
- 图形参数：黄色 `#FFF8B8 / 40%`；青色 `#CDFEF8 / 16%`；橙色图层透明度80%、
  填充透明度80%（合成约64%），橙色弥散 `stdDeviation=52`，位置相对源稿向下16px。
- 页面内容必须位于背景之上；H5使用 `.v9-background-content` 作为前景层，不得修改组件内部DOM或SVG。

```html
<main class="v9-page v9-page--background-focus">
  <v9-background-focus></v9-background-focus>
  <div class="v9-background-content">…</div>
</main>
```

### 29.4 Immersive

- 使用固定180°全页竖向渐变：`#FFD8B9 0% → #FDF7E9 17.5259% → #F8F9FD 48.684% → #F0F1F5 100%`。
- 渐变随页面实际高度铺满，不使用固定370px高度，不叠加Focus Atmosphere。
- H5在页面根容器使用 `.v9-page--background-immersive`；Figma直接设置页面Frame的线性渐变。
- 这是固定页面实现，不建立独立Figma组件、不登记Component Key、不计入正式组件数量。

```html
<main class="v9-page v9-page--background-immersive">…</main>
```

---

## 三十、Task Sheet / Shell（任务型底部容器）

**生产组件，直接使用。** Figma Component Set 已发布，H5封装、显式映射与四种结构状态的视觉确认
均已完成；`<v9-task-sheet>` 登记为 `V9_COMPONENTS.kind=component`。

Task Sheet 是依附地图、相机、扫描、轨迹等持续主场景的底部任务容器。它让主场景保持可见，同时承载
一个持续任务的名称、当前内容与可选操作。底部位置、白色Surface或圆角外观本身不能作为命中依据。

### 30.1 使用门槛

以下条件必须同时成立：

1. 上方存在需要持续保留的主场景，例如地图、相机、扫描区域、实时轨迹或沉浸式内容；
2. 底部区域承载一个正在进行的任务，而不是一次性菜单、普通说明卡片或单纯操作栏；
3. 用户需要一边观察主场景，一边查看任务信息、状态或执行操作；
4. 多个业务状态共享同一容器骨架 `Header → Content → 可选 Action → Home Indicator`。

常见命中场景包括实时带跑、扫描分析、导航任务、拍摄质检与位置任务。业务状态如分析中、建议更新、
失败、过期或完成只改变Slot内容，不增加Shell变体。

### 30.2 不使用的场景

| 场景 | 正确承载 |
|------|----------|
| 普通页面流中的信息卡片 | `CellCard / Shell` |
| 页面底部只有提交操作 | `Action Button Group` + 页面Footer |
| 临时确认、警告或强打断 | `Dialog` |
| 从底部弹出选项、选择后关闭 | 对应选择型容器或Dialog，不使用Task Sheet |
| 大量表单、长内容或独立滚动任务 | Page / Form Card |
| 上方主场景没有保留价值，主要内容全部位于底部 | 独立Page |

### 30.3 Figma 信息与结构

| 属性 | 值 |
|------|-----|
| Node ID | `202:2121` |
| 名称 | `Task Sheet / Shell` |
| 类型 | COMPONENT_SET |
| Component Set Key | `3e5a87efceded0f91bcb4fa4472ff1799aebd8c2` |
| 发布状态 | CURRENT（2026-09-11回读） |
| 变体 | `Content Boundary=Single / Multiline` |

```text
Task Sheet / Shell
├─ Body
│  ├─ Main
│  │  ├─ Header Slot
│  │  └─ Content Slot
│  └─ Action Slot（可选）
└─ Home Indicator（固定 light）
```

公开属性：

| Figma属性 | H5属性 / Slot | 说明 |
|-----------|-------------------|------|
| `Content Boundary` | `content-boundary="auto|single|multiline"` | Figma为Single/Multiline；H5默认auto，按末端说明实际渲染行数解析 |
| `Show Action#61:0` | `show-action="true|false"` | 控制Action区域；没有有效Action Slot内容时自动收拢 |
| `Header Slot#61:3` | `slot="header"` | 默认依赖正式Cardheader实例 |
| `Content Slot#61:6` | `slot="content"` | 默认依赖正式CardContent实例，也可替换为经确认的任务内容Pattern |
| `Action Slot#61:9` | `slot="action"` | 默认依赖正式Action Button Group实例 |

Home Indicator 是Shell固定直接依赖，不对调用层暴露替换或theme属性，始终使用light。

### 30.4 容器与间距合同

| 项目 | Single | Multiline | Token / 说明 |
|------|--------|-----------|---------------|
| 宽度 | 375px | 375px | 固定移动端基准宽 |
| 高度 | Hug | Hug | 随内容自然增长 |
| Body顶部间距 | 20px | 20px | `space/space/extra lg` |
| Main左右Padding | 20px | 20px | `space/space/extra lg` |
| Header → Content | 16px | 16px | `space/space/lg`；不再按内容数量区分 |
| 末端Content → Action | 20px | 16px | Single / Multiline光学补偿 |
| Home Indicator | 375×34px | 375×34px | 固定light；横条顶部20px |

Surface使用`surface default`，顶部左右圆角使用Extra-large 30px，底部保持直角；阴影使用Level 4
上浮阴影。Action到页面底部不再叠加独立20px Padding，底部安全区由34px Home Indicator承担。

### 30.5 上下文字体与CardContent补偿

Task Sheet继续保留真实Cardheader与CardContent实例，不复制二者内部DOM。以下值是Task Sheet对嵌套实例
的上下文覆盖，不反向修改两个源组件的默认字号：

| 元素 | 字号 / 行高 | 字重 | 颜色 |
|------|-------------|------|------|
| Header标题 | 20px / 20px；折行时20px / 30px | Semibold 600 | `--v9-text-primary` (#222) |
| Content标题 | 16px / 16px；折行时16px / 24px | Medium 500 | `--v9-text-body` (#444) |
| Content说明 | 单行14px / 14px；多行14px / 21px | Regular 400 | `--v9-text-secondary` (#757575) |

| Content Boundary | 标题 → 说明 | 说明 → Action |
|------------------|-------------|---------------|
| `Single` | 10px | 20px |
| `Multiline` | 8px | 16px |

这两组差异共同补偿多行说明的额外行盒，使Header后任务内容与Action前的可见留白保持接近。不能把
“多行减4px”推广为全局公式；只有Task Sheet或其他组件合同明确时才使用对应补偿。

### 30.6 内容组合规则

- 进度、奖励、地址、麦克风等业务模块属于Content Slot内部的Task Sheet Pattern，不增加Shell变体。
- 麦克风等辅助能力优先使用正式`CardContent / subtle`与核心任务内容区分层级；是否使用Subtle由
  信息角色判断，不由按钮文案或模块所在位置决定。
- `Content Boundary`只描述Action之前最后一个可见内容边界，不表达分析中、失败、完成等业务状态。
- `Show Action=false`时完全移除Action区域及其相邻间距；不得保留空Slot高度。
- H5的`auto`只按实际渲染行数解析Single/Multiline，不按字符数、文案类型或业务状态猜测。写入Figma时
  必须把解析结果落为源组件现有的Single或Multiline变体。

### 30.7 全部结构状态

Task Sheet自身只有四个合法结构状态，不与Header、Content、Action内部状态生成笛卡尔积：

| Content Boundary | Show Action | 结果 |
|------------------|-------------|------|
| Single | true | 单行末端内容 + 20px + Action |
| Single | false | 单行末端内容；Action与相邻间距收拢 |
| Multiline | true | 多行末端内容 + 16px + Action |
| Multiline | false | 多行末端内容；Action与相邻间距收拢 |

```html
<v9-task-sheet content-boundary="auto" show-action="true" aria-label="任务面板">
  <v9-cardheader slot="header" title="AI 带跑任务"></v9-cardheader>
  <v9-cardcontent slot="content" layout="editorial" surface="pure"
    title="任务标题" description="建议准备好后会在这里展示。"></v9-cardcontent>
  <v9-action-group slot="action" layout="primary">
    <v9-button size="full" variant="primary">默认文案</v9-button>
  </v9-action-group>
</v9-task-sheet>
```

### 30.8 正式状态与源描述

- Figma源组件已发布为CURRENT，实际Auto Layout为Header → Content 16px；Component Set Key为
  `3e5a87efceded0f91bcb4fa4472ff1799aebd8c2`。
- H5四种结构状态、自动行数解析、Action收拢、上下文字号和光学间距均已完成视觉确认，运行时登记为
  `V9_COMPONENTS.kind=component`，可用于生产页面和双端映射。
- Figma库搜索结果中的Description仍保留旧的12px与12/24分组文案，属于源描述元数据漂移；不得用它
  覆盖当前实例几何和本节正式合同。后续维护Figma源组件时应同步修正文案，但不影响当前已发布组件身份。

---

## 三十一、Accent Card（橙色结构卡）

Accent Card 是信息关系容器，不绑定固定业务内容。先判断一张卡内的信息是同一对象的主信息及属性、
同一对象的上下两区，还是一个统领标题下的多个同级子项，再选 `Single / Split / Grouped`。橙色面积
与承载信息量共同决定视觉权重：大面积橙色可承载主信息；小面积橙色也可能只交代背景、统领标题或
营销牵引，不能仅凭颜色判断内容重要程度。

| 结构 | Figma 源 / Key | 内容关系与边界 |
|---|---|---|
| Single | `231:2280` / `7164d71177a5006524fbeff88a0cb17f8b58e614` | 一个主信息区；可附说明、期限等属于同一主信息的属性。关掉属性后高度一起收拢。 |
| Split | `231:2294` / `e8c552655e0ae8ffa1f446550d9a6934fb66d635` | 橙色上区交代上下文，白色下区承载同一对象的详情；上下两区必须服务同一主题。两个无共同关系的对象应拆成两卡。 |
| Grouped | `231:2311` / `728fffcdfc89a48f1d7cd8830c0aff105630889f` | 一个 Header 统领若干同级子项；容器只规定方向和间距，不规定子项白底、圆角、字体、文案或业务类型。 |

### Single：主信息及其属性

- 默认宽345px，随宿主可用宽度收窄；圆角16px、左右与顶部Padding 20px、底部16px。
- `Main information` 是可替换 Slot，默认含标题与说明；标题是22/22元黑，说明为12/12 Medium，
  默认两者相隔14px。标题用元黑是为了突出卡片的身份、权益或主张名称；普通解释性标签、分区语境标题
  不因此改用元黑。长文案依全局自动折行行高规则适配。
- `Title#19:0` 编辑默认标题；`Show Description#22:0` 控制默认说明显隐。说明文字位于
  `Main information#23:0` Slot 中，不存在独立的 `Description` TEXT 属性；替换整个 Slot 时，
  调用方负责其中内容排布，不能把 Slot 内的说明误写成已发布 TEXT 属性。
- `Expiry#19:2` 与 `Show Expiry#22:1` 管理期限属性，期限不是第二个信息区；默认期限区顶部20px，
  分割线至文字15.5px。`Show Decoration#22:2` 控制背景圆环。关闭可选区时按可见内容收拢高度。
- 背景的橙色渐变、半透明圆环和期限分割线渐变是组件局部固定视觉；圆环以 CSS 绘制，不制作 SVG，
  也不扩展为可任意替换的全局背景 Token。

### Split：同一对象的上下两区

- 默认宽345px，圆角16px；橙色 `Orange context#22:3` 与白色 `White content#19:3` 均为 Slot。
- 上区默认高度47px、四周16px；白色下区高度随内容，四周16px。白色下区可包含正式内容组件或
  适合该对象的内容组合，不能由示例文案或示例子组件倒推出固定业务模板。
- 当期限、状态只是主信息的附属属性，仍用 Single；当下区承载独立的详情层次，但与上区属于同一主题，
  才用 Split。两个互不相关的入口或对象不拼成一张 Split。

### Grouped：同级子项的分组容器

- 顶层变体 `Direction=Vertical/Horizontal`、`HeaderSpacing=Comfortable/Compact` 共4种。
  `Header#21:8` 与 `Peer items#21:9` 都是 Slot；数量随实际内容变化，不用数量变体模拟。
- Comfortable：顶部16px、Header到子项16px；Compact：顶部8px、Header到子项8px。
  左右及底部Padding 8px，Header在容器内再左缩进12px，子项间距8px。
- Vertical源宽351px，子项纵向排列；Horizontal源宽345px，子项横向排列。子项可填入口、权益、
  奖励或其他同级结构，必须由所填内容自身的正式组件/局部组合确定外观；不建立固定的 `Group Item` 样式。
- Header默认示例为16/16 PingFang SC Semibold，不将 Single 的元黑标题规则套用到分组标题。

H5 使用一个 `<v9-accent-card mode="single|split|grouped">`。Single 提供 `title`、`description`、
`expiry` 与三个 `show-*` 开关，完整替换主信息时使用 `slot="main-information"`；Split 使用
`slot="orange-context"`、`slot="white-content"`；Grouped 使用 `title` 或 `slot="header"`，
多个子项逐个标记 `slot="peer-item"`，并设置 `direction`、`header-spacing`。没有提供的业务内容
不能由运行时补造示例文案。它是独立卡片结构，不嵌套进通用 CellCard / Shell。

---

## 三十二、Option Tile / Warning Count

用于网格选项与按项目展示的警示信息，不绑定具体业务内容。区别于30px胶囊形、单行横排的
Pill Option：本组件为12px圆角块，支持多选、说明文字与多行组合；不覆盖或替换Pill Option。
Warning不是选中态，也不是可操作的危险按钮。页面级反馈仍按Alert/Toast/Dialog各自职责选择，
不能把所有红色提示都改成Option Tile。

**接入状态**：2026-11-04回读主规范库：Option Tile（Node `303:2188`，Set Key
`82721d3fe1471e5052d7346b0470293b482d7317`）与 Warning Item · Count（Node `303:2204`，Key
`3064873b46f0f7f7d36b6f7064e3722e4fb5d2f2`）均为`CURRENT`，且跨文件导入验证通过。
两项H5封装与双端映射齐全，身份为`component`；Option Group仅为布局与交互组合，保持`primitive`。

### 32.1 内容与状态

| 轴 | 值 | 规则 |
|---|---|---|
| Content | Title / Description | 无副标题 / 有副标题；默认Title |
| State | Unselected / Selected / Warning | 未选中 / 已选中 / 警示；默认Unselected |

两轴共6个组合。允许多项同时选中、再次点击取消，初始可全部不选；不存在Warning＋Selected。
Warning仅展示，不响应点击、空格或回车，不进入键盘焦点；不自行扩展Disabled等未定义视觉状态。

### 32.2 视觉合同

| 内容 | 字体／行高 | 布局 |
|---|---|---|
| Title | PingFang SC Regular 14/14 | 高45px、左右padding12px，居中，只允许单行，超长省略 |
| Description标题 | PingFang SC Semibold 14px；单行14px，实际折行18px | 左对齐，可多行 |
| Description副标题 | PingFang SC Regular 12/16 | 可多行，不设固定最大行数 |

- 所有状态圆角12px，无描边、无阴影；有副标题时四周padding12px，主副标题gap8px。
- Description随内容自然增高，同排按最高项拉齐；156px宽、标题1行＋副标题2行的源样本高78px，
  **78px不是所有文案的固定高度或最小高度**，不保留示例专用84/104px固定高度。
- 未选中：背景Surface Inset `#F6F8FB`，标题Text Secondary `#757575`，副标题Text Tertiary `#999999`。
- 已选中：背景Primary `#FF6435`的6%透明度，标题和副标题均Primary。
- 警示：背景既有Warning BG `#FFEAE8`，标题和副标题均Error `#FF1930`。
- 上述18px／16px行高来自源稿，是本组件局部例外；不改全局1.5倍规则，不推广到其他组件。
  中文不使用元黑或数字字体。

### 32.3 组合规则

- 无副标题每行2–5列；有副标题每行2–3列；不提供单列模式。
- 同组使用一致的Content结构、等宽列与同排等高；有副标题时禁止为了塞入4–5列缩字或截断说明。
- 2–4列项间距8px；5列项间距4px。宽度由父容器决定，不把源样本156px写成固定项宽。
- 分组是布局与选择逻辑，不新增业务卡片底色、标题或外边距。警示计数用同级网格布局组合，
  不纳入选择值集合；数字含义由业务提供，不自动解释成已选数量。

### 32.4 Warning Item · Count

独立静态展示结构：45px高、12px圆角、左右padding12px；标签与数字整体居中，gap4px。
标签PingFang SC Regular 14/14，数字Barlow Semi Condensed Bold 16/16；背景与文字沿用Warning色。
不提供选中态、点击事件或副标题；保持数字可见，标签过长单行省略。

H5调用与事件、精确Figma属性只维护在`v9-figma-map.md`的对应映射章节。

## 组件 Figma Node ID 索引

| 组件 | Node ID | 类型 |
|------|---------|------|
| Button Full-width | `53:2650` | COMPONENT_SET |
| Action Button Group | `53:4557` | COMPONENT_SET |
| Button | `53:2666` | COMPONENT_SET |
| App bars | `1:714` | COMPONENT_SET |
| CellCard / Shell | `53:4359` | COMPONENT_SET |
| CellCard（Legacy，正式库） | `1:1462` | COMPONENT_SET |
| Cardheader | `53:3382` | COMPONENT_SET |
| CardContent | `53:3274` | COMPONENT_SET |
| Entry Item | `88:966` | COMPONENT_SET |
| Entry Group | `88:1107` | COMPONENT_SET |
| Accent Card / Single | `231:2280` | COMPONENT |
| Accent Card / Split | `231:2294` | COMPONENT |
| Accent Card / Grouped | `231:2311` | COMPONENT_SET |
| Pill Option | `134:2555` | COMPONENT_SET |
| Pill Option Group / Action | `134:2580` | COMPONENT |
| Pill Option / Horizontal Scroll Frame | `134:2587` | COMPONENT |
| Form Item / Textual | `156:1970` | COMPONENT_SET |
| Form Item / Control | `156:2079` | COMPONENT_SET |
| Form Item Group | `161:2626` | COMPONENT |
| CellCard / Form Mode | `161:2645` | COMPONENT_SET |
| background/Focus | `175:3045` | COMPONENT |
| Alert | `53:2872` | COMPONENT_SET |
| arrow | `53:3541` | COMPONENT_SET |
| Badge | `1:1536` | COMPONENT_SET |
| Status Bar | `1:1545` | COMPONENT_SET |
| TextLink | `53:3019` | COMPONENT_SET |
| ExpandLink | `53:3438` | COMPONENT_SET |
| tag | `53:3057` | COMPONENT_SET |
| Tabs（Line / Card统一Set） | `274:2175` | COMPONENT_SET |
| StatusOverlay | `53:3251` | COMPONENT_SET |
| Selection Control | `53:3858` | COMPONENT_SET |
| Agreement | `53:3901` | COMPONENT_SET |
| Dialog | `53:5759` | COMPONENT |
| info-icon | `1:2015` | COMPONENT_SET |
| Tooltip | `1:2072` | COMPONENT_SET |
| Toast.Icon | `53:4338` | COMPONENT_SET |
| Toast | `67:5896` | COMPONENT |
| Loading | `1:2097` | COMPONENT_SET |
| Quantity Stepper | `1:2026` | COMPONENT_SET |
| _Metric/Trend | `1:2466` | COMPONENT_SET |
| Metric Item | `1:2189` | COMPONENT_SET |
| Metric Group | `1:2130` | COMPONENT_SET |
| Scrollable Metrics | `1:2107` | COMPONENT_SET |
| Address Group | `67:5956` | COMPONENT_SET |
| Empty | `67:5952` | COMPONENT |
| Task Sheet / Shell | `202:2121` | COMPONENT_SET |
| Option Tile | `303:2188` | COMPONENT_SET |
| Warning Item · Count | `303:2204` | COMPONENT |

---

## 组件库 Component Key 索引（用于 importComponentByKeyAsync）

搭建页面时**必须使用以下 Key 导入组件实例**，禁止手动用 Frame 拼装已有库组件。

> **Key 主来源**：9.0规范（fileKey: `KKuaHEUNwnenHwumr4a3Ta`），页面：控件。
> 最后核对：2026-10-13。Tabs已统一为主规范库Node `274:2175`的发布Set；Rounded暂不接入。

### 数据组件（`9.0规范`）

| 组件 | Component Key | 预期导入方法 | 变体数 | 当前用途 |
|---|---|---|---:|---|
| `_Metric/Trend` | `eaf83aa21f6ea003b10f9230832e3477758184cb` | `importComponentSetByKeyAsync` | 2 | Metric Item 的 Up/Down 直接依赖 |
| Metric Item | `325f62a22400f8b48bc4152ab0a9630d1a13050b` | `importComponentSetByKeyAsync` | 24 | 单项指标；Trend 为暴露嵌套实例 |
| Metric Group | `dfce934231c846e5b5a0a4b4d1a8f8e1c03a82fb` | `importComponentSetByKeyAsync` | 8 | Container × Count；固定1–4项 Pure 组合 |
| Scrollable Metrics | `3a60277975447586bdcb6dc06178968c7c675404` | `importComponentSetByKeyAsync` | 2 | Container；横滑 Subtle 组合 |

上述 Key 来自 fileKey `KKuaHEUNwnenHwumr4a3Ta`。跨文件导入前必须检查发布状态；未发布时不得
把它们当作可跨文件导入的生产库，也不得用手工 Frame 作为导入失败的替代方案。

### 组件索引（按真实发布状态使用）

| 组件 | Component Key | 导入方法 | 变体数 | 用途 |
|------|--------------|---------|-------|------|
| App bars | `9e8e0bc5b08337e2e67bb26d1f26d97419349c11` | `importComponentSetByKeyAsync` | 8 | 导航栏；含 None black |
| Button Full-width | `c5d57a72c624a7978ef5fdec6e2010171ebbb0ae` | `importComponentSetByKeyAsync` | 5 | 通栏按钮；Fill父级；直接依赖 |
| Action Button Group | `af44df67d9d41c12a1b3a2a875305fa4fc58711b` | `importComponentSetByKeyAsync` | 4 | Fill操作按钮组合；无背景与内边距 |
| Task Sheet / Shell | `3e5a87efceded0f91bcb4fa4472ff1799aebd8c2` | `importComponentSetByKeyAsync` | 2 | 已发布CURRENT；正式任务型底部容器 |
| Button | `224026a8170761826d4fa9f6b9471e931a58a35d` | `importComponentSetByKeyAsync` | 27 | 常规按钮（Large/Medium/Small） |
| Cardheader | `fea3a0eced02f3bbf3bc9475e82141c3f814ce99` | `importComponentSetByKeyAsync` | 8 | 卡片头部 |
| CardContent | `de76d55616005615dfed5df6425a12d6c53b4125` | `importComponentSetByKeyAsync` | 10 | 卡片内容 |
| Entry Item | `b3a6aadac84920a3275e0abe8c484f25febab0c9` | `importComponentSetByKeyAsync` | 26 | 单个功能入口；横向/纵向、Pure/Subtle |
| Entry Group | `92e4ea0fe8817c2103b977f0e8833f14ac18cd0e` | `importComponentSetByKeyAsync` | 30 | List与Grid 2/3/4/5功能入口组合 |
| Accent Card / Single | `7164d71177a5006524fbeff88a0cb17f8b58e614` | `importComponentByKeyAsync` | — | 单区主信息及可选属性 |
| Accent Card / Split | `e8c552655e0ae8ffa1f446550d9a6934fb66d635` | `importComponentByKeyAsync` | — | 同一对象上下分区 |
| Accent Card / Grouped | `728fffcdfc89a48f1d7cd8830c0aff105630889f` | `importComponentSetByKeyAsync` | 4 | Header + 可替换同级子项 |
| Pill Option | `73ea26bf053cde1706bb4bf3fbc6b932c3704300` | `importComponentSetByKeyAsync` | 8 | 单个胶囊项；State × Context × Icon |
| Pill Option Group / Select | `a089cc889c9548ca8c0e83316abb41a90a952b7e` | `importComponentSetByKeyAsync` | 2 | Required/Optional单选逻辑；Options Slot任意数量 |
| Pill Option Group / Action | `0e779e851ee3c531adb1775457c4a031e3bc5042` | `importComponentByKeyAsync` | — | 即时快捷操作；Options Slot任意数量 |
| Pill Option / Horizontal Scroll Frame | `de1adea3af9f7f1b450370cdb6804e7ae56ecc36` | `importComponentByKeyAsync` | — | 超过4项时的单行横滑视口 |
| Form Item / Textual | `330f6f5aad5bd6c37aa868638e36f26c5a30229a` | `importComponentSetByKeyAsync` | 12 | Input/Select × Empty/Filled × Default/Error/Disabled |
| Form Item / Control | `b209337c26cc7df60b10d56df59381ab693fd5e4` | `importComponentSetByKeyAsync` | 12 | Radio/Checkbox × Checked False/True × Default/Error/Disabled |
| Form Item Group | `23d8858fea9d0034c1671b66ecf52671f595258f` | `importComponentByKeyAsync` | — | 任意数量Textual/Control连续组合；0间距、无外层Padding |
| CellCard / Form Mode | `0b91e870ccc0502bb91ae7f95b1bf6c71d389ecc` | `importComponentSetByKeyAsync` | 2 | Header True/False；Cardheader + Form Item Group |
| background/Focus | `f422b4ea2accd5a8c0c6e8ef715a793ef3be9c69` | `importComponentByKeyAsync` | — | 370px高的单任务顶部氛围背景；唯一正式Background组件 |
| Status Bar | `5ae52e4d10b33a143c0442c40b046dd4142f6f9c` | `importComponentSetByKeyAsync` | 2 | 底部 Home Indicator（light/dark） |
| Alert | `e6ca9c4ca52c7057d33ed4fb958331f12f4863b2` | `importComponentSetByKeyAsync` | 12 | 提示条 |
| TextLink | `9b5dff35ea49a2a3fe1ee92f717df9b9e6ed2263` | `importComponentSetByKeyAsync` | 12 | 文字链接 |
| arrow | `039a24a1cd5b5668c8fbb594cd3215fd900cd167` | `importComponentSetByKeyAsync` | 48 | 箭头/关闭图标 |
| Badge | `0212f7d9033e2c87eae8adee18c0dac1cb1e44a2` | `importComponentSetByKeyAsync` | 4 | 数量/溢出/新内容/未读点角标 |
| ExpandLink | `1bceaf94e775b40b0136862d9524acb5a011ed41` | `importComponentSetByKeyAsync` | 24 | 展开/收起链接 |
| tag | `c98fb3fcc4effbb025029bd2b6c047ff6bb8df25` | `importComponentSetByKeyAsync` | 24 | 标签（outline/light/solid × Default/success/error/tertiary） |
| Tabs | `a681c138c3d45ba5171ab72ca575931f4aefa65d` | `importComponentSetByKeyAsync` | 23 | Line 18个结构变体 + Card 5个变体；Line另有背景BOOLEAN |
| StatusOverlay | `782146985226886d1e121f8d6095e8713c821bc5` | `importComponentSetByKeyAsync` | 3 | 状态蒙层（Success/failed/None） |
| Selection Control | `f2b2b67087429cf42a14334ffcfcea6b420a82cc` | `importComponentSetByKeyAsync` | 8 | checkbox/radio 的选中、未选与禁用态 |
| Agreement | `078cc511ceec8f47b82e413d1c57513f0f5603e9` | `importComponentSetByKeyAsync` | 3 | 协议详情、已阅读、未阅读 |
| Dialog | `60b7ce0dfb77bae12d0fcc9afd9845dc982328ef` | `importComponentByKeyAsync` | - | 已发布CURRENT；含媒体槽、Agreement与必选操作区 |
| info-icon | `8d2dd490e80649720116077901d32424b01aa2d3` | `importComponentSetByKeyAsync` | 2 | 12/14px信息图标（M/S，无状态变化） |
| Tooltip | `a84674c3788dbf7127dad3d0188c7b06ac53e532` | `importComponentSetByKeyAsync` | 4 | 四方向文字提示气泡 |
| Toast.Icon | `ee5ed6f07d3efde40ab7fd90620400aeb03f4413` | `importComponentSetByKeyAsync` | 4 | Toast 的warning/success/error/loading图标 |
| Toast | `aca48e84f8f65fdf013efd4074e95be185c5b5e1` | `importComponentByKeyAsync` | - | 页面中央轻提示；可隐藏图标 |
| Loading | `64b3b6a365d2f40f48ba3d4af93ae7f712dd9c14` | `importComponentSetByKeyAsync` | 3 | 常规、上滑、下拉加载提示 |
| Quantity Stepper | `113641d4e06fbbd3e6adb4018b07a73830189ea2` | `importComponentSetByKeyAsync` | 3 | 1–99数量递增递减 |
| CellCard / Shell | `98c23ccd985a334de8197701fa1d02ead7c910e0` | `importComponentSetByKeyAsync` | 8 | Header/Content/Footer 三Region容器 |
| Address Group | `146e09239141aba3be4a34a393db834e0e67653a` | `importComponentSetByKeyAsync` | 2 | 起终点两行地址；Default/Large |
| Empty | `cf091b39ec48ac5e170b726d6c0f1670b9621dab` | `importComponentByKeyAsync` | — | 空状态正式组件；文案写入公开TEXT属性 |
| Option Tile | `82721d3fe1471e5052d7346b0470293b482d7317` | `importComponentSetByKeyAsync` | 6 | 多选网格与不可交互警示 |
| Warning Item · Count | `3064873b46f0f7f7d36b6f7064e3722e4fb5d2f2` | `importComponentByKeyAsync` | — | 静态警示标签与计数 |

### CellCard / Shell 发布状态

| 组件 | 来源 | Component Key | 状态 |
|------|------|---------------|------|
| CellCard / Shell | 9.0规范 Node `53:4359` | `98c23ccd985a334de8197701fa1d02ead7c910e0` | 正式发布；新页面使用 |
| CellCard（Legacy） | 9.0规范 Node `1:1462` | `c126d13cbbf9959f76f29ebd2494aa32da4fcdfd` | 仅兼容既有固定结构 |

新页面必须导入 CellCard / Shell；Legacy Key 不得冒充 Slot 版，也不得用于新的自由组合。

### Legacy CellCard 兼容流程

Legacy 组件固定包含 Cardheader + CardContent + Button Full-width，只用于维护既有页面：

1. 通过 Legacy Key 导入并创建实例；
2. 只 resize 外层宽度为351px，不 resize 固定内部节点；
3. 通过内部 Cardheader、CardContent 和 Button 属性维护既有结构；
4. 不向 Legacy CellCard 增加新的自由组合、Content Pattern 或 Card Pattern。

⚠️ **禁止批量恢复 visible**：`findAll(n => !n.visible).forEach(n => n.visible = true)` 会破坏规范库默认隐藏的节点状态。

### Legacy CardContent 变体选择指南

| 业务场景 | 应用变体 | 说明 |
|---------|---------|------|
| 主标题 + 副标题（上下纵排） | `ContentLayout=Editorial` | 单条记录的标题+描述，如"最近任务 / 上传时间" |
| 多列数据（左右横排） | `ContentLayout=list` | 左边正文、右边辅助描述对齐排列 |
| 含图片 | `ContentLayout=Media` | 带图片的内容区 |
| 不需要内容区 | `visible=false` 整个 CardContent 实例 | 如 FAQ 卡片只需要 Cardheader |

### 参考组件（仅供查看，不直接实例化）

| 组件 | Component Key | 说明 |
|------|--------------|------|
| card（旧版） | `75e370d87c58df2c1f3911f730ce3fd6965d8848` | ⚠️ 已废弃；新页面等待正式发布的 CellCard / Shell |

### 各组件关键属性速查

#### Button Full-width
- TEXT 属性 key：`text#1094:3`
- 变体属性：`variant`（Primary/Subtle）、`state`（Default/Visited/Disabled）
- 当前 Component Set Key：`c5d57a72c624a7978ef5fdec6e2010171ebbb0ae`

#### Action Button Group
- Component Set Key：`af44df67d9d41c12a1b3a2a875305fa4fc58711b`
- 变体属性：`layout`（Primary/Stacked/Inline/Secondary）
- 组件集只暴露布局变体；按钮文案继续修改内部 Button Full-width 的 `text#1094:3`
- 目标结构必须由组件实例保留，禁止 detach 后重排按钮

#### Button
- Component Set Key：`224026a8170761826d4fa9f6b9471e931a58a35d`
- TEXT 属性 key：`Button Text#1115:178`
- 变体属性：`mode`（Primary/Subtle/Weak）、`statue`（Default/Vistited/Disabled）、`size`（Large/Medium/Small）

#### Cardheader
- Component Set Key：`fea3a0eced02f3bbf3bc9475e82141c3f814ce99`；发布状态 `CURRENT`，
  使用 `importComponentSetByKeyAsync` 导入。
- TEXT 属性 key：`header Text#1114:0`（标题）、`SubtitleText#1114:155`（副标题）
- BOOLEAN 属性 key：`ShowSubtitle#578:18`（是否显示副标题）
- 变体属性：`Actiontype`（None/Link/Expand）、`ExpandStated`（None/Expand/Collapsed）、`Show Tag`（true/false）
- ⚠️ **必须直接用目标变体创建实例**，禁止先用 None 变体创建再通过 `setProperties` 切换 Actiontype，切换后高度会异常压缩为 19px
- ⚠️ **禁止 resize 高度**；当前无Tag变体高40px、带Tag变体高43px，创建后保留源高度
- 正确顺序：① `linkVariant.createInstance()` → ② `resize(w, inst.height)`（只改宽）→ ③ `setProperties`（只改 BOOLEAN/TEXT）→ ④ `replaceFonts` → ⑤ 改 `characters`

#### CardContent
- TEXT 属性 key：`TitleText#1137:0`（正文标题）、`DescriptionText #1114:132`（描述）
- Component Set Key：`de76d55616005615dfed5df6425a12d6c53b4125`
- BOOLEAN 属性 key：`Show Title Medium#578:20`、`  ShowDescription#1146:21`、`ShowFloatingButton#578:22`
- 变体属性：`surface`（pure/subtle）、`ContentLayout`（Editorial/list/Media）、`Media size`（None/Large/Medium）、`Action`（None/Floating）

#### Entry Item
- Component Set Key：`b3a6aadac84920a3275e0abe8c484f25febab0c9`
- 变体属性：`Orientation`、`Surface`、`Icon Size`、`Interaction`、`Description`
- TEXT属性：`Title#27:0`、`Description Text#27:12`；INSTANCE_SWAP：`Icon#27:36`
- Vertical无Trailing Button；Subtle Vertical无Icon Size 50

#### Entry Group
- Component Set Key：`92e4ea0fe8817c2103b977f0e8833f14ac18cd0e`
- 变体属性：`Layout`、`Count`、`Item Surface`、`Icon Size`
- 直接依赖Entry Item Set Key `b3a6aadac84920a3275e0abe8c484f25febab0c9`
- 业务文案和Icon写入内部 `_Entry/Item N` 实例；禁止detach后重排

#### arrow
- Component Set Key：`039a24a1cd5b5668c8fbb594cd3215fd900cd167`
- 变体属性：`arrow icon`（grey/white/orange/red）、`size`（L/M/S）、`icon`（arrow/close button/down/up）
- `arrow icon` 含空格；不得沿用旧属性名 `arrowIcon`

#### Badge
- Component Set Key：`0212f7d9033e2c87eae8adee18c0dac1cb1e44a2`
- 变体属性：`type`（count/overflow/dot/label-new）
- 仅 `count` 暴露可编辑文本属性；`overflow`、`label-new` 与 `dot` 使用源组件固定内容

#### Selection Control
- Component Set Key：`f2b2b67087429cf42a14334ffcfcea6b420a82cc`
- 变体属性：`type`（checkbox/radio）、`state`（unchecked/checked/unchecked disable/checked disable）
- 禁用状态继续保留在 `state` 枚举中，不新增 `disabled` 属性

#### Agreement
- Component Set Key：`078cc511ceec8f47b82e413d1c57513f0f5603e9`
- 变体属性：`state`（detail/checked/unchecked）
- TEXT 属性 key：`Text#1980:0`，只作用于 checked/unchecked；detail 文案固定
- checked/unchecked 直接依赖 Selection Control 的 checkbox 变体

#### Dialog
- Component Key：`60b7ce0dfb77bae12d0fcc9afd9845dc982328ef`；当前源状态 `CURRENT`，身份为 `component`
- BOOLEAN 属性：`Close button#53:1`、`Head Media#53:2`、`Content Text#53:3`、`Content image#53:4`
- TEXT 属性：`Tittle Text#53:5`、`Content Text2#53:6`
- `Header Media` 与 `Content Image` 是可替换槽位：先打开对应 Boolean，再覆盖槽位内容；禁止 detach 或改槽位尺寸
- 直接依赖 Agreement 与 Action Button Group；后者继续依赖 Button Full-width

#### info-icon
- Component Set Key：`8d2dd490e80649720116077901d32424b01aa2d3`
- 有效变体属性：`size`（M/S）；没有 Disabled 状态
- H5 使用随 Skill 固化的源 SVG，不用字符或临时 CSS 重画

#### Tooltip
- Component Set Key：`a84674c3788dbf7127dad3d0188c7b06ac53e532`
- 变体属性：`arrow`（top-right/top-left/bottom-right/bottom-left）
- TEXT 属性：`Text#295:0`

#### Toast.Icon
- Component Set Key：`ee5ed6f07d3efde40ab7fd90620400aeb03f4413`
- 变体属性：`type`（warning/success/loading/error）
- H5 使用 `assets/components/toast/` 中随 Skill 固化的 Figma 原始导出资产；warning/success/error
  使用SVG，loading使用18×18透明PNG以规避源SVG的 `foreignObject` 浏览器兼容问题

#### Toast
- Component Key：`aca48e84f8f65fdf013efd4074e95be185c5b5e1`
- BOOLEAN 属性：`icon#67:13`
- TEXT 属性：`Text#67:14`
- 图标类型通过内部 `Toast.Icon.type` 设置；主组件没有独立 Variant 或 Slot
- 直接依赖正式 `Toast.Icon`；2026-07-31 已移除隐藏的未发布旧图标实例

#### Loading
- Component Set Key：`64b3b6a365d2f40f48ba3d4af93ae7f712dd9c14`
- 变体属性：`type`（normal/pull-up/pull-down）；图标始终存在，不提供 icon Boolean 状态
- 直接依赖 `加载/加载` Component Key `d44e92e0421b43e0512c0d5515e0e3a4e758c0c6`，禁止 detach 后重画

#### Quantity Stepper
- Component Set Key：`113641d4e06fbbd3e6adb4018b07a73830189ea2`
- 变体属性：`state`（default/max/min）
- TEXT 属性：`value#149:4`，仅 default 变体开放；max/min 固定99/1

#### tag
- 变体属性：`size`（Default/S）、`Variant`（outline/light/solid）、`Status`（Default/success/error/tertiary）
- 常用组合：待上传 → `Variant=light, Status=Default`；审核中 → `Variant=light, Status=success`；未通过 → `Variant=light, Status=error`

#### App bars
- 变体属性：`类型`（Flat/Text/None/Icon/Flat white/Text white/None white/None black）
- 原始尺寸：**375×88px**（含内部顶部系统状态区44px + 导航栏44px），创建实例后**禁止 resize**，保持原始高度
- ⚠️ **App bars 内部已包含顶部系统状态区**，页面顶部只需放置 App bars 一个实例；禁止再拼44px顶部状态栏。底部 Status Bar / Home Indicator 不属于重复项
- ⚠️ **内容区起始 y 固定为 88**，不能用 `instance.height`（返回值不可靠）推算
- ⚠️ PingFang SC 字体不可用时，需先对实例内 TEXT 节点替换字体（Noto Sans SC），再修改 `characters`，不能直接 `setProperties`

#### Status Bar
- Component Set Key：`5ae52e4d10b33a143c0442c40b046dd4142f6f9c`
- 变体属性：`theme`（light/dark）
- 该组件是页面底部 Home Indicator，与 App bars 内部的44px顶部系统状态区相互独立

#### Tabs
- Set Key：`a681c138c3d45ba5171ab72ca575931f4aefa65d`；统一从主规范库导入Set实例，不再使用旧Line单变体Key。
- Line变体属性：`variant=line`、`amount=2/3/4`、`Active=1..amount`、
  `Distribution=Equal/Start`；`Show Background#110:0`为BOOLEAN，默认`true`。
- Card变体属性：`variant=card`、`amount=2/3`、`Active=1..amount`；Distribution与背景显隐不作用于Card。
- `Label 1#119:0`、`Label 2#119:1`、`Label 3#119:2`为TEXT属性；四项Line的第4项在源组件
  补齐公开TEXT属性前，通过实例内可见文字层定向覆盖，不得detach。
- 使用 `Active` 属性直接切换选中状态，禁止detach后手工移动Indicator；Line创建后保持375×42px。
- Card内容写入 `Content Area / Adaptive#125:0` Slot。
- H5使用 `panel-1` / `panel-2` / `panel-3` 命名Slot；映射Figma时只把当前Active面板写入
  `Content Area / Adaptive#125:0`。
- 使用时保持351px宽；不同Tab内容按最高内容统一高度；全部Active状态保持Level 1阴影。

#### StatusOverlay
- 变体属性：`State`（Success/failed/None）

> 如需查找更多组件，使用 `search_design_system` 并限定 libraryKey:
> `lk-2da8834b5155e15c43aaff36eb3d6dfd723be0037508c3655ce7ee6ff6915f7514fbedede0db3112d0b39eec678b7cb800311cfbc5084939677f5fa9b42fff39`
