> **数值唯一源：`assets/tokens.json`。** 改值请改 tokens.json 后跑 `node build-tokens.js`；本文件表格为人读规范，禁止绕过 token 自造数字字号。

# 字体与数据规范

## 一、字族与字重

| Token | 字族 | 用途 |
|---|---|---|
| `Text` | PingFang SC（回退 Noto Sans SC） | 中文标题、正文、指标名称、中文/英文单位 |
| `Number` | Barlow Semi Condensed（回退 PingFang SC） | 核心数字、小数、数字标点、货币符号 |

| Token | 实际字重 |
|---|---|
| `Regular` | Regular / 400 |
| `Medium` | Medium / 500 |
| `Semibold` | Semibold / 600 |
| `Bold` | Bold / 700 |

使用核心数字时统一采用 Barlow Semi Condensed Bold 700，letter-spacing 为 0。`DataValue` 的值只允许数字或英文，不提供中文值类型；中文状态或描述使用普通 Text 组件，不进入数字组件。

## 二、Number 四级核心字阶

| 样式名 | Figma 路径 | CSS Token | 字号 | 2×稿字号 | 行高 | 典型角色 |
|---|---|---|---:|---:|---:|---|
| Number/XL | `Number/XL` | `--v9-fz-number-xl` | 36px | 72px | 36px | 页面或卡片核心数据、Hero 数据 |
| Number/L | `Number/L` | `--v9-fz-number-l` | 30px | 60px | 30px | 模块一级数据、重点比较数据 |
| Number/M | `Number/M` | `--v9-fz-number-m` | 27px | 54px | 27px | 常规数据看板、重复概览指标 |
| Number/S | `Number/S` | `--v9-fz-number-s` | 24px | 48px | 24px | 高密度辅助数据、决策信息行 |

750px 宽的 Figma 画板属于 2×稿。读取该类文件时先换算到 375px 逻辑尺寸，再匹配 Number Token；不要把 Figma 中的 72/60/54/48 误认为 H5 字号。

### 字阶选择顺序

1. 先判断业务重要性和页面层级：页面核心、模块核心、常规概览、辅助信息。
2. 再检查信息密度、最长可能值、单位长度和可用宽度。
3. 使用最长真实值验证，不使用最短示例值决定字号。
4. 同一行或同一对比组保持同一核心字阶。
5. 最长值无法容纳时整组降一级，不单独缩小其中一项。

禁止把数据数量直接映射为字号。单行 1–4 项都可以按需使用 XL/L/M/S；数量只影响可容纳性，不决定业务层级。例如，两项模块汇总既可在页面核心场景使用 XL，也可在普通模块中使用 L。

## 三、整数、小数、货币符号与单位

把“前缀 + 整数/小数 + 单位”视为一个完整数据组合。对齐、居中、测量宽度和溢出判断都以完整组合为准，不只计算整数。

### 小数与货币前缀

| 核心数字 | 默认小数字号 | H5 字号来源 | 说明 |
|---|---:|---|---|
| XL 36 | M 27 | `--v9-fz-number-m` | 适合页面 Hero 金额，如 `¥2620.55` |
| L 30 | S 24 | `--v9-fz-number-s` | 适合模块一级金额，如 `¥1200.36` |
| M 27 | 18px 辅助字号 | 复用 `--v9-fz-headline-m` 的18px值 | Figma 样式为 `Number/Auxiliary/M`，不增加第五级核心字阶 |
| S 24 | 16px 辅助字号 | 复用 `--v9-fz-headline-s` 的16px值 | Figma 样式为 `Number/Auxiliary/S`，用于高密度数据 |

- 让小数点跟随整数部分，不单独降级或增加间距。
- 让整数和小数保持 Barlow Semi Condensed Bold、相同颜色和 0 letter-spacing。
- 让位于数字前的货币符号（如 `¥`）与核心整数使用同一字号、Number 字族、Bold 700 和颜色；只有小数部分按上表降级。
- 18/16 的 H5 映射只复用现有字号值，不继承 Headline 的 PingFang SC 或 Semibold 属性；实际字体仍由 Number 样式控制为 Barlow Semi Condensed Bold 700，单行行高等于字号。

### 组件级紧凑数字

`Scrollable Metrics` 是当前明确采用18px紧凑数字的组件。其前缀、整数、小数和英文值统一使用
18px、Barlow Semi Condensed Bold 700、18px行高与0字距；单位仍为14px Text Bold。
该18px复用 `Number/Auxiliary/M` 的字号语义，但属于组件合同，不扩充 XL/L/M/S 四级核心字阶，
也不新增 Text Style、Variable 或 Token。

### 单位

- 让单位字号与该指标的名称字号一致，不占用 XL/L/M/S 四级核心数字字阶。
- 让单位使用 Text 字族的 Bold 700；这是组件文字样式，不新增独立字号或颜色 Token。
- 让单位颜色继承核心数字颜色，不使用透明度或次要文字色弱化。
- 让核心数字与单位保持 `2px` 间距，直接复用 2XS：Figma 使用 `space/space/2xs`，H5 使用 `--v9-space-2xs`；不要新增数据专用间距 Token。
- 让数字、小数和货币符号按文字基线对齐；单位在共同基线基础上使用Number组件的固定光学校正：
  XL/L向上2px，M/S向上1px。Metric Item复用同尺寸Number结果，不再增加第二次位移。
- 中文/英文单位使用 Text 字族；货币符号和纯数字标点使用 Number 字族。

“单位不占核心字阶”只表示 Token 分工：单位仍属于数字组件规范，不等于把单位视为普通、无关的正文。

H5 组合示例：

```html
<div class="v9-number v9-number--xl"
     style="--v9-number-unit-size:var(--v9-fz-body-m)">
  <span class="v9-number__affix">¥</span>
  <span class="v9-number__value">
    <span class="v9-number__integer">2620</span>
    <span class="v9-number__decimal">.55</span>
  </span>
  <span class="v9-number__unit">元</span>
</div>
```

实际组件只保留业务需要的前缀或单位；不要为了套结构同时添加多余的“¥”和“元”。

## 四、数据对齐

### 水平对齐

- 对等宽指标格、短数字、横向概览采用居中时，让指标名称和完整数据组合共享同一中心轴。
- 对长金额、比较数据或高密度决策信息采用左对齐时，让指标名称和完整数据组合共享同一左边界。
- 在同一模块内保持统一对齐方式，不因某个数字较短而单独更改。
- 不默认建立统一右对齐或小数点对齐；只有表格、账单等明确要求纵向比数时再启用。

### 垂直对齐与阅读顺序

允许按阅读任务选择两种结构：

- `指标名称 → 核心数字`：先理解含义再读值，适合金额、保障、决策和比较模块。
- `核心数字 → 指标名称`：先扫结果再读含义，适合首页概览、评分和快速状态看板。

同一组数据只采用一种顺序。指标名称、核心数字、环比等数据内部节点不默认增加 4px；先依靠文字自身的行盒形成节奏，只有结构确有需要时再增加明确间距。

Pure/Subtle、固定/横滑和数据 Grid gap 属于组件组合规则，统一见 `components.md`「数据组件」。

## 五、普通文本样式

普通文本和 Number 都按实际渲染行数设置行高：单行文字的行高等于字号；发生换行后，整个文字节点使用字号的1.5倍行高。H5正式组件通过运行时检测实际行数并切换 `.is-multiline`，不要通过文案长度猜测是否多行。

| 样式名 | Figma 路径 | 字族 | 字重 | 字号 | 行高 | 用途 |
|---|---|---|---|---:|---:|---|
| Headline Extra Large | Page Pattern / Page Title | PingFang SC | Semibold | 26px | 26px / 39px | 正文中的任务型页面标题 |
| Headline Large | `Healine/Headline Large` | PingFang SC | Semibold | 22px | 22px / 33px | 页面大标题 |
| Headline Medium | `Healine/Headline Medium` | PingFang SC | Semibold | 18px | 18px / 27px | 区块标题 |
| Headline Small | `Healine/Headline Small` | PingFang SC | Semibold | 16px | 16px / 24px | 卡片/小标题 |
| Title | `Title/Title` | PingFang SC | Semibold | 16px | 16px / 24px | 列表项标题 |
| Title Medium | `Title/Title Medium` | PingFang SC | Semibold | 14px | 14px / 21px | 次级标题/按钮文字 |
| Body Large | `Body/Body Large` | PingFang SC | Regular | 16px | 16px / 24px | 主要正文、重要描述 |
| Body Medium | `Body/Body Medium` | PingFang SC | Regular | 14px | 14px / 21px | 常规正文、指标名称、描述 |
| Body Small | `Body/Body Small` | PingFang SC | Regular | 12px | 12px / 18px | 紧凑辅助正文 |
| Label Medium | `Lable/Lable Medium` | PingFang SC | Regular | 11px | 11px / 16.5px | 小标签/角标 |

> Figma 源分组中的 `Healine`、`Lable` 为既有拼写，查找旧样式时保留；新建 Number 样式统一使用 `Number/XL-L-M-S`。

Headline Extra Large只用于明确命中的Page Pattern页面标题，不替代Appbar标题、卡片标题或普通区块标题。
当前值来自 `Focused Form Page` 参考节点；页面组合与适用边界见 `pages/focused-form-page.md`。

## 六、交付自查

- 除正式组件明确声明的辅助数字合同外，核心数据是否只使用 36/30/27/24 四级字阶，没有保留旧 45px Display 或自行扩充第五级？
- 是否按业务重要性、层级、密度、最长值和空间选字号，而非按数据数量固定？
- 同组数据是否保持同一核心字阶和同一对齐轴？
- 居中时是否居中了完整数据组合，而不是只居中整数？
- 货币前缀是否与核心整数同字号，小数是否按组合规则降级，且三者保持基线对齐？
- 单位是否与指标名称同字号、与数字同色，并复用 2XS 保持 2px？
- 单行文字与 Number 的行高是否等于字号；多行文字是否按实际渲染行数切换为字号×1.5？
- 26px Headline Extra Large是否只用于符合Page Pattern定义的任务型页面标题，没有替代Appbar或区块标题？
- 数据内部是否避免无依据的默认 4px？
- 组件层的 Pure/Subtle 与 Grid gap 是否按 `components.md` 执行？
