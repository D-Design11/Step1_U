# 组件维护事务

本分支只用于新增、修改、替换或下线组件，以及发现 Figma、H5、映射之间发生漂移时。
它不是普通页面出图的附加步骤。收到组件链接后先完成源组件核对；有不确定的变体、状态、Slot、
交互或直接依赖时，先向用户确认，再修改规范或实现。
普通页面H5产出按 `workflow.md`；把已确认页面写入Figma按 `figma-workflow.md`。

## 完成门槛

只有以下三项同时成立，组件才能登记为 `V9_COMPONENTS.kind=component`：

1. Figma 中存在已发布、可跨文件导入的真实 Component / Component Set；
2. H5 中存在可直接调用的 `<v9-*>`，包含内部 DOM、SVG/资产、状态、交互与可访问性；
3. `v9-figma-map.md` 中存在可执行的 Component Key、变体、内容属性和 H5 属性映射。

任一项缺失时，使用 `pending`、`primitive`、`internal` 或 `h5-only` 表达真实状态，并在交付结果中
明确缺项。只完成 CSS、演示页或某个 Figma Frame，不算组件完整接入。

## Step 1：读取源组件并确认范围

1. 打开主规范库文件（`KKuaHEUNwnenHwumr4a3Ta`）查询当前组件列表，与 `components.md` 做全量对比；
   这项全库核对只属于组件维护事务，不在普通 H5 页面出图前重复执行。
2. 读取用户提供或差异清单命中的 Figma Component / Component Set，不以截图或旧文档代替源组件。
3. 核对组件名称、变体轴、属性类型、默认值、状态、Slot、尺寸、Auto Layout、可见层级与直接依赖。
4. 对比 `components.md`、`v9-figma-map.md`、`V9_COMPONENTS` 与现有 H5 实现，列出新增、变化、删除项。
5. 组合组件必须展开检查内部实例；依赖 Set Key 或属性名变化时，同步更新调用方、映射、规范与H5实现。
6. Tabs 统一维护主规范库 Node `274:2175` 的已发布 Set；Line 与 Card 不再分属两个源。
   Line 的 Equal / Start 与背景显隐必须按同一 Set 属性映射，Rounded 暂不接入。
7. 未发布、Key 失效、属性含义不明或源组件本身存在冲突时，停止写入并向用户确认。

## Step 2：审计直接依赖与 Token

- 记录每个直接依赖的 Component / Component Set Key、使用变体和暴露属性；依赖变化时同步更新调用方。
- 优先复用规范库已有 Variable、Text Style、Effect Style 与 Space Token；不得在目标文件创建重复集合。
- 只有规范库确实不存在、且该值会跨组件复用时，才允许新增至 `tokens.json` 并同步正式 Figma Variables。
- 组件局部、不可复用的光学校正可以保留在组件实现中，并在组件合同和映射中说明；不得伪装成全局 Token。
- `v9-tokens.css` 与 `tokens-tables.md` 是生成产物，任何 Token 变更都只修改 `tokens.json` 后运行
  `assets/build-tokens.js`。

## Step 3：按职责更新文件

| 目标文件 | 只维护什么 | 不应写入什么 |
|---------|-----------|-------------|
| `references/components.md` | 组件职责、属性、结构、尺寸、视觉状态、Token 来源、Slot 边界和使用规则 | H5 class、CSS 变量名、Figma 文本属性 Key、导入代码、修复历史 |
| `references/v9-figma-map.md` | Component/Set Key、变体值、文本/布尔/Swap 属性、H5 属性与 class、精确实现补偿 | 业务选型解释、版本历史 |
| `assets/v9-components.js` | `<v9-*>` 注册、内部 DOM、属性、状态、交互、事件、ARIA 与 `V9_COMPONENTS.kind` | 设计规范长文、重复 Token 数值 |
| `assets/v9-core.css` | 组件样式、布局、状态与必要的组件局部补偿 | 可复用新值直接写死、页面业务组合 |
| `assets/components/` | 从源组件固化的 SVG、PNG、Spinner 等固定资产 | 可用 CSS/Token 表达的重复资源、示例业务图片 |
| `assets/tokens.json` | 跨组件复用的 Token 唯一数值源 | 单组件局部补偿、Figma Component Key |
| `references/custom-rules.md` | 尚未进入正式组件体系的用户覆盖规则与跨组件红线 | 已被正式组件吸收的重复合同 |
| `CHANGELOG.md` | 本次规范归位、Token 增删、映射、行为与兼容性变化 | 组件当前合同的重复副本 |

当用户规则已被正式源组件吸收时，把稳定组件合同迁入 `components.md`，把实现映射迁入
`v9-figma-map.md`，并删除 `custom-rules.md` 中的重复内容。`workflow.md` 的错误清单只收录可跨组件复用的
执行错误；单组件稳定参数不得复制到错误清单。

## Step 4：实现双端组件与映射

### Figma

1. 在规范源文件中维护真实 Component / Component Set，保留 Auto Layout、变量绑定和嵌套实例关系。
2. 变体用于有限、离散的结构或状态；文案、显隐、图标替换优先使用 TEXT、BOOLEAN、INSTANCE_SWAP
   或 Slot 属性，避免变体爆炸。
3. 可替换媒体区域必须保留实例和槽位结构：有真实内容时替换槽位内容，无内容时关闭槽位；不得写死
   业务图片、detach 或把图片叠在组件外。
4. 发布后回读可跨文件导入的 Key、属性和值；仅存在本地 Node ID 时保持 `pending`。
5. 维护已有源组件时，若插件环境无法加载其当前规范字体，停止需要字体加载的文本属性修改并记录待办；
   不得为完成脚本而把源组件永久替换成回退字体。页面搭建分支的字体回退策略不适用于规范主件维护。

### H5

1. 在 `v9-components.js` 封装可直接调用的自定义元素；页面不需要复制内部 DOM 才能使用。
2. 复用 `v9-core.css` 与 `assets/components/`；组件公开属性和状态与 Figma 变体/属性保持可直映。
3. 实现关键交互、事件、disabled/focus 行为与可访问属性；不能只补一组静态 CSS。
4. 页面演示只用于覆盖状态与交互，不代替正式运行时实现。

### 映射

1. 在 `v9-figma-map.md` 建立 Figma Component / Component Set 与 `<v9-*>` 的显式映射。
2. 记录顶层变体、内容属性、嵌套实例修改路径和必要回读方式；不记录可由有效 Set Key 与变体属性
   得到的冗余单 Variant Key。
3. 同步 `V9_COMPONENTS.kind`；三项门槛尚未齐全时不得登记为 `component`。

## Step 5：构建与一致性验证

按受影响范围执行，不能只验证发生修改的一侧：

- [ ] Figma：变体、属性、Slot、嵌套依赖、Variable/Text Style 绑定和发布状态均已回读。
- [ ] H5：全部状态和关键交互通过演示页与浏览器检查；DOM、SVG、事件和 ARIA 来自正式运行时。
- [ ] 映射：Figma 属性、H5 属性、默认值和枚举逐项对应；无过期 Key 或旧文本属性。
- [ ] Token：若 `tokens.json` 有变化，已运行 `node assets/build-tokens.js`，并确认两个生成文件仅包含预期差异。
- [ ] Runtime：修改 `v9-components.js`、`v9-core.css`、映射、资产或组件身份后，运行
  `node scripts/validate-h5-runtime.mjs`。
- [ ] 依赖：组合组件的全部直接依赖仍可导入，状态与暴露属性没有失效。
- [ ] 全量排查：修复同类问题后扫描全部变体、示例和相关页面，不能只检查首个实例。
- [ ] 清理：没有重复 Token/Variable、临时 Frame、示例占位图、失效资产或伪造 Component Key。

## Step 6：记录与发布

1. 更新 `CHANGELOG.md`，记录规范归位、组件身份、Key/属性、Token、H5 行为、兼容性与验证结果。
2. 发布新版 Skill 前检查 `SKILL.md` 的资源索引仍覆盖实际文件，并验证所有相对路径存在。
3. 运行 Skill 结构验证；若用户要求可下载包，再从验证通过的工作副本生成 zip。
4. 最终报告分别列出：Figma 变化、H5 变化、映射/文档变化、Token/资产变化、验证结果与尚未满足的门槛。

> Figma 与 H5 的结构同步不会自动发生。源组件变化未触发本事务时，Skill 会发生漂移；Token 构建只能
> 自动同步数值派生文件，不能替代组件结构、交互和映射维护。
