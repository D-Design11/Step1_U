> **数值唯一源：`assets/tokens.json`。** 改值请改 tokens.json 后跑 `node build-tokens.js`；本文件表格为生成/人读参考，勿手改派生数值。

# 间距与圆角

## 一、基础数值 (Number Primitives)

基础数值 token，供间距和圆角引用。

| Token | 值 |
|-------|-----|
| `Number/Number0` | 0 |
| `Number/Number2` | 2 |
| `Number/Number4` | 4 |
| `Number/Number8` | 8 |
| `Number/Number10` | 10 |
| `Number/Number12` | 12 |
| `Number/Number14` | 14 |
| `Number/Number16` | 16 |
| `Number/Number20` | 20 |
| `Number/Number24` | 24 |
| `Number/Number32` | 32 |
| `Number/Number 48` | 48 |
| `Number/Number 64` | 64 |

### 描边

| Token | 值 |
|-------|-----|
| `Stroke/Number0` | 0 |
| `Stroke/Number1` | 1 |

## 二、圆角 (Radius)

| Token | 值 | 用途 |
|-------|-----|------|
| `None` | 0px | 无圆角 |
| `Extra-small` | 4px | 小标签/小元素 |
| `Small` | 8px | medium toast / 子卡片内部的更小元素 |
| `Medium` | 12px | 输入框 / large卡片内子卡片（如 subtle 内容区） |
| `Large` | 16px | 页面级卡片容器 |
| `Extra-large` | 30px | 底部弹出面板 |
| `Full` | 1000px | 全圆/胶囊按钮 |

## 三、间距 (Space)

### Space 层级

| Token | 值 | 引用 |
|-------|-----|------|
| `space/space/2xs` | 2px | → Number2；CSS `--v9-space-2xs` |
| `space/space/xs` | 4px | → Number4；CSS `--v9-space-xs` |
| `space/space/sm` | 8px | → Number8；CSS `--v9-space-sm` |
| `Number/Number10` | 10px | Action Button Group 当前 itemSpacing；CSS `--v9-space-10` |
| `space/space/md` | 12px | → Number12；CSS `--v9-space-md` |
| `space/space/lg` | 16px | → Number16；CSS `--v9-space-lg` |
| `space/space/extra lg` | 20px | → Number20；CSS `--v9-space-xl` |
| `space/space/extra  extra lg` | 24px | → Number24；CSS `--v9-space-2xl` |
| Page Pattern大结构间距 | 32px | → Number32；CSS `--v9-space-3xl` |

### Layout 布局

| Token | 值 | 引用 |
|-------|-----|------|
| `space/New group/layout/margin` | 12px | → Number12 |
| `space/New group/layout/gutter` | 8px | → Number8 |

## 四、Padding 内边距

| Token | 值 | 引用 |
|-------|-----|------|
| `padding/xs` | 4px | → Number4 |
| `padding/sm` | 8px | → Number8 |
| `padding/md` | 16px | → Number16 |
| `padding/lg` | 24px | → Number24 |

### Gap 间隔

| Token | 值 | 引用 |
|-------|-----|------|
| `padding/gap/icon` | 4px | → Number4 |
| `padding/gap/text` | 4px | → Number4 |
| `padding/gap/card` | 12px | → Number12 |
| `padding/gap/text inline` | 4px | → Number4 |
| `padding/gap/text stack` | 4px | → Number4 |
| `padding/gap/button-group` | 12px | → Number12 |

`Action Button Group` 源组件（Node `1819:445`）的容器 padding 为20px，直接复用
`space/space/extra lg`；按钮间 itemSpacing 为10px，源组件当前使用基础值 `Number/Number10`，
没有绑定 `padding/gap/button-group`。H5 必须用 `--v9-space-xl` 与 `--v9-space-10` 还原，
不得把10px静默替换成现有12px的 `padding/gap/button-group`。这只是同步既有 Figma 基础值，
不要求新建 `Action Button Gap` 等重复 Figma Variable。

数据组件的 8/12/16px 组合间距直接复用现有 `space/sm`、`space/md`、`space/lg`，不建立
`Metric gap` 等重复 Token。具体选择逻辑见 `components.md`「数据组件」。

核心数字与单位的2px间距直接使用既有 `space/space/2xs`，不新增 `data/affix gap` 等语义别名；
只有该间距未来需要脱离2XS独立变化时，才允许新增组件语义 Token。

### 光学间距与数值间距

- 组件间距的目标是让相邻内容的**可见边界**形成稳定节奏，不是让所有 Auto Layout `itemSpacing`
  机械相等。多行文字的行盒会改变可见边界，组件可以通过正式变体或上下文合同做光学补偿。
- 光学补偿必须由对应组件或 Page Pattern 明确给出适用条件和具体值；不得看到多行文字就统一
  “减4px”，也不得把一个组件的补偿值推广到其他组件。
- Figma 检查时同时核对 Auto Layout 数值与最终可见留白；H5 以实际渲染行数判断，不按字符数、
  文案类型或业务状态猜测。Task Sheet 的具体 Single / Multiline 合同见 `components.md`。

## 五、Responsive（响应式）

| Token | 值 | 说明 |
|-------|-----|------|
| `Device` | `mobile` | 设备类型 |
| `Device Width` | 375 | 设备宽度 |
| `Root Font Size` | 16 | 根字号 |
| `Scale` | 1.25 | 缩放系数 |

## 六、Stroke（描边）

| Token | 值 | 引用 |
|-------|-----|------|
| `stroke/none` | 0 | → Stroke/Number0 |
| `stroke/thin` | 1 | → Stroke/Number1 |

## 七、Grid（栅格）

空集合，暂无变量定义。
