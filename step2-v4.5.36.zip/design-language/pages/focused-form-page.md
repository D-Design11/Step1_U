# Focused Form Page｜聚焦表单任务页

## 页面目标

用于承载一个明确、单一且需要用户在主操作前完成填写、选择、核对或确认的任务。页面通过独立的
任务标题、Focus背景、集中式任务内容和稳定的底部操作区，帮助用户理解任务并完成提交。

本 Page 不承载纯启动、进入或跳转入口。页面只有标题、简短说明和可立即点击的主按钮时，即使业务
文案使用“开启”“确认”等词，也不构成本 Page。

常见场景包括实名信息填写、资格或身份认证、输入验证码或出行码、证件信息提交、资料确认，以及
单步骤申请或开通。

## 命中条件

使用本 Page 必须同时满足：

- PageSpec 只有一个核心任务，主要行为是填写、选择、核对或确认信息，而不是启动或进入功能。
- 页面存在至少一个有独立任务价值的 Main Content 模块；它可以是字段、选项、协议相关确认或需要
  用户实质核对的信息块，但不能只是解释主按钮的一句文案。
- 主操作与 Main Content 存在技术或业务依赖，例如填写、校验、勾选、确认后才能提交，或用户必须先
  核对会影响决定的信息。
- 关闭所有可选内容后，最简状态仍能形成完整、紧凑的任务页面。
- 页面不依赖复杂导航、多业务模块、高密度信息浏览或多区域联动。

PRD 中的“填写”“认证”“确认”“提交”等词只能作为辅助信号；最终应根据页面目标、模块数量、字段和
操作关系综合判断。“单一任务 + 底部操作区”本身不构成命中。

以下情况不使用本 Page：

- 页面只包含 Page Title、短说明和一个进入即可点击的 CTA；
- 主行为是“开始、开启、进入、继续、查看”等轻量入口，且没有前置填写、选择或实质核对；
- Main Content 只负责解释按钮，删除 Page 外壳后理解和操作没有明显损失；
- 可选内容隐藏后只剩空壳，必须依赖 Focus 背景、远距离吸底或大面积留白维持版式；
- Appbar、Page Title、Card Title 语义重复，页面层级多于业务信息层级；
- 必须添加 PRD 未定义的说明、插图或模块才能让页面看起来完整；
- 页面主要用于浏览列表、详情、数据或多个同等级业务模块。
- 页面包含复杂筛选、Tab、多区域联动或多个并行核心任务。
- 表单很长并已拆成多个独立步骤；此时应使用分步表单页面。

## 最小有效内容

Focused Form Page 的最简业务状态必须包含：

1. 一个任务型 Page Title；
2. 至少一个能独立承载填写、选择、核对或确认任务的 Main Content 模块；
3. 与该 Main Content 直接相关的 Action Button Group；
4. 必要时出现的错误、禁用、已选或加载反馈；这些状态不要求默认展示，但页面结构必须能够承载。

Page Description、Agreement和额外说明均为可选项，不得依靠它们填充页面。只有标题、说明和CTA时，
不满足最小有效内容。

## 未命中时的回退

- 启动、进入或轻量继续操作优先使用正式组件与Token自由组合，例如Default页面背景、Appbar、
  CellCard、Entry或Action Button Group；具体组件由内容归属决定，不固定成新的模板。
- 操作应靠近它所解释或影响的内容，页面高度由内容自然形成；不得为了模拟本Page而保留空的
  Page Header、Focus背景或远距离吸底操作区。
- 相同自由组合在多个真实业务页面中稳定重复后，再评估新增Launch / Entry类Page Pattern；
  单个案例不直接升级为Page。

## 页面结构

```text
Page
├─ Background / Focus                 必选
├─ Appbar                             必选；形式与标题按导航场景选择
├─ Page Header                        必选
│  ├─ Page Title                      必选
│  └─ Page Description                可选
├─ Main Content                       必选
│  └─ Form Card / Form Group / Task Content
├─ Agreement                          可选；按实际高度进入内容底部或组合底部操作区
├─ Action Button Group                必选；内部形式按业务选择，可与Agreement组成固定区
└─ Home Indicator                     按设备环境显示
```

组件的公开属性、状态、Slot、内部间距与 H5 标签统一查 `references/components.md`，本 Page 不复制组件合同。

## 结构关系

### Appbar 与 Page Header

- Appbar 使用正式组件支持的任意合法形式，不固定为 `None`；是否显示标题由导航和业务语义决定。
- Appbar 标题表示页面位置或业务名称，Page Title 表示当前任务，两者可以同时存在。
- 两者同时存在时应承担不同语义；如果文案和含义完全重复，应减少重复表达。
- Page Header 属于页面正文，不属于 Appbar，也不属于 Form Card。
- 每个页面只设置一个 Page Title。

### Main Content

- 单字段使用 Form Item，连续字段使用 Form Item Group，需要白色卡片承载时使用 Form Card。
- Form Card 的 Header 可以存在，也可以省略；是否显示由内容结构决定。
- 不得为了增加层次而把每一个字段分别包成卡片。
- 非表单任务内容只能使用与任务相符的正式组件或明确登记的页面本地组合。

### Agreement

- Agreement 是页面级提交条件，不属于 Form Card。
- 有协议或确认要求时，先在页面完成实际渲染，再根据当前视口和内容高度选择 `Content Bottom` 或
  `Combined Fixed`；没有相关要求时隐藏且不保留空白。
- `Content Bottom`：Page Header、Main Content、必要间距和Agreement能够完整容纳在独立按钮操作区
  上方的首屏可用区域时，Agreement位于内容区域底部，Action Button Group继续使用独立底部操作区。
- `Combined Fixed`：上述内容无法完整容纳，或错误信息、折行、动态字段使页面超出首屏时，Agreement
  与Action Button Group组成固定底部操作区；Main Content单独滚动。
- 模式判断不得按字段数量、预估文案长度或设计稿状态写死。视口尺寸、字段显隐、错误状态、异步内容、
  字体加载或Agreement折行导致实际高度变化时，H5必须重新测量并切换模式。
- 协议名称按 Agreement 组件合同支持高亮，勾选与按钮状态的业务关系由 PRD 决定。

### Action Button Group

- Page 固定其底部操作区角色，不限制为单按钮或单一主操作。
- Single、Inline、Stacked 等形式及按钮角色、数量、状态均按 PRD 与 Action Button Group 组件合同选择。
- `Combined Fixed`使用单个通栏主按钮时，375px基准画布的组合区为136px：顶部12px、Agreement实际
  高度42px、Agreement到按钮12px、按钮50px、底部20px；Agreement左右12px，按钮左右20px。
  Home Indicator的34px设备区域单独计算，不包含在136px内。
- Agreement实际折行或Action Button Group改用Inline、Stacked等形式时，组合区按内部实际高度自然
  增高；仍保持顶部12px、Agreement到Action Button Group 12px和底部20px，不得压缩组件内容。
- `Combined Fixed`下，滚动容器必须至少预留组合区的实际高度；最后一个字段、错误信息和说明内容必须
  能完整滚动到固定区上方，不得被Agreement或按钮遮挡。

## 字号

| 内容 | 字号/行高 | 字重 | 颜色 |
|---|---:|---|---|
| Page Title | 26/26px；多行26/39px | PingFang SC Semibold | Text Primary |
| Page Description | 14/14px；多行14/21px | PingFang SC Regular | Text Tertiary |

Page Title 使用 `--v9-fz-headline-xl`。单行行高等于字号；发生实际换行后，整个文字节点使用字号的
1.5倍行高。CardHeader、Form Item、Agreement 和 Action Button Group 的文字规格继续查各自组件合同。

## 间距与对齐

### 垂直关系

```text
Appbar 内容区结束
↓ 20px
Page Title
↓ 12px
Page Description（可选）
↓ 32px
Main Content
```

- 没有 Page Description 时，从 Page Title 实际底部到 Main Content 保持32px；H5使用
  `--v9-space-3xl`，Figma复用 `Number/Number32`。
- Page Title 或 Description 折行时，所有间距都从文字实际渲染边界开始计算。
- Main Content 内部和组件之间的间距继续遵循正式组件合同，不由本 Page 覆盖。

### 横向关系

- 页面主要容器服从全局12px页面 Margin：375px画布中的主要卡片宽351px。
- Page Header 左侧固定为28px，与卡片内部内容轴对齐，而不是与卡片外边缘对齐。
- 28px内容轴来自 `12px Page Margin + 16px Card Padding`。
- Page Title、Page Description、CardHeader正文和Form Item左侧字段名应共享这条内容轴。
- 右侧输入、选择和控制项的对齐由 Form Item 组件合同处理。

## 背景

- 页面使用正式 `Background / Focus`，Base 为 `#F6F8FB`，Atmosphere 位于页面顶部。
- Focus 背景只营造任务聚焦感，不承担信息表达，也不得影响标题和表单可读性。
- 不得在页面中重新手工拼接 Focus 渐变与 Atmosphere 图形。
- Focus 与 Immersive 的选择边界仍以 `references/components.md` 的 Page Background 规则为准。

## 内容与状态

- Page Title 使用任务型表达，直接说明用户当前要完成什么；避免“信息页面”“认证中心”等抽象栏目名。
- Page Description 只补充影响判断或操作的信息，不重复标题，非必要说明不占用首屏。
- Main Content 根据字段、错误信息和业务内容自然增高，页面超出可视高度时允许滚动。
- Error、Disabled、Checked、Loading 等状态由实际组件合同和 PRD 状态矩阵决定。
- Agreement位置必须由渲染后的可用高度决定：首屏可容纳时进入内容底部，超出时进入组合固定区。
  不得始终固定Agreement，也不得用无来源的固定高度或占位空白伪造未超屏状态。

## 内容范围与结构韧性

同一 Page 必须同时检查三种内容范围：

| 范围 | 验收重点 |
|---|---|
| 最少内容 | 只保留必选模块时仍紧凑完整；不能退化为标题、短说明、CTA和大面积空白 |
| 常规内容 | 字段、选项、说明和状态按信息关系自然排列；主操作与任务内容保持明确关联 |
| 最多内容 | 长文案、错误、Agreement或更多字段出现时切换为Combined Fixed并允许滚动；滚动区预留组合区实际高度 |

同时在目标产品的短、基准和长视口中检查：不得只通过固定高度、无来源的 `min-height`、人为扩张间距
或远距离吸底让某一个视口看起来平衡。相邻业务状态采用不同页面结构时，还需确认差异来自任务语义，
而不是单张效果图的装饰选择。

## 验收

可自动检查的结构事实：

- 使用正式 Background / Focus，且未手工重画其内部图形。
- 页面只有一个 Page Title，字号为26px，单行行高26px、多行行高39px。
- Page Title 与 Description 为12px，Page Header 与 Main Content 为32px。
- 主要容器使用12px页面Margin，Page Header左侧为28px并与卡片内容轴对齐。
- Agreement存在时按实际渲染高度选择Content Bottom或Combined Fixed；模式不会仅因字段数量写死。
- Combined Fixed单通栏主按钮基准结构为12 + 42 + 12 + 50 + 20 = 136px，Home Indicator另计34px。
- Combined Fixed的滚动区预留组合区实际高度，最后一个字段、错误提示和说明均可完整滚动到固定区上方。
- Appbar、Form和Action Button Group调用正式组件，没有复制其内部DOM。
- 最简业务状态包含一个有独立任务价值的Main Content模块，不是“标题 + 短说明 + CTA”。

需要视觉和业务判断：

- 页面是否确实只有一个核心任务，且首屏能够理解并开始完成任务。
- Appbar 标题与 Page Title 是否各自有用、没有语义重复。
- Page Title 是否准确表达任务，Description 是否提供必要而非重复的信息。
- Action Button Group 的形式、按钮角色与业务路径是否匹配。
- 页面是否过空、过挤，Focus 背景是否过强或影响阅读。
- 表单长度是否已经更适合分步页面。
- 主操作是否依赖Main Content，而不是进入页面即可执行的纯启动操作。
- Agreement布局模式是否与当前实际内容高度匹配；错误出现、文案折行和视口变化后是否正确重新判断。
- 删除Page Header、Focus背景和固定操作区后，页面理解或任务完成是否会明显受损；没有损失时不使用本Page。
- 最少、常规、最多内容及短、基准、长视口下是否都能保持合理层级、操作距离与内容连续性。
- 与相邻业务状态的结构差异是否有明确任务语义，而不是为了单页装饰。

## PageSpec 输入

生成前确认页面目标、用户、任务性质（完成任务或启动/进入）、核心任务、模块、字段与类型、必填项、
默认值、错误状态、协议与勾选规则、操作项及其角色和状态、主操作与Main Content的依赖、最少/常规/
最多内容、会改变实际高度的动态状态、目标视口、相邻业务状态、提交后的去向、PRD来源与未知项。
Agreement布局模式由渲染结果决定，不要求PRD预先指定。未知信息不得补成业务事实。

## 参考来源

- Figma文件：`3qAvCPewiZFJYKRMaV0mlN`
- 参考节点：`90:6034`、`104:3989`、`104:3707`
- 用途：`90:6034`验证页面结构、页面标题字阶、间距与内容轴；`104:3989`验证首屏可容纳时的
  Content Bottom；`104:3707`验证超出首屏时的Combined Fixed与136px单按钮组合区。
- 正式组件样式仍以主规范库及 `references/components.md` 为准。
