# Driver Express Register Page｜司机极速注册引导页

## 页面目标

用于引导已经在滴滴其他出行业务完成资质认证的用户复用既有资质，以更短路径注册成为司机。
本页只提供一个高强调注册主操作，并保留手动上传证件的低强调兜底入口。

**来源**：Figma fileKey `dhjgTiqD7K1OQyDra1s26y`，node `21:4`，参考Frame 375×812。

## 命中条件

只有以下事实同时成立时才使用本 Page：

- 当前业务是司机注册，而不是普通活动、信息浏览或资料填写；
- 用户已有可复用的出行业务资质，页面利益点是减少重复提交；
- 页面主要行为是直接发起极速注册，只有一个同等级主操作；
- 手动上传证件是放弃资质复用后的兜底路径；
- 顶部Hero承担核心视觉和注册利益表达，而不是纯装饰图片。

“司机”“注册”“一键”等词只能作为辅助信号。普通司机注册营销页、实名信息表单、证件上传页、
多步骤注册流程或没有资质复用能力的页面均不命中。部分命中时按正式组件与Token自由组合，不套用本页。

## 页面结构

```text
Page
├─ Hero                               页面顶部开始，非组件
├─ Appbar / None black                透明覆盖在浅色Hero上
├─ Benefit Title                      注册利益标题，可局部Primary高亮
├─ Action Button Group
│  └─ Button / Full-width Primary     唯一高强调主操作
├─ Secondary Entry                    手动上传证件注册，低强调兜底
├─ Disclaimer                         必要的授权或复用说明
└─ Home Indicator                     按设备环境显示
```

## 组件编排

本表只固定该Page如何组合当前正式组件，不复制组件内部尺寸、状态全集或Figma Key；组件自身规格继续以
`references/components.md`为准。

| 页面元素 | H5实现 | 身份与页面边界 |
|---|---|---|
| Hero | 页面本地`<img>`，资源读取同名资产清单 | 非组件；使用`cover`与`center top`，不登记为正式组件 |
| 顶部导航 | `<v9-appbar type="none-black" show-back title="">` | 正式Appbar；透明覆盖在浅色Hero上，不允许页面样式改写内部DOM或SVG |
| Benefit Title | 页面本地`<h1>` | 非组件；负责注册利益表达，只允许一个Primary高亮片段 |
| 主操作组合 | `<v9-action-group layout="primary">` | 正式Action Button Group；只承载一个同等级主操作 |
| 主按钮 | `<v9-button size="full" variant="primary">` | 正式Button Full-width；`state`、文案与操作结果来自当前PRD |
| 手动上传入口 | `<v9-textlink importance="secondary" size="m" icon="arrow">` | 正式TextLink；组件内部复用Arrow L，不在页面外再拼一个Arrow |
| Disclaimer | 页面本地`<p>` | 非组件；只承载PRD已提供且确有必要的授权、资质复用或免责说明 |
| Home Indicator | `<v9-home-indicator theme="light">` | 正式组件；按设备环境显示，不由页面手画 |

### 最小H5调用骨架

以下骨架只固定组件标签、变体与顺序，不是完整页面模板。标题、链接地址、业务说明、交互状态和结果必须
由当前PRD提供；页面仍统一加载`assets/v9-core.css`与`assets/v9-components.js`。

```html
<img class="driver-express-register__hero" src="assets/pages/driver-express-register/hero.png" alt="">
<v9-appbar type="none-black" show-back title=""></v9-appbar>

<h1 class="driver-express-register__benefit-title">
  专属极速注册通道<br>
  <span class="driver-express-register__accent">最快1步</span>成为司机
</h1>

<v9-action-group layout="primary">
  <v9-button size="full" variant="primary">同意并使用极速注册</v9-button>
</v9-action-group>

<v9-textlink importance="secondary" size="m" icon="arrow" href="{{manual_upload_href}}">
  不使用，手动上传证件注册
</v9-textlink>

<p class="driver-express-register__disclaimer">按当前PRD填写必要说明</p>
<v9-home-indicator theme="light"></v9-home-indicator>
```

## 参考几何与自适应

以下数值用于在375×812源Frame上校准视觉关系，不是要求所有设备使用绝对定位的固定模板。

| 区域 | 375px参考画布 | 页面合同 |
|---|---|---|
| Appbar | 顶部0–88px | 透明覆盖Hero，内部系统状态区与导航区均由正式组件维护 |
| Hero | 顶部0–419px | 全宽裁切，视觉焦点居中靠上；419px只属于当前业务资产参考槽位 |
| Benefit Title | 参考顶部约429px、最大宽335px、居中 | 页面专属PingFang SC Semibold 28px；实际单行为28px行高，实际多行为42px行高 |
| 主操作组合 | 参考顶部约539px、左右20px、宽335px | Action Button Group Fill；按钮高度与圆角由正式组件维护 |
| 手动上传入口 | 参考顶部约613px、水平居中 | TextLink M / Secondary；保持低于主按钮的视觉强调 |
| Disclaimer | 参考顶部约704px、左右20px、宽335px | Body Small 12px；实际多行为18px行高，使用Text Tertiary |
| Home Indicator | 375×34px、贴底 | 短屏与长屏都保持在页面最终底部，不覆盖业务内容 |

- 主按钮20px左右边距复用`--v9-space-xl`，是本Page的页面级例外，不改变全局12px页面Margin。
- 短视口先收拢可伸缩留白，再允许页面按阅读顺序整体滚动；不得压缩正式组件高度、遮挡说明或把关键
  操作移出可达区域。长视口只延展弹性留白，不改变Hero裁切焦点与主次关系。
- 参考坐标用于截图对齐；H5应使用正常文档流、Grid或Flex表达区域关系，不把全部元素写成绝对定位。

## 内容与可变范围

生成页面时根据PRD确定以下内容，不从参考稿补写未知业务：

- 注册利益标题及局部高亮范围；
- 主操作文案、状态和实际结果；
- 手动上传兜底入口文案与去向；
- 底部授权、资质复用或业务说明；
- Hero是否仍使用当前业务资产。

页面目标、单一主操作层级、手动上传的兜底关系以及Hero上透明Appbar是本Page的结构合同。若PRD改变
这些关系，应退出本Page并重新按`pages/_index.md`判断，而不是继续套用。

## 远程图片资产

图片元数据位于[`driver-express-register.assets.json`](driver-express-register.assets.json)。Skill中不保存
Hero PNG；清单同时提供HTTPS来源、Hash、尺寸、语义描述、裁切方式和焦点位置，供无法直接识别Skill内
二进制图片的Agent读取。

命中本页并确认使用当前Hero后，在H5项目生成完成、页面校验和附件构建之前执行：

```bash
node scripts/fetch-page-assets.mjs driver-express-register <H5项目目录>
```

脚本把图片下载到清单声明的项目相对路径并验证SHA-256与PNG尺寸。远程URL只用于生成阶段获取资产；
页面源码引用下载后的本地路径，最终自包含HTML必须由现有构建脚本内嵌图片，不得保留外部图片依赖。
网络不可访问、Hash或尺寸不匹配时停止出图并报告实际URL，不使用占位图、Figma临时导出或近似重绘替代。

## 视觉与规范边界

- 页面保持一个主要视觉焦点：Hero与注册利益共同服务极速注册，不再增加同等级促销模块。
- 标题中只高亮最关键的效率利益词，弱信息不得使用高饱和色争抢层级。
- Benefit Title确认保留本Page专属28px字号；单行行高28px，实际多行行高42px。旧参考稿中的40px
  多行行高不得沿用；该专属字阶只服务本业务Hero利益标题，不扩展为全局Page Title或通用文字样式。
- Appbar、Button、TextLink、Arrow和Home Indicator始终使用当前Skill的`v9-components.js`正式实现；
  本Page不保存或引入旧版拆分运行时。
- 页面私有class只负责Hero、标题、说明和区域关系，不得模拟正式组件或覆盖其Shadow DOM。

## 验收

- PRD完整命中本Page，而不是仅命中“注册”关键词；
- Hero从页面顶部连续展示，Appbar透明覆盖且图标在图片上清晰可见；
- 页面只有一个高强调主操作，手动上传保持低强调兜底关系；
- Hero下载文件通过Hash和尺寸校验，项目引用本地路径；
- 最终HTML不包含外部图片、绝对路径、`file:///`或本地服务依赖；
- 页面使用当前`v9-core.css`、`v9-components.js`和`v9-tokens.css`，没有带入旧版运行时；
- 375px及目标短、基准、长视口下均无关键内容遮挡、异常裁切或依赖大面积空白维持版式。
