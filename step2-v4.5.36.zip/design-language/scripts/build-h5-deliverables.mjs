#!/usr/bin/env node

import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  statSync,
  writeFileSync,
} from "node:fs";
import {
  basename,
  dirname,
  extname,
  join,
  relative,
  resolve,
  sep,
} from "node:path";
import { fileURLToPath } from "node:url";
import { deflateRawSync } from "node:zlib";

const [projectArg, outputArg, slugArg, entryArg = "index.html"] = process.argv.slice(2);

if (!projectArg || !outputArg || !slugArg) {
  console.error(
    "Usage: node scripts/build-h5-deliverables.mjs " +
    "<h5-project-directory> <output-directory> <project-slug> [entry-html]",
  );
  process.exit(1);
}

if (!/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(slugArg)) {
  console.error("project-slug must use lowercase letters, digits, and single hyphens.");
  process.exit(1);
}

const projectRoot = resolve(projectArg);
const outputRoot = resolve(outputArg);
const entryPath = resolve(projectRoot, entryArg);
const currentRuntimeRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..", "assets");

if (!existsSync(projectRoot) || !statSync(projectRoot).isDirectory()) {
  console.error(`H5 project directory not found: ${projectRoot}`);
  process.exit(1);
}
if (!existsSync(entryPath) || !statSync(entryPath).isFile()) {
  console.error(`Entry HTML not found: ${entryPath}`);
  process.exit(1);
}

const ignoredDirectories = new Set([".git", "node_modules"]);
const ignoredFiles = new Set([".DS_Store"]);

const isInsideProject = (path) => {
  const rel = relative(projectRoot, path);
  return rel === "" || (!rel.startsWith(`..${sep}`) && rel !== "..");
};

const stripQueryAndHash = (value) => value.split("#", 1)[0].split("?", 1)[0];

const isEmbeddedReference = (value) =>
  /^(?:data:|blob:|#|about:|mailto:|tel:|javascript:)/i.test(value.trim());

const isRemoteReference = (value) => /^(?:https?:)?\/\//i.test(value.trim());

const decodeReference = (value) => {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
};

const resolveLocalReference = (value, sourceFile) => {
  const raw = String(value).trim();
  if (!raw || isEmbeddedReference(raw)) return null;
  if (isRemoteReference(raw)) {
    throw new Error(`External resource is not allowed in a self-contained deliverable: ${raw}`);
  }
  const clean = decodeReference(stripQueryAndHash(raw));
  const absolute = resolve(dirname(sourceFile), clean);
  if (!isInsideProject(absolute)) {
    throw new Error(
      `Resource escapes the H5 project directory: ${raw}. ` +
      "Copy the component runtime and assets into the project before delivery.",
    );
  }
  if (!existsSync(absolute) || !statSync(absolute).isFile()) {
    throw new Error(`Local resource not found: ${raw} (from ${relative(projectRoot, sourceFile)})`);
  }
  return absolute;
};

const mimeTypes = new Map([
  [".svg", "image/svg+xml"],
  [".png", "image/png"],
  [".jpg", "image/jpeg"],
  [".jpeg", "image/jpeg"],
  [".gif", "image/gif"],
  [".webp", "image/webp"],
  [".avif", "image/avif"],
  [".ico", "image/x-icon"],
  [".woff", "font/woff"],
  [".woff2", "font/woff2"],
  [".ttf", "font/ttf"],
  [".otf", "font/otf"],
  [".css", "text/css"],
  [".js", "text/javascript"],
  [".mjs", "text/javascript"],
]);

const toDataURI = (file) => {
  const mime = mimeTypes.get(extname(file).toLowerCase()) || "application/octet-stream";
  return `data:${mime};base64,${readFileSync(file).toString("base64")}`;
};

const inlineCssCache = new Map();

const inlineCssText = (css, sourceFile, stack = []) => {
  let result = css.replace(
    /@import\s+(?:url\(\s*)?["']?([^"')\s;]+)["']?\s*\)?\s*;/gi,
    (_, reference) => {
      const imported = resolveLocalReference(reference, sourceFile);
      if (!imported) return "";
      if (stack.includes(imported)) {
        throw new Error(`Circular CSS import: ${[...stack, imported].join(" -> ")}`);
      }
      return inlineCssFile(imported, [...stack, sourceFile]);
    },
  );

  result = result.replace(/url\(\s*(["']?)([^"')]+)\1\s*\)/gi, (match, _quote, reference) => {
    const trimmed = reference.trim();
    if (!trimmed || isEmbeddedReference(trimmed)) return match;
    const asset = resolveLocalReference(trimmed, sourceFile);
    return asset ? `url("${toDataURI(asset)}")` : match;
  });
  return result;
};

const inlineCssFile = (file, stack = []) => {
  if (inlineCssCache.has(file)) return inlineCssCache.get(file);
  const bundled = inlineCssText(readFileSync(file, "utf8"), file, stack);
  inlineCssCache.set(file, bundled);
  return bundled;
};

const getAttribute = (tag, name) => {
  const match = tag.match(new RegExp(`\\b${name}\\s*=\\s*(["'])(.*?)\\1`, "i"));
  return match ? match[2] : null;
};

const replaceAttribute = (tag, name, value) => {
  const expression = new RegExp(`(\\b${name}\\s*=\\s*)(["'])(.*?)\\2`, "i");
  return tag.replace(expression, `$1"${value}"`);
};

const collectFiles = (directory) => {
  const files = [];
  const walk = (current) => {
    for (const entry of readdirSync(current)) {
      if (ignoredDirectories.has(entry) || ignoredFiles.has(entry)) continue;
      const absolute = join(current, entry);
      if (absolute === outputRoot || absolute.startsWith(`${outputRoot}${sep}`)) continue;
      const stats = statSync(absolute);
      if (stats.isDirectory()) walk(absolute);
      else if (stats.isFile()) files.push({ absolute, stats });
    }
  };
  walk(directory);
  return files;
};

const findRequiredRuntimeFile = (name) => {
  const matches = collectFiles(projectRoot).filter((item) => basename(item.absolute) === name);
  if (matches.length === 0) {
    throw new Error(
      `Complete source package is missing ${name}. ` +
      "Copy v9-core.css, v9-components.js, v9-tokens.css, and component assets into the project.",
    );
  }
  return matches[0].absolute;
};

const assertCurrentRuntimeFile = (name) => {
  const projectFile = findRequiredRuntimeFile(name);
  const currentFile = resolve(currentRuntimeRoot, name);
  if (!existsSync(currentFile) || !statSync(currentFile).isFile()) {
    throw new Error(`Current Skill runtime source is missing ${name}.`);
  }
  if (!readFileSync(projectFile).equals(readFileSync(currentFile))) {
    throw new Error(
      `${relative(projectRoot, projectFile)} is not the current Skill ${name}. ` +
      "Replace v9-core.css, v9-components.js, and v9-tokens.css from the current Skill assets directory before building.",
    );
  }
  return projectFile;
};

for (const required of ["v9-core.css", "v9-components.js", "v9-tokens.css"]) {
  assertCurrentRuntimeFile(required);
}

const transformRuntime = (source, runtimeFile) => {
  const runtimeDirectory = dirname(runtimeFile);
  const coreFile = resolve(runtimeDirectory, "v9-core.css");
  if (!existsSync(coreFile)) {
    throw new Error(`v9-components.js must sit beside v9-core.css: ${runtimeFile}`);
  }

  const assetDirectory = resolve(runtimeDirectory, "components");
  const assetMap = {};
  if (existsSync(assetDirectory)) {
    for (const item of collectFiles(assetDirectory)) {
      const key = `components/${relative(assetDirectory, item.absolute).split(sep).join("/")}`;
      assetMap[key] = toDataURI(item.absolute);
    }
  }

  const bootstrapPattern =
    /const coreURL\s*=\s*new URL\("\.\/v9-core\.css",\s*import\.meta\.url\);[\s\S]*?const assetHref\s*=\s*\(path\)\s*=>\s*new URL\(path,\s*import\.meta\.url\)\.href;/;

  if (!bootstrapPattern.test(source)) {
    throw new Error("Unable to locate the v9-components.js resource bootstrap for single-file bundling.");
  }

  const embeddedCore = toDataURIFromText("text/css", inlineCssFile(coreFile));
  const replacement = [
    `const coreHref = ${JSON.stringify(embeddedCore)};`,
    `const embeddedAssetMap = Object.freeze(${JSON.stringify(assetMap)});`,
    "const assetHref = (path) => embeddedAssetMap[String(path).replace(/^\\.\\//, \"\")] || \"\";",
  ].join("\n");

  return source.replace(bootstrapPattern, replacement);
};

function toDataURIFromText(mime, value) {
  return `data:${mime};base64,${Buffer.from(value, "utf8").toString("base64")}`;
}

const inlineScript = (file) => {
  let source = readFileSync(file, "utf8");
  if (basename(file) === "v9-components.js") {
    source = transformRuntime(source, file);
  } else {
    if (/(?:^|\n)\s*import\s+(?!\.)|\bimport\s*\(/m.test(source)) {
      throw new Error(`Page script contains an unresolved module import: ${relative(projectRoot, file)}`);
    }
    if (source.includes("import.meta.url")) {
      throw new Error(`Page script contains an unresolved import.meta.url asset path: ${relative(projectRoot, file)}`);
    }
  }
  return source.replace(/<\/script/gi, "<\\/script");
};

const inlineHtmlResources = (source) => {
  let html = source;

  html = html.replace(/<(?:img|source|video|audio|track|input|iframe)\b[^>]*>/gi, (tag) => {
    let next = tag;
    for (const attribute of ["src", "poster"]) {
      const value = getAttribute(next, attribute);
      if (!value || isEmbeddedReference(value)) continue;
      const asset = resolveLocalReference(value, entryPath);
      if (asset) next = replaceAttribute(next, attribute, toDataURI(asset));
    }
    const srcset = getAttribute(next, "srcset");
    if (srcset) {
      const embedded = srcset.split(",").map((candidate) => {
        const [url, descriptor = ""] = candidate.trim().split(/\s+/, 2);
        const asset = resolveLocalReference(url, entryPath);
        return `${asset ? toDataURI(asset) : url}${descriptor ? ` ${descriptor}` : ""}`;
      }).join(", ");
      next = replaceAttribute(next, "srcset", embedded);
    }
    return next;
  });

  html = html.replace(/<link\b[^>]*>/gi, (tag) => {
    const href = getAttribute(tag, "href");
    const rel = (getAttribute(tag, "rel") || "").toLowerCase().split(/\s+/);
    if (!href) return tag;
    if (rel.includes("stylesheet")) {
      const cssFile = resolveLocalReference(href, entryPath);
      return `<style data-v9-bundled-from="${relative(projectRoot, cssFile).split(sep).join("/")}">\n${inlineCssFile(cssFile)}\n</style>`;
    }
    if (rel.includes("icon") || rel.includes("apple-touch-icon")) {
      const iconFile = resolveLocalReference(href, entryPath);
      return replaceAttribute(tag, "href", toDataURI(iconFile));
    }
    return tag;
  });

  html = html.replace(/<style\b([^>]*)>([\s\S]*?)<\/style>/gi, (_, attributes, css) =>
    `<style${attributes}>${inlineCssText(css, entryPath)}</style>`,
  );

  html = html.replace(/<script\b([^>]*)\bsrc\s*=\s*(["'])(.*?)\2([^>]*)><\/script>/gi,
    (_, before, _quote, reference, after) => {
      const scriptFile = resolveLocalReference(reference, entryPath);
      const attributes = `${before} ${after}`.replace(/\s+/g, " ").trim();
      const attributeProbe = `<script${attributes ? ` ${attributes}` : ""}>`;
      const type = (getAttribute(attributeProbe, "type") || "").toLowerCase();
      const deferredClassic = type !== "module" && /(?:^|\s)defer(?:\s|=|$)/i.test(attributes);
      const normalizedAttributes = attributes.replace(/(?:^|\s)defer(?:\s|=(["'])?defer\1)?(?=\s|$)/gi, " ")
        .replace(/\s+/g, " ").trim();
      const script = inlineScript(scriptFile);
      const executable = deferredClassic
        ? `document.addEventListener("DOMContentLoaded", () => {\n${script}\n}, { once: true });`
        : script;
      return `<script${normalizedAttributes ? ` ${normalizedAttributes}` : ""}>\n${executable}\n</script>`;
    },
  );

  const marker = '<meta name="v9-deliverable" content="self-contained">';
  if (!html.includes(marker)) {
    html = /<\/head>/i.test(html) ? html.replace(/<\/head>/i, `  ${marker}\n</head>`) : `${marker}\n${html}`;
  }
  return html;
};

const crcTable = (() => {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    table[index] = value >>> 0;
  }
  return table;
})();

const crc32 = (buffer) => {
  let crc = 0xffffffff;
  for (const byte of buffer) crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
};

const toDosDateTime = (date) => ({
  time: ((date.getHours() & 0x1f) << 11) | ((date.getMinutes() & 0x3f) << 5) | ((date.getSeconds() / 2) & 0x1f),
  date: (((Math.max(1980, date.getFullYear()) - 1980) & 0x7f) << 9) | (((date.getMonth() + 1) & 0x0f) << 5) | (date.getDate() & 0x1f),
});

const buildZip = (entries) => {
  const locals = [];
  const centrals = [];
  let offset = 0;

  for (const entry of entries) {
    const name = Buffer.from(entry.name.split(sep).join("/"), "utf8");
    const data = Buffer.isBuffer(entry.data) ? entry.data : Buffer.from(entry.data);
    const deflated = deflateRawSync(data, { level: 9 });
    const compressed = deflated.length < data.length ? deflated : data;
    const method = compressed === deflated ? 8 : 0;
    const checksum = crc32(data);
    const stamp = toDosDateTime(entry.date || new Date());
    const flags = 0x0800;

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(flags, 6);
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(stamp.time, 10);
    localHeader.writeUInt16LE(stamp.date, 12);
    localHeader.writeUInt32LE(checksum, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(data.length, 22);
    localHeader.writeUInt16LE(name.length, 26);
    localHeader.writeUInt16LE(0, 28);
    locals.push(localHeader, name, compressed);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(0x0314, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(flags, 8);
    centralHeader.writeUInt16LE(method, 10);
    centralHeader.writeUInt16LE(stamp.time, 12);
    centralHeader.writeUInt16LE(stamp.date, 14);
    centralHeader.writeUInt32LE(checksum, 16);
    centralHeader.writeUInt32LE(compressed.length, 20);
    centralHeader.writeUInt32LE(data.length, 24);
    centralHeader.writeUInt16LE(name.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);
    centrals.push(centralHeader, name);
    offset += localHeader.length + name.length + compressed.length;
  }

  const centralDirectory = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralDirectory.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...locals, centralDirectory, end]);
};

try {
  const standaloneHtml = inlineHtmlResources(readFileSync(entryPath, "utf8"));
  mkdirSync(outputRoot, { recursive: true });
  const htmlOutput = resolve(outputRoot, `${slugArg}.html`);
  const zipOutput = resolve(outputRoot, `${slugArg}.zip`);
  writeFileSync(htmlOutput, standaloneHtml);

  const generatedDate = new Date();
  const zipEntries = [{
    name: `${slugArg}/${slugArg}.html`,
    data: Buffer.from(standaloneHtml, "utf8"),
    date: generatedDate,
  }];
  for (const item of collectFiles(projectRoot)) {
    const sourceName = relative(projectRoot, item.absolute).split(sep).join("/");
    zipEntries.push({
      name: `${slugArg}/source/${sourceName}`,
      data: readFileSync(item.absolute),
      date: item.stats.mtime,
    });
  }
  writeFileSync(zipOutput, buildZip(zipEntries));

  console.log(`Built self-contained HTML: ${htmlOutput}`);
  console.log(`Built complete source ZIP: ${zipOutput}`);
} catch (error) {
  console.error(`H5 deliverable build failed: ${error.message}`);
  process.exit(1);
}
