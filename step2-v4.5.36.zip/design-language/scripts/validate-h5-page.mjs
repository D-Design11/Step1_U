import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { basename, dirname, extname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(process.argv[2] || "");
const currentRuntimeRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..", "assets");
if (!process.argv[2] || !existsSync(projectRoot) || !statSync(projectRoot).isDirectory()) {
  console.error("Usage: node scripts/validate-h5-page.mjs <h5-project-directory>");
  process.exit(1);
}

const ignoredDirectories = new Set([".git", "node_modules"]);
const sourceExtensions = new Set([".html", ".htm", ".js", ".mjs", ".jsx", ".ts", ".tsx", ".css"]);
const runtimeFiles = new Set(["v9-components.js", "v9-core.css", "v9-tokens.css"]);
const allFiles = [];

const walk = (directory) => {
  for (const entry of readdirSync(directory)) {
    if (ignoredDirectories.has(entry)) continue;
    const absolute = join(directory, entry);
    const stats = statSync(absolute);
    if (stats.isDirectory()) walk(absolute);
    else allFiles.push(absolute);
  }
};
walk(projectRoot);

const pageSources = allFiles.filter((file) =>
  sourceExtensions.has(extname(file).toLowerCase()) && !runtimeFiles.has(basename(file)),
);
const sourceRecords = pageSources.map((file) => ({
  file,
  relativePath: relative(projectRoot, file),
  source: readFileSync(file, "utf8"),
}));
const combinedSource = sourceRecords.map((record) => record.source).join("\n");
const failures = [];
const inheritedRanges = [];

// Only legacy replacement heuristics use this view. Component contracts always inspect original source.
const withoutInheritedRanges = (record) => {
  const ranges = [];
  const usedIds = new Set();
  let active = null;
  for (const comment of record.source.matchAll(/<!--[\s\S]*?-->|\/\*[\s\S]*?\*\//g)) {
    const body = comment[0].startsWith("<!--") ? comment[0].slice(4, -3).trim() : comment[0].slice(2, -2).trim();
    if (!body.startsWith("design-source:")) continue;
    const start = /^design-source:start\s+([a-z0-9][a-z0-9_-]*)\s*\|\s*baseline:\s*(\S[\s\S]*)$/i.exec(body);
    const end = /^design-source:end\s+([a-z0-9][a-z0-9_-]*)$/i.exec(body);
    if (start) {
      if (active || usedIds.has(start[1])) {
        failures.push(`${record.relativePath}: nested or duplicate design-source range ${start[1]}.`);
        continue;
      }
      usedIds.add(start[1]);
      active = { id: start[1], baseline: start[2].trim(), from: comment.index };
    } else if (end) {
      if (!active || active.id !== end[1]) {
        failures.push(`${record.relativePath}: unmatched design-source end ${end[1]}.`);
        continue;
      }
      ranges.push({ ...active, to: comment.index + comment[0].length });
      inheritedRanges.push({ file: record.relativePath, id: active.id, baseline: active.baseline });
      active = null;
    } else {
      failures.push(`${record.relativePath}: invalid design-source marker; start requires ID and baseline reference.`);
    }
  }
  if (active) failures.push(`${record.relativePath}: unclosed design-source range ${active.id}.`);
  let source = record.source;
  for (const range of ranges.reverse()) {
    source = source.slice(0, range.from) + source.slice(range.from, range.to).replace(/[^\r\n]/g, " ") + source.slice(range.to);
  }
  return { ...record, source };
};
const v9Records = sourceRecords.map(withoutInheritedRanges);
const v9Source = v9Records.map((record) => record.source).join("\n");

const emptyIntentPattern = /暂无(?:新|更多)?(?:内容|数据|任务|记录|结果)|无数据|没有可展示内容|no data|empty state/i;
const directEmptyPatterns = [
  /<v9-empty(?:\s|>)/i,
  /(?:create|createElement)\(\s*["']v9-empty["']/i,
];
const manualEmptyPatterns = [
  /\bclass(?:Name)?\s*=\s*["'`][^"'`]*\bempty-state\b/i,
  /\bclass\s*:\s*["'`][^"'`]*\bempty-state\b/i,
  /\.empty-state\b/i,
];

const hasEmptyIntent = emptyIntentPattern.test(v9Source);
const usesV9Empty = directEmptyPatterns.some((pattern) => pattern.test(combinedSource));
const usesV9EmptyOutsideInherited = directEmptyPatterns.some((pattern) => pattern.test(v9Source));
const manualMatches = v9Records.filter((record) =>
  manualEmptyPatterns.some((pattern) => pattern.test(record.source)),
);
const declaresMultiStatePreview = /data-v9-preview\s*=\s*["']multi-state["']/i.test(combinedSource);
const hasPreviewControls = /data-v9-preview-controls(?:\s|=|>)/i.test(combinedSource);
const previewRouteMatches = combinedSource.match(/data-preview-route(?:\s|=|:)/gi) || [];

const getAttribute = (source, name) => {
  const match = source.match(new RegExp(`\\b${name}\\s*=\\s*["']([^"']*)["']`, "i"));
  return match ? match[1].trim().toLowerCase() : null;
};

const hasAttribute = (source, name) =>
  new RegExp(`\\b${name}(?:\\s*=|\\s|$)`, "i").test(source);

const validateRuntimeParity = () => {
  for (const name of runtimeFiles) {
    const projectMatches = allFiles.filter((file) => basename(file) === name);
    if (projectMatches.length === 0) {
      failures.push(`H5 project is missing ${name}. Copy the current Skill runtime into the project.`);
      continue;
    }
    if (projectMatches.length > 1) {
      failures.push(`H5 project contains multiple ${name} files; keep one current Skill runtime copy.`);
      continue;
    }

    const currentFile = resolve(currentRuntimeRoot, name);
    if (!existsSync(currentFile)) {
      failures.push(`Current Skill runtime source is missing ${name}.`);
      continue;
    }
    if (!readFileSync(projectMatches[0]).equals(readFileSync(currentFile))) {
      failures.push(
        `${relative(projectRoot, projectMatches[0])} is not the current Skill ${name}; ` +
        "replace the three runtime files from the current Skill assets directory.",
      );
    }
  }
};

const validateEntryItems = () => {
  for (const record of sourceRecords) {
    const items = [...record.source.matchAll(/<v9-entry-item\b([^>]*)>/gi)];
    items.forEach((match, index) => {
      const attributes = match[1];
      const orientation = getAttribute(attributes, "orientation") || "horizontal";
      const surface = getAttribute(attributes, "surface") || "pure";
      const iconSize = getAttribute(attributes, "icon-size") || "30";
      const interaction = getAttribute(attributes, "interaction") || "whole-item";
      const label = `${record.relativePath} Entry Item #${index + 1}`;
      if (!["horizontal", "vertical"].includes(orientation)) {
        failures.push(`${label}: invalid orientation="${orientation}".`);
      }
      if (!["pure", "subtle"].includes(surface)) {
        failures.push(`${label}: invalid surface="${surface}".`);
      }
      if (!["30", "40", "50"].includes(iconSize)) {
        failures.push(`${label}: invalid icon-size="${iconSize}".`);
      }
      if (!["whole-item", "trailing-button"].includes(interaction)) {
        failures.push(`${label}: invalid interaction="${interaction}".`);
      }
      if (orientation === "vertical" && interaction === "trailing-button") {
        failures.push(`${label}: Vertical does not have a Trailing Button variant.`);
      }
      if (orientation === "vertical" && surface === "subtle" && iconSize === "50") {
        failures.push(`${label}: Vertical + Subtle does not have an Icon Size 50 variant.`);
      }
    });
  }
};

const validateEntryGroups = () => {
  for (const record of sourceRecords) {
    const groups = [...record.source.matchAll(/<v9-entry-group\b([^>]*)>([\s\S]*?)<\/v9-entry-group>/gi)];
    groups.forEach((match, index) => {
      const attributes = match[1];
      const body = match[2];
      const layout = getAttribute(attributes, "layout") || "list";
      const itemSurface = getAttribute(attributes, "item-surface");
      const iconSize = getAttribute(attributes, "icon-size");
      const declaredCount = getAttribute(attributes, "count");
      const actualCount = (body.match(/<v9-entry-item\b/gi) || []).length;
      const label = `${record.relativePath} Entry Group #${index + 1}`;
      if (!["list", "grid-2", "grid-3", "grid-4", "grid-5"].includes(layout)) {
        failures.push(`${label}: invalid layout="${layout}".`);
        return;
      }
      if (actualCount === 0) failures.push(`${label}: at least one <v9-entry-item> is required.`);
      if (declaredCount && Number(declaredCount) !== actualCount) {
        failures.push(`${label}: count="${declaredCount}" does not match ${actualCount} child items.`);
      }
      if (layout === "grid-2" && actualCount < 2) {
        failures.push(`${label}: Grid 2 does not support Count 1.`);
      }
      if (layout === "grid-3" && actualCount < 3) {
        failures.push(`${label}: Grid 3 does not support Count 1 or 2.`);
      }
      if (layout === "grid-4" && actualCount < 3) {
        failures.push(`${label}: the published Grid 4 family starts at Count 3.`);
      }
      if (layout === "grid-5" && actualCount < 5) {
        failures.push(`${label}: the published Grid 5 family starts at Count 5.`);
      }
      if (layout === "list" && iconSize && iconSize !== "40") {
        failures.push(`${label}: List uses Icon Size 40.`);
      }
      if (layout === "grid-2") {
        if (itemSurface && itemSurface !== "subtle") failures.push(`${label}: Grid 2 uses Item Surface Subtle.`);
        if (iconSize && !["30", "40"].includes(iconSize)) failures.push(`${label}: Grid 2 supports Icon Size 30 or 40.`);
      }
      if (layout === "grid-3") {
        const surface = itemSurface || "pure";
        if (surface === "pure" && iconSize && iconSize !== "50") {
          failures.push(`${label}: Pure Grid 3 uses Icon Size 50.`);
        }
        if (surface === "subtle" && iconSize && !["30", "40"].includes(iconSize)) {
          failures.push(`${label}: Subtle Grid 3 supports Icon Size 30 or 40.`);
        }
      }
      if (layout === "grid-4") {
        if (itemSurface && itemSurface !== "pure") failures.push(`${label}: Grid 4 uses Item Surface Pure.`);
        if (iconSize && !["30", "40"].includes(iconSize)) failures.push(`${label}: Grid 4 supports Icon Size 30 or 40.`);
      }
      if (layout === "grid-5") {
        if (itemSurface && itemSurface !== "pure") failures.push(`${label}: Grid 5 uses Item Surface Pure.`);
        if (iconSize && iconSize !== "50") failures.push(`${label}: Grid 5 uses Icon Size 50.`);
      }
    });
  }
};

const validateFormItems = () => {
  for (const record of sourceRecords) {
    const items = [...record.source.matchAll(/<v9-form-item(?=[\s>])([^>]*)>/gi)];
    items.forEach((match, index) => {
      const attributes = match[1];
      const interaction = getAttribute(attributes, "interaction") || "input";
      const content = getAttribute(attributes, "content") || "empty";
      const state = getAttribute(attributes, "state") || "default";
      const label = `${record.relativePath} Form Item #${index + 1}`;
      const textual = ["input", "select"].includes(interaction);
      if (!["input", "select", "radio", "checkbox"].includes(interaction)) {
        failures.push(`${label}: invalid interaction="${interaction}".`);
      }
      if (!['empty', 'filled'].includes(content)) {
        failures.push(`${label}: invalid content="${content}".`);
      }
      if (!["default", "error", "disabled"].includes(state)) {
        failures.push(`${label}: invalid state="${state}"; Focus and Readonly are not supported.`);
      }
      if (hasAttribute(attributes, "focus") || hasAttribute(attributes, "readonly")) {
        failures.push(`${label}: Focus and Readonly are not published Form Item states.`);
      }
      if (/\b(?:bottom-space|data-v9-bottom-space)(?:\s*=|\s|$)/i.test(attributes)) {
        failures.push(`${label}: continuous Error bottom spacing is computed by <v9-form-item-group>; do not set it manually.`);
      }
      if (!textual && (hasAttribute(attributes, "content") || hasAttribute(attributes, "placeholder") || hasAttribute(attributes, "value"))) {
        failures.push(`${label}: Control only accepts checked/state; content, placeholder, and value belong to Textual.`);
      }
      if (textual && hasAttribute(attributes, "checked")) {
        failures.push(`${label}: checked only applies to Radio/Checkbox Control.`);
      }
    });
  }
};

const validateFormGroupsAndCards = () => {
  for (const record of sourceRecords) {
    const groups = [...record.source.matchAll(/<v9-form-item-group\b([^>]*)>([\s\S]*?)<\/v9-form-item-group>/gi)];
    groups.forEach((match, index) => {
      const actualCount = (match[2].match(/<v9-form-item(?=[\s>])/gi) || []).length;
      if (actualCount === 0) {
        failures.push(`${record.relativePath} Form Item Group #${index + 1}: at least one <v9-form-item> is required.`);
      }
      if (/\b(?:gap|padding|surface)\s*=/i.test(match[1])) {
        failures.push(`${record.relativePath} Form Item Group #${index + 1}: Group does not expose gap, padding, or surface.`);
      }
    });

    const cards = [...record.source.matchAll(/<v9-form-card\b([^>]*)>([\s\S]*?)<\/v9-form-card>/gi)];
    cards.forEach((match, index) => {
      const header = getAttribute(match[1], "header");
      const groupCount = (match[2].match(/<v9-form-item-group\b/gi) || []).length;
      const label = `${record.relativePath} Form Card #${index + 1}`;
      if (header && !["true", "false"].includes(header)) {
        failures.push(`${label}: header must be true or false.`);
      }
      if (groupCount !== 1) {
        failures.push(`${label}: exactly one <v9-form-item-group> is required.`);
      }
      if (/slot\s*=\s*["']footer["']/i.test(match[2])) {
        failures.push(`${label}: CellCard / Form Mode does not have a Footer region.`);
      }
    });

    const genericCards = [...record.source.matchAll(/<v9-card\b[^>]*>([\s\S]*?)<\/v9-card>/gi)];
    genericCards.forEach((match, index) => {
      if (/<v9-form-card\b/i.test(match[1])) {
        failures.push(`${record.relativePath} Card #${index + 1}: do not nest <v9-form-card> inside generic <v9-card>.`);
      }
    });
  }
};

const validateBackgroundModes = () => {
  for (const record of sourceRecords) {
    const classValues = [...record.source.matchAll(/\bclass(?:Name)?\s*=\s*["'`]([^"'`]*)["'`]/gi)]
      .map((match) => match[1]);
    classValues.forEach((classValue, index) => {
      if (!/(?:^|\s)v9-page(?:\s|$)/.test(classValue)) return;
      const modes = ["default", "focus", "immersive"].filter((mode) =>
        new RegExp(`(?:^|\\s)v9-page--background-${mode}(?:\\s|$)`).test(classValue),
      );
      if (modes.length > 1) {
        failures.push(`${record.relativePath} Page Background #${index + 1}: only one mode is allowed; found ${modes.join(", ")}.`);
      }
    });

    if (/<(?!v9-background-focus\b)[^>]+\bclass\s*=\s*["'][^"']*\bv9-background-focus\b/i.test(record.source)) {
      failures.push(`${record.relativePath}: do not reproduce Focus with .v9-background-focus; use <v9-background-focus>.`);
    }
  }

  const usesFocusComponent = /<v9-background-focus(?:\s|>)/i.test(combinedSource) ||
    /(?:create|createElement)\(\s*["']v9-background-focus["']/i.test(combinedSource);
  const usesFocusMode = /\bv9-page--background-focus\b/i.test(combinedSource);
  if (usesFocusMode && !usesFocusComponent) {
    failures.push("Focus page mode is declared, but <v9-background-focus> is missing.");
  }
  if (usesFocusComponent && !usesFocusMode) {
    failures.push("<v9-background-focus> is used without .v9-page--background-focus.");
  }
  if (usesFocusComponent) {
    if (!/v9-core\.css/i.test(combinedSource)) {
      failures.push("<v9-background-focus> is used, but v9-core.css is not loaded by the page sources.");
    }
    if (!/v9-components\.js/i.test(combinedSource)) {
      failures.push("<v9-background-focus> is used, but v9-components.js is not loaded by the page sources.");
    }
    const normalizedFiles = allFiles.map((file) => relative(projectRoot, file).replaceAll("\\", "/"));
    if (!normalizedFiles.some((file) => file.endsWith("assets/components/background-focus/atmosphere.svg"))) {
      failures.push("<v9-background-focus> source asset missing: assets/components/background-focus/atmosphere.svg");
    }
  }
};

const validateTaskSheets = () => {
  for (const record of sourceRecords) {
    const sheets = [...record.source.matchAll(/<v9-task-sheet\b([^>]*)>([\s\S]*?)<\/v9-task-sheet>/gi)];
    sheets.forEach((match, index) => {
      const attributes = match[1];
      const body = match[2];
      const boundary = getAttribute(attributes, "content-boundary") || "auto";
      const showAction = getAttribute(attributes, "show-action") || "true";
      const dynamicBoundary = boundary.includes("${");
      const dynamicAction = showAction.includes("${");
      const label = `${record.relativePath} Task Sheet #${index + 1}`;
      const headerCount = (body.match(/\bslot\s*=\s*["']header["']/gi) || []).length;
      const contentCount = (body.match(/\bslot\s*=\s*["']content["']/gi) || []).length;
      const actionCount = (body.match(/\bslot\s*=\s*["']action["']/gi) || []).length;

      if (!dynamicBoundary && !["auto", "single", "multiline"].includes(boundary)) {
        failures.push(`${label}: invalid content-boundary="${boundary}".`);
      }
      if (!dynamicAction && !["true", "false"].includes(showAction)) {
        failures.push(`${label}: show-action must be true or false.`);
      }
      if (headerCount !== 1) failures.push(`${label}: exactly one slot="header" child is required.`);
      if (contentCount !== 1) failures.push(`${label}: exactly one slot="content" child is required.`);
      if (!dynamicAction && showAction === "true" && actionCount !== 1) {
        failures.push(`${label}: show-action=true requires exactly one slot="action" child.`);
      }
      if (actionCount > 1) failures.push(`${label}: at most one slot="action" child is allowed.`);
    });
  }

  if (/<v9-task-sheet\b/i.test(combinedSource)) {
    if (!/v9-core\.css/i.test(combinedSource)) {
      failures.push("Task Sheet is used, but v9-core.css is not loaded by the page sources.");
    }
    if (!/v9-components\.js/i.test(combinedSource)) {
      failures.push("Task Sheet is used, but v9-components.js is not loaded by the page sources.");
    }
  }
};

if (declaresMultiStatePreview && !hasPreviewControls) {
  failures.push('Multi-state preview is declared, but [data-v9-preview-controls] is missing.');
}
if (declaresMultiStatePreview && previewRouteMatches.length < 2) {
  failures.push('Multi-state preview must expose at least two [data-preview-route] entries.');
}
if (hasPreviewControls && !declaresMultiStatePreview) {
  failures.push('Preview controls exist, but data-v9-preview="multi-state" is not declared.');
}

validateRuntimeParity();
validateEntryItems();
validateEntryGroups();
validateFormItems();
validateFormGroupsAndCards();
validateBackgroundModes();
validateTaskSheets();

if (/<v9-entry-(?:item|group)\b/i.test(combinedSource)) {
  if (!/v9-core\.css/i.test(combinedSource)) {
    failures.push("Entry components are used, but v9-core.css is not loaded by the page sources.");
  }
  if (!/v9-components\.js/i.test(combinedSource)) {
    failures.push("Entry components are used, but v9-components.js is not loaded by the page sources.");
  }
}

if (/<v9-form-(?:item|item-group|card)\b/i.test(combinedSource)) {
  if (!/v9-core\.css/i.test(combinedSource)) {
    failures.push("Form components are used, but v9-core.css is not loaded by the page sources.");
  }
  if (!/v9-components\.js/i.test(combinedSource)) {
    failures.push("Form components are used, but v9-components.js is not loaded by the page sources.");
  }
}

if (manualMatches.length > 0) {
  failures.push(
    `Manual empty-state replacement found in: ${manualMatches.map((item) => item.relativePath).join(", ")}. ` +
    "Use <v9-empty> and .v9-empty-container instead of .empty-state.",
  );
}

if (hasEmptyIntent && !usesV9EmptyOutsideInherited) {
  failures.push("Empty-state copy exists, but the page does not call <v9-empty>.");
}

if (usesV9Empty) {
  if (!/v9-core\.css/i.test(combinedSource)) {
    failures.push("<v9-empty> is used, but v9-core.css is not loaded by the page sources.");
  }
  if (!/v9-components\.js/i.test(combinedSource)) {
    failures.push("<v9-empty> is used, but v9-components.js is not loaded by the page sources.");
  }

  const normalizedFiles = allFiles.map((file) => relative(projectRoot, file).replaceAll("\\", "/"));
  for (const asset of ["assets/components/empty/illustration.svg"]) {
    if (!normalizedFiles.some((file) => file.endsWith(asset))) {
      failures.push(`<v9-empty> source asset missing: ${asset}`);
    }
  }
  for (const obsoleteAsset of [
    "assets/components/empty/illustration.png",
    "assets/components/empty/mask.svg",
  ]) {
    if (normalizedFiles.some((file) => file.endsWith(obsoleteAsset))) {
      failures.push(`<v9-empty> obsolete split asset found: ${obsoleteAsset}`);
    }
  }
}

if (failures.length > 0) {
  console.error(failures.map((message) => `- ${message}`).join("\n"));
  process.exit(1);
}

const result = hasEmptyIntent
  ? "empty intent detected; <v9-empty>, runtime references, and source assets verified"
  : "no empty-state intent detected; no manual .empty-state replacement found";
const previewResult = declaresMultiStatePreview
  ? `multi-state preview controls verified (${previewRouteMatches.length} route entries)`
  : "single-state preview contract";
for (const range of inheritedRanges) {
  console.log(`Inherited source scope: ${range.file} / ${range.id}; baseline: ${range.baseline}`);
}
console.log(`H5 page validation passed: current Skill runtime verified; ${result}; ${previewResult}; inherited scopes: ${inheritedRanges.length}.`);
if (inheritedRanges.length) console.log("Inherited scopes skip only legacy empty-state replacement checks. Verify authorization, baseline fidelity and rendered states separately; this is not whole-page 9.0 certification.");
