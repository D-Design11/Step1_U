import assert from "node:assert/strict";

const elements = new Map();
globalThis.HTMLElement = class {
  constructor() {
    this.attachShadow({ mode: "open" });
  }
  attachShadow() {
    this.shadowRoot = {};
    return this.shadowRoot;
  }
};
globalThis.customElements = {
  get: (name) => elements.get(name),
  define: (name, element) => elements.set(name, element),
};
globalThis.Node = { TEXT_NODE: 3 };
globalThis.MutationObserver = class {
  constructor(callback) {
    this.callback = callback;
    this.disconnected = false;
  }
  observe(target, options) {
    this.target = target;
    this.options = options;
  }
  disconnect() {
    this.disconnected = true;
  }
  emit(records) {
    if (!this.disconnected) this.callback(records);
  }
};

await import("../assets/v9-components.js");
const Card = customElements.get("v9-card");
const card = new Card();
const header = { nodeType: 1, hidden: false, parentNode: card };
const content = { nodeType: 1, hidden: true, parentNode: card };

const createRegion = (name, assignedNodes) => {
  const slot = {
    assignedNodes: () => assignedNodes,
    addEventListener: (event, listener) => {
      assert.equal(event, "slotchange");
      slot.onChange = listener;
    },
  };
  return { name, hidden: false, slot, querySelector: () => slot };
};
const regions = [
  createRegion("header", [header]),
  createRegion("content", [content]),
  createRegion("footer", []),
];
card.shadowRoot.querySelectorAll = (selector) =>
  selector === "[data-region]" ? regions : selector === "slot" ? regions.map((region) => region.slot) : [];
card.mount = () => {};

card.render();
assert.equal(regions[0].hidden, false, "header should remain visible");
assert.equal(regions[1].hidden, true, "collapsed content should have no region");
assert.equal(regions[2].hidden, true, "empty footer should have no region");
assert.deepEqual(card._slotVisibilityObserver.options.attributeFilter, ["hidden"]);
assert.equal(card._slotVisibilityObserver.options.subtree, true);

content.hidden = false;
card._slotVisibilityObserver.emit([{ type: "attributes", attributeName: "hidden", target: content }]);
assert.equal(regions[1].hidden, false, "expanding a slotted child must reveal the content region");

content.hidden = true;
card._slotVisibilityObserver.emit([{ type: "attributes", attributeName: "hidden", target: content }]);
assert.equal(regions[1].hidden, true, "collapsing a slotted child must hide the content region");

content.hidden = false;
regions[1].slot.onChange();
assert.equal(regions[1].hidden, false, "slot assignment changes must still refresh regions");

const previousObserver = card._slotVisibilityObserver;
card.render();
assert.equal(previousObserver.disconnected, true, "re-render must disconnect the previous observer");
card.disconnectedCallback();
assert.equal(card._slotVisibilityObserver.disconnected, true, "disconnect must release the observer");

console.log("CellCard slot visibility behavior passed: collapse → expand → collapse, slotchange, cleanup.");
