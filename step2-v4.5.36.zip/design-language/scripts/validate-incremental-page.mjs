import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { deflateSync, inflateSync } from "node:zlib";

const [baselineInput, currentInput, scopeInput, diffInput] = process.argv.slice(2);

if (!baselineInput || !currentInput || !scopeInput) {
  console.error(
    "Usage: node scripts/validate-incremental-page.mjs " +
    "<baseline.png> <current.png> <allowed-regions.json> [diff.png]",
  );
  process.exit(1);
}

const baselinePath = resolve(baselineInput);
const currentPath = resolve(currentInput);
const scopePath = resolve(scopeInput);
const diffPath = diffInput ? resolve(diffInput) : null;

for (const path of [baselinePath, currentPath, scopePath]) {
  if (!existsSync(path)) {
    console.error(`Incremental validation input not found: ${path}`);
    process.exit(1);
  }
}

const pngSignature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

const paeth = (left, above, upperLeft) => {
  const prediction = left + above - upperLeft;
  const leftDistance = Math.abs(prediction - left);
  const aboveDistance = Math.abs(prediction - above);
  const upperLeftDistance = Math.abs(prediction - upperLeft);
  if (leftDistance <= aboveDistance && leftDistance <= upperLeftDistance) return left;
  return aboveDistance <= upperLeftDistance ? above : upperLeft;
};

const decodePng = (path) => {
  const source = readFileSync(path);
  if (source.length < 33 || !source.subarray(0, 8).equals(pngSignature)) {
    throw new Error(`${path}: expected a PNG file.`);
  }

  let offset = 8;
  let width;
  let height;
  let bitDepth;
  let colorType;
  let interlace;
  const idat = [];

  while (offset + 12 <= source.length) {
    const length = source.readUInt32BE(offset);
    const type = source.toString("ascii", offset + 4, offset + 8);
    const dataStart = offset + 8;
    const dataEnd = dataStart + length;
    if (dataEnd + 4 > source.length) throw new Error(`${path}: invalid PNG chunk length.`);
    const data = source.subarray(dataStart, dataEnd);
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
      interlace = data[12];
    } else if (type === "IDAT") {
      idat.push(data);
    } else if (type === "IEND") {
      break;
    }
    offset = dataEnd + 4;
  }

  if (!width || !height || idat.length === 0) throw new Error(`${path}: incomplete PNG.`);
  if (bitDepth !== 8 || ![2, 6].includes(colorType) || interlace !== 0) {
    throw new Error(`${path}: only non-interlaced 8-bit RGB/RGBA PNG screenshots are supported.`);
  }

  const channels = colorType === 6 ? 4 : 3;
  const stride = width * channels;
  const inflated = inflateSync(Buffer.concat(idat));
  const expectedLength = (stride + 1) * height;
  if (inflated.length !== expectedLength) {
    throw new Error(`${path}: unexpected decoded length ${inflated.length}; expected ${expectedLength}.`);
  }

  const rows = Buffer.alloc(stride * height);
  for (let y = 0; y < height; y += 1) {
    const sourceRow = y * (stride + 1);
    const filter = inflated[sourceRow];
    const targetRow = y * stride;
    for (let x = 0; x < stride; x += 1) {
      const raw = inflated[sourceRow + 1 + x];
      const left = x >= channels ? rows[targetRow + x - channels] : 0;
      const above = y > 0 ? rows[targetRow - stride + x] : 0;
      const upperLeft = y > 0 && x >= channels ? rows[targetRow - stride + x - channels] : 0;
      let value;
      if (filter === 0) value = raw;
      else if (filter === 1) value = raw + left;
      else if (filter === 2) value = raw + above;
      else if (filter === 3) value = raw + Math.floor((left + above) / 2);
      else if (filter === 4) value = raw + paeth(left, above, upperLeft);
      else throw new Error(`${path}: unsupported PNG filter ${filter}.`);
      rows[targetRow + x] = value & 255;
    }
  }

  const rgba = Buffer.alloc(width * height * 4);
  for (let pixel = 0; pixel < width * height; pixel += 1) {
    const sourceIndex = pixel * channels;
    const targetIndex = pixel * 4;
    rgba[targetIndex] = rows[sourceIndex];
    rgba[targetIndex + 1] = rows[sourceIndex + 1];
    rgba[targetIndex + 2] = rows[sourceIndex + 2];
    rgba[targetIndex + 3] = channels === 4 ? rows[sourceIndex + 3] : 255;
  }
  return { width, height, rgba };
};

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) {
    value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  }
  return value >>> 0;
});

const crc32 = (buffer) => {
  let value = 0xffffffff;
  for (const byte of buffer) value = crcTable[(value ^ byte) & 255] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
};

const pngChunk = (type, data) => {
  const typeBuffer = Buffer.from(type, "ascii");
  const chunk = Buffer.alloc(data.length + 12);
  chunk.writeUInt32BE(data.length, 0);
  typeBuffer.copy(chunk, 4);
  data.copy(chunk, 8);
  chunk.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])), data.length + 8);
  return chunk;
};

const encodePng = ({ width, height, rgba }) => {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y += 1) {
    const rowStart = y * (width * 4 + 1);
    raw[rowStart] = 0;
    rgba.copy(raw, rowStart + 1, y * width * 4, (y + 1) * width * 4);
  }
  return Buffer.concat([
    pngSignature,
    pngChunk("IHDR", ihdr),
    pngChunk("IDAT", deflateSync(raw)),
    pngChunk("IEND", Buffer.alloc(0)),
  ]);
};

const baseline = decodePng(baselinePath);
const current = decodePng(currentPath);
if (baseline.width !== current.width || baseline.height !== current.height) {
  console.error(
    `Incremental validation failed: screenshot dimensions differ ` +
    `(${baseline.width}×${baseline.height} vs ${current.width}×${current.height}).`,
  );
  process.exit(1);
}

const scope = JSON.parse(readFileSync(scopePath, "utf8"));
const regions = scope.allowedRegions;
if (!Array.isArray(regions)) {
  throw new Error(`${scopePath}: allowedRegions must be an array.`);
}
const pixelThreshold = scope.pixelThreshold ?? 0;
const maxOutsideChangedPixels = scope.maxOutsideChangedPixels ?? 0;
if (!Number.isInteger(pixelThreshold) || pixelThreshold < 0 || pixelThreshold > 255) {
  throw new Error(`${scopePath}: pixelThreshold must be an integer from 0 to 255.`);
}
if (!Number.isInteger(maxOutsideChangedPixels) || maxOutsideChangedPixels < 0) {
  throw new Error(`${scopePath}: maxOutsideChangedPixels must be a non-negative integer.`);
}

const allowed = new Uint8Array(baseline.width * baseline.height);
regions.forEach((region, index) => {
  const values = [region.x, region.y, region.width, region.height];
  if (!values.every(Number.isInteger) || region.width <= 0 || region.height <= 0) {
    throw new Error(`${scopePath}: allowedRegions[${index}] requires integer x/y and positive width/height.`);
  }
  if (region.x < 0 || region.y < 0 || region.x + region.width > baseline.width || region.y + region.height > baseline.height) {
    throw new Error(`${scopePath}: allowedRegions[${index}] exceeds screenshot bounds.`);
  }
  for (let y = region.y; y < region.y + region.height; y += 1) {
    allowed.fill(1, y * baseline.width + region.x, y * baseline.width + region.x + region.width);
  }
});

let outsideChangedPixels = 0;
let insideChangedPixels = 0;
const diff = Buffer.alloc(baseline.rgba.length);
for (let pixel = 0; pixel < baseline.width * baseline.height; pixel += 1) {
  const offset = pixel * 4;
  const delta = Math.max(
    Math.abs(baseline.rgba[offset] - current.rgba[offset]),
    Math.abs(baseline.rgba[offset + 1] - current.rgba[offset + 1]),
    Math.abs(baseline.rgba[offset + 2] - current.rgba[offset + 2]),
    Math.abs(baseline.rgba[offset + 3] - current.rgba[offset + 3]),
  );
  const changed = delta > pixelThreshold;
  if (changed && allowed[pixel]) insideChangedPixels += 1;
  if (changed && !allowed[pixel]) outsideChangedPixels += 1;

  const gray = Math.round(
    (current.rgba[offset] * 0.2126 + current.rgba[offset + 1] * 0.7152 + current.rgba[offset + 2] * 0.0722) * 0.35 + 166,
  );
  diff[offset] = changed ? (allowed[pixel] ? 255 : 222) : gray;
  diff[offset + 1] = changed ? (allowed[pixel] ? 143 : 25) : gray;
  diff[offset + 2] = changed ? (allowed[pixel] ? 53 : 48) : gray;
  diff[offset + 3] = 255;
}

if (diffPath) writeFileSync(diffPath, encodePng({ ...baseline, rgba: diff }));

const protectedPixels = allowed.reduce((count, value) => count + (value ? 0 : 1), 0);
const outsideRatio = protectedPixels === 0 ? 0 : outsideChangedPixels / protectedPixels;
const summary =
  `Incremental diff: ${insideChangedPixels} changed pixels inside allowed regions; ` +
  `${outsideChangedPixels} outside (${(outsideRatio * 100).toFixed(4)}%).`;

if (outsideChangedPixels > maxOutsideChangedPixels) {
  console.error(
    `Incremental page validation failed: ${summary} ` +
    `Allowed maximum is ${maxOutsideChangedPixels}.${diffPath ? ` Diff: ${diffPath}` : ""}`,
  );
  process.exit(1);
}

console.log(`Incremental page validation passed: ${summary}${diffPath ? ` Diff: ${diffPath}` : ""}`);
