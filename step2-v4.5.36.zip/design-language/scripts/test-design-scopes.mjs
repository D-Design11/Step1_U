// Regression checks: protected source regions must not exempt actual V9 contracts or new V9 regions.
import { mkdtempSync, mkdirSync, copyFileSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import assert from "node:assert/strict";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const scratch = mkdtempSync(join(tmpdir(), "v9-design-scopes-"));
const inherited = (content, id = "old-empty") => `<!-- design-source:start ${id} | baseline: source.html#empty -->\n${content}\n<!-- design-source:end ${id} -->`;
const legacy = '<div class="empty-state">暂无记录</div>';
const formal = '<v9-empty text="暂无记录"></v9-empty>';
let count = 0;
function check(name, content, ok, expected = "", setup = () => {}) {
  const project = join(scratch, String(++count));
  mkdirSync(join(project, "assets/components/empty"), { recursive: true });
  for (const file of ["v9-core.css", "v9-components.js", "v9-tokens.css", "components/empty/illustration.svg"]) {
    copyFileSync(join(root, "assets", file), join(project, "assets", file));
  }
  writeFileSync(join(project, "index.html"), `<link rel="stylesheet" href="assets/v9-core.css"><script type="module" src="assets/v9-components.js"></script>${content}`);
  setup(project);
  const result = spawnSync(process.execPath, [join(root, "scripts/validate-h5-page.mjs"), project], { encoding: "utf8" });
  const output = result.stdout + result.stderr;
  assert.equal(result.status, ok ? 0 : 1, `${name}\n${output}`);
  if (expected) assert.ok(output.includes(expected), `${name}: missing diagnostic ${expected}\n${output}`);
  console.log(`PASS ${name}`);
}
try {
  check("unmarked new empty state is rejected", legacy, false, "Manual empty-state replacement");
  check("formal V9 empty remains accepted", formal, true);
  check("protected legacy empty is preserved", inherited(legacy), true, "Inherited source scope:");
  check("mixed legacy and formal V9", inherited(legacy) + formal, true);
  check("legacy exception cannot hide new empty replacement", inherited(legacy) + legacy, false, "Manual empty-state replacement");
  check("formal component inside legacy still validates attributes", inherited('<v9-form-item state="readonly"></v9-form-item>'), false, "invalid state");
  check("formal component inside legacy still requires assets", inherited(formal), false, "source asset missing", p => rmSync(join(p, "assets/components/empty/illustration.svg")));
  check("formal component in legacy does not satisfy new region", inherited(formal) + '<div>暂无任务</div>', false, "does not call <v9-empty>");
  check("runtime drift remains an error", inherited(legacy), false, "not the current Skill", p => writeFileSync(join(p, "assets/v9-components.js"), "// changed"));
  check("unclosed scope rejected", '<!-- design-source:start old | baseline: ref.png -->' + legacy, false, "unclosed design-source");
  check("mismatched scope rejected", '<!-- design-source:start old | baseline: ref.png -->' + legacy + '<!-- design-source:end different -->', false, "unmatched design-source");
  check("missing evidence rejected", '<!-- design-source:start old -->' + legacy + '<!-- design-source:end old -->', false, "invalid design-source");
  check("nested scopes rejected", inherited(inherited(legacy, "inner"), "outer"), false, "nested or duplicate");
  check("duplicate scopes rejected", inherited(legacy) + inherited(legacy), false, "nested or duplicate");
  check("JS template and CSS scopes are supported", '<div id="old"></div>', true, "inherited scopes: 2", p => {
    writeFileSync(join(p, "old.js"), '/* design-source:start old-js | baseline: ref.html#empty */\nconst old = `<div class="empty-state">暂无记录</div>`;\n/* design-source:end old-js */');
    writeFileSync(join(p, "old.css"), '/* design-source:start old-css | baseline: ref.css */\n.empty-state{background:white}\n/* design-source:end old-css */');
  });
  check("preview controls remain required in mixed projects", inherited(legacy) + '<main data-v9-preview="multi-state"></main>', false, "preview-controls");
  console.log(`Design scope regression passed: ${count} cases.`);
} finally {
  rmSync(scratch, { recursive: true, force: true });
}
