#!/usr/bin/env node

import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const [pageId, outputArg] = process.argv.slice(2);
const skillRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");

const stop = (message) => {
  console.error(message);
  process.exit(1);
};

if (!pageId || !outputArg || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(pageId)) {
  stop("Usage: node scripts/fetch-page-assets.mjs <page-id> <h5-project-directory>");
}

const outputRoot = resolve(outputArg);
if (!existsSync(outputRoot) || !statSync(outputRoot).isDirectory()) {
  stop(`H5 project directory not found: ${outputRoot}`);
}

const manifestPath = resolve(skillRoot, "pages", `${pageId}.assets.json`);
if (!existsSync(manifestPath)) stop(`Page asset manifest not found: ${manifestPath}`);

let manifest;
try {
  manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
} catch (error) {
  stop(`Invalid page asset manifest ${manifestPath}: ${error.message}`);
}

if (manifest.page !== pageId || !Array.isArray(manifest.assets) || manifest.assets.length === 0) {
  stop(`Page asset manifest must declare page="${pageId}" and a non-empty assets array.`);
}

const isInsideOutput = (path) => {
  const value = relative(outputRoot, path);
  return value !== ".." && !value.startsWith(`..${sep}`);
};

const readPngSize = (buffer) => {
  const signature = "89504e470d0a1a0a";
  if (buffer.length < 24 || buffer.subarray(0, 8).toString("hex") !== signature) return null;
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
};

const verify = (asset, buffer) => {
  const hash = createHash("sha256").update(buffer).digest("hex");
  if (!/^[a-f0-9]{64}$/i.test(asset.sha256 || "")) {
    throw new Error(`${asset.id}: manifest sha256 must contain 64 hexadecimal characters.`);
  }
  if (hash !== asset.sha256.toLowerCase()) {
    throw new Error(`${asset.id}: SHA-256 mismatch; expected ${asset.sha256}, received ${hash}.`);
  }
  if (asset.mimeType === "image/png") {
    const size = readPngSize(buffer);
    if (!size) throw new Error(`${asset.id}: downloaded file is not a valid PNG.`);
    if (size.width !== asset.width || size.height !== asset.height) {
      throw new Error(
        `${asset.id}: PNG size mismatch; expected ${asset.width}x${asset.height}, ` +
        `received ${size.width}x${size.height}.`,
      );
    }
  }
};

for (const asset of manifest.assets) {
  if (!asset?.id || !asset?.target || !asset?.url) stop("Every page asset requires id, target, and url.");
  let source;
  try {
    source = new URL(asset.url);
  } catch {
    stop(`${asset.id}: invalid asset URL ${asset.url}`);
  }
  if (source.protocol !== "https:") stop(`${asset.id}: only HTTPS asset URLs are allowed.`);

  const targetPath = resolve(outputRoot, asset.target);
  if (!isInsideOutput(targetPath)) stop(`${asset.id}: target escapes the H5 project directory: ${asset.target}`);

  try {
    if (existsSync(targetPath)) {
      const cached = readFileSync(targetPath);
      try {
        verify(asset, cached);
        console.log(`Page asset already valid: ${asset.target}`);
        continue;
      } catch {
        console.warn(`Cached page asset is stale; fetching the declared source: ${asset.target}`);
      }
    }

    const response = await fetch(source, { redirect: "follow" });
    if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`);
    const contentType = response.headers.get("content-type")?.split(";", 1)[0]?.trim();
    if (asset.mimeType && contentType && contentType !== asset.mimeType) {
      throw new Error(`MIME type mismatch; expected ${asset.mimeType}, received ${contentType}`);
    }
    const contentLength = Number(response.headers.get("content-length") || 0);
    if (contentLength > 20 * 1024 * 1024) throw new Error("asset exceeds the 20MB limit");
    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.length > 20 * 1024 * 1024) throw new Error("asset exceeds the 20MB limit");
    verify(asset, buffer);
    mkdirSync(dirname(targetPath), { recursive: true });
    writeFileSync(targetPath, buffer);
    console.log(`Fetched page asset: ${asset.target}`);
  } catch (error) {
    stop(`${asset.id}: unable to materialize ${asset.url}: ${error.message}`);
  }
}

console.log(`Page assets ready for ${pageId}.`);
