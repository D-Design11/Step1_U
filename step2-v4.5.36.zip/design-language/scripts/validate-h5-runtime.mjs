import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const runtimePath = resolve(root, "assets/v9-components.js");
const cssPath = resolve(root, "assets/v9-core.css");
const skillPath = resolve(root, "SKILL.md");
const workflowPath = resolve(root, "references/workflow.md");
const figmaWorkflowPath = resolve(root, "references/figma-workflow.md");
const maintenanceWorkflowPath = resolve(root, "references/component-maintenance.md");
const migrationPath = resolve(root, "references/h5-migration.md");
const mapPath = resolve(root, "references/v9-figma-map.md");
const componentsPath = resolve(root, "references/components.md");
const spacingPath = resolve(root, "references/spacing.md");
const tokensPath = resolve(root, "assets/tokens.json");
const pageIndexPath = resolve(root, "pages/_index.md");
const focusedFormPagePath = resolve(root, "pages/focused-form-page.md");
const driverExpressPagePath = resolve(root, "pages/driver-express-register.md");
const driverExpressAssetsPath = resolve(root, "pages/driver-express-register.assets.json");
const pageAssetFetcherPath = resolve(root, "scripts/fetch-page-assets.mjs");
const pageValidatorPath = resolve(root, "scripts/validate-h5-page.mjs");
const incrementalValidatorPath = resolve(root, "scripts/validate-incremental-page.mjs");
const deliverableBuilderPath = resolve(root, "scripts/build-h5-deliverables.mjs");
const deliverableValidatorPath = resolve(root, "scripts/validate-h5-deliverables.mjs");
const tabsInactiveWingPath = resolve(root, "assets/components/tabs/inactive-wing.svg");
const tabsInactiveWidePath = resolve(root, "assets/components/tabs/inactive-wide.svg");
const backgroundFocusAssetPath = resolve(root, "assets/components/background-focus/atmosphere.svg");

const runtime = readFileSync(runtimePath, "utf8");
const css = readFileSync(cssPath, "utf8");
const skill = readFileSync(skillPath, "utf8");
const workflow = readFileSync(workflowPath, "utf8");
const figmaWorkflow = readFileSync(figmaWorkflowPath, "utf8");
const maintenanceWorkflow = readFileSync(maintenanceWorkflowPath, "utf8");
const migration = readFileSync(migrationPath, "utf8");
const figmaMap = readFileSync(mapPath, "utf8");
const components = readFileSync(componentsPath, "utf8");
const spacing = readFileSync(spacingPath, "utf8");
const tokens = JSON.parse(readFileSync(tokensPath, "utf8"));
const pageIndex = readFileSync(pageIndexPath, "utf8");
const focusedFormPage = readFileSync(focusedFormPagePath, "utf8");
const driverExpressPage = readFileSync(driverExpressPagePath, "utf8");
const driverExpressAssets = JSON.parse(readFileSync(driverExpressAssetsPath, "utf8"));
const pageAssetFetcher = readFileSync(pageAssetFetcherPath, "utf8");
const pageValidator = readFileSync(pageValidatorPath, "utf8");
const incrementalValidator = readFileSync(incrementalValidatorPath, "utf8");
const deliverableBuilder = readFileSync(deliverableBuilderPath, "utf8");
const deliverableValidator = readFileSync(deliverableValidatorPath, "utf8");
const backgroundFocusAsset = readFileSync(backgroundFocusAssetPath, "utf8");
const commonWorkflow = workflow.slice(workflow.indexOf("# 一、公共主干"), workflow.indexOf("# 二、H5 执行分支"));

const fail = (message) => {
  throw new Error(message);
};

const expectIncludes = (source, value, label) => {
  if (!source.includes(value)) fail(`${label}: missing ${value}`);
};

const expectExcludes = (source, value, label) => {
  if (source.includes(value)) fail(`${label}: unexpected ${value}`);
};

const expectToken = (group, name, value) => {
  const actual = tokens[group]?.tokens?.[name]?.value;
  if (actual !== value) fail(`Token mismatch for ${name}: expected ${value}, got ${actual}`);
};

expectToken("fontSize", "--v9-fz-body-l", "16px");
expectToken("fontSize", "--v9-fz-body-m", "14px");
expectToken("fontSize", "--v9-fz-body-s", "12px");
expectToken("fontSize", "--v9-fz-headline-xl", "26px");
expectToken("space", "--v9-space-3xl", "32px");
expectToken("shadow", "--v9-shadow-4", "0px -12px 32px rgba(15,40,77,0.08)");

expectIncludes(skill, "pages/_index.md", "Page Pattern router");
expectIncludes(skill, "`Create`（创建／重新设计）", "Create task route");
expectIncludes(skill, "`Local Edit`（既有设计增量修改）", "Local Edit task route");
expectIncludes(skill, "`H5 Migration`（9.0合规迁移）", "H5 Migration task route");
expectIncludes(skill, "references/figma-workflow.md", "Progressive Figma workflow route");
expectIncludes(skill, "references/component-maintenance.md", "Progressive component-maintenance route");
expectIncludes(workflow, "`Create`", "Create boundary in common workflow");
expectIncludes(workflow, "`Local Edit`", "Local Edit boundary in common workflow");
expectIncludes(workflow, "`H5 Migration`", "H5 Migration boundary in common workflow");
expectExcludes(workflow, "# 三、Figma 执行分支", "Figma workflow must remain a progressive reference");
expectExcludes(workflow, "# 四、组件维护事务", "Component maintenance must remain a progressive reference");
expectIncludes(figmaWorkflow, "# Figma 页面写入工作流", "Standalone Figma workflow");
expectIncludes(maintenanceWorkflow, "# 组件维护事务", "Standalone component-maintenance workflow");
expectIncludes(pageIndex, "`Local Edit` 不读取", "Local Edit skips Page Pattern");
expectIncludes(pageIndex, "focused-form-page.md", "Focused Form Page index entry");
expectIncludes(pageIndex, "driver-express-register.md", "Driver Express Register Page index entry");
expectIncludes(pageIndex, "<page-id>.assets.json", "Optional Page remote-asset sidecar rule");
expectIncludes(focusedFormPage, "Appbar 内容区结束", "Focused Form Page vertical relationship");
expectIncludes(focusedFormPage, "Page Header 左侧固定为28px", "Focused Form Page content axis");
expectIncludes(focusedFormPage, "Single、Inline、Stacked", "Focused Form Page action variants");
expectExcludes(workflow, "Focused Form Page", "Page Pattern details must not be duplicated in workflow");
expectExcludes(workflow, "Driver Express Register Page", "Business Page details must not be duplicated in workflow");
expectIncludes(driverExpressPage, "只有以下事实同时成立", "Driver Express Register strict full-match rule");
expectIncludes(driverExpressPage, "driver-express-register.assets.json", "Driver Express Register remote-asset route");
expectIncludes(driverExpressPage, "fetch-page-assets.mjs", "Driver Express Register asset materialization command");
expectIncludes(driverExpressPage, '<v9-appbar type="none-black"', "Driver Express Register transparent Appbar");
expectIncludes(driverExpressPage, '<v9-action-group layout="primary">', "Driver Express Register formal action composition");
expectIncludes(driverExpressPage, '<v9-button size="full" variant="primary">', "Driver Express Register formal primary button");
expectIncludes(driverExpressPage, '<v9-textlink importance="secondary" size="m" icon="arrow"', "Driver Express Register formal fallback entry");
expectIncludes(driverExpressPage, "实际多行为42px行高", "Driver Express Register page-specific benefit-title line height");
expectIncludes(driverExpressPage, "最终自包含HTML", "Driver Express Register offline final-delivery rule");
expectExcludes(driverExpressPage, "assets/templates", "Driver Express Register must not depend on a fixed template");
expectExcludes(driverExpressPage, "v9-appbar.js", "Driver Express Register must not use the obsolete split Appbar runtime");
expectExcludes(driverExpressPage, "v9-controls.js", "Driver Express Register must not use the obsolete split controls runtime");
if (driverExpressAssets.page !== "driver-express-register") fail("Driver Express Register asset manifest page mismatch");
if (!Array.isArray(driverExpressAssets.assets) || driverExpressAssets.assets.length !== 1) {
  fail("Driver Express Register asset manifest must contain exactly one Hero asset");
}
const driverHero = driverExpressAssets.assets[0];
if (driverHero.id !== "hero" || driverHero.mimeType !== "image/png") {
  fail("Driver Express Register Hero identity or MIME type mismatch");
}
if (!/^https:\/\//.test(driverHero.url)) fail("Driver Express Register Hero must use HTTPS");
if (!/^[a-f0-9]{64}$/i.test(driverHero.sha256 || "")) fail("Driver Express Register Hero SHA-256 is invalid");
if (driverHero.width !== 1127 || driverHero.height !== 1260) fail("Driver Express Register Hero dimensions mismatch");
if (driverHero.target !== "assets/pages/driver-express-register/hero.png") {
  fail("Driver Express Register Hero target path mismatch");
}
expectIncludes(pageAssetFetcher, 'source.protocol !== "https:"', "Page asset HTTPS guard");
expectIncludes(pageAssetFetcher, 'createHash("sha256")', "Page asset SHA-256 verification");
expectIncludes(pageAssetFetcher, "readPngSize", "Page asset PNG dimension verification");
expectIncludes(pageAssetFetcher, "target escapes the H5 project directory", "Page asset output path guard");
expectIncludes(pageIndex, "先按 `references/components.md` 判断 Task Sheet", "Task Sheet routing hint");
expectExcludes(workflow, "Task Sheet", "Task Sheet component rules must not be duplicated in workflow");
expectIncludes(spacing, "### 光学间距与数值间距", "Generic optical spacing principle");
expectIncludes(spacing, "不得看到多行文字就统一", "Optical spacing non-formula guard");

expectIncludes(runtime, "class V9BackgroundFocus extends V9Element", "Focus Background Web Component");
expectIncludes(runtime, 'assetHref("components/background-focus/atmosphere.svg")', "Focus Background source asset");
expectIncludes(css, ".v9-page--background-focus{background:#F6F8FB;}", "Focus page base color");
expectIncludes(css, ".v9-background-focus{position:relative;display:block;width:100%;height:370px", "Focus fixed-height geometry");
expectIncludes(css, "filter:saturate(1.6);", "Focus atmosphere saturation");
expectIncludes(css, ".v9-page--background-immersive{background:linear-gradient(180deg,#FFD8B9 0%,#FDF7E9 17.5259%,#F8F9FD 48.684%,#F0F1F5 100%);}", "Immersive fixed gradient");
expectIncludes(backgroundFocusAsset, 'fill="#FFF8B8"', "Focus yellow atmosphere color");
expectIncludes(backgroundFocusAsset, 'opacity="0.16"', "Focus cyan atmosphere opacity");
expectIncludes(backgroundFocusAsset, 'stdDeviation="52"', "Focus orange diffusion");
expectIncludes(components, "## 二十九、Page Background", "Page Background component contract");
expectIncludes(components, "高密度效率页即使有主任务也优先Default", "Background mode decision contract");
expectIncludes(figmaMap, "### Page Background 映射", "Page Background Figma mapping");
expectIncludes(pageValidator, "validateBackgroundModes", "Page Background page validation");
expectIncludes(pageValidator, "validateTaskSheets", "Task Sheet page validation");
expectIncludes(pageValidator, 'show-action=true requires exactly one slot="action" child', "Task Sheet action-slot guard");
expectExcludes(workflow, "选择 Background 模式", "Background selection must not be duplicated in workflow");

const registryBlock = runtime.match(/export const V9_COMPONENTS = Object\.freeze\(\{([\s\S]*?)\n\}\);/);
const definitionsBlock = runtime.match(/const definitions = \{([\s\S]*?)\n\};/);
const tagBlock = runtime.match(/class V9Tag extends V9Element \{([\s\S]*?)\n\}\n\nclass V9Badge/);
const alertBlock = runtime.match(/class V9Alert extends V9Element \{([\s\S]*?)\n\}\n\nclass V9Number/);
if (!registryBlock || !definitionsBlock || !tagBlock || !alertBlock) fail("Unable to read runtime registry, definitions, Tag, or Alert implementation");

const registryEntries = [...registryBlock[1].matchAll(
  /"([^"]+)": \{ rootClass: "([^"]+)", kind: "([^"]+)" \}/g,
)].map((match) => ({ name: match[1], rootClass: match[2], kind: match[3] }));
const registryNames = registryEntries.map((entry) => entry.name);
const definitionNames = [...definitionsBlock[1].matchAll(/"([^"]+)": V9/g)].map((match) => match[1]);

for (const name of registryNames) {
  if (!definitionNames.includes(name)) fail(`Registered component has no definition: ${name}`);
}
for (const name of definitionNames) {
  if (!registryNames.includes(name)) fail(`Defined component is missing from registry: ${name}`);
}

const requiredElements = [
  "v9-background-focus",
  "v9-appbar",
  "v9-card",
  "v9-cardheader",
  "v9-cardcontent",
  "v9-task-sheet",
  "v9-accent-card",
  "v9-entry-item",
  "v9-entry-group",
  "v9-pill-option",
  "v9-pill-option-group",
  "v9-form-item",
  "v9-form-item-group",
  "v9-form-card",
  "v9-address-group",
  "v9-metric-item",
  "v9-metric-group",
  "v9-metric-scroll",
  "v9-button",
  "v9-action-group",
  "v9-dialog",
  "v9-quantity-stepper",
  "v9-toast-icon",
  "v9-toast",
  "v9-empty",
];
for (const name of requiredElements) {
  if (!registryNames.includes(name)) fail(`Required direct-call component missing: ${name}`);
}

const identity = Object.fromEntries(registryEntries.map((entry) => [entry.name, entry.kind]));
const expectedIdentity = {
  "v9-background-focus": "component",
  "v9-card": "component",
  "v9-address-group": "component",
  "v9-dialog": "component",
  "v9-empty": "component",
  "v9-entry-item": "component",
  "v9-entry-group": "component",
  "v9-pill-option": "component",
  "v9-pill-option-group": "component",
  "v9-option-tile": "component",
  "v9-option-group": "primitive",
  "v9-warning-count": "component",
  "v9-form-item": "component",
  "v9-form-item-group": "component",
  "v9-form-card": "component",
  "v9-task-sheet": "component",
  "v9-accent-card": "component",
  "v9-number": "primitive",
  "v9-back": "internal",
  "v9-list-row": "internal",
};
for (const [name, kind] of Object.entries(expectedIdentity)) {
  if (identity[name] !== kind) fail(`Identity mismatch for ${name}: expected ${kind}, got ${identity[name]}`);
}

const expectedCounts = { component: 41, primitive: 2, internal: 2 };
for (const [kind, expected] of Object.entries(expectedCounts)) {
  const actual = registryEntries.filter((entry) => entry.kind === kind).length;
  if (actual !== expected) fail(`Identity count mismatch for ${kind}: expected ${expected}, got ${actual}`);
}

const currentPublishedKeys = [
  "82721d3fe1471e5052d7346b0470293b482d7317",
  "3064873b46f0f7f7d36b6f7064e3722e4fb5d2f2",
  "f422b4ea2accd5a8c0c6e8ef715a793ef3be9c69",
  "c5d57a72c624a7978ef5fdec6e2010171ebbb0ae",
  "af44df67d9d41c12a1b3a2a875305fa4fc58711b",
  "224026a8170761826d4fa9f6b9471e931a58a35d",
  "fea3a0eced02f3bbf3bc9475e82141c3f814ce99",
  "de76d55616005615dfed5df6425a12d6c53b4125",
  "b3a6aadac84920a3275e0abe8c484f25febab0c9",
  "92e4ea0fe8817c2103b977f0e8833f14ac18cd0e",
  "7164d71177a5006524fbeff88a0cb17f8b58e614",
  "e8c552655e0ae8ffa1f446550d9a6934fb66d635",
  "728fffcdfc89a48f1d7cd8830c0aff105630889f",
  "e6ca9c4ca52c7057d33ed4fb958331f12f4863b2",
  "9b5dff35ea49a2a3fe1ee92f717df9b9e6ed2263",
  "1bceaf94e775b40b0136862d9524acb5a011ed41",
  "039a24a1cd5b5668c8fbb594cd3215fd900cd167",
  "c98fb3fcc4effbb025029bd2b6c047ff6bb8df25",
  "782146985226886d1e121f8d6095e8713c821bc5",
  "f2b2b67087429cf42a14334ffcfcea6b420a82cc",
  "078cc511ceec8f47b82e413d1c57513f0f5603e9",
  "60b7ce0dfb77bae12d0fcc9afd9845dc982328ef",
  "ee5ed6f07d3efde40ab7fd90620400aeb03f4413",
  "aca48e84f8f65fdf013efd4074e95be185c5b5e1",
  "98c23ccd985a334de8197701fa1d02ead7c910e0",
  "146e09239141aba3be4a34a393db834e0e67653a",
  "cf091b39ec48ac5e170b726d6c0f1670b9621dab",
  "73ea26bf053cde1706bb4bf3fbc6b932c3704300",
  "a089cc889c9548ca8c0e83316abb41a90a952b7e",
  "0e779e851ee3c531adb1775457c4a031e3bc5042",
  "de1adea3af9f7f1b450370cdb6804e7ae56ecc36",
  "330f6f5aad5bd6c37aa868638e36f26c5a30229a",
  "b209337c26cc7df60b10d56df59381ab693fd5e4",
  "23d8858fea9d0034c1671b66ecf52671f595258f",
  "0b91e870ccc0502bb91ae7f95b1bf6c71d389ecc",
  "3e5a87efceded0f91bcb4fa4472ff1799aebd8c2",
];
for (const key of currentPublishedKeys) {
  expectIncludes(figmaMap, key, `Current Figma mapping ${key}`);
  expectIncludes(components, key, `Current component source ${key}`);
}

for (const entry of registryEntries.filter((item) => item.kind === "component")) {
  if (!figmaMap.includes(`<${entry.name}`)) fail(`Formal component missing Figma mapping: ${entry.name}`);
}
expectExcludes(figmaMap, "Description#27:12", "Obsolete Entry Item text property");
expectExcludes(components, "Description#27:12", "Obsolete Entry Item text property in component contract");
expectIncludes(figmaMap, "Description Text#27:12", "Published Entry Item text property");
expectIncludes(runtime, "class V9AccentCard extends V9Element", "Accent Card runtime");
expectIncludes(css, ".v9-accent-card--grouped", "Accent Card structure styles");
expectExcludes(css, "components/accent-card/ring.svg", "Accent Card ring must remain CSS artwork");

const requiredAssets = [
  "assets/components/background-focus/atmosphere.svg",
  "assets/components/appbar/back-black.svg",
  "assets/components/appbar/back-white.svg",
  "assets/components/appbar/cellular-black.svg",
  "assets/components/appbar/cellular-white.svg",
  "assets/components/appbar/wifi-black.svg",
  "assets/components/appbar/wifi-white.svg",
  "assets/components/appbar/battery-black.svg",
  "assets/components/appbar/battery-white.svg",
  "assets/components/metric-trend/up.svg",
  "assets/components/metric-trend/down.svg",
  "assets/components/toast/warning.svg",
  "assets/components/toast/success.svg",
  "assets/components/toast/error.svg",
  "assets/components/toast/loading.png",
  "assets/components/status-overlay/success.svg",
  "assets/components/status-overlay/failed.svg",
  "assets/components/empty/illustration.svg",
  "assets/components/alert/info.svg",
  "assets/components/alert/warning.svg",
  "assets/components/alert/arrow-info.svg",
  "assets/components/alert/arrow-warning.svg",
];
for (const asset of requiredAssets) {
  if (!existsSync(resolve(root, asset))) fail(`Required source asset missing: ${asset}`);
}
for (const obsoleteAsset of [
  "assets/components/empty/illustration.png",
  "assets/components/empty/mask.svg",
]) {
  if (existsSync(resolve(root, obsoleteAsset))) fail(`Obsolete split Empty asset found: ${obsoleteAsset}`);
}

expectIncludes(css, ".v9-appbar__back", "Appbar CSS");
expectIncludes(runtime, 'new CustomEvent("v9-back", { bubbles: true })', "Appbar public back event");
expectIncludes(css, ".v9-appbar--flat{box-shadow:none;}", "Appbar no-divider contract");
expectIncludes(runtime, 'const transparent = white || type.endsWith("-black");', "Appbar transparent-theme classification");
expectIncludes(runtime, 'transparent ? "v9-appbar--transparent" : ""', "Appbar transparent runtime class");
expectIncludes(css, ".v9-appbar--transparent{background:transparent;}", "Appbar transparent background contract");
expectIncludes(css, "text-decoration:none;}", "Appbar text action without underline");
expectExcludes(css, "box-shadow:inset 0 -0.5px 0 0 var(--v9-outline)", "Obsolete Appbar divider shadow");
expectIncludes(css, ".v9-adaptive-line-height:not(.is-multiline){line-height:1;}", "Single-line adaptive typography");
expectIncludes(css, ".v9-adaptive-line-height.is-multiline{line-height:1.5;}", "Multiline adaptive typography");
expectIncludes(css, ".v9-btn--full{width:100%;height:50px;font-size:18px;line-height:18px", "Full Button line height");
expectIncludes(css, ".v9-btn--large{width:100px;height:40px;font-size:16px;line-height:16px", "Button Large fixed width and line height");
expectIncludes(css, ".v9-btn--medium{width:88px;height:35px;font-size:14px;line-height:14px", "Button Medium fixed width and line height");
expectIncludes(css, ".v9-btn--small{width:88px;height:28px;font-size:14px;line-height:14px", "Button Small fixed width and line height");
expectIncludes(runtime, '["primary", "subtle", "weak"]', "Button Weak runtime variant");
expectIncludes(runtime, 'size === "full" && requestedVariant === "weak" ? "primary" : requestedVariant', "Button Full-width excludes Weak");
expectIncludes(css, ".v9-btn--weak{background:var(--v9-surface-default);color:var(--v9-text-primary);border:0;font-weight:400;}", "Button Weak default contract");
expectIncludes(css, ".v9-btn--weak.is-visited{color:var(--v9-text-secondary);}", "Button Weak visited contract");
expectIncludes(css, ".v9-btn--weak.is-disabled{color:var(--v9-text-muted);cursor:not-allowed;}", "Button Weak disabled contract");
expectIncludes(components, 'variant="weak" size="large|medium|small" state="default|visited|disabled"', "Button Weak formal component contract");
expectIncludes(components, "白色背景禁止使用Weak", "Button Weak white-background prohibition");
expectIncludes(figmaMap, "### Button Weak 正式映射", "Button Weak formal Figma mapping");
expectExcludes(figmaMap, "Weak待样式确认", "Obsolete Button Weak staged mapping");
expectIncludes(css, ".v9-action-group{width:100%;min-width:0", "Action Group Fill container");
expectIncludes(css, "gap:var(--v9-space-10);padding:0;background:transparent;", "Action Group zero-padding contract");
expectIncludes(css, ".v9-footer{background:var(--v9-surface-default)", "Sticky footer wrapper");
expectIncludes(css, "padding:20px 12px;box-sizing:border-box;", "Sticky footer 20px vertical padding");
expectIncludes(css, ".v9-action-group--secondary>.v9-btn{width:162.5px", "Action Group Secondary source width");
expectIncludes(css, "font-size:12px;line-height:12px", "Tag single-line typography");
expectIncludes(css, ".v9-tag--default-size{padding:4px;}", "Tag Default padding");
expectIncludes(css, ".v9-tag--s{padding:2px;}", "Tag Small padding");
expectIncludes(css, "font-size:14px;line-height:14px;font-weight:400;white-space:nowrap;", "Agreement single-line typography");
expectIncludes(css, ".v9-agreement>v9-selection-control{display:inline-flex;width:18px;height:18px", "Agreement control fixed visual box");
expectIncludes(css, ".v9-agreement__text{display:block;align-self:center", "Agreement text center alignment");
expectIncludes(css, ".v9-agreement__copy{display:inline-flex;align-items:center;font-size:14px;line-height:14px;white-space:nowrap;}", "Agreement single-protocol copy geometry");
expectIncludes(css, ".v9-agreement--multi{align-items:flex-start;white-space:normal;}", "Agreement multi-protocol host geometry");
expectIncludes(css, ".v9-agreement__copy.is-multi{flex-wrap:wrap;align-items:baseline;white-space:normal;line-height:21px;}", "Agreement multi-protocol wrapping");
expectIncludes(css, ".v9-agreement__name{color:var(--v9-primary);text-decoration:none;}", "Agreement protocol name highlight");
expectIncludes(css, ".v9-agreement__detail{display:inline-flex;align-items:center;gap:var(--v9-space-2xs);", "Agreement detail link geometry");
expectIncludes(css, ".v9-agreement__detail>v9-arrow{display:inline-flex;width:18px;height:18px", "Agreement detail arrow box");
expectIncludes(css, "right:26px", "Statusbar geometry");
expectIncludes(css, "align-items:flex-start", "Cardheader top alignment");
expectIncludes(css, ".v9-appbar__title{font-size:18px;line-height:18px", "Appbar title line height");
expectIncludes(css, "font-size:16px;\n  line-height:16px", "Appbar action line height");
expectIncludes(css, ".v9-alert--default .v9-alert__text{font-size:14px;line-height:14px", "Alert Default line height");
expectIncludes(css, ".v9-alert--small .v9-alert__text{font-size:12px;line-height:12px", "Alert Small line height");
expectIncludes(css, ".v9-alert--default{height:42px;padding:12px 10px;}", "Alert Default geometry");
expectIncludes(css, ".v9-alert--standard{width:375px;max-width:100%;border-radius:0;}", "Alert Standard geometry");
expectIncludes(css, ".v9-alert--contained{width:355px;max-width:100%;border-radius:var(--v9-radius-md);}", "Alert Contained geometry");
expectIncludes(css, ".v9-alert--small.v9-alert--link{height:42px", "Alert Small Link height");
expectIncludes(css, ".v9-alert--small.v9-alert--pure{height:36px", "Alert Small Pure height");
expectIncludes(css, "components/alert/info.svg", "Alert Info source asset");
expectIncludes(css, "components/alert/warning.svg", "Alert Warning source asset");
expectIncludes(css, "components/alert/arrow-info.svg", "Alert Info arrow asset");
expectIncludes(css, "components/alert/arrow-warning.svg", "Alert Warning arrow asset");
expectIncludes(css, ".v9-alert--info .v9-alert__text{color:var(--v9-primary);}", "Alert Info text color");
expectIncludes(css, ".v9-alert--warning .v9-alert__text{color:var(--v9-error);}", "Alert Warning text color");
expectIncludes(css, ".v9-address-group--default .v9-address-group__text{font-size:var(--v9-fz-body-m);line-height:14px", "Address Default line height");
expectIncludes(css, ".v9-address-group--large .v9-address-group__text{font-size:var(--v9-fz-headline-m);line-height:18px", "Address Large line height");
expectIncludes(css, "--v9-metric-label-gap:6px;--v9-metric-trend-gap:9px;", "Metric XL/L/S spacing");
expectIncludes(css, "--v9-metric-label-gap:6px;--v9-metric-trend-gap:9px;", "Metric L spacing");
expectIncludes(css, "--v9-metric-label-gap:6px;--v9-metric-trend-gap:8px;", "Metric M spacing");
expectIncludes(css, ".v9-metric-item--s{--v9-metric-number-size:var(--v9-fz-number-s);", "Metric S size mapping");
expectIncludes(css, "--v9-metric-decimal-size:var(--v9-fz-headline-s);--v9-metric-label-gap:6px;--v9-metric-trend-gap:9px;", "Metric S spacing");
expectIncludes(css, "transform:translateY(-2px);", "Number XL/L unit optical correction");
expectIncludes(css, ".v9-number--m .v9-number__unit,\n.v9-number--s .v9-number__unit{transform:translateY(-1px);}", "Number M/S unit optical correction");
expectIncludes(css, "--v9-fz-headline-m", "Scrollable Metrics 18px mapping");
expectIncludes(css, "max-width:188px", "Toast maximum width");
expectIncludes(css, "var(--v9-space-md) var(--v9-space-lg)", "Toast padding");
expectIncludes(css, ".v9-toast-icon--loading", "Toast loading animation");
expectIncludes(runtime, '["none", "warning", "success", "loading", "error"]', "Toast icon states");
expectIncludes(runtime, 'detail: { reason: "timeout" }', "Toast close event");
expectIncludes(runtime, 'const containsChinese = (value = "") => /\\p{Script=Han}/u.test(String(value));', "Metric Trend Chinese guard");
expectIncludes(runtime, 'querySelectorAll(".v9-adaptive-line-height")', "Adaptive line-height targets");
expectIncludes(runtime, "document.createRange()", "Rendered line measurement");
expectIncludes(runtime, "range.getClientRects()", "Rendered line rectangle measurement");
expectIncludes(runtime, 'element.classList.toggle("is-multiline", lineTops.size > 1);', "Actual-line-count switch");
expectIncludes(runtime, 'new ResizeObserver(sync)', "Adaptive line-height resize handling");
expectIncludes(runtime, 'const defaultBack = ["flat", "text", "none", "icon"].includes(baseType);', "Icon Appbar default black back button");
expectIncludes(runtime, "coreURL.search = new URL(import.meta.url).search;", "Shadow DOM CSS cache version propagation");
expectIncludes(components, "所有8种类型底部均不绘制灰色分割线或 inner shadow", "Appbar no-divider component contract");
expectIncludes(components, "背景透明；用于Appbar后方存在浅色背景图", "None black transparent component contract");
expectIncludes(figmaMap, "Icon\n默认调用 `back-black.svg`", "Icon Appbar black-back mapping");
expectIncludes(figmaMap, "`None black` 映射为透明Appbar背景", "None black transparent Figma mapping");
expectExcludes(components, "#### Flat（有底线分割）", "Obsolete Appbar Flat divider documentation");
expectIncludes(runtime, 'const hasTrend = trend !== "none" && !containsChinese(trendValue);', "Metric Trend rendering guard");
expectIncludes(runtime, '<span class="v9-metric-trend__value">${escapeHTML(trendValue)}</span>', "Metric Trend value node");
expectIncludes(runtime, '<v9-arrow size="l" color="${importance === "important"', "TextLink fixed L arrow");
expectIncludes(runtime, 'class="v9-expandlink__label"', "ExpandLink explicit text box");
expectIncludes(runtime, '<v9-arrow size="l" color="${color}"', "ExpandLink fixed L arrow");
expectIncludes(runtime, ':host{display:inline-flex;line-height:0;vertical-align:middle;}', "ExpandLink fitted host box");
expectIncludes(runtime, '<span class="v9-number v9-number--${size}">', "Metric Item reuses Number size alignment");
expectIncludes(runtime, 'size === "full" ? "width:100%;"', "Full-width button fills parent");
expectExcludes(runtime, 'size === "full" ? "width:335px;"', "Full-width button must not hard-code Action Group width");
expectIncludes(runtime, ':host{display:block;width:100%;min-width:0;}', "Action Group Fill host");
expectIncludes(runtime, '.v9-action-group--secondary ::slotted(v9-button){width:162.5px;max-width:100%;}', "Action Group Secondary source width runtime");
expectIncludes(runtime, '"variant", "mode", "action", "size", "position"', "Alert public variant attributes");
expectIncludes(runtime, '"show-icon", "show-button", "aria-label"', "Alert Boolean and accessibility attributes");
expectIncludes(runtime, 'size === "default" || action === "link"', "Alert icon visibility defaults");
expectIncludes(runtime, 'action === "link" && size === "default"', "Alert arrow visibility defaults");
expectIncludes(runtime, '<span class="v9-alert__icon" aria-hidden="true"></span>', "Alert semantic icon node");
expectExcludes(runtime, '${variant === "warning" ? "!" : "i"}', "Obsolete Alert character icons");
expectExcludes(alertBlock[1], '<v9-arrow size="l" color="grey" icon="arrow"></v9-arrow>', "Obsolete Alert grey arrow");
expectIncludes(runtime, 'class="v9-agreement__detail" href="${href}"', "Agreement detail whole-row link");
expectIncludes(runtime, '<v9-arrow size="l" color="grey" icon="arrow"></v9-arrow>', "Agreement detail L arrow");
expectIncludes(runtime, "text.split(/(《[^》]+》)/u).filter(Boolean)", "Agreement all protocol ranges parsing");
expectIncludes(runtime, "protocolCount > 1 ? \" is-multi\" : \"\"", "Agreement multi-protocol state");
expectExcludes(runtime, "text.match(/^(.*?)(《[^》]+》)(.*)$/u)", "Obsolete single-protocol parsing");
expectIncludes(runtime, 'class="v9-agreement__name" href="${href}"', "Agreement protocol name link");
expectIncludes(runtime, ':host{display:inline-flex;width:18px;height:18px;line-height:0;vertical-align:middle;}', "Selection Control fixed host box");
expectIncludes(runtime, 'detail: { action }', "Alert action event");
expectIncludes(components, "Default + link", "Alert visibility component contract");
expectIncludes(components, "两个视觉盒中心点必须一致", "Agreement alignment component contract");
expectIncludes(components, "一个或多个 `《…》`", "Agreement multi-protocol component contract");
expectIncludes(components, "多个协议名称", "Agreement multiple-name component contract");
expectIncludes(components, "共用该地址", "Agreement shared href contract");
const agreementProtocolProbe = "我已阅读《公证处协议》《数字证书服务协议》《个人信息授权书》"
  .split(/(《[^》]+》)/u)
  .filter(Boolean)
  .filter((part) => /^《[^》]+》$/u.test(part));
if (agreementProtocolProbe.length !== 3) {
  fail("Agreement multi-protocol parsing probe: expected 3 protocol names");
}
expectIncludes(components, "辅助入口选型", "CardContent auxiliary-entry decision contract");
expectIncludes(components, "移除后原主流程仍可完成", "CardContent auxiliary-entry observable criterion");
expectIncludes(components, "表单与提交反馈选型", "Feedback component decision contract");
expectIncludes(components, "每个相关Form Item分别显示自己的Error", "Field-local feedback contract");
expectIncludes(figmaMap, "Alert 变体与资产映射", "Alert Figma mapping detail");
expectIncludes(figmaMap, "arrow-warning.svg", "Alert warning arrow mapping");
expectIncludes(runtime, '<v9-textlink importance="secondary" size="m"', "Cardheader Link reuses TextLink M Secondary");
expectIncludes(tagBlock[1], ':host{display:inline-flex;line-height:0;vertical-align:middle;}', "Tag host must fit visual node");
expectIncludes(runtime, '<v9-arrow size="l" color="grey" icon="${collapsed ? "up" : "down"}', "Cardheader Expand fixed L arrow");
expectIncludes(runtime, 'class="v9-cardheader__expand-label"', "Cardheader Expand explicit text box");
expectIncludes(runtime, '"media-alt", "media-size"', "CardContent media-size attribute");
expectIncludes(runtime, '"description", "description-tone", "media-src"', "CardContent description tone attribute");
expectIncludes(runtime, '["default", "error"]', "CardContent description tone normalization");
expectIncludes(runtime, 'v9-cardcontent__desc--${descriptionTone}', "CardContent description tone class");
expectIncludes(runtime, '`v9-cardcontent--description-${descriptionTone}`', "CardContent description spacing class");
expectIncludes(runtime, '"action", "action-text", "show-title", "show-description", "show-floating-button"', "CardContent action and visibility attributes");
expectIncludes(runtime, 'action === "floating"', "CardContent Floating action mapping");
expectIncludes(runtime, 'const action = layout === "editorial" ? requestedAction : "none";', "CardContent legal Action normalization");
expectIncludes(runtime, 'const media = layout === "media" && mediaSize !== "none"', "CardContent Media frame always renders");
expectIncludes(runtime, 'data-placeholder="${hasMediaSource ? "false" : "true"}"', "CardContent gray placeholder state");
expectIncludes(runtime, '${hasMediaSource ? `<img class="v9-cardcontent__media"', "CardContent image is explicitly opt-in");
expectExcludes(runtime, 'layout === "media" && mediaSize !== "none" && this.hasAttribute("media-src")', "CardContent Media must not disappear without a source");
expectIncludes(runtime, '<slot name="media-overlay"></slot>', "CardContent StatusOverlay slot");
expectIncludes(runtime, 'components/status-overlay/${state}.svg', "StatusOverlay Figma SVG asset binding");
expectIncludes(runtime, ':host{display:block;position:absolute;inset:auto 0 0;height:35px;}', "StatusOverlay fixed height");
expectExcludes(runtime, 'M2.2 6.1 4.7 8.6 9.9 3.4', "StatusOverlay inline success path");
expectExcludes(runtime, 'm3 3 6 6M9 3 3 9', "StatusOverlay inline failed path");
expectIncludes(runtime, "class V9Empty extends V9Element", "Empty Web Component");
expectIncludes(runtime, 'components/empty/illustration.svg', "Empty single-SVG asset binding");
expectExcludes(runtime, 'components/empty/illustration.png', "Empty obsolete PNG binding");
expectExcludes(runtime, 'components/empty/mask.svg', "Empty obsolete mask binding");
expectIncludes(runtime, '.v9-card__header:not([hidden])~.v9-card__footer:not([hidden])', "Card Header-to-Footer spacing across hidden Content");
expectIncludes(runtime, '.v9-card__header:not([hidden])+.v9-card__content:not([hidden]){margin-top:var(--v9-space-md);}', "Card Header-to-Content 12px spacing");
expectExcludes(runtime, '.v9-card__header:not([hidden])+.v9-card__footer:not([hidden])', "Card Header-to-Footer must not require DOM adjacency");
expectIncludes(runtime, "class V9AddressGroup extends V9Element", "Address Group Web Component");
expectIncludes(runtime, 'aria-label="起点：${escapeHTML(startText)}"', "Address Group full accessible start text");
expectIncludes(css, ".v9-address-group__text{min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}", "Address Group real ellipsis");
expectIncludes(css, "calc(var(--v9-space-xs) + var(--v9-space-2xs))", "Address Group local 6px gap composition");
expectIncludes(css, ".v9-address-group__marker--start{background:#05AC7E;}", "Address Group local origin marker color");
expectIncludes(runtime, 'this.requestClose("escape")', "Dialog Escape behavior");
expectIncludes(runtime, 'document.body?.classList.add("v9-modal-open")', "Dialog scroll lock");
expectIncludes(runtime, 'this.restoreFocusTo = this.deepActiveElement()', "Dialog focus restoration source");
expectIncludes(runtime, '<slot name="agreement"><v9-agreement', "Dialog Agreement slot and fallback");
expectIncludes(runtime, 'detail: { reason }', "Dialog close reason event");
expectIncludes(runtime, 'const hasRequiredAction = Boolean(actionGroup?.querySelector("v9-button:not([hidden])"));', "Dialog required action guard");
expectIncludes(runtime, 'detail: { reason: "missing-actions" }', "Dialog missing-actions invalid event");
expectIncludes(runtime, 'this.onAdaptiveLineHeightSync?.(elements);', "Dialog adaptive spacing hook");
expectIncludes(runtime, 'copy?.classList.toggle("is-single-line-pair", bothSingleLine);', "Dialog single-line pair spacing state");
expectIncludes(css, '.v9-dialog__copy.is-single-line-pair{gap:var(--v9-space-lg);}', "Dialog dual-single-line 16px gap");
expectIncludes(css, 'padding:15px var(--v9-space-xl) var(--v9-space-xl);', "Dialog panel 20px bottom padding");
expectIncludes(css, '.v9-dialog__close{position:relative;width:100%;height:18px;', "Dialog close structural row");
expectIncludes(css, ".v9-metric-trend--up{background:#D6FFEE", "Metric Trend local Up background");
expectIncludes(css, "padding:1px 5px 2px 0;align-items:flex-start", "Metric Trend value padding");
expectIncludes(css, "border-bottom-left-radius:0", "Metric Trend sharp bottom-left corner");
expectIncludes(css, ".v9-textlink{display:inline-flex;height:18px", "TextLink 18px line box");
expectIncludes(css, "padding:0;font-family:var(--v9-font-cn)", "TextLink has no vertical padding");
expectExcludes(css, "padding-block:var(--v9-space-2xs)", "TextLink obsolete 22px compensation");
expectIncludes(css, ".v9-cardheader__title{font-size:var(--v9-cardheader-title-size,16px);line-height:1", "Cardheader contextual title typography");
expectIncludes(css, ".v9-cardheader__subtitle{font-size:var(--v9-cardheader-subtitle-size,14px);line-height:1", "Cardheader subtitle contextual size with 14px default");
expectIncludes(css, "margin-top:var(--v9-cardheader-title-subtitle-gap,10px);", "Cardheader contextual title-to-subtitle gap with 10px default");
expectIncludes(css, '.v9-cardheader[data-show-subtitle="false"]{align-items:center;}', "Cardheader no-subtitle center alignment");
expectIncludes(css, ".v9-cardheader__expand{display:inline-flex;align-items:center;justify-content:center;height:18px", "Cardheader Expand centered line box");
expectIncludes(css, "font-family:var(--v9-font-cn);font-size:14px;font-weight:400;line-height:14px", "Cardheader Expand explicit typography");
expectIncludes(runtime, ".v9-cardheader__title-row{display:flex;align-items:center;gap:var(--v9-space-sm);}", "Cardheader title-to-Tag gap");
expectIncludes(css, ".v9-cardcontent__desc--error{color:var(--v9-error);}", "CardContent error description tone");
expectIncludes(css, "white-space:pre-line", "CardContent multiline description preservation");
expectIncludes(css, ".v9-cardcontent--subtle{background:var(--v9-surface-inset);border-radius:var(--v9-radius-md);padding:12px;}", "CardContent Subtle padding");
expectIncludes(css, ".v9-cardcontent--editorial .v9-cardcontent__copy{gap:var(--v9-cardcontent-copy-gap,10px);}", "CardContent contextual Editorial copy gap");
expectIncludes(css, ".v9-cardcontent--action-floating .v9-cardcontent__copy{gap:var(--v9-cardcontent-copy-gap,var(--v9-space-sm));}", "CardContent contextual Floating copy gap");
expectIncludes(css, ".v9-cardcontent__title{font-size:var(--v9-cardcontent-title-size,14px);line-height:1", "CardContent contextual title typography");
expectIncludes(css, "color:var(--v9-cardcontent-title-color,var(--v9-text-body));", "CardContent title body color default");
expectIncludes(runtime, "class V9TaskSheet extends V9Element", "Task Sheet Web Component");
expectIncludes(runtime, '["auto", "single", "multiline"]', "Task Sheet content-boundary states");
expectIncludes(runtime, 'root.dataset.contentBoundary = resolvedBoundary;', "Task Sheet rendered-line boundary resolution");
expectIncludes(runtime, '--v9-cardheader-title-size:20px;', "Task Sheet Cardheader title override");
expectIncludes(runtime, '--v9-cardcontent-title-size:16px;', "Task Sheet CardContent title override");
expectIncludes(runtime, '--v9-cardcontent-copy-gap:10px;', "Task Sheet Single inner gap");
expectIncludes(runtime, '--v9-cardcontent-copy-gap:var(--v9-space-sm);', "Task Sheet Multiline inner gap");
expectIncludes(css, ".v9-task-sheet{width:375px;max-width:100%", "Task Sheet fixed source width");
expectIncludes(css, "border-radius:var(--v9-radius-xl) var(--v9-radius-xl) 0 0;box-shadow:var(--v9-shadow-4);", "Task Sheet surface geometry");
expectIncludes(css, ".v9-task-sheet__body{display:flex;flex-direction:column;align-items:center;padding-top:20px;gap:20px;}", "Task Sheet Single outer spacing");
expectIncludes(css, "gap:var(--v9-space-lg);padding:0 20px;", "Task Sheet main 16px and 20px geometry");
expectIncludes(css, '.v9-task-sheet[data-content-boundary="multiline"] .v9-task-sheet__body{gap:var(--v9-space-lg);}', "Task Sheet Multiline outer spacing");
expectIncludes(css, '.v9-task-sheet[data-show-action="false"] .v9-task-sheet__action{display:none;}', "Task Sheet action collapse");
expectIncludes(components, "## 三十、Task Sheet / Shell", "Task Sheet component contract");
expectIncludes(components, "V9_COMPONENTS.kind=component", "Task Sheet formal component state");
expectIncludes(figmaMap, "### Task Sheet / Shell 正式映射", "Task Sheet Figma mapping detail");
expectIncludes(figmaMap, "Header→Content固定16px", "Task Sheet header-content mapping");
expectIncludes(figmaMap, "不得扩展成全局“多行统一减4px”公式", "Task Sheet optical spacing boundary");
expectIncludes(css, ".v9-cardcontent--action-floating .v9-cardcontent__body{display:flex;align-items:center;gap:var(--v9-space-xs);}", "CardContent Floating 4px action gap");
expectIncludes(css, ".v9-cardcontent--list .v9-cardcontent__body{display:flex;flex-direction:column;gap:var(--v9-space-lg);}", "CardContent List 16px row gap");
expectIncludes(css, ".v9-cardcontent--media{display:flex;gap:12px;align-items:flex-start;}", "CardContent Media 12px main gap");
expectIncludes(css, ".v9-cardcontent--media .v9-cardcontent__copy{display:flex;flex-direction:column;gap:var(--v9-cardcontent-copy-gap,var(--v9-space-sm));}", "CardContent contextual Media copy gap");
expectIncludes(css, ".v9-cardcontent--description-default .v9-cardcontent__copy{gap:var(--v9-cardcontent-copy-gap,10px);}", "CardContent contextual default description gap");
expectIncludes(css, ".v9-cardcontent--description-error .v9-cardcontent__copy{gap:var(--v9-cardcontent-copy-gap,var(--v9-space-sm));}", "CardContent contextual error description gap");
expectIncludes(css, ".v9-cardcontent__media-frame--medium{width:40px;height:40px;}", "CardContent Media Medium geometry");
expectIncludes(css, ".v9-cardcontent__media-frame--large{width:85px;height:65px;}", "CardContent Media Large geometry");
expectIncludes(runtime, "class V9EntryItem extends V9Element", "Entry Item Web Component");
expectIncludes(runtime, "class V9EntryGroup extends V9Element", "Entry Group Web Component");
expectIncludes(runtime, '"whole-item", "trailing-button"', "Entry Item interaction variants");
expectIncludes(runtime, 'new CustomEvent("v9-entry-activate"', "Entry Item public activation event");
expectIncludes(runtime, 'item.setAttribute("orientation", isList ? "horizontal" : "vertical")', "Entry Group orientation contract");
expectIncludes(runtime, 'item.setAttribute("show-description", isList ? "true" : "false")', "Entry Group description contract");
expectIncludes(css, ".v9-entry-item--subtle .v9-entry-item__placeholder{background:#E4E8EC;}", "Entry Item private subtle placeholder color");
expectIncludes(css, ".v9-entry-item--horizontal.v9-entry-item--pure.v9-entry-item--whole-item{padding:var(--v9-space-sm) 0;}", "Entry Item Pure no-action padding");
expectIncludes(css, ".v9-entry-item--horizontal.v9-entry-item--pure.v9-entry-item--trailing-button{padding:var(--v9-space-md) 0;}", "Entry Item Pure trailing-action padding");
expectIncludes(css, ".v9-entry-item--vertical.v9-entry-item--icon-50{gap:var(--v9-space-md);}", "Entry Item Icon 50 gap");
expectIncludes(css, "button.v9-entry-item--vertical{text-align:center;}", "Entry Item Vertical button alignment override");
expectIncludes(css, ".v9-entry-item--vertical .v9-entry-item__icon{align-self:center;}", "Entry Item Vertical icon centering");
expectIncludes(css, ".v9-entry-item--vertical .v9-entry-item__copy{width:100%;align-items:center;text-align:center;}", "Entry Item Vertical copy centering");
expectIncludes(css, ".v9-entry-item--vertical .v9-entry-item__description{text-align:center;}", "Entry Item Vertical text centering");
expectIncludes(css, ".v9-entry-group--grid-2{grid-template-columns:repeat(2,minmax(0,1fr));row-gap:var(--v9-space-sm);}", "Entry Group Grid 2 geometry");
expectIncludes(css, ".v9-entry-group--grid-3{grid-template-columns:repeat(3,minmax(0,1fr));row-gap:var(--v9-space-lg);}", "Entry Group Grid 3 geometry");
expectIncludes(css, ".v9-entry-group--grid-5{grid-template-columns:repeat(5,minmax(0,1fr));row-gap:var(--v9-space-lg);}", "Entry Group Grid 5 geometry");
expectExcludes(JSON.stringify(tokens), "#E4E8EC", "Entry Item private color must not become a global token");
expectIncludes(components, "## 二十六、Entry", "Entry component contract");
expectIncludes(components, "3项短文案优先A", "Entry Group A/B/C selection contract");
expectIncludes(figmaMap, "Entry Item / Entry Group 映射", "Entry Figma mapping detail");
expectIncludes(figmaMap, "ac2a9155d039d7c6e4cf126901d1cd674fd9d6f5", "Entry Item placeholder dependency");
expectIncludes(figmaMap, "dca4a53b0ef6207ca79fe5c0cd26ccb1aace01e2", "Entry Item Button dependency");
expectIncludes(components, "3项短文案优先A", "Entry component selection remains in components reference");
expectIncludes(pageValidator, "validateEntryGroups", "Entry page validation");
expectIncludes(runtime, "class V9PillOption extends V9Element", "Pill Option Web Component");
expectIncludes(runtime, "class V9PillOptionGroup extends V9Element", "Pill Option Group Web Component");
expectIncludes(runtime, '"value", "label", "selected", "context", "show-icon", "aria-label"', "Pill Option public attributes");
expectIncludes(runtime, '["select", "action"]', "Pill Option Group interaction modes");
expectIncludes(runtime, '["required", "optional"]', "Pill Option Group selection modes");
expectIncludes(runtime, 'new CustomEvent("v9-change"', "Pill Option Select change event");
expectIncludes(runtime, 'new CustomEvent("v9-action"', "Pill Option Action event");
expectIncludes(runtime, 'role="${interaction === "select" ? "radiogroup" : "group"}"', "Pill Option Group ARIA role");
expectIncludes(runtime, '["ArrowLeft", "ArrowRight", "Home", "End"]', "Pill Option keyboard interaction");
expectIncludes(runtime, 'root?.classList.toggle("is-scrollable", options.length > 4);', "Pill Option overflow threshold");
expectIncludes(css, ".v9-pill-option{display:inline-flex;height:30px", "Pill Option 30px geometry");
expectIncludes(css, "gap:var(--v9-space-xs)", "Pill Option 4px icon gap");
expectIncludes(css, ".v9-pill-option--icon{padding-left:var(--v9-space-sm);}", "Pill Option 8px icon-side padding");
expectIncludes(css, ".v9-pill-option--context-white.is-unselected{box-shadow:inset 0 0 0 .5px var(--v9-outline);}", "Pill Option white-context outline");
expectIncludes(css, ".v9-pill-option.is-selected{background:var(--v9-primary);color:var(--v9-on-primary);", "Pill Option selected colors");
expectIncludes(css, ".v9-pill-option__placeholder{display:block;width:16px;height:16px", "Pill Option private placeholder");
expectIncludes(css, ".v9-pill-option-group.is-scrollable{overflow-x:auto", "Pill Option horizontal scrolling");
expectExcludes(JSON.stringify(tokens), "#D9DDE3", "Pill Option private placeholder must not become a global token");
expectIncludes(components, "## 二十七、Pill Option", "Pill Option component contract");
expectIncludes(components, "再次点击当前项可取消到0", "Pill Option Optional selection contract");
expectIncludes(components, "超过4项时使用Horizontal Scroll Frame", "Pill Option overflow component contract");
expectIncludes(components, "668cd2db2c698d375fec32b01bb0398305ea29a6", "Pill Option Legacy exclusion contract");
expectIncludes(figmaMap, "### Pill Option / Group 映射", "Pill Option Figma mapping detail");
expectIncludes(figmaMap, "a089cc889c9548ca8c0e83316abb41a90a952b7e", "Pill Option Select Group mapping");
expectIncludes(figmaMap, "Options Slot增删实例", "Pill Option arbitrary count mapping");
expectIncludes(components, "Pill Option用于紧凑筛选、单选和输入区上方的快捷操作", "Pill Option selection remains in components reference");
expectIncludes(runtime, "class V9FormItem extends V9Element", "Form Item Web Component");
expectIncludes(runtime, "class V9FormItemGroup extends V9Element", "Form Item Group Web Component");
expectIncludes(runtime, "class V9FormCard extends V9Element", "Form Card Web Component");
expectIncludes(runtime, '["input", "select", "radio", "checkbox"]', "Form Item unified interaction modes");
expectIncludes(runtime, '["default", "error", "disabled"]', "Form Item published states");
expectExcludes(runtime, '["default", "focus", "readonly"', "Form Item excludes Focus and Readonly variants");
expectIncludes(runtime, 'new CustomEvent("v9-select"', "Form Item Select event");
expectIncludes(runtime, 'new CustomEvent("v9-change"', "Form Item change event");
expectIncludes(css, ".v9-form-item:not(.is-error){min-height:50px;}", "Form Item default minimum height");
expectIncludes(css, "column-gap:20px", "Form Item label-to-content minimum gap");
expectIncludes(css, "gap:var(--v9-space-xs);", "Form Item label-to-info gap");
expectIncludes(css, ".v9-form-item--input.is-error{min-height:86px;}", "Form Item Input Error height");
expectIncludes(css, ".v9-form-item--select.is-error,.v9-form-item--control.is-error{min-height:90px;}", "Form Item Select and Control Error height");
expectIncludes(css, ':host([data-v9-bottom-space="false"]) .v9-form-item--input.is-error{min-height:70px;}', "Continuous Input Error compact height");
expectIncludes(css, ':host([data-v9-bottom-space="false"]) .v9-form-item--select.is-error,', "Continuous Select Error compact selector");
expectIncludes(css, ':host([data-v9-bottom-space="false"]) .v9-form-item--control.is-error{min-height:74px;}', "Continuous Select and Control Error compact height");
expectIncludes(css, ".v9-form-item__error{width:100%;min-height:28px", "Form Item stretching 28px error background");
expectIncludes(css, ".v9-form-item-group{width:100%;min-width:0;box-sizing:border-box;display:flex;flex-direction:column;gap:0;}", "Form Item Group zero-gap contract");
expectIncludes(runtime, "syncContinuousErrorSpacing()", "Form Item Group continuous Error synchronization");
expectIncludes(runtime, 'currentIsError && nextIsError', "Only non-final adjacent Error item is compacted");
expectIncludes(runtime, 'attributeFilter: ["state"]', "Continuous Error state-change observation");
expectIncludes(css, '.v9-form-card[data-header="true"]{gap:var(--v9-space-sm);}', "Form Card 8px header-to-group gap");
expectIncludes(css, ".v9-form-card__header v9-cardheader{--v9-cardheader-subtitle-size:12px;", "Form Card 12px contextual subtitle");
expectIncludes(css, "--v9-cardheader-title-subtitle-gap:12px;", "Form Card 12px contextual title-to-subtitle gap");
expectIncludes(components, "## 二十八、Form Item", "Form Item component contract");
expectIncludes(components, "不足20px时内容整体换到下一行", "Form Item wrapping contract");
expectIncludes(components, "Group只负责纵向组合", "Form Item Group ownership contract");
expectIncludes(components, "连续Error采用“只收拢非末项”的规则", "Continuous Error spacing contract");
expectIncludes(components, "Input Error高70px，Select/Control Error高74px", "Continuous Error compact heights contract");
expectIncludes(components, "完全移除Header与8px间距", "Form Card optional header contract");
expectIncludes(figmaMap, "父组合对嵌套Cardheader实例的上下文覆盖", "Form Card Figma contextual subtitle mapping");
expectIncludes(figmaMap, "### Form Item / Group / Form Mode 映射", "Form Item Figma mapping detail");
expectIncludes(figmaMap, "一个 `<v9-form-item>` 按 `interaction` 分流到两个Figma Set", "Form Item unified H5 identity mapping");
expectIncludes(figmaMap, "Bottom Space#200:0", "Textual Bottom Space Figma property mapping");
expectIncludes(figmaMap, "Bottom Space#200:13", "Control Bottom Space Figma property mapping");
expectIncludes(figmaMap, "H5的 `<v9-form-item-group>` 按直属Item顺序自动识别连续Error段", "Continuous Error dual-end behavior mapping");
expectIncludes(components, "单字段使用 `<v9-form-item>`；连续字段使用 `<v9-form-item-group>`", "Form component selection remains in components reference");
expectIncludes(pageValidator, "validateFormItems", "Form Item page validation");
expectIncludes(pageValidator, "validateFormGroupsAndCards", "Form Group and Card page validation");
expectIncludes(pageValidator, "Focus and Readonly are not published Form Item states", "Form unsupported state page guard");
expectIncludes(pageValidator, "continuous Error bottom spacing is computed by <v9-form-item-group>", "Manual continuous Error spacing page guard");
expectIncludes(pageValidator, "do not nest <v9-form-card> inside generic <v9-card>", "Form Card nesting page guard");
expectIncludes(css, ".v9-overlay{position:absolute;left:0;right:0;bottom:0;height:35px", "StatusOverlay 85x35 composition geometry");
expectIncludes(css, ".v9-empty{width:100px;height:126px", "Empty component geometry");
expectIncludes(css, "margin-top:var(--v9-space-md)", "Empty 12px illustration-to-text gap");
expectIncludes(css, ".v9-empty__art img{display:block;width:100px;height:100px", "Empty single-SVG geometry");
expectExcludes(css, "components/empty/mask.svg", "Empty obsolete CSS mask");
expectIncludes(css, ".v9-empty-container{display:grid;place-items:center;}", "Empty parent centering helper");
expectIncludes(css, '.v9-card>.v9-cardheader:not([hidden])~.v9-card__footer:not([hidden])', "Legacy Card Header-to-Footer spacing across hidden Content");
expectIncludes(components, "H5 收到含中文的 `trend-value` 时不渲染整个 Trend", "Metric Trend component contract");
expectIncludes(components, "三种文字尺寸均固定使用 Arrow 的 L 尺寸", "TextLink arrow component contract");
expectIncludes(components, "上1px、右5px、下2px、左0", "Metric Trend visual contract");
expectIncludes(components, "左下角固定为0圆角的", "Metric Trend corner contract");
expectIncludes(components, "Figma 与 H5 都使用18px行盒", "TextLink alignment contract");
expectIncludes(components, "使宿主宽高与内部视觉节点完全一致", "Tag host sizing contract");
expectIncludes(components, "CellCard Footer 时直接 Fill 319px可用宽度", "Full-width button container contract");
expectIncludes(components, "Header → Footer 固定16px", "Card Header-to-Footer spacing contract");
expectIncludes(components, "## 二十四、Address Group", "Address Group component contract");
expectIncludes(components, "Tab / Shift+Tab 必须在弹窗内循环", "Dialog keyboard accessibility contract");
expectIncludes(components, 'v9-invalid.detail.reason="missing-actions"', "Dialog required actions component contract");
expectIncludes(components, "TextLink M / Secondary", "Cardheader Link dependency contract");
expectIncludes(components, "Link 与 Expand 的箭头均使用正式 Arrow `size=L`", "Cardheader L arrow contract");
expectIncludes(components, "Link 与 Expand 的操作行都必须使用18px固定行盒", "Cardheader action alignment contract");
expectIncludes(components, "标题行与副标题的间距固定为10px", "Cardheader subtitle spacing contract");
expectIncludes(components, "标题与行内 Tag 的间距固定为8px", "Cardheader Tag spacing contract");
expectIncludes(components, "Editorial 标题 ↔ 描述 | Default 10px；Error 8px", "CardContent description spacing contract");
expectIncludes(components, "Media 图片 ↔ 文字区 | 12px", "CardContent Media spacing contract");
expectIncludes(components, "名称 ↔ DataValue：XL/L/M/S统一为6px", "Metric label spacing contract");
expectIncludes(components, "XL=9px、L=9px、M=8px、S=9px", "Metric trend spacing contract");
expectIncludes(components, "XL/L相对基线向上2px，M/S向上1px", "Number unit optical contract");
expectIncludes(components, "三种文字尺寸均固定使用 Arrow L（18px）", "ExpandLink fixed arrow contract");
expectIncludes(components, "无副标题时标题、Tag和右侧操作按可见盒中心垂直对齐", "Cardheader conditional alignment contract");
expectIncludes(components, "Header ↔ Content 12px", "Card Header-to-Content spacing contract");
expectIncludes(components, "只有作为页面吸底操作区时", "Action Group sticky-padding contract");
expectIncludes(components, 'slot="media-overlay"', "CardContent Media overlay contract");
expectIncludes(components, "最终尺寸必须为 **85×35px**", "StatusOverlay Large Media geometry contract");
expectIncludes(components, "assets/components/status-overlay/success.svg", "StatusOverlay formal asset contract");
expectIncludes(components, "多条原因属于同一业务对象", "CardContent grouped description contract");
expectIncludes(components, 'description-tone="error"', "CardContent error description contract");
expectIncludes(components, "H5 只允许选择下方列出的10个源变体组合", "CardContent ten-variant contract");
expectIncludes(components, "默认状态是复用 `--v9-surface-inset` 的灰色占位框", "CardContent default gray placeholder contract");
expectIncludes(components, "## 二十五、Empty", "Empty component contract");
expectIncludes(components, "组件在容器中的水平、垂直居中由父容器负责", "Empty centering ownership contract");
expectIncludes(components, "默认不得设置固定 `height`、`min-height` 或额外 Padding", "Empty parent sizing boundary contract");
expectIncludes(components, "不是 Empty 组件尺寸、Variant 或通用容器规格", "Empty page-specific size boundary contract");
expectIncludes(components, "由父级正式 `<v9-card>` 的 Content Slot提供白底", "Empty Card surface ownership contract");
expectIncludes(components, "禁止用 `.empty-state`、普通 `<div>`", "Empty manual replacement prohibition");
expectIncludes(components, "H5固定资产必须保持为单一SVG", "Empty single-SVG asset contract");
expectExcludes(components, "Media Large 仅支持 Floating", "CardContent obsolete Media Floating contract");
expectIncludes(figmaMap, "一旦包含中文，", "Metric Trend Figma write guard");
expectIncludes(figmaMap, "内部 Arrow 始终 `size=L`", "TextLink Figma mapping");
expectIncludes(figmaMap, "固定使用 `padding:1px 5px 2px 0`", "Metric Trend H5 mapping");
expectIncludes(figmaMap, "`border-bottom-left-radius:0`", "Metric Trend corner mapping");
expectIncludes(figmaMap, "H5 `.v9-textlink` 同样使用18px行盒", "TextLink H5 alignment mapping");
expectIncludes(figmaMap, "### Tag 宿主与视觉节点映射", "Tag host explicit mapping");
expectIncludes(figmaMap, "Button实例在319px Footer Slot内使用Fill", "Full-width button Figma context mapping");
expectIncludes(figmaMap, "Cardheader Link 依赖映射", "Cardheader Link explicit mapping");
expectIncludes(figmaMap, "H5 Expand操作区固定为18px行盒", "Cardheader Expand alignment mapping");
expectIncludes(figmaMap, "ExpandLink 使用相同的18px可见行盒与固定 Arrow L", "ExpandLink Figma mapping");
expectIncludes(figmaMap, '`false` 使用 `align-items:center`', "Cardheader conditional alignment mapping");
expectIncludes(figmaMap, "Default固定10px、Error固定8px", "CardContent description spacing mapping");
expectIncludes(figmaMap, "XL/L向上2px，M/S向上1px", "Number unit optical mapping");
expectIncludes(figmaMap, "Header Region到Content Region固定12px", "CellCard region spacing mapping");
expectIncludes(figmaMap, "CardContent Media 与 StatusOverlay 映射", "CardContent Media overlay mapping");
expectIncludes(figmaMap, "共同形成85×35px结果", "StatusOverlay Figma geometry mapping");
expectIncludes(figmaMap, "CardContent Description 映射", "CardContent Description mapping");
expectIncludes(figmaMap, "CardContent 只映射源组件集当前存在的10个变体", "CardContent ten-variant mapping");
expectIncludes(figmaMap, "未传 `media-src` 时保留源组件灰色媒体占位", "CardContent placeholder Figma mapping");
expectIncludes(figmaMap, "### Empty 映射", "Empty explicit Figma mapping");
expectIncludes(figmaMap, "cf091b39ec48ac5e170b726d6c0f1670b9621dab", "Empty Component Key mapping");
expectIncludes(figmaMap, "Text#67:15", "Empty text mapping");
expectIncludes(figmaMap, "固定12px", "Empty Figma spacing mapping");
expectIncludes(figmaMap, "运行时不得再依赖PNG或独立mask", "Empty single-SVG mapping");
expectIncludes(figmaMap, "### Address Group 映射", "Address Group explicit Figma mapping");
expectIncludes(figmaMap, "Header Slot#2043:4", "CellCard Header Slot mapping");
expectIncludes(figmaMap, "v9-close.detail.reason", "Dialog close reason mapping");
expectIncludes(figmaMap, 'v9-invalid.detail.reason="missing-actions"', "Dialog missing actions mapping");
expectIncludes(figmaMap, "KKuaHEUNwnenHwumr4a3Ta", "Current Figma source mapping");
expectIncludes(figmaMap, "Rounded 暂不接入", "Rounded Tabs deferral");
expectExcludes(figmaMap, "77059581cb686d8d57f921de68f0b6d30d491887", "Rounded Tabs must remain excluded");
expectIncludes(css, '.v9-tabs--line{width:375px;box-sizing:border-box;height:42px;', "Tabs Line base geometry");
expectIncludes(css, '.v9-tabs--distribution-equal{padding-right:var(--v9-space-sm);padding-left:var(--v9-space-sm);gap:var(--v9-space-sm);}', "Tabs Equal distribution");
expectIncludes(css, '.v9-tabs--distribution-start{justify-content:flex-start;padding-right:var(--v9-space-md);padding-left:var(--v9-space-md);', "Tabs Start alignment");
expectIncludes(css, 'gap:var(--v9-space-2xl);', "Tabs Start 24px gap");
expectIncludes(css, '.v9-tabs--background-visible{background:var(--v9-surface-default);}', "Tabs visible background");
expectIncludes(css, '.v9-tabs--background-transparent{background:transparent;}', "Tabs transparent background");
expectIncludes(css, 'grid-template-rows:16px 4px;row-gap:var(--v9-space-sm);', "Tabs separates text and indicator rows");
expectIncludes(css, '.v9-tabs__label{height:16px;', "Tabs preserves the 16px text line box");
expectIncludes(css, '.v9-tabs__item.is-active .v9-tabs__indicator{background:var(--v9-primary);}', "Tabs active indicator state");
expectExcludes(css, '.v9-tabs__item.is-active::after', "Tabs indicator must not be overlaid inside the text item");
expectIncludes(runtime, "background:transparent;font-family:inherit;", "Tabs preserves component typography");
expectExcludes(runtime, "background:transparent;font:inherit;", "Tabs must not reset size and line height");
expectIncludes(runtime, 'class="v9-tabs__label"', "Tabs label uses a dedicated text layer");
expectIncludes(runtime, 'class="v9-tabs__indicator"', "Tabs indicator uses a dedicated layout layer");
expectIncludes(components, "下方保留2px容器 Padding", "Tabs underline geometry contract");
expectIncludes(components, "16px（单行 = 字号）", "Tabs line-height contract");
expectIncludes(components, "### Line 公开属性与交互", "Tabs Line public contract");
expectIncludes(components, "Card调用时忽略`distribution`与`show-background`", "Tabs Line-only attribute boundary");
expectIncludes(figmaMap, "Tabs Line 几何与字体映射", "Tabs explicit geometry mapping");
if (!existsSync(tabsInactiveWingPath)) fail("Tabs Card asset is missing: inactive-wing.svg");
if (!existsSync(tabsInactiveWidePath)) fail("Tabs Card asset is missing: inactive-wide.svg");
expectIncludes(runtime, 'static observedAttributes = ["items", "active", "variant", "distribution", "show-background"]', "Tabs public attributes");
expectIncludes(runtime, 'normalize(this.getAttribute("distribution"), ["equal", "start"], "equal")', "Tabs distribution normalization");
expectIncludes(runtime, 'isTrue(this, "show-background", true)', "Tabs background defaults to visible");
expectIncludes(runtime, 'v9-tabs--distribution-${distribution}', "Tabs distribution class mapping");
expectIncludes(runtime, 'v9-tabs--background-${showBackground ? "visible" : "transparent"}', "Tabs background class mapping");
expectIncludes(runtime, 'if (variant === "card")', "Tabs Card runtime branch");
expectIncludes(runtime, 'components/tabs/${asset}', "Tabs Card uses packaged Figma assets");
expectIncludes(runtime, '<slot name="panel-${position}">', "Tabs Card named panel slots");
expectIncludes(runtime, 'new CustomEvent("v9-change", { bubbles: true, detail: { active } })', "Tabs change event contract");
expectIncludes(runtime, '["ArrowLeft", "ArrowRight", "Home", "End"]', "Tabs keyboard interaction contract");
expectIncludes(runtime, "ResizeObserver(sync)", "Tabs Card equal-height observer");
expectIncludes(css, ".v9-tabs--card{position:relative;width:351px;", "Tabs Card base geometry");
expectIncludes(css, "box-shadow:var(--v9-shadow-1);font-family:var(--v9-font-cn);", "Tabs Card base shadow contract");
expectExcludes(css, '.v9-tabs--card[data-active=', "Tabs Card shadow must not depend on active state");
expectIncludes(css, "padding:var(--v9-space-lg);", "Tabs Card content spacing");
expectIncludes(css, "white-space:nowrap;text-overflow:ellipsis;", "Tabs Card truncation contract");
expectIncludes(components, "全部Active状态统一使用Level 1阴影", "Tabs Card all-state shadow specification");
expectIncludes(components, "Line负责页面级或大区域内容切换", "Tabs selection remains in components reference");
expectIncludes(figmaMap, "### Tabs Card 正式映射", "Tabs Card formal Figma mapping");
expectIncludes(figmaMap, "a681c138c3d45ba5171ab72ca575931f4aefa65d", "Tabs unified Figma Set Key");
expectExcludes(figmaMap, "ec3d82f380eef9aec11505f2617113f19fb82427", "Retired Tabs Card Set Key");
expectIncludes(figmaMap, '`distribution` `show-background`', "Tabs Line H5 attributes");
expectIncludes(figmaMap, ".v9-tabs--distribution-start", "Tabs Start CSS mapping");
expectIncludes(figmaMap, ".v9-tabs--background-transparent", "Tabs transparent CSS mapping");
expectIncludes(runtime, ':host{display:inline-flex;line-height:0;vertical-align:top;}', "Badge host matches the visible badge boundary");
expectIncludes(css, ".v9-badge--count,.v9-badge--overflow{height:14px;padding:1px var(--v9-space-xs) 1px var(--v9-space-2xs);", "Badge numeric asymmetric padding");
expectIncludes(components, "数字型`count`与`overflow`使用左2px、右4px内边距", "Badge numeric padding contract");
expectIncludes(components, "左侧与文字右边缘重叠2px，顶部高于24px文字行盒2px", "Badge attachment geometry contract");
expectIncludes(figmaMap, "Figma Badge实例边界对应H5 Shadow DOM内", "Badge visible-boundary mapping");
expectIncludes(workflow, "Trend 可见值是否仅使用数字、英文与必要符号", "Metric Trend delivery check");
expectIncludes(workflow, "多状态或可展开内容必须建立状态矩阵", "PRD state matrix workflow");
expectIncludes(workflow, "区分内容分点与界面结构", "PRD content grouping workflow");
expectIncludes(workflow, "在9.0区域创建页面本地节点前", "Component capability check before local nodes");
expectExcludes(workflow, "## PRD 语义 → H5 组件选型表", "Workflow must not duplicate the component catalog");
expectExcludes(workflow, "涉及卡片时读取 `components.md`", "Workflow must not add component-specific checklist steps");
expectExcludes(workflow, "涉及表单时先判断结构层级", "Workflow must not add component-specific checklist steps");
expectIncludes(skill, "仅交付 H5 时不读取 `v9-figma-map.md`", "H5-only skips Figma mapping workflow");
expectIncludes(commonWorkflow, "H5 源码本身记录页面模块到 H5 组件的选择结果", "H5 source records component selection");
expectExcludes(commonWorkflow, "去规范库验证 skill", "Common workflow must not perform full Figma library audit");
expectExcludes(commonWorkflow, "做组件映射表", "Common workflow must not require a Figma mapping table");
expectIncludes(figmaWorkflow, "生成当前页面组件映射表", "Figma branch creates the page mapping table");
expectIncludes(maintenanceWorkflow, "与 `components.md` 做全量对比", "Component maintenance owns the full library audit");
expectIncludes(maintenanceWorkflow, "组合组件必须展开检查内部实例", "Component maintenance direct-dependency audit");
expectIncludes(workflow, "单个 Full-width 按钮是否 Fill 319px可用宽度", "Card Footer geometry delivery check");
expectIncludes(workflow, "单行=字号，多行=字号×1.5", "Actual-line-count typography delivery check");
expectIncludes(workflow, "只有放入吸底 `v9-footer` 时", "Action Group sticky-padding delivery check");
expectIncludes(workflow, "用 StatusOverlay、Tag、失败原因等可选字段是否存在推断卡片能否展开", "State independence error check");
expectIncludes(workflow, "默认状态不做图片填充", "CardContent placeholder delivery check");
expectIncludes(workflow, "空状态是否调用 `<v9-empty>`", "Empty component delivery check");
expectIncludes(workflow, "正式 `<v9-card>` Content Slot承载", "Empty Card container delivery check");
expectIncludes(workflow, "空状态父容器是否只承担可用区域与居中对齐", "Empty parent sizing delivery check");
expectIncludes(workflow, "只有 PRD、Figma 或正式组件合同明确尺寸时才固定高度", "Empty fixed-height source guard");
expectIncludes(workflow, "validate-h5-page.mjs <H5项目目录>", "H5 page validator workflow");
expectExcludes(workflow, "先判定任务模式并写入 PageSpec", "Workflow must not force fixed PageSpec");
expectIncludes(workflow, "不强制填写固定PageSpec", "Local Edit needs no fixed PageSpec");
expectIncludes(workflow, "未提及的区域和维度保持基准不变", "Existing-page change boundary workflow");
expectIncludes(workflow, "允许修改维度只有 `Color`", "Color-only local-change guard");
expectIncludes(workflow, "references/h5-migration.md", "H5 compliance migration route");
expectIncludes(skill, "references/h5-migration.md", "H5 migration progressive-disclosure index");
expectIncludes(migration, "可编辑的既有H5 + 明确修改动作 + 指定范围整体符合9.0", "H5 migration semantic trigger");
expectIncludes(migration, "不是关键词正则", "H5 migration keyword guard");
expectIncludes(migration, "必须替换旧标签、私有DOM或外观模拟实现", "H5 migration formal-component replacement");
expectIncludes(migration, "迁移覆盖率", "H5 migration acceptance coverage");
expectIncludes(migration, "保持现有格式不变", "H5 migration format-preservation boundary");
expectIncludes(workflow, "不生成目标页面", "Undefined destination-page guard");
expectIncludes(workflow, "validate-incremental-page.mjs", "Existing-page screenshot validation workflow");
expectIncludes(skill, "validate-incremental-page.mjs", "Existing-page validator route");
expectIncludes(incrementalValidator, "allowedRegions", "Existing-page allowed-region manifest");
expectIncludes(incrementalValidator, "outsideChangedPixels", "Existing-page protected-pixel check");
expectIncludes(incrementalValidator, "only non-interlaced 8-bit RGB/RGBA PNG screenshots are supported", "Existing-page PNG input contract");
expectIncludes(skill, "HTML + ZIP 双附件（默认交付物）", "Default dual-attachment delivery route");
expectIncludes(workflow, "## 附件式 H5 交付", "H5 attachment delivery workflow");
expectIncludes(workflow, "预览并下载 HTML", "H5 attachment response format");
expectIncludes(deliverableBuilder, "Built self-contained HTML", "H5 deliverable build script");
expectIncludes(deliverableBuilder, "Resource escapes the H5 project directory", "H5 external-project dependency guard");
expectIncludes(deliverableBuilder, 'document.addEventListener("DOMContentLoaded"', "Deferred classic script execution preservation");
expectIncludes(deliverableValidator, "self-contained HTML and complete offline source ZIP verified", "H5 deliverable validation script");
expectIncludes(deliverableValidator, "Standalone HTML contains a local server or absolute file URL", "H5 localhost/file guard");
expectIncludes(pageValidator, 'data-v9-preview="multi-state"', "H5 page multi-state preview declaration guard");
expectIncludes(pageValidator, "at least two [data-preview-route] entries", "H5 page preview-route guard");
expectIncludes(deliverableValidator, "Multi-state standalone HTML is missing [data-v9-preview-controls]", "H5 deliverable preview-controls guard");
expectIncludes(workflow, "### 多状态预览控制器", "Multi-state preview workflow");
expectIncludes(workflow, "naturalWidth>0", "Empty rendered asset delivery check");
expectIncludes(pageValidator, "Manual empty-state replacement found", "H5 page manual-empty guard");
expectIncludes(pageValidator, "Empty-state copy exists, but the page does not call <v9-empty>", "H5 page component-call guard");
expectIncludes(pageValidator, "assets/components/empty/illustration.svg", "H5 page Empty asset guard");
expectIncludes(pageValidator, "obsolete split asset found", "H5 page Empty split-asset rejection");
expectIncludes(maintenanceWorkflow, "不得为完成脚本而把源组件永久替换成回退字体", "Source component font preservation workflow");

for (const doc of [
  [skill, "v9-components.js", "SKILL.md"],
  [workflow, "<v9-card>", "workflow.md"],
  [figmaMap, "<v9-appbar>", "v9-figma-map.md"],
  [skill, "页面本地组合", "SKILL.md"],
  [workflow, "页面本地组合", "workflow.md"],
  [workflow, "才允许手动创建并", "workflow.md"],
  [figmaMap, "H5 组件身份审计", "v9-figma-map.md"],
]) {
  expectIncludes(doc[0], doc[1], doc[2]);
}

await import("./test-card-slot-visibility.mjs");

console.log(
  `H5 runtime validation passed: ${registryNames.length} elements, ` +
  `${expectedCounts.component} formal two-sided components.`,
);
