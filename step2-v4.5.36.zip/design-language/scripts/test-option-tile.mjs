// Usage: V9_PLAYWRIGHT_MODULE=/absolute/path/to/playwright node scripts/test-option-tile.mjs
// Optional V9_CHROME_PATH and V9_QA_SCREENSHOT. Never changes Figma or Skill assets.
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFileSync, existsSync } from "node:fs";
import { dirname, resolve, extname } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.V9_PLAYWRIGHT_MODULE || "playwright");
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const states = ["unselected", "selected", "warning"];
const item = (state, content = "title") => `<v9-option-tile style="width:156px" state="${state}" content="${content}" label="选项标题" description="副标题说明内容，可根据实际信息换行"></v9-option-tile>`;
const html = `<!doctype html><meta charset="utf-8"><link rel="stylesheet" href="/assets/v9-core.css">
<style>body{font-family:'PingFang SC',sans-serif;background:#f0f1f5;margin:24px}.matrix{display:flex;gap:24px;margin:20px 0}article{padding:16px;background:white;border-radius:16px;width:319px;margin:20px 0}v9-option-tile{min-width:0}h1{font-size:22px}</style>
<h1>Option Tile · Runtime QA</h1><div id="title" class="matrix">${states.map(s => item(s)).join("")}</div>
<div id="description" class="matrix">${states.map(s => item(s,"description")).join("")}</div>
<article><v9-option-group id="group" columns="3" content="description" aria-label="测试多选">
<v9-option-tile value="a" state="selected" label="允许多行的选项标题" description="副标题补充说明，支持多行"></v9-option-tile>
<v9-option-tile value="b" label="选项标题" description="副标题补充说明，支持多行"></v9-option-tile>
<v9-option-tile value="c" state="warning" label="警示" description="警示说明"></v9-option-tile>
</v9-option-group></article>
<article><v9-warning-count id="count" label="绕路" count="2"></v9-warning-count></article>
<script type="module">import {V9_COMPONENTS} from '/assets/v9-components.js';window.registry=V9_COMPONENTS;window.ready=true;</script>`;
const server = createServer((req,res)=>{
  const url = new URL(req.url,"http://localhost");
  if(url.pathname==="/"){res.setHeader("Content-Type","text/html; charset=utf-8");res.end(html);return;}
  const path=resolve(root,"."+url.pathname);
  if(!path.startsWith(root+"/")||!existsSync(path)){res.writeHead(404);res.end();return;}
  res.setHeader("Content-Type",({".js":"text/javascript",".css":"text/css",".svg":"image/svg+xml"})[extname(path)]||"application/octet-stream");
  res.end(readFileSync(path));
});
await new Promise(r=>server.listen(0,"127.0.0.1",r));
let browser;
try {
  const chrome=process.env.V9_CHROME_PATH||"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
  browser=await chromium.launch({headless:true,...(existsSync(chrome)?{executablePath:chrome}:{})});
  const page=await browser.newPage({viewport:{width:800,height:1000}});
  const errors=[];page.on("pageerror",e=>errors.push(e.message));
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  await page.waitForFunction(()=>window.ready);
  await page.evaluate(()=>document.fonts.ready);
  await page.waitForFunction(()=>document.querySelector('#title v9-option-tile').getBoundingClientRect().height===45);
  const metrics=await page.evaluate(()=>{
    const all=s=>[...document.querySelectorAll(s)];
    return {title:all('#title v9-option-tile').map(e=>e.getBoundingClientRect().height),
      description:all('#description v9-option-tile').map(e=>e.getBoundingClientRect().height),
      row:all('#group v9-option-tile').map(e=>e.getBoundingClientRect().height),
      line:getComputedStyle(document.querySelector('#group v9-option-tile').shadowRoot.querySelector('.v9-option-tile__title')).lineHeight};
  });
  assert.deepEqual(metrics.title,[45,45,45]);assert.deepEqual(metrics.description,[78,78,78]);
  assert.equal(new Set(metrics.row).size,1);assert.equal(metrics.line,'18px');
  await page.evaluate(()=>{window.events=[];document.querySelector('#group').addEventListener('v9-change',e=>events.push(e.detail));});
  const opts=page.locator('#group v9-option-tile');
  await opts.nth(1).locator('button').click();
  assert.deepEqual(await page.evaluate(()=>document.querySelector('#group').values),['a','b']);
  assert.equal(await page.evaluate(()=>events.length),1);
  await opts.nth(1).locator('button').press('Space');
  assert.deepEqual(await page.evaluate(()=>document.querySelector('#group').values),['a']);
  assert.equal(await page.evaluate(()=>document.querySelectorAll('#group v9-option-tile')[1].shadowRoot.activeElement?.tagName),'BUTTON');
  await opts.nth(2).locator('[role=note]').click();
  assert.equal(await page.evaluate(()=>events.length),2);
  assert.equal(await opts.nth(2).locator('button').count(),0);
  await page.evaluate(()=>{const b=document.querySelectorAll('#group v9-option-tile')[1];b.setAttribute('state','selected');b.setAttribute('state','warning');});
  assert.deepEqual(await page.evaluate(()=>document.querySelector('#group').values),['a']);
  assert.equal(await opts.nth(1).locator('[aria-pressed]').count(),0);
  assert.equal(await page.evaluate(()=>events.length),2);
  for(const [content,requested,effective,gap] of [['title','1','2','8px'],['title','5','5','4px'],['description','5','3','8px'],['description','abc','2','8px']]){
    await page.evaluate(({content,requested})=>{const g=document.querySelector('#group');g.setAttribute('content',content);g.setAttribute('columns',requested);},{content,requested});
    assert.equal(await page.locator('#group [data-columns]').getAttribute('data-columns'),effective);
    assert.equal(await page.locator('#group slot').evaluate(e=>getComputedStyle(e).gap),gap);
  }
  await page.evaluate(()=>{const g=document.querySelector('#group');g.setAttribute('content','description');g.setAttribute('columns','3');g.children[0].setAttribute('description','这是很长的说明文字'.repeat(15));});
  const tall=await opts.evaluateAll(es=>es.map(e=>e.getBoundingClientRect().height));
  assert(tall[0]>104);assert.equal(new Set(tall).size,1);
  await page.evaluate(()=>{const g=document.querySelector('#group');g.children[0].setAttribute('label','短标题');[...g.children].forEach(e=>e.setAttribute('description','短说明'));});
  await page.waitForFunction(()=>document.querySelector('#group v9-option-tile').getBoundingClientRect().height===62);
  await page.evaluate(()=>{const e=document.querySelector('#title v9-option-tile');e.setAttribute('label','很长的选项文字'.repeat(12));});
  assert.equal(await page.locator('#title v9-option-tile').first().evaluate(e=>e.getBoundingClientRect().height),45);
  assert.equal(await page.locator('#title .v9-option-tile__title').first().evaluate(e=>getComputedStyle(e).textOverflow),'ellipsis');
  await page.evaluate(()=>document.querySelector('#count').setAttribute('count','0'));
  assert.equal(await page.locator('#count .v9-warning-count__value').textContent(),'0');
  await page.evaluate(()=>document.querySelector('#count').setAttribute('label','<img src=x onerror=alert(1)>'));
  assert.equal(await page.locator('#count img').count(),0);
  await page.reload();await page.waitForFunction(()=>window.ready);await page.evaluate(()=>document.fonts.ready);
  if(process.env.V9_QA_SCREENSHOT)await page.screenshot({path:process.env.V9_QA_SCREENSHOT,fullPage:true});
  assert.deepEqual(errors,[]);
  console.log('Option Tile PASS: 6 states, source geometry, multi-select/events, keyboard/focus, inert Warning, legal columns/gaps, grow/shrink/equal-height, ellipsis, escaping and count updates.');
} finally { await browser?.close();await new Promise(r=>server.close(r)); }
