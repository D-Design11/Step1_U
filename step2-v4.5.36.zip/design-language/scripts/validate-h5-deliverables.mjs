#!/usr/bin/env node

import { existsSync, readFileSync, statSync } from "node:fs";
import { basename, extname, resolve } from "node:path";

const [htmlArg, zipArg] = process.argv.slice(2);
if (!htmlArg || !zipArg) {
  console.error("Usage: node scripts/validate-h5-deliverables.mjs <standalone-html> <source-zip>");
  process.exit(1);
}

const htmlPath = resolve(htmlArg);
const zipPath = resolve(zipArg);
const failures = [];

for (const [path, extension, label] of [
  [htmlPath, ".html", "Standalone HTML"],
  [zipPath, ".zip", "Source ZIP"],
]) {
  if (!existsSync(path) || !statSync(path).isFile()) failures.push(`${label} not found: ${path}`);
  else if (extname(path).toLowerCase() !== extension) failures.push(`${label} must use ${extension}: ${path}`);
}

const listZipEntries = (buffer) => {
  let endOffset = -1;
  for (let offset = buffer.length - 22; offset >= Math.max(0, buffer.length - 65557); offset -= 1) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) {
      endOffset = offset;
      break;
    }
  }
  if (endOffset < 0) throw new Error("ZIP end-of-central-directory record not found");
  const count = buffer.readUInt16LE(endOffset + 10);
  let offset = buffer.readUInt32LE(endOffset + 16);
  const entries = [];
  for (let index = 0; index < count; index += 1) {
    if (buffer.readUInt32LE(offset) !== 0x02014b50) throw new Error("Invalid ZIP central directory");
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    entries.push(buffer.subarray(offset + 46, offset + 46 + nameLength).toString("utf8"));
    offset += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
};

if (failures.length === 0) {
  const html = readFileSync(htmlPath, "utf8");
  const slug = basename(htmlPath, extname(htmlPath));
  const styleSources = [...html.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)]
    .map((match) => match[1])
    .join("\n");
  const stripped = html
    .replace(/<script\b(?![^>]*\bsrc\s*=)[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, "");

  if (!/<meta\s+name=["']v9-deliverable["']\s+content=["']self-contained["']/i.test(html)) {
    failures.push("Standalone HTML is missing the v9 self-contained marker.");
  }
  if (/<script\b[^>]*\bsrc\s*=/i.test(stripped)) failures.push("Standalone HTML still contains an external script src.");
  if (/<link\b[^>]*\brel=["'][^"']*stylesheet[^"']*["'][^>]*\bhref\s*=/i.test(stripped)) {
    failures.push("Standalone HTML still contains a linked stylesheet.");
  }
  if (/\b(?:127\.0\.0\.1|localhost)\b|file:\/\/\//i.test(html)) {
    failures.push("Standalone HTML contains a local server or absolute file URL.");
  }
  if (!/<v9-[a-z0-9-]+(?:\s|>)/i.test(html)) failures.push("Standalone HTML does not call any <v9-*> component.");
  if (!/customElements\.define\(/.test(html)) failures.push("Standalone HTML does not contain the V9 component runtime.");
  if (!/const coreHref\s*=\s*["']data:text\/css;base64,/i.test(html)) {
    failures.push("Standalone HTML does not embed the Shadow DOM core stylesheet.");
  }

  const declaresMultiStatePreview = /data-v9-preview\s*=\s*["']multi-state["']/i.test(html);
  const hasPreviewControls = /data-v9-preview-controls(?:\s|=|>)/i.test(html);
  const previewRouteMatches = html.match(/data-preview-route(?:\s|=|:)/gi) || [];
  if (declaresMultiStatePreview && !hasPreviewControls) {
    failures.push("Multi-state standalone HTML is missing [data-v9-preview-controls].");
  }
  if (declaresMultiStatePreview && previewRouteMatches.length < 2) {
    failures.push("Multi-state standalone HTML must expose at least two [data-preview-route] entries.");
  }
  if (hasPreviewControls && !declaresMultiStatePreview) {
    failures.push('Standalone HTML has preview controls but lacks data-v9-preview="multi-state".');
  }

  for (const match of stripped.matchAll(/<(?:img|source|video|audio|track|input|iframe)\b[^>]*\b(?:src|poster)\s*=\s*["']([^"']+)["']/gi)) {
    if (!/^(?:data:|blob:|#|about:)/i.test(match[1])) failures.push(`Standalone HTML contains a non-embedded resource: ${match[1]}`);
  }
  for (const match of styleSources.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/gi)) {
    if (!/^(?:data:|blob:|#)/i.test(match[1].trim())) failures.push(`Standalone HTML contains a non-embedded CSS resource: ${match[1]}`);
  }

  try {
    const entries = listZipEntries(readFileSync(zipPath));
    const required = [
      `${slug}/${slug}.html`,
      "/source/assets/v9-core.css",
      "/source/assets/v9-components.js",
      "/source/assets/v9-tokens.css",
    ];
    if (basename(zipPath, extname(zipPath)) !== slug) failures.push("HTML and ZIP base names must match.");
    if (!entries.includes(required[0])) failures.push(`Source ZIP is missing ${required[0]}.`);
    for (const suffix of required.slice(1)) {
      if (!entries.some((entry) => entry.endsWith(suffix))) failures.push(`Source ZIP is missing *${suffix}.`);
    }
    if (!entries.some((entry) => entry.includes("/source/assets/components/"))) {
      failures.push("Source ZIP is missing the offline component asset directory.");
    }
    if (entries.some((entry) => entry.endsWith(".DS_Store") || entry.includes("/node_modules/") || entry.includes("/.git/"))) {
      failures.push("Source ZIP contains ignored development files.");
    }
  } catch (error) {
    failures.push(`Source ZIP cannot be read: ${error.message}`);
  }
}

if (failures.length > 0) {
  console.error(failures.map((message) => `- ${message}`).join("\n"));
  process.exit(1);
}

console.log("H5 deliverable validation passed: self-contained HTML and complete offline source ZIP verified.");
