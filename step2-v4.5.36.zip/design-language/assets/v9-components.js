/**
 * 9.0 设计规范 — 可直接调用的 H5 Web Components
 *
 * 使用方式：
 *   <link rel="stylesheet" href="assets/v9-core.css">
 *   <script type="module" src="assets/v9-components.js"></script>
 *
 * 页面只传属性、文案和命名 Slot；组件内部 DOM、SVG、状态与对齐关系由本运行时维护。
 */

const coreURL = new URL("./v9-core.css", import.meta.url);
coreURL.search = new URL(import.meta.url).search;
const coreHref = coreURL.href;
const assetHref = (path) => new URL(path, import.meta.url).href;

const escapeHTML = (value = "") =>
  String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

const safeURL = (value = "") => {
  const url = String(value).trim();
  if (/^javascript:/i.test(url)) return "#";
  return escapeHTML(url);
};

const normalize = (value, values, fallback) => {
  const candidate = String(value || "").toLowerCase();
  return values.includes(candidate) ? candidate : fallback;
};

const containsChinese = (value = "") => /\p{Script=Han}/u.test(String(value));

const isTrue = (element, name, fallback = false) => {
  if (!element.hasAttribute(name)) return fallback;
  return element.getAttribute(name) !== "false";
};

class V9Element extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    this.render();
  }

  attributeChangedCallback() {
    if (this.isConnected) this.render();
  }

  disconnectedCallback() {
    this._adaptiveLineHeightObserver?.disconnect();
    if (this._adaptiveLineHeightFrame) cancelAnimationFrame(this._adaptiveLineHeightFrame);
  }

  mount(content, hostStyle = ":host{display:inline-block;}") {
    this._adaptiveLineHeightObserver?.disconnect();
    if (this._adaptiveLineHeightFrame) cancelAnimationFrame(this._adaptiveLineHeightFrame);
    this.shadowRoot.innerHTML = `
      <link rel="stylesheet" href="${coreHref}">
      <style>${hostStyle}</style>
      ${content}
    `;
    this.syncAdaptiveLineHeights();
  }

  syncAdaptiveLineHeights() {
    const elements = [...this.shadowRoot.querySelectorAll(".v9-adaptive-line-height")];
    if (!elements.length) return;
    const sync = () => {
      elements.forEach((element) => {
        const range = document.createRange();
        range.selectNodeContents(element);
        const lineTops = new Set(
          [...range.getClientRects()]
            .filter((rect) => rect.width > 0 && rect.height > 0)
            .map((rect) => Math.round(rect.top * 2) / 2),
        );
        element.classList.toggle("is-multiline", lineTops.size > 1);
      });
      this.onAdaptiveLineHeightSync?.(elements);
    };
    this._adaptiveLineHeightFrame = requestAnimationFrame(sync);
    if (typeof ResizeObserver !== "undefined") {
      this._adaptiveLineHeightObserver = new ResizeObserver(sync);
      elements.forEach((element) => this._adaptiveLineHeightObserver.observe(element));
    }
  }
}

class V9BackgroundFocus extends V9Element {
  render() {
    const atmosphere = assetHref("components/background-focus/atmosphere.svg");
    this.mount(
      `<span class="v9-background-focus" aria-hidden="true">
        <span class="v9-background-focus__base"></span>
        <img class="v9-background-focus__atmosphere" src="${atmosphere}" alt="">
      </span>`,
      ":host{display:block;width:100%;height:370px;line-height:0;pointer-events:none;}",
    );
  }
}

class V9Arrow extends V9Element {
  static observedAttributes = ["size", "color", "icon"];

  render() {
    const size = normalize(this.getAttribute("size"), ["l", "m", "s"], "s");
    const color = normalize(this.getAttribute("color"), ["grey", "white", "orange", "red"], "grey");
    const icon = normalize(this.getAttribute("icon"), ["arrow", "down", "up", "close"], "arrow");
    this.mount(
      `<span class="v9-arrow v9-arrow--${size} v9-arrow--${color} v9-arrow--${icon}" aria-hidden="true"></span>`,
    );
  }
}

class V9Button extends V9Element {
  static observedAttributes = ["variant", "state", "size", "disabled", "type", "aria-label"];

  render() {
    const size = normalize(this.getAttribute("size"), ["full", "large", "medium", "small"], "large");
    const requestedVariant = normalize(this.getAttribute("variant"), ["primary", "subtle", "weak"], "primary");
    const variant = size === "full" && requestedVariant === "weak" ? "primary" : requestedVariant;
    const state = normalize(this.getAttribute("state"), ["default", "visited", "disabled"], "default");
    const disabled = state === "disabled" || this.hasAttribute("disabled");
    const aria = this.getAttribute("aria-label");
    this.mount(
      `<button class="v9-btn v9-btn--${variant} v9-btn--${size}${state !== "default" ? ` is-${state}` : ""}"
        type="${escapeHTML(this.getAttribute("type") || "button")}"
        ${disabled ? "disabled" : ""}
        ${aria ? `aria-label="${escapeHTML(aria)}"` : ""}><slot></slot></button>`,
      `:host{display:${size === "full" ? "block" : "inline-block"};min-width:0;${size === "full" ? "width:100%;" : ""}}
       button{font:inherit;}${size === "full" ? ".v9-btn{width:100%;}" : ""}`,
    );
  }
}

class V9ActionGroup extends V9Element {
  static observedAttributes = ["layout"];

  render() {
    const layout = normalize(this.getAttribute("layout"), ["primary", "stacked", "inline", "secondary"], "primary");
    this.mount(
      `<div class="v9-action-group v9-action-group--${layout}"><slot></slot></div>`,
      `:host{display:block;width:100%;min-width:0;}slot{display:contents;}
       ::slotted(v9-button){display:block;}
       .v9-action-group--primary ::slotted(v9-button),
       .v9-action-group--stacked ::slotted(v9-button){width:100%;}
       .v9-action-group--inline ::slotted(v9-button){flex:1 1 0;min-width:0;}
       .v9-action-group--secondary ::slotted(v9-button){width:162.5px;max-width:100%;}`,
    );
    const slot = this.shadowRoot.querySelector("slot");
    const sync = () => slot.assignedElements().forEach((button) => button.setAttribute("size", "full"));
    slot.addEventListener("slotchange", sync);
    sync();
  }
}

class V9Tag extends V9Element {
  static observedAttributes = ["variant", "status", "size"];

  render() {
    const variant = normalize(this.getAttribute("variant"), ["outline", "light", "solid"], "light");
    const status = normalize(this.getAttribute("status"), ["default", "success", "error", "tertiary"], "default");
    const size = normalize(this.getAttribute("size"), ["default", "s"], "default");
    this.mount(
      `<span class="v9-tag v9-tag--${variant} v9-tag--${size === "default" ? "default-size" : "s"} is-${status}"><slot></slot></span>`,
      ":host{display:inline-flex;line-height:0;vertical-align:middle;}",
    );
  }
}

class V9Badge extends V9Element {
  static observedAttributes = ["type", "label"];

  render() {
    const type = normalize(this.getAttribute("type"), ["count", "overflow", "dot", "label-new"], "count");
    const fixed = type === "overflow" ? "99+" : type === "label-new" ? "新" : "";
    const label = type === "dot" ? "" : (this.getAttribute("label") || fixed);
    this.mount(
      `<span class="v9-badge v9-badge--${type}" ${type === "dot" ? 'aria-label="有新内容"' : ""}>${escapeHTML(label)}</span>`,
      ":host{display:inline-flex;line-height:0;vertical-align:top;}",
    );
  }
}

class V9SelectionControl extends V9Element {
  static observedAttributes = ["type", "checked", "disabled", "aria-label"];

  render() {
    const type = normalize(this.getAttribute("type"), ["checkbox", "radio"], "checkbox");
    const checked = isTrue(this, "checked");
    const disabled = isTrue(this, "disabled");
    this.mount(
      `<button class="v9-selection-control v9-selection-control--${type}${checked ? " is-checked" : ""}${disabled ? " is-disabled" : ""}"
        type="button" role="${type}" aria-checked="${checked}" ${disabled ? "disabled" : ""}
        aria-label="${escapeHTML(this.getAttribute("aria-label") || (type === "radio" ? "单选" : "复选"))}"></button>`,
      ":host{display:inline-flex;width:18px;height:18px;line-height:0;vertical-align:middle;}",
    );
    this.shadowRoot.querySelector("button").addEventListener("click", () => {
      if (disabled) return;
      this.toggleAttribute("checked", type === "radio" ? true : !checked);
      this.dispatchEvent(new Event("change", { bubbles: true }));
    });
  }
}

class V9Agreement extends V9Element {
  static observedAttributes = ["state", "text", "href"];

  render() {
    const state = normalize(this.getAttribute("state"), ["detail", "checked", "unchecked"], "unchecked");
    const text = this.getAttribute("text") || (state === "detail" ? "查看协议名称详情" : "我已阅读《协议名称》");
    const href = safeURL(this.getAttribute("href") || "#");
    const control = state === "detail" ? "" :
      `<v9-selection-control type="checkbox" ${state === "checked" ? "checked" : ""} aria-label="${escapeHTML(text)}"></v9-selection-control>`;
    const parts = text.split(/(《[^》]+》)/u).filter(Boolean);
    const protocolCount = parts.filter((part) => /^《[^》]+》$/u.test(part)).length;
    const confirmation = protocolCount > 0
      ? `<span class="v9-agreement__copy${protocolCount > 1 ? " is-multi" : ""}">${parts.map((part) => /^《[^》]+》$/u.test(part)
        ? `<a class="v9-agreement__name" href="${href}">${escapeHTML(part)}</a>`
        : `<span class="v9-agreement__prefix">${escapeHTML(part)}</span>`).join("")}</span>`
      : `<a class="v9-agreement__text" href="${href}">${escapeHTML(text)}</a>`;
    const content = state === "detail"
      ? `<a class="v9-agreement__detail" href="${href}"><span class="v9-agreement__text">${escapeHTML(text)}</span><v9-arrow size="l" color="grey" icon="arrow"></v9-arrow></a>`
      : `${control}${confirmation}`;
    this.mount(
      `<span class="v9-agreement v9-agreement--${state}${protocolCount > 1 ? " v9-agreement--multi" : ""}">${content}</span>`,
      ":host{display:inline-block;}a{color:inherit;text-decoration:none;}",
    );
  }
}

class V9InfoIcon extends V9Element {
  static observedAttributes = ["size", "aria-label", "for"];

  render() {
    const size = normalize(this.getAttribute("size"), ["m", "s"], "m");
    const targetId = this.getAttribute("for");
    this.mount(`<button type="button" class="v9-info-icon v9-info-icon--${size}" aria-label="${escapeHTML(this.getAttribute("aria-label") || "查看说明")}" ${targetId ? `aria-controls="${escapeHTML(targetId)}"` : ""}></button>`);
    this.shadowRoot.querySelector("button").addEventListener("click", () => {
      if (targetId) {
        const target = this.getRootNode().getElementById?.(targetId) || document.getElementById(targetId);
        if (target?.localName === "v9-tooltip") {
          const next = target.getAttribute("open") === "true" ? "false" : "true";
          target.setAttribute("open", next);
          this.shadowRoot.querySelector("button").setAttribute("aria-expanded", next);
        }
      }
      this.dispatchEvent(new CustomEvent("v9-info", { bubbles: true, detail: { targetId } }));
    });
  }
}

class V9Tooltip extends V9Element {
  static observedAttributes = ["arrow", "text", "open"];

  render() {
    const arrow = normalize(this.getAttribute("arrow"), ["top-right", "top-left", "bottom-right", "bottom-left"], "top-left");
    const visible = !this.hasAttribute("open") || isTrue(this, "open");
    this.mount(
      `<span class="v9-tooltip v9-tooltip--${arrow}" role="tooltip" ${visible ? "" : "hidden"}>
        <span class="v9-tooltip__arrow" aria-hidden="true"></span>
        <span class="v9-tooltip__bubble v9-adaptive-line-height">${escapeHTML(this.getAttribute("text") || "")}<slot></slot></span>
      </span>`,
      ":host{display:inline-block;}:host([open='false']){display:none;}",
    );
  }
}

class V9Loading extends V9Element {
  static observedAttributes = ["type"];

  render() {
    const type = normalize(this.getAttribute("type"), ["normal", "pull-up", "pull-down"], "normal");
    const labels = { normal: "正在加载", "pull-up": "上滑刷新", "pull-down": "下拉刷新" };
    this.mount(`<span class="v9-loading v9-loading--${type}" role="status" aria-live="polite"><span class="v9-loading__icon" aria-hidden="true"></span>${labels[type]}</span>`);
  }
}

class V9QuantityStepper extends V9Element {
  static observedAttributes = ["state", "value", "min", "max"];

  render() {
    const min = Number(this.getAttribute("min") || 1);
    const max = Number(this.getAttribute("max") || 99);
    let value = Number(this.getAttribute("value") || 20);
    value = Math.max(min, Math.min(max, value));
    const state = value <= min ? "min" : value >= max ? "max" : "default";
    this.mount(
      `<span class="v9-quantity-stepper is-${state}" role="group" aria-label="数量">
        <button class="v9-quantity-stepper__button v9-quantity-stepper__minus" type="button" aria-label="减少数量" ${state === "min" ? "disabled" : ""}></button>
        <output class="v9-quantity-stepper__value" role="spinbutton" aria-live="polite"
          aria-valuemin="${min}" aria-valuemax="${max}" aria-valuenow="${value}">${value}</output>
        <button class="v9-quantity-stepper__button v9-quantity-stepper__plus" type="button" aria-label="增加数量" ${state === "max" ? "disabled" : ""}></button>
      </span>`,
    );
    const change = (next) => {
      this.setAttribute("value", String(Math.max(min, Math.min(max, next))));
      this.dispatchEvent(new Event("change", { bubbles: true }));
    };
    this.shadowRoot.querySelector(".v9-quantity-stepper__minus").addEventListener("click", () => change(value - 1));
    this.shadowRoot.querySelector(".v9-quantity-stepper__plus").addEventListener("click", () => change(value + 1));
  }
}

class V9Alert extends V9Element {
  static observedAttributes = [
    "variant", "mode", "action", "size", "position", "text", "href",
    "show-icon", "show-button", "aria-label",
  ];

  render() {
    const variant = normalize(this.getAttribute("variant"), ["info", "warning"], "info");
    const mode = normalize(this.getAttribute("mode"), ["standard", "contained"], "contained");
    const size = normalize(this.getAttribute("size"), ["default", "small"], "default");
    const position = normalize(this.getAttribute("position"), ["top", "default"], size === "small" ? "default" : "top");
    const href = this.getAttribute("href");
    const action = normalize(
      this.getAttribute("action"),
      ["link", "pure"],
      href ? "link" : "pure",
    );
    const showIcon = isTrue(this, "show-icon", size === "default" || action === "link");
    const showButton = isTrue(this, "show-button", action === "link" && size === "default");
    const actionControl = showButton
      ? (href
          ? `<a class="v9-alert__arrow" href="${safeURL(href)}" aria-label="${escapeHTML(this.getAttribute("aria-label") || "查看详情")}"></a>`
          : `<button class="v9-alert__arrow" type="button" aria-label="${escapeHTML(this.getAttribute("aria-label") || "查看详情")}"></button>`)
      : "";
    this.mount(
      `<div class="v9-alert v9-alert--${variant} v9-alert--${mode} v9-alert--${action} v9-alert--${size} v9-alert--${position}" role="${variant === "warning" ? "alert" : "status"}">
        ${showIcon ? `<span class="v9-alert__icon" aria-hidden="true"></span>` : ""}
        <span class="v9-alert__text v9-adaptive-line-height">${escapeHTML(this.getAttribute("text") || "")}<slot></slot></span>
        ${actionControl}
      </div>`,
      ":host{display:block;width:100%;}a,button{display:inline-flex;}button{appearance:none;border:0;background:transparent;padding:0;}",
    );
    this.shadowRoot.querySelector("button.v9-alert__arrow")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("v9-action", { bubbles: true, detail: { action } }));
    });
  }
}

class V9Number extends V9Element {
  static observedAttributes = ["size", "prefix", "integer", "decimal", "unit"];

  render() {
    const size = normalize(this.getAttribute("size"), ["xl", "l", "m", "s"], "xl");
    const prefix = this.getAttribute("prefix");
    const decimal = this.getAttribute("decimal");
    const unit = this.getAttribute("unit");
    this.mount(
      `<span class="v9-number v9-number--${size}">
        ${prefix != null ? `<span class="v9-number__affix">${escapeHTML(prefix)}</span>` : ""}
        <span class="v9-number__value"><span class="v9-number__integer">${escapeHTML(this.getAttribute("integer") || "0")}</span>${decimal != null ? `<span class="v9-number__decimal">${escapeHTML(decimal)}</span>` : ""}</span>
        ${unit != null ? `<span class="v9-number__unit">${escapeHTML(unit)}</span>` : ""}
      </span>`,
    );
  }
}

class V9MetricItem extends V9Element {
  static observedAttributes = [
    "label", "size", "trend", "trend-value", "value-type", "prefix",
    "integer", "decimal", "unit", "english-value", "compact",
  ];

  render() {
    const size = normalize(this.getAttribute("size"), ["xl", "l", "m", "s"], "xl");
    const trend = normalize(this.getAttribute("trend"), ["none", "up", "down"], "none");
    const valueType = normalize(this.getAttribute("value-type"), ["number", "english"], "number");
    const compact = this.hasAttribute("compact");
    const trendValue = this.getAttribute("trend-value") || "0.5";
    const hasTrend = trend !== "none" && !containsChinese(trendValue);
    const value = valueType === "english"
      ? `<div class="v9-metric-item__english">${escapeHTML(this.getAttribute("english-value") || "")}</div>`
      : `<span class="v9-number v9-number--${size}">
          ${this.hasAttribute("prefix") ? `<span class="v9-number__affix">${escapeHTML(this.getAttribute("prefix"))}</span>` : ""}
          <span class="v9-number__value">
            <span class="v9-number__integer">${escapeHTML(this.getAttribute("integer") || "0")}</span>
            ${this.hasAttribute("decimal") ? `<span class="v9-number__decimal">${escapeHTML(this.getAttribute("decimal"))}</span>` : ""}
          </span>
          ${this.hasAttribute("unit") ? `<span class="v9-number__unit">${escapeHTML(this.getAttribute("unit"))}</span>` : ""}
        </span>`;
    const trendNode = !hasTrend ? "" :
      `<div class="v9-metric-item__trend">
        <span class="v9-metric-trend v9-metric-trend--${trend}">
          <span class="v9-metric-trend__icon" aria-hidden="true"></span>
          <span class="v9-metric-trend__value">${escapeHTML(trendValue)}</span>
        </span>
      </div>`;
    this.mount(
      `<div class="v9-metric-item${compact ? " is-compact" : ` v9-metric-item--${size}`}${hasTrend ? " v9-metric-item--has-trend" : ""}">
        <div class="v9-metric-item__content">
          <div class="v9-metric-item__label v9-adaptive-line-height">${escapeHTML(this.getAttribute("label") || "指标名称")}</div>
          ${value}
        </div>
        ${trendNode}
      </div>`,
      ":host{display:block;min-width:0;}",
    );
  }
}

class V9MetricGroup extends V9Element {
  static observedAttributes = ["count", "container", "size"];

  render() {
    const count = normalize(this.getAttribute("count"), ["1", "2", "3", "4"], "1");
    const container = normalize(this.getAttribute("container"), ["standalone", "embedded"], "standalone");
    this.mount(
      `<div class="v9-metric-group v9-metric-group--count-${count}${container === "embedded" ? " v9-metric-group--embedded" : ""}"><slot></slot></div>`,
      ":host{display:block;width:100%;}slot{display:contents;}::slotted(v9-metric-item){min-width:0;}",
    );
    const slot = this.shadowRoot.querySelector("slot");
    const sync = () => {
      const size = this.getAttribute("size");
      if (!size) return;
      slot.assignedElements().forEach((item) => item.setAttribute("size", size));
    };
    slot.addEventListener("slotchange", sync);
    sync();
  }
}

class V9MetricScroll extends V9Element {
  static observedAttributes = ["container"];

  render() {
    const container = normalize(this.getAttribute("container"), ["standalone", "embedded"], "standalone");
    this.mount(
      `<div class="v9-metric-scroll${container === "embedded" ? " v9-metric-scroll--embedded" : ""}"><slot></slot></div>`,
      `:host{display:block;width:100%;}slot{display:contents;}
       ::slotted(v9-metric-item){width:100px;box-sizing:border-box;flex:0 0 100px;
         padding:var(--v9-space-md);border-radius:var(--v9-radius-md);
         background:var(--v9-surface-inset);scroll-snap-align:start;}`,
    );
    const slot = this.shadowRoot.querySelector("slot");
    const sync = () => slot.assignedElements().forEach((item) => item.setAttribute("compact", ""));
    slot.addEventListener("slotchange", sync);
    sync();
  }
}

class V9Appbar extends V9Element {
  static observedAttributes = [
    "type", "title", "time", "show-back", "action-text", "action-href",
    "icon1", "icon2", "aria-label",
  ];

  render() {
    const type = normalize(
      this.getAttribute("type"),
      ["flat", "text", "none", "icon", "flat-white", "text-white", "none-white", "none-black"],
      "flat",
    );
    const white = type.includes("white");
    const transparent = white || type.endsWith("-black");
    const baseType = type.replace("-white", "").replace("-black", "");
    const defaultBack = ["flat", "text", "none", "icon"].includes(baseType);
    const showBack = isTrue(this, "show-back", defaultBack);
    const iconColor = white ? "white" : "black";
    const appClasses = [
      "v9-appbar",
      baseType === "flat" ? "v9-appbar--flat" : "",
      transparent ? "v9-appbar--transparent" : "",
      white ? "v9-appbar--white" : "",
    ].filter(Boolean).join(" ");
    const showTitle = baseType !== "none" && this.hasAttribute("title");
    const actionText = this.getAttribute("action-text");
    const status = `
      <div class="v9-statusbar v9-statusbar--${iconColor}">
        <span class="v9-statusbar__time">${escapeHTML(this.getAttribute("time") || "9:41")}</span>
        <span class="v9-statusbar__icons" aria-hidden="true">
          <img class="v9-statusbar__cellular" src="${assetHref(`components/appbar/cellular-${iconColor}.svg`)}" alt="">
          <img class="v9-statusbar__wifi" src="${assetHref(`components/appbar/wifi-${iconColor}.svg`)}" alt="">
          <img class="v9-statusbar__battery" src="${assetHref(`components/appbar/battery-${iconColor}.svg`)}" alt="">
        </span>
      </div>`;
    const back = showBack
      ? `<button class="v9-appbar__back" type="button" aria-label="${escapeHTML(this.getAttribute("aria-label") || "返回")}"><img src="${assetHref(`components/appbar/back-${iconColor}.svg`)}" alt=""></button>`
      : "";
    const action = baseType === "text" && actionText
      ? `<a class="v9-appbar__action" href="${safeURL(this.getAttribute("action-href") || "#")}">${escapeHTML(actionText)}</a>`
      : "";
    const icons = baseType === "icon"
      ? `<span class="v9-appbar__icons">
          ${isTrue(this, "icon1", true) ? `<button class="v9-appbar__icon-button" type="button" data-action="icon1" aria-label="操作一"><img src="${assetHref("components/appbar/action-1.svg")}" alt=""></button>` : ""}
          ${isTrue(this, "icon2", true) ? `<button class="v9-appbar__icon-button" type="button" data-action="icon2" aria-label="操作二"><img src="${assetHref("components/appbar/action-2.svg")}" alt=""></button>` : ""}
        </span>`
      : "";
    this.mount(
      `<header class="${appClasses}">
        ${status}
        <div class="v9-appbar__nav">
          ${back}
          ${showTitle ? `<div class="v9-appbar__title">${escapeHTML(this.getAttribute("title"))}</div>` : ""}
          ${action}${icons}
        </div>
      </header>`,
      ":host{display:block;width:375px;height:88px;}",
    );
    this.shadowRoot.querySelector(".v9-appbar__back")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("v9-back", { bubbles: true }));
    });
  }
}

class V9Back extends V9Element {
  static observedAttributes = ["theme", "aria-label"];

  render() {
    const theme = normalize(this.getAttribute("theme"), ["black", "white"], "black");
    this.mount(
      `<button class="v9-back" type="button" aria-label="${escapeHTML(this.getAttribute("aria-label") || "返回")}">
        <img src="${assetHref(`components/appbar/back-${theme}.svg`)}" alt="">
      </button>`,
      ":host{display:inline-block;width:40px;height:40px;}img{display:block;width:40px;height:40px;}",
    );
  }
}

class V9CardHeader extends V9Element {
  static observedAttributes = [
    "title", "subtitle", "action-type", "action-text", "action-href",
    "expand-state", "show-tag", "tag-text", "tag-status",
  ];

  render() {
    const actionType = normalize(this.getAttribute("action-type"), ["none", "link", "expand"], "none");
    const showSubtitle = this.hasAttribute("subtitle");
    const showTag = isTrue(this, "show-tag");
    const tag = showTag
      ? `<v9-tag variant="light" status="${escapeHTML(this.getAttribute("tag-status") || "default")}">${escapeHTML(this.getAttribute("tag-text") || "")}</v9-tag>`
      : "";
    const inlineTag = showTag && actionType !== "none" ? tag : "";
    let action = showTag && actionType === "none" ? tag : "";
    if (actionType === "link") {
      action = `<v9-textlink importance="secondary" size="m" href="${safeURL(this.getAttribute("action-href") || "#")}" icon="arrow">${escapeHTML(this.getAttribute("action-text") || "查看")}</v9-textlink>`;
    }
    if (actionType === "expand") {
      const state = normalize(this.getAttribute("expand-state"), ["expand", "collapsed"], "expand");
      const collapsed = state === "collapsed";
      action = `<button class="v9-cardheader__expand" type="button" aria-expanded="${collapsed}"><span class="v9-cardheader__expand-label">${escapeHTML(this.getAttribute("action-text") || (collapsed ? "收起" : "展开"))}</span><v9-arrow size="l" color="grey" icon="${collapsed ? "up" : "down"}"></v9-arrow></button>`;
    }
    this.mount(
      `<div class="v9-cardheader" data-actiontype="${actionType}" data-show-subtitle="${showSubtitle}">
        <div class="v9-cardheader__main">
          <div class="v9-cardheader__title-row"><div class="v9-cardheader__title v9-adaptive-line-height">${escapeHTML(this.getAttribute("title") || "卡片标题")}</div>${inlineTag}</div>
          ${showSubtitle ? `<div class="v9-cardheader__subtitle v9-adaptive-line-height">${escapeHTML(this.getAttribute("subtitle"))}</div>` : ""}
        </div>
        ${action}
      </div>`,
      `:host{display:block;width:100%;}.v9-cardheader__main{min-width:0;flex:1;}
       .v9-cardheader__title-row{display:flex;align-items:center;gap:var(--v9-space-sm);}
       v9-textlink{display:inline-flex;flex:none;}
       .v9-cardheader__expand v9-arrow{display:inline-flex;width:18px;height:18px;line-height:0;flex:none;}`,
    );
    const button = this.shadowRoot.querySelector(".v9-cardheader__expand");
    if (button) {
      button.addEventListener("click", () => {
        const next = this.getAttribute("expand-state") === "collapsed" ? "expand" : "collapsed";
        this.setAttribute("expand-state", next);
        this.dispatchEvent(new CustomEvent("v9-toggle", { bubbles: true, detail: { state: next } }));
      });
    }
  }
}

class V9Card extends V9Element {
  disconnectedCallback() {
    super.disconnectedCallback();
    this._slotVisibilityObserver?.disconnect();
  }

  render() {
    this._slotVisibilityObserver?.disconnect();
    this.mount(
      `<article class="v9-card">
        <div class="v9-card__header" data-region="header"><slot name="header"></slot></div>
        <div class="v9-card__content" data-region="content"><slot name="content"></slot></div>
        <div class="v9-card__footer" data-region="footer"><slot name="footer"></slot></div>
      </article>`,
      `:host{display:block;width:351px;}
       .v9-card__header:not([hidden])+.v9-card__content:not([hidden]){margin-top:var(--v9-space-md);}
       .v9-card__content:not([hidden])+.v9-card__footer:not([hidden]),
       .v9-card__header:not([hidden])~.v9-card__footer:not([hidden]){margin-top:var(--v9-space-lg);}
       [data-region][hidden]{display:none!important;}slot{display:contents;}`,
    );
    const sync = () => {
      this.shadowRoot.querySelectorAll("[data-region]").forEach((region) => {
        const slot = region.querySelector("slot");
        region.hidden = slot.assignedNodes({ flatten: true }).every((node) =>
          node.nodeType === Node.TEXT_NODE ? !node.textContent.trim() : node.hidden,
        );
      });
    };
    this.shadowRoot.querySelectorAll("slot").forEach((slot) => slot.addEventListener("slotchange", sync));
    this._slotVisibilityObserver = new MutationObserver((records) => {
      if (records.some((record) =>
        record.type === "attributes" && record.target.parentNode === this && record.attributeName === "hidden"
      )) sync();
    });
    this._slotVisibilityObserver.observe(this, {
      attributes: true,
      attributeFilter: ["hidden"],
      subtree: true,
    });
    sync();
  }
}

class V9FormItem extends V9Element {
  static observedAttributes = [
    "interaction", "content", "state", "checked", "label", "placeholder", "value",
    "show-info", "error-message", "aria-label",
  ];

  render() {
    const interaction = normalize(this.getAttribute("interaction"), ["input", "select", "radio", "checkbox"], "input");
    const textual = interaction === "input" || interaction === "select";
    const content = normalize(this.getAttribute("content"), ["empty", "filled"], "empty");
    const state = normalize(this.getAttribute("state"), ["default", "error", "disabled"], "default");
    const disabled = state === "disabled";
    const checked = isTrue(this, "checked", false);
    const showInfo = isTrue(this, "show-info", true);
    const label = this.getAttribute("label") || "字段名称";
    const placeholder = this.getAttribute("placeholder") || "请输入";
    const value = this.getAttribute("value") || "示例内容";
    const errorMessage = this.getAttribute("error-message") || "请检查填写内容";
    const visibleText = content === "filled" ? value : placeholder;
    const labelGroup = `<span class="v9-form-item__label-group">
      <span class="v9-form-item__label v9-adaptive-line-height">${escapeHTML(label)}</span>
      ${showInfo ? `<v9-info-icon size="m" aria-label="${escapeHTML(`${label}说明`)}"></v9-info-icon>` : ""}
    </span>`;
    let control = "";
    if (interaction === "input") {
      control = `<input class="v9-form-item__input${content === "empty" ? " is-placeholder" : ""}"
        type="text" value="${content === "filled" ? escapeHTML(value) : ""}" placeholder="${escapeHTML(placeholder)}"
        aria-label="${escapeHTML(this.getAttribute("aria-label") || label)}" aria-invalid="${state === "error"}"
        ${disabled ? "disabled" : ""}>`;
    } else if (interaction === "select") {
      control = `<button class="v9-form-item__select${content === "empty" ? " is-placeholder" : ""}" type="button"
        aria-label="${escapeHTML(this.getAttribute("aria-label") || label)}" aria-haspopup="listbox"
        aria-invalid="${state === "error"}" ${disabled ? "disabled" : ""}>
        <span class="v9-form-item__value v9-adaptive-line-height">${escapeHTML(visibleText)}</span>
        <v9-arrow size="l" color="grey" icon="arrow"></v9-arrow>
      </button>`;
    } else {
      control = `<v9-selection-control type="${interaction}" ${checked ? "checked" : ""} ${disabled ? "disabled" : ""}
        aria-label="${escapeHTML(this.getAttribute("aria-label") || label)}"></v9-selection-control>`;
    }
    const error = state === "error"
      ? `<div class="v9-form-item__error v9-adaptive-line-height" id="v9-form-item-error" role="alert">${escapeHTML(errorMessage)}</div>`
      : "";
    const kind = textual ? "textual" : "control";
    this.mount(
      `<div class="v9-form-item v9-form-item--${kind} v9-form-item--${interaction} is-${state}"
        data-content="${textual ? content : "not-applicable"}">
        <div class="v9-form-item__row">${labelGroup}${control}</div>
        ${error}
      </div>`,
      `:host{display:block;width:100%;min-width:0;}v9-info-icon{display:inline-flex;width:14px;height:14px;flex:none;}
       v9-arrow{display:inline-flex;width:18px;height:18px;flex:none;line-height:0;}
       v9-selection-control{display:inline-flex;width:18px;height:18px;flex:none;margin-left:auto;line-height:0;}`,
    );
    this.shadowRoot.querySelector("input")?.addEventListener("change", (event) => {
      const nextValue = event.currentTarget.value;
      this.setAttribute("value", nextValue);
      this.setAttribute("content", nextValue ? "filled" : "empty");
      this.dispatchEvent(new CustomEvent("v9-change", {
        bubbles: true,
        detail: { interaction, value: nextValue, content: nextValue ? "filled" : "empty" },
      }));
    });
    this.shadowRoot.querySelector(".v9-form-item__select")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("v9-select", {
        bubbles: true,
        detail: { value: content === "filled" ? value : "" },
      }));
    });
    this.shadowRoot.querySelector("v9-selection-control")?.addEventListener("change", (event) => {
      const nextChecked = event.currentTarget.hasAttribute("checked");
      this.toggleAttribute("checked", nextChecked);
      this.dispatchEvent(new CustomEvent("v9-change", {
        bubbles: true,
        detail: { interaction, checked: nextChecked },
      }));
    });
  }
}

class V9FormItemGroup extends V9Element {
  static observedAttributes = ["aria-label"];

  disconnectedCallback() {
    super.disconnectedCallback();
    this._formItemObserver?.disconnect();
    this.querySelectorAll(":scope > v9-form-item[data-v9-bottom-space]").forEach((item) => {
      item.removeAttribute("data-v9-bottom-space");
    });
  }

  syncContinuousErrorSpacing() {
    const items = [...this.children].filter((child) => child.localName === "v9-form-item");
    items.forEach((item, index) => {
      const currentIsError = normalize(item.getAttribute("state"), ["default", "error", "disabled"], "default") === "error";
      const next = items[index + 1];
      const nextIsError = next
        && normalize(next.getAttribute("state"), ["default", "error", "disabled"], "default") === "error";
      if (currentIsError && nextIsError) item.setAttribute("data-v9-bottom-space", "false");
      else item.removeAttribute("data-v9-bottom-space");
    });
  }

  render() {
    this._formItemObserver?.disconnect();
    this.mount(
      `<div class="v9-form-item-group" role="group" aria-label="${escapeHTML(this.getAttribute("aria-label") || "表单字段组")}"><slot></slot></div>`,
      `:host{display:block;width:100%;min-width:0;}slot{display:contents;}
       ::slotted(v9-form-item){display:block;width:100%;min-width:0;}`,
    );
    const sync = () => this.syncContinuousErrorSpacing();
    this.shadowRoot.querySelector("slot")?.addEventListener("slotchange", sync);
    if (typeof MutationObserver !== "undefined") {
      this._formItemObserver = new MutationObserver((records) => {
        records.forEach((record) => {
          record.removedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE && node.localName === "v9-form-item") {
              node.removeAttribute("data-v9-bottom-space");
            }
          });
        });
        sync();
      });
      this._formItemObserver.observe(this, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["state"],
      });
    }
    sync();
  }
}

class V9FormCard extends V9Element {
  static observedAttributes = [
    "header", "title", "subtitle", "action-type", "action-text", "action-href",
    "expand-state", "show-tag", "tag-text", "tag-status",
  ];

  render() {
    const showHeader = isTrue(this, "header", true);
    const subtitle = this.hasAttribute("subtitle")
      ? ` subtitle="${escapeHTML(this.getAttribute("subtitle"))}"`
      : "";
    const showTag = isTrue(this, "show-tag", false);
    const header = showHeader
      ? `<div class="v9-form-card__header"><v9-cardheader
          title="${escapeHTML(this.getAttribute("title") || "卡片标题")}"${subtitle}
          action-type="${escapeHTML(this.getAttribute("action-type") || "none")}"
          action-text="${escapeHTML(this.getAttribute("action-text") || "")}"
          action-href="${safeURL(this.getAttribute("action-href") || "#")}"
          expand-state="${escapeHTML(this.getAttribute("expand-state") || "expand")}"
          ${showTag ? "show-tag" : ""} tag-text="${escapeHTML(this.getAttribute("tag-text") || "")}"
          tag-status="${escapeHTML(this.getAttribute("tag-status") || "default")}"></v9-cardheader></div>`
      : "";
    this.mount(
      `<article class="v9-form-card" data-header="${showHeader}">${header}<slot></slot></article>`,
      `:host{display:block;width:351px;min-width:0;}slot{display:contents;}
       .v9-form-card__header v9-cardheader{display:block;width:100%;}
       ::slotted(v9-form-item-group){display:block;width:100%;min-width:0;}`,
    );
  }
}

class V9AddressGroup extends V9Element {
  static observedAttributes = ["size", "start-text", "end-text", "aria-label"];

  render() {
    const size = normalize(this.getAttribute("size"), ["default", "large"], "large");
    const startText = this.getAttribute("start-text") || "地址信息最多一行没有字数限制";
    const endText = this.getAttribute("end-text") || "金域华府二期东门唐家岭地址信息最多展示一行";
    this.mount(
      `<div class="v9-address-group v9-address-group--${size}" role="group"
        aria-label="${escapeHTML(this.getAttribute("aria-label") || "起点和终点地址")}">
        <div class="v9-address-group__row" aria-label="起点：${escapeHTML(startText)}">
          <span class="v9-address-group__marker v9-address-group__marker--start" aria-hidden="true"></span>
          <span class="v9-address-group__text" aria-hidden="true">${escapeHTML(startText)}</span>
        </div>
        <div class="v9-address-group__row" aria-label="终点：${escapeHTML(endText)}">
          <span class="v9-address-group__marker v9-address-group__marker--end" aria-hidden="true"></span>
          <span class="v9-address-group__text" aria-hidden="true">${escapeHTML(endText)}</span>
        </div>
      </div>`,
      ":host{display:block;width:100%;min-width:0;}",
    );
  }
}

class V9ListRow extends V9Element {
  static observedAttributes = ["label", "value"];

  render() {
    this.mount(`<div class="v9-list-row"><span class="v9-list-row__k v9-adaptive-line-height">${escapeHTML(this.getAttribute("label") || "")}</span><span class="v9-list-row__v v9-adaptive-line-height">${escapeHTML(this.getAttribute("value") || "")}</span></div>`, ":host{display:block;width:100%;}");
  }
}

class V9AccentCard extends V9Element {
  static observedAttributes = [
    "mode", "title", "description", "expiry", "show-description", "show-expiry",
    "show-decoration", "direction", "header-spacing", "aria-label",
  ];

  render() {
    const mode = normalize(this.getAttribute("mode"), ["single", "split", "grouped"], "single");
    const label = escapeHTML(this.getAttribute("aria-label") || this.getAttribute("title") || "橙色结构卡");
    let body;
    let slotStyle = "slot{display:contents;}";

    if (mode === "single") {
      const title = this.getAttribute("title") || "";
      const description = this.getAttribute("description") || "";
      const expiry = this.getAttribute("expiry") || "";
      const showDescription = isTrue(this, "show-description", Boolean(description));
      const showExpiry = isTrue(this, "show-expiry", Boolean(expiry));
      const showDecoration = isTrue(this, "show-decoration", true);
      body = `<div class="v9-accent-card v9-accent-card--single" role="group" aria-label="${label}">
        ${showDecoration ? '<span class="v9-accent-card__decoration" aria-hidden="true"></span>' : ""}
        <div class="v9-accent-card__main"><slot name="main-information">
          <span class="v9-accent-card__title v9-adaptive-line-height">${escapeHTML(title)}</span>
          ${showDescription ? `<span class="v9-accent-card__description v9-adaptive-line-height">${escapeHTML(description)}</span>` : ""}
        </slot></div>
        ${showExpiry ? `<div class="v9-accent-card__expiry">
          <span class="v9-accent-card__rule" aria-hidden="true"></span>
          <span class="v9-accent-card__expiry-text v9-adaptive-line-height">${escapeHTML(expiry)}</span>
        </div>` : ""}
      </div>`;
    } else if (mode === "split") {
      body = `<div class="v9-accent-card v9-accent-card--split" role="group" aria-label="${label}">
        <div class="v9-accent-card__orange-context"><slot name="orange-context"></slot></div>
        <div class="v9-accent-card__white-content"><slot name="white-content"></slot></div>
      </div>`;
    } else {
      const direction = normalize(this.getAttribute("direction"), ["vertical", "horizontal"], "vertical");
      const spacing = normalize(this.getAttribute("header-spacing"), ["comfortable", "compact"], "comfortable");
      body = `<div class="v9-accent-card v9-accent-card--grouped v9-accent-card--${direction} v9-accent-card--${spacing}"
        role="group" aria-label="${label}">
        <div class="v9-accent-card__header"><slot name="header">${escapeHTML(this.getAttribute("title") || "")}</slot></div>
        <div class="v9-accent-card__peers"><slot name="peer-item"></slot></div>
      </div>`;
      slotStyle += direction === "horizontal"
        ? '::slotted([slot="peer-item"]){display:block;flex:1 1 0;min-width:0;}'
        : '::slotted([slot="peer-item"]){display:block;width:100%;min-width:0;}';
    }
    this.mount(body, `:host{display:block;width:max-content;max-width:100%;min-width:0;} ${slotStyle}`);
  }
}

class V9EntryItem extends V9Element {
  static observedAttributes = [
    "orientation", "surface", "icon-size", "interaction", "show-description",
    "title", "description", "action-text", "href", "aria-label", "data-entry-group-layout",
  ];

  render() {
    const orientation = normalize(this.getAttribute("orientation"), ["horizontal", "vertical"], "horizontal");
    const surface = normalize(this.getAttribute("surface"), ["pure", "subtle"], "pure");
    const iconSize = normalize(this.getAttribute("icon-size"), ["30", "40", "50"], "30");
    const requestedInteraction = normalize(
      this.getAttribute("interaction"),
      ["whole-item", "trailing-button"],
      "whole-item",
    );
    const interaction = orientation === "vertical" ? "whole-item" : requestedInteraction;
    const groupedAsGrid = this.getAttribute("data-entry-group-layout") === "grid";
    const showDescription = !groupedAsGrid && isTrue(this, "show-description", true);
    const title = this.getAttribute("title") || "功能入口";
    const description = this.getAttribute("description") || "说明文案";
    const classes = [
      "v9-entry-item",
      `v9-entry-item--${orientation}`,
      `v9-entry-item--${surface}`,
      `v9-entry-item--icon-${iconSize}`,
      `v9-entry-item--${interaction}`,
      `v9-entry-item--description-${showDescription ? "true" : "false"}`,
    ].join(" ");
    const copy = `<span class="v9-entry-item__copy">
      <span class="v9-entry-item__title v9-adaptive-line-height">${escapeHTML(title)}</span>
      ${showDescription ? `<span class="v9-entry-item__description v9-adaptive-line-height">${escapeHTML(description)}</span>` : ""}
    </span>`;
    const content = `<span class="v9-entry-item__icon" aria-hidden="true">
        <slot name="icon"><span class="v9-entry-item__placeholder"></span></slot>
      </span>${copy}`;
    const ariaLabel = escapeHTML(this.getAttribute("aria-label") || title);
    const actionText = escapeHTML(this.getAttribute("action-text") || "去看看");
    const href = this.getAttribute("href");
    let body;
    if (interaction === "trailing-button") {
      body = `<div class="${classes}" role="group" aria-label="${ariaLabel}">
        ${content}
        <v9-button class="v9-entry-item__action" size="medium" variant="primary">${actionText}</v9-button>
      </div>`;
    } else if (href) {
      body = `<a class="${classes}" href="${safeURL(href)}" aria-label="${ariaLabel}">${content}</a>`;
    } else {
      body = `<button class="${classes}" type="button" aria-label="${ariaLabel}">${content}</button>`;
    }
    this.mount(
      body,
      `:host{display:block;width:100%;min-width:0;}slot[name="icon"]{display:contents;}
       ::slotted([slot="icon"]){display:block;width:100%;height:100%;max-width:100%;max-height:100%;object-fit:contain;}`,
    );
    const target = interaction === "trailing-button"
      ? this.shadowRoot.querySelector("v9-button")
      : this.shadowRoot.querySelector("a,button");
    target?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("v9-entry-activate", {
        bubbles: true,
        detail: { interaction },
      }));
    });
  }
}

class V9EntryGroup extends V9Element {
  static observedAttributes = ["layout", "count", "item-surface", "icon-size", "aria-label"];

  render() {
    const layout = normalize(
      this.getAttribute("layout"),
      ["list", "grid-2", "grid-3", "grid-4", "grid-5"],
      "list",
    );
    const requestedSurface = normalize(this.getAttribute("item-surface"), ["pure", "subtle"], "pure");
    const itemSurface = layout === "grid-2"
      ? "subtle"
      : ["grid-4", "grid-5"].includes(layout)
        ? "pure"
        : requestedSurface;
    const requestedIconSize = normalize(this.getAttribute("icon-size"), ["30", "40", "50"], "40");
    const iconSize = layout === "list"
      ? "40"
      : layout === "grid-5" || (layout === "grid-3" && itemSurface === "pure")
        ? "50"
        : requestedIconSize === "50"
          ? "40"
          : requestedIconSize;
    this.mount(
      `<div class="v9-entry-group v9-entry-group--${layout} v9-entry-group--surface-${itemSurface}"
        role="group" aria-label="${escapeHTML(this.getAttribute("aria-label") || "功能入口组")}">
        <slot></slot>
      </div>`,
      `:host{display:block;width:100%;min-width:0;}slot{display:contents;}
       ::slotted(v9-entry-item){display:block;width:100%;min-width:0;}`,
    );
    const slot = this.shadowRoot.querySelector("slot");
    const sync = () => {
      const isList = layout === "list";
      slot.assignedElements({ flatten: true })
        .filter((item) => item.localName === "v9-entry-item")
        .forEach((item) => {
          item.setAttribute("orientation", isList ? "horizontal" : "vertical");
          item.setAttribute("surface", itemSurface);
          item.setAttribute("icon-size", iconSize);
          item.setAttribute("interaction", "whole-item");
          item.setAttribute("show-description", isList ? "true" : "false");
          item.setAttribute("data-entry-group-layout", isList ? "list" : "grid");
        });
    };
    slot.addEventListener("slotchange", sync);
    sync();
  }
}

class V9PillOption extends V9Element {
  static observedAttributes = [
    "value", "label", "selected", "context", "show-icon", "aria-label",
    "data-v9-pill-role", "data-v9-pill-tabindex",
  ];

  render() {
    const selected = isTrue(this, "selected", false);
    const context = normalize(this.getAttribute("context"), ["default", "white"], "default");
    const showIcon = isTrue(this, "show-icon", true);
    const label = this.getAttribute("label") || "选中选项";
    const role = normalize(this.getAttribute("data-v9-pill-role"), ["button", "radio"], "button");
    const tabIndex = this.getAttribute("data-v9-pill-tabindex") ?? "0";
    const classes = [
      "v9-pill-option",
      `v9-pill-option--context-${context}`,
      showIcon ? "v9-pill-option--icon" : "v9-pill-option--text-only",
      selected ? "is-selected" : "is-unselected",
    ].join(" ");
    this.mount(
      `<button class="${classes}" type="button" role="${role}" tabindex="${escapeHTML(tabIndex)}"
        aria-label="${escapeHTML(this.getAttribute("aria-label") || label)}"
        ${role === "radio" ? `aria-checked="${selected}"` : ""}>
        ${showIcon ? `<span class="v9-pill-option__icon" aria-hidden="true">
          <slot name="icon"><span class="v9-pill-option__placeholder"></span></slot>
        </span>` : ""}
        <span class="v9-pill-option__label">${escapeHTML(label)}</span>
      </button>`,
      `:host{display:inline-flex;line-height:0;vertical-align:middle;}slot[name="icon"]{display:contents;}
       ::slotted([slot="icon"]){display:block;width:16px;height:16px;max-width:16px;max-height:16px;color:inherit;fill:currentColor;}`,
    );
    this.shadowRoot.querySelector("button")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("v9-pill-option-activate", {
        bubbles: true,
        composed: true,
        detail: {
          value: this.getAttribute("value") || label,
          selected,
        },
      }));
    });
  }

  focusControl() {
    this.shadowRoot?.querySelector("button")?.focus();
  }
}

class V9PillOptionGroup extends V9Element {
  static observedAttributes = ["interaction", "selection", "active", "aria-label"];

  connectedCallback() {
    this.onOptionActivate ||= (event) => this.handleOptionActivate(event);
    this.onGroupKeydown ||= (event) => this.handleKeydown(event);
    this.addEventListener("v9-pill-option-activate", this.onOptionActivate);
    this.addEventListener("keydown", this.onGroupKeydown);
    super.connectedCallback();
  }

  disconnectedCallback() {
    this.removeEventListener("v9-pill-option-activate", this.onOptionActivate);
    this.removeEventListener("keydown", this.onGroupKeydown);
    super.disconnectedCallback();
  }

  get interaction() {
    return normalize(this.getAttribute("interaction"), ["select", "action"], "select");
  }

  get selection() {
    return normalize(this.getAttribute("selection"), ["required", "optional"], "required");
  }

  options() {
    return [...this.children].filter((item) => item.localName === "v9-pill-option");
  }

  effectiveActive(count = this.options().length) {
    if (this.interaction === "action" || count === 0) return 0;
    const requested = Number.parseInt(this.getAttribute("active") || "", 10);
    if (this.selection === "optional") {
      return Number.isInteger(requested) && requested >= 0 && requested <= count ? requested : 0;
    }
    return Number.isInteger(requested) && requested >= 1 && requested <= count ? requested : 1;
  }

  syncOptions() {
    const options = this.options();
    const active = this.effectiveActive(options.length);
    const root = this.shadowRoot?.querySelector(".v9-pill-option-group");
    root?.classList.toggle("is-scrollable", options.length > 4);
    root?.setAttribute("data-scrollable", String(options.length > 4));
    options.forEach((option, index) => {
      const selected = this.interaction === "select" && active === index + 1;
      if (selected !== option.hasAttribute("selected")) option.toggleAttribute("selected", selected);
      const role = this.interaction === "select" ? "radio" : "button";
      if (option.getAttribute("data-v9-pill-role") !== role) option.setAttribute("data-v9-pill-role", role);
      const tabIndex = this.interaction === "action" || index + 1 === (active || 1) ? "0" : "-1";
      if (option.getAttribute("data-v9-pill-tabindex") !== tabIndex) {
        option.setAttribute("data-v9-pill-tabindex", tabIndex);
      }
    });
  }

  emitChange(active, option) {
    this.dispatchEvent(new CustomEvent("v9-change", {
      bubbles: true,
      composed: true,
      detail: { active, value: option?.getAttribute("value") || option?.getAttribute("label") || "" },
    }));
  }

  handleOptionActivate(event) {
    const options = this.options();
    const index = options.indexOf(event.target);
    if (index < 0) return;
    event.stopPropagation();
    const option = options[index];
    if (this.interaction === "action") {
      this.dispatchEvent(new CustomEvent("v9-action", {
        bubbles: true,
        composed: true,
        detail: { index: index + 1, value: option.getAttribute("value") || option.getAttribute("label") || "" },
      }));
      return;
    }
    const current = this.effectiveActive(options.length);
    if (this.selection === "required" && current === index + 1) return;
    const next = this.selection === "optional" && current === index + 1 ? 0 : index + 1;
    this.setAttribute("active", String(next));
    this.emitChange(next, next === 0 ? null : option);
  }

  handleKeydown(event) {
    if (this.interaction !== "select" || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    const options = this.options();
    if (!options.length) return;
    const currentIndex = Math.max(0, options.indexOf(event.target));
    let nextIndex = currentIndex;
    if (event.key === "ArrowLeft") nextIndex = (currentIndex - 1 + options.length) % options.length;
    if (event.key === "ArrowRight") nextIndex = (currentIndex + 1) % options.length;
    if (event.key === "Home") nextIndex = 0;
    if (event.key === "End") nextIndex = options.length - 1;
    event.preventDefault();
    const active = nextIndex + 1;
    this.setAttribute("active", String(active));
    this.emitChange(active, options[nextIndex]);
    queueMicrotask(() => options[nextIndex]?.focusControl());
  }

  render() {
    const interaction = this.interaction;
    this.mount(
      `<div class="v9-pill-option-group v9-pill-option-group--${interaction}"
        role="${interaction === "select" ? "radiogroup" : "group"}"
        aria-label="${escapeHTML(this.getAttribute("aria-label") || (interaction === "select" ? "胶囊单选项" : "快捷操作"))}">
        <slot></slot>
      </div>`,
      `:host{display:block;width:351px;max-width:100%;min-width:0;}slot{display:flex;gap:8px;flex-wrap:nowrap;white-space:nowrap;}
       ::slotted(v9-pill-option){display:inline-flex;flex:0 0 auto;}`,
    );
    const slot = this.shadowRoot.querySelector("slot");
    slot.addEventListener("slotchange", () => this.syncOptions());
    this.syncOptions();
  }
}

// Option Tile: published source and cross-file import verified 2026-11-04.
class V9OptionTile extends V9Element {
  static observedAttributes = ["content", "state", "label", "description", "value", "aria-label"];

  get state() {
    return normalize(this.getAttribute("state"), ["unselected", "selected", "warning"], "unselected");
  }

  get value() {
    return this.getAttribute("value") ?? this.getAttribute("label") ?? "";
  }

  render() {
    const focused = !!this.shadowRoot.activeElement;
    const content = normalize(this.getAttribute("content"), ["title", "description"], "title");
    const state = this.state;
    const warning = state === "warning";
    const label = this.getAttribute("label") ?? "选项标题";
    const tag = warning ? "div" : "button";
    const description = this.getAttribute("description") ?? "";
    this.mount(
      `<${tag} class="v9-option-tile v9-option-tile--${content} is-${state}"
        ${warning ? 'role="note"' : `type="button" aria-pressed="${state === "selected"}"`}
        ${this.hasAttribute("aria-label") ? `aria-label="${escapeHTML(this.getAttribute("aria-label"))}"` : ""}>
        <span class="v9-option-tile__title${content === "description" ? " v9-adaptive-line-height" : ""}"
          ${content === "title" ? `title="${escapeHTML(label)}"` : ""}>${escapeHTML(label)}</span>
        ${content === "description" ? `<span class="v9-option-tile__description">${escapeHTML(description)}</span>` : ""}
      </${tag}>`,
      ":host{display:flex;min-width:0;} .v9-option-tile{flex:1;}",
    );
    this.shadowRoot.querySelector("button")?.addEventListener("click", () => {
      const next = this.state === "selected" ? "unselected" : "selected";
      this.setAttribute("state", next);
      this.dispatchEvent(new CustomEvent("v9-change", {
        bubbles: true, composed: true,
        detail: { value: this.value, state: next, selected: next === "selected" },
      }));
    });
    if (focused && !warning) this.shadowRoot.querySelector("button")?.focus();
  }
}

class V9OptionGroup extends V9Element {
  static observedAttributes = ["content", "columns", "aria-label"];

  connectedCallback() {
    this.onTileChange ||= (event) => {
      if (!this.options().includes(event.target)) return;
      event.stopImmediatePropagation();
      this.dispatchEvent(new CustomEvent("v9-change", {
        bubbles: true, composed: true,
        detail: { ...event.detail, values: this.values },
      }));
    };
    this.addEventListener("v9-change", this.onTileChange);
    super.connectedCallback();
  }

  disconnectedCallback() {
    this.removeEventListener("v9-change", this.onTileChange);
    super.disconnectedCallback();
  }

  options() { return [...this.children].filter((node) => node.localName === "v9-option-tile"); }
  get values() { return this.options().filter((item) => item.state === "selected").map((item) => item.value); }

  syncOptions() {
    const content = normalize(this.getAttribute("content"), ["title", "description"], "title");
    this.options().forEach((option) => {
      if (option.getAttribute("content") !== content) option.setAttribute("content", content);
    });
  }

  render() {
    const content = normalize(this.getAttribute("content"), ["title", "description"], "title");
    const requested = Number(this.getAttribute("columns") || 2);
    const max = content === "description" ? 3 : 5;
    const columns = Number.isInteger(requested) ? Math.max(2, Math.min(max, requested)) : 2;
    this.mount(
      `<div class="v9-option-group" role="group" data-columns="${columns}"
        aria-label="${escapeHTML(this.getAttribute("aria-label") || "多选项")}">
        <slot></slot>
      </div>`,
      `:host{display:block;min-width:0;}slot{display:grid;grid-template-columns:repeat(${columns},minmax(0,1fr));gap:var(${columns === 5 ? "--v9-space-xs" : "--v9-space-sm"});align-items:stretch;}
       ::slotted(v9-option-tile){min-width:0;}`,
    );
    this.shadowRoot.querySelector("slot").addEventListener("slotchange", () => this.syncOptions());
    this.syncOptions();
  }
}

class V9WarningCount extends V9Element {
  static observedAttributes = ["label", "count", "aria-label"];

  render() {
    const label = this.getAttribute("label") ?? "";
    const count = this.getAttribute("count") ?? "";
    this.mount(
      `<div class="v9-warning-count" role="note"
        ${this.hasAttribute("aria-label") ? `aria-label="${escapeHTML(this.getAttribute("aria-label"))}"` : ""}>
        <span class="v9-warning-count__label" title="${escapeHTML(label)}">${escapeHTML(label)}</span>
        <span class="v9-warning-count__value">${escapeHTML(count)}</span>
      </div>`,
      ":host{display:flex;min-width:0;} .v9-warning-count{flex:1;}",
    );
  }
}

class V9CardContent extends V9Element {
  static observedAttributes = [
    "surface", "layout", "title", "description", "description-tone", "media-src", "media-alt", "media-size",
    "action", "action-text", "show-title", "show-description", "show-floating-button",
    "list-label", "list-value", "list-label-2", "list-value-2",
  ];

  render() {
    const surface = normalize(this.getAttribute("surface"), ["pure", "subtle"], "pure");
    const layout = normalize(this.getAttribute("layout"), ["editorial", "list", "media"], "editorial");
    const mediaSize = normalize(this.getAttribute("media-size"), ["none", "medium", "large"], "large");
    const descriptionTone = normalize(this.getAttribute("description-tone"), ["default", "error"], "default");
    const requestedAction = normalize(this.getAttribute("action"), ["none", "floating"], "none");
    const action = layout === "editorial" ? requestedAction : "none";
    const showTitle = this.hasAttribute("title") && this.getAttribute("show-title") !== "false";
    const showDescription = this.hasAttribute("description") && this.getAttribute("show-description") !== "false";
    const showFloatingButton = action === "floating" && this.getAttribute("show-floating-button") !== "false";
    const classes = [
      "v9-cardcontent", `v9-cardcontent--${surface}`, `v9-cardcontent--${layout}`,
      `v9-cardcontent--media-${mediaSize}`, `v9-cardcontent--action-${action}`,
      `v9-cardcontent--description-${descriptionTone}`,
    ].join(" ");
    const hasMediaSource = this.hasAttribute("media-src") && this.getAttribute("media-src").trim() !== "";
    const media = layout === "media" && mediaSize !== "none"
      ? `<div class="v9-cardcontent__media-frame v9-cardcontent__media-frame--${mediaSize}" data-placeholder="${hasMediaSource ? "false" : "true"}">
          ${hasMediaSource ? `<img class="v9-cardcontent__media" src="${safeURL(this.getAttribute("media-src"))}" alt="${escapeHTML(this.getAttribute("media-alt") || "")}">` : ""}
          <slot name="media-overlay"></slot>
        </div>`
      : "";
    const copy = `<div class="v9-cardcontent__copy">
      ${showTitle ? `<div class="v9-cardcontent__title v9-adaptive-line-height">${escapeHTML(this.getAttribute("title"))}</div>` : ""}
      ${showDescription ? `<div class="v9-cardcontent__desc v9-cardcontent__desc--${descriptionTone} v9-adaptive-line-height">${escapeHTML(this.getAttribute("description"))}</div>` : ""}
      ${layout === "editorial" ? "<slot></slot>" : ""}
    </div>`;
    const floatingButton = showFloatingButton
      ? `<v9-button class="v9-cardcontent__floating" size="medium" variant="primary">${escapeHTML(this.getAttribute("action-text") || "默认状态")}</v9-button>`
      : "";
    const listRow = (labelName, valueName) => {
      const label = this.getAttribute(labelName);
      const value = this.getAttribute(valueName);
      return label != null || value != null
        ? `<div class="v9-cardcontent__list-row"><span class="v9-adaptive-line-height">${escapeHTML(label || "")}</span><span class="v9-adaptive-line-height">${escapeHTML(value || "")}</span></div>`
        : "";
    };
    const body = layout === "list"
      ? `<div class="v9-cardcontent__body">
          ${listRow("list-label", "list-value")}
          ${listRow("list-label-2", "list-value-2")}
          <slot></slot>
        </div>`
      : `<div class="v9-cardcontent__body">${copy}${floatingButton}</div>`;
    this.mount(
      `<div class="${classes}">
        ${media}
        ${body}
      </div>`,
      `:host{display:block;width:100%;}.v9-cardcontent__body{min-width:0;flex:1;}slot:not([name]){display:contents;}
       .v9-cardcontent__copy{min-width:0;flex:1;}
       ::slotted(v9-status-overlay){position:absolute;inset:auto 0 0;}`,
    );
  }
}

class V9TaskSheet extends V9Element {
  static observedAttributes = ["content-boundary", "show-action", "aria-label"];

  disconnectedCallback() {
    super.disconnectedCallback();
    this._taskSheetResizeObserver?.disconnect();
    if (this._taskSheetFrame) cancelAnimationFrame(this._taskSheetFrame);
  }

  countRenderedLines(element) {
    if (!element) return 0;
    const range = document.createRange();
    range.selectNodeContents(element);
    return new Set(
      [...range.getClientRects()]
        .filter((rect) => rect.width > 0 && rect.height > 0)
        .map((rect) => Math.round(rect.top * 2) / 2),
    ).size;
  }

  syncTaskSheet() {
    const root = this.shadowRoot.querySelector(".v9-task-sheet");
    const contentSlot = this.shadowRoot.querySelector('slot[name="content"]');
    const actionSlot = this.shadowRoot.querySelector('slot[name="action"]');
    if (!root || !contentSlot || !actionSlot) return;
    if (this._taskSheetResizeObserver) {
      [...this.shadowRoot.querySelectorAll("slot")]
        .flatMap((slot) => slot.assignedElements({ flatten: true }))
        .forEach((element) => this._taskSheetResizeObserver.observe(element));
    }

    const requestedBoundary = normalize(
      this.getAttribute("content-boundary"),
      ["auto", "single", "multiline"],
      "auto",
    );
    let resolvedBoundary = requestedBoundary === "multiline" ? "multiline" : "single";
    if (requestedBoundary === "auto") {
      const content = contentSlot.assignedElements({ flatten: true })
        .find((element) => element.localName === "v9-cardcontent");
      const description = content?.shadowRoot?.querySelector(".v9-cardcontent__desc");
      resolvedBoundary = this.countRenderedLines(description) > 1 ? "multiline" : "single";
    }

    const hasAction = actionSlot.assignedNodes({ flatten: true }).some((node) =>
      node.nodeType === Node.TEXT_NODE ? Boolean(node.textContent.trim()) : !node.hidden,
    );
    const showAction = isTrue(this, "show-action", true) && hasAction;
    root.dataset.contentBoundary = resolvedBoundary;
    root.dataset.showAction = String(showAction);
    this.dataset.resolvedBoundary = resolvedBoundary;
  }

  scheduleTaskSheetSync() {
    if (this._taskSheetFrame) cancelAnimationFrame(this._taskSheetFrame);
    this._taskSheetFrame = requestAnimationFrame(() => {
      this.syncTaskSheet();
      this._taskSheetFrame = requestAnimationFrame(() => this.syncTaskSheet());
    });
  }

  render() {
    this._taskSheetResizeObserver?.disconnect();
    const requestedBoundary = normalize(
      this.getAttribute("content-boundary"),
      ["auto", "single", "multiline"],
      "auto",
    );
    this.mount(
      `<section class="v9-task-sheet" data-content-boundary="${requestedBoundary === "multiline" ? "multiline" : "single"}" data-show-action="false"
        aria-label="${escapeHTML(this.getAttribute("aria-label") || "任务面板")}">
        <div class="v9-task-sheet__body">
          <div class="v9-task-sheet__main">
            <div class="v9-task-sheet__header"><slot name="header"></slot></div>
            <div class="v9-task-sheet__content"><slot name="content"></slot></div>
          </div>
          <div class="v9-task-sheet__action"><slot name="action"></slot></div>
        </div>
        <v9-home-indicator theme="light"></v9-home-indicator>
      </section>`,
      `:host{display:block;width:375px;max-width:100%;}
       slot{display:contents;}
       slot[name="header"]::slotted(v9-cardheader){
         --v9-cardheader-title-size:20px;
         --v9-cardheader-title-weight:600;
         --v9-cardheader-title-color:var(--v9-text-primary);
       }
       slot[name="content"]::slotted(v9-cardcontent){
         --v9-cardcontent-title-size:16px;
         --v9-cardcontent-title-weight:500;
         --v9-cardcontent-title-color:var(--v9-text-body);
         --v9-cardcontent-copy-gap:10px;
       }
       .v9-task-sheet[data-content-boundary="multiline"] slot[name="content"]::slotted(v9-cardcontent){
         --v9-cardcontent-copy-gap:var(--v9-space-sm);
       }`,
    );

    const slots = [...this.shadowRoot.querySelectorAll("slot")];
    slots.forEach((slot) => slot.addEventListener("slotchange", () => this.scheduleTaskSheetSync()));
    if (typeof ResizeObserver !== "undefined") {
      this._taskSheetResizeObserver = new ResizeObserver(() => this.scheduleTaskSheetSync());
      slots.flatMap((slot) => slot.assignedElements({ flatten: true }))
        .forEach((element) => this._taskSheetResizeObserver.observe(element));
    }
    this.scheduleTaskSheetSync();
  }
}

class V9TextLink extends V9Element {
  static observedAttributes = ["importance", "size", "href", "icon"];

  render() {
    const importance = normalize(this.getAttribute("importance"), ["important", "secondary", "theme", "error"], "secondary");
    const size = normalize(this.getAttribute("size"), ["l", "m", "s"], "m");
    this.mount(
      `<a class="v9-textlink v9-textlink--${importance} v9-textlink--${size}" href="${safeURL(this.getAttribute("href") || "#")}"><slot></slot>${this.hasAttribute("icon") ? `<v9-arrow size="l" color="${importance === "important" ? "orange" : importance === "error" ? "red" : importance === "theme" ? "white" : "grey"}" icon="${escapeHTML(this.getAttribute("icon"))}"></v9-arrow>` : ""}</a>`,
      `:host{display:inline-flex;line-height:0;vertical-align:middle;}a{text-decoration:none;}
       v9-arrow{display:inline-flex;width:18px;height:18px;line-height:0;align-items:center;justify-content:center;}`,
    );
  }
}

class V9ExpandLink extends V9Element {
  static observedAttributes = ["importance", "size", "state"];

  render() {
    const importance = normalize(this.getAttribute("importance"), ["important", "secondary", "theme", "error"], "secondary");
    const size = normalize(this.getAttribute("size"), ["l", "m", "s"], "m");
    const state = normalize(this.getAttribute("state"), ["expand", "collapse"], "expand");
    const color = importance === "important" ? "orange" : importance === "error" ? "red" : importance === "theme" ? "white" : "grey";
    this.mount(
      `<button class="v9-textlink v9-textlink--${importance} v9-textlink--${size} v9-expandlink"
        type="button" aria-expanded="${state === "collapse"}">
        <span class="v9-expandlink__label">${state === "expand" ? "展开" : "收起"}</span>
        <v9-arrow size="l" color="${color}" icon="${state === "expand" ? "down" : "up"}"></v9-arrow>
      </button>`,
      `:host{display:inline-flex;line-height:0;vertical-align:middle;}
       button{appearance:none;border:0;padding:0;background:transparent;}
       v9-arrow{display:inline-flex;width:18px;height:18px;line-height:0;align-items:center;justify-content:center;flex:none;}`,
    );
    this.shadowRoot.querySelector("button").addEventListener("click", () => {
      const next = state === "expand" ? "collapse" : "expand";
      this.setAttribute("state", next);
      this.dispatchEvent(new CustomEvent("v9-toggle", { bubbles: true, detail: { state: next } }));
    });
  }
}

class V9StatusOverlay extends V9Element {
  static observedAttributes = ["state", "text"];

  render() {
    const state = normalize(this.getAttribute("state"), ["success", "failed"], "success");
    const text = this.getAttribute("text") || (state === "success" ? "已通过" : "未通过");
    this.mount(
      `<div class="v9-overlay v9-overlay--${state}">
        <img src="${assetHref(`components/status-overlay/${state}.svg`)}" alt="" aria-hidden="true">
        <span>${escapeHTML(text)}</span>
      </div>`,
      ":host{display:block;position:absolute;inset:auto 0 0;height:35px;}img{display:block;width:12px;height:12px;flex:none;}",
    );
  }
}

class V9Empty extends V9Element {
  static observedAttributes = ["text", "aria-label"];

  render() {
    const text = this.getAttribute("text") || "这里是文案";
    const ariaLabel = this.getAttribute("aria-label") || text;
    this.mount(
      `<div class="v9-empty" role="status" aria-label="${escapeHTML(ariaLabel)}">
        <div class="v9-empty__art" aria-hidden="true">
          <img src="${assetHref("components/empty/illustration.svg")}" alt="">
        </div>
        <div class="v9-empty__text" aria-hidden="true">${escapeHTML(text)}</div>
      </div>`,
      ":host{display:block;width:100px;height:126px;}",
    );
  }
}

let tabsInstanceCounter = 0;

class V9Tabs extends V9Element {
  static observedAttributes = ["items", "active", "variant", "distribution", "show-background"];

  constructor() {
    super();
    this.tabsId = `v9-tabs-${++tabsInstanceCounter}`;
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    this._tabsPanelResizeObserver?.disconnect();
    if (this._tabsPanelFrame) cancelAnimationFrame(this._tabsPanelFrame);
  }

  parsedItems(limit) {
    return (this.getAttribute("items") || "")
      .split(/[,|]/)
      .map((item) => item.trim())
      .filter(Boolean)
      .slice(0, limit);
  }

  render() {
    const variant = normalize(this.getAttribute("variant"), ["line", "card"], "line");
    if (variant === "card") {
      this.renderCard();
      return;
    }
    this.renderLine();
  }

  renderLine() {
    const items = this.parsedItems(4);
    const requestedActive = Number(this.getAttribute("active") || 1);
    const active = Math.max(1, Math.min(items.length || 1, Number.isFinite(requestedActive) ? requestedActive : 1));
    const distribution = normalize(this.getAttribute("distribution"), ["equal", "start"], "equal");
    const showBackground = isTrue(this, "show-background", true);
    this.mount(
      `<div class="v9-tabs v9-tabs--line v9-tabs--distribution-${distribution} v9-tabs--background-${showBackground ? "visible" : "transparent"}" role="tablist" data-distribution="${distribution}" data-show-background="${showBackground}">${items.map((item, index) => `<button class="v9-tabs__item${index + 1 === active ? " is-active" : ""}" type="button" role="tab" aria-selected="${index + 1 === active}" tabindex="${index + 1 === active ? 0 : -1}" data-index="${index + 1}"><span class="v9-tabs__label">${escapeHTML(item)}</span><span class="v9-tabs__indicator" aria-hidden="true"></span></button>`).join("")}</div>`,
      ":host{display:block;width:375px;}.v9-tabs__item{appearance:none;border:0;background:transparent;font-family:inherit;}",
    );
    this.bindTabEvents(".v9-tabs__item", items.length);
  }

  cardShapeMarkup(amount, active) {
    const shape = (className, asset = "inactive-wing.svg") =>
      `<img class="v9-tabs-card__shape ${className}" src="${assetHref(`components/tabs/${asset}`)}" alt="" aria-hidden="true">`;
    if (amount === 3 && active === 1) return `${shape("v9-tabs-card__shape--3-right", "inactive-wide.svg")}<i class="v9-tabs-card__divider v9-tabs-card__divider--right" aria-hidden="true"></i>`;
    if (amount === 3 && active === 2) return `${shape("v9-tabs-card__shape--3-left-small")} ${shape("v9-tabs-card__shape--3-right-small")}`;
    if (amount === 3 && active === 3) return `${shape("v9-tabs-card__shape--3-left")}<i class="v9-tabs-card__divider v9-tabs-card__divider--left" aria-hidden="true"></i>`;
    if (amount === 2 && active === 1) return shape("v9-tabs-card__shape--2-right");
    return shape("v9-tabs-card__shape--2-left");
  }

  renderCard() {
    let items = this.parsedItems(3);
    if (items.length < 2) items = ["选项一", "选项二"];
    const amount = Math.min(3, items.length);
    const requestedActive = Number(this.getAttribute("active") || 1);
    const active = Math.max(1, Math.min(amount, Number.isFinite(requestedActive) ? requestedActive : 1));
    const tabs = items.map((item, index) => {
      const position = index + 1;
      return `<button id="${this.tabsId}-tab-${position}" class="v9-tabs-card__tab${position === active ? " is-active" : ""}" type="button" role="tab" aria-selected="${position === active}" aria-controls="${this.tabsId}-panel-${position}" tabindex="${position === active ? 0 : -1}" data-index="${position}" title="${escapeHTML(item)}"><span class="v9-tabs-card__label">${escapeHTML(item)}</span></button>`;
    }).join("");
    const panels = items.map((item, index) => {
      const position = index + 1;
      return `<div id="${this.tabsId}-panel-${position}" class="v9-tabs-card__panel${position === active ? " is-active" : ""}" role="tabpanel" aria-labelledby="${this.tabsId}-tab-${position}" ${position === active ? "" : "aria-hidden=\"true\""}><slot name="panel-${position}"><v9-entry-item orientation="horizontal" surface="subtle" icon-size="40" interaction="whole-item" show-description="true" title="${escapeHTML(item)}内容" description="说明文案"></v9-entry-item></slot></div>`;
    }).join("");
    this.mount(
      `<section class="v9-tabs v9-tabs--card" data-amount="${amount}" data-active="${active}">
        <div class="v9-tabs-card__header-surface" aria-hidden="true"></div>
        ${this.cardShapeMarkup(amount, active)}
        <div class="v9-tabs-card__tabs" role="tablist" aria-label="卡片内容切换" style="--v9-tabs-card-amount:${amount}">${tabs}</div>
        <div class="v9-tabs-card__content"><div class="v9-tabs-card__stage">${panels}</div></div>
      </section>`,
      `:host{display:block;width:351px;min-width:0;}.v9-tabs-card__tab{appearance:none;border:0;background:transparent;font-family:inherit;}
       ::slotted([slot^="panel-"]){display:block;width:100%;min-width:0;}`,
    );
    this.bindTabEvents(".v9-tabs-card__tab", amount);
    this.syncCardPanelHeight();
  }

  bindTabEvents(selector, amount) {
    this.shadowRoot.querySelectorAll(selector).forEach((button) => {
      button.addEventListener("click", () => this.selectTab(Number(button.dataset.index)));
      button.addEventListener("keydown", (event) => {
        if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
        event.preventDefault();
        let next = Number(button.dataset.index);
        if (event.key === "ArrowLeft") next = next === 1 ? amount : next - 1;
        if (event.key === "ArrowRight") next = next === amount ? 1 : next + 1;
        if (event.key === "Home") next = 1;
        if (event.key === "End") next = amount;
        this.selectTab(next, true);
      });
    });
  }

  selectTab(active, restoreFocus = false) {
    const current = Number(this.getAttribute("active") || 1);
    if (active === current) return;
    this.setAttribute("active", String(active));
    this.dispatchEvent(new CustomEvent("v9-change", { bubbles: true, detail: { active } }));
    if (restoreFocus) {
      requestAnimationFrame(() => this.shadowRoot.querySelector(`[data-index="${active}"]`)?.focus());
    }
  }

  syncCardPanelHeight() {
    this._tabsPanelResizeObserver?.disconnect();
    if (this._tabsPanelFrame) cancelAnimationFrame(this._tabsPanelFrame);
    const stage = this.shadowRoot.querySelector(".v9-tabs-card__stage");
    const panels = [...this.shadowRoot.querySelectorAll(".v9-tabs-card__panel")];
    if (!stage || !panels.length) return;
    const sync = () => {
      stage.style.height = `${Math.max(...panels.map((panel) => panel.scrollHeight))}px`;
    };
    const observe = () => {
      this._tabsPanelResizeObserver?.disconnect();
      if (typeof ResizeObserver === "undefined") return;
      this._tabsPanelResizeObserver = new ResizeObserver(sync);
      panels.forEach((panel) => this._tabsPanelResizeObserver.observe(panel));
      this.shadowRoot.querySelectorAll("slot").forEach((slot) => {
        slot.assignedElements({ flatten: true }).forEach((element) => this._tabsPanelResizeObserver.observe(element));
      });
    };
    this.shadowRoot.querySelectorAll("slot").forEach((slot) => {
      slot.addEventListener("slotchange", () => {
        observe();
        sync();
      });
    });
    observe();
    this._tabsPanelFrame = requestAnimationFrame(sync);
  }
}

class V9HomeIndicator extends V9Element {
  static observedAttributes = ["theme"];

  render() {
    const theme = normalize(this.getAttribute("theme"), ["light", "dark"], "light");
    this.mount(`<div class="v9-home-indicator v9-home-indicator--${theme}" aria-hidden="true"></div>`, ":host{display:block;width:375px;height:34px;}");
  }
}

class V9ToastIcon extends V9Element {
  static observedAttributes = ["type"];

  render() {
    const type = normalize(this.getAttribute("type"), ["warning", "success", "loading", "error"], "warning");
    const extension = type === "loading" ? "png" : "svg";
    const source = assetHref(`./components/toast/${type}.${extension}`);
    this.mount(
      `<img class="v9-toast-icon v9-toast-icon--${type}" src="${source}" alt="" aria-hidden="true">`,
      ":host{display:inline-flex;width:18px;height:18px;flex:none;}",
    );
  }
}

class V9Toast extends V9Element {
  static observedAttributes = ["open", "text", "icon-type", "duration"];

  constructor() {
    super();
    this.dismissTimer = null;
  }

  disconnectedCallback() {
    clearTimeout(this.dismissTimer);
    this.dismissTimer = null;
  }

  render() {
    clearTimeout(this.dismissTimer);
    this.dismissTimer = null;

    const open = this.hasAttribute("open") && isTrue(this, "open");
    const iconType = normalize(
      this.getAttribute("icon-type"),
      ["none", "warning", "success", "loading", "error"],
      "warning",
    );
    const urgent = iconType === "warning" || iconType === "error";
    const durationValue = this.hasAttribute("duration") ? Number(this.getAttribute("duration")) : Number.NaN;
    const duration = Number.isFinite(durationValue) && durationValue >= 0 ? durationValue : 2000;
    const icon = iconType === "none" ? "" : `<v9-toast-icon type="${iconType}"></v9-toast-icon>`;

    this.mount(
      `<div class="v9-toast" role="${urgent ? "alert" : "status"}" aria-live="${urgent ? "assertive" : "polite"}" ${open ? "" : "hidden"}>
        ${icon}
        <span class="v9-toast__text v9-adaptive-line-height">${escapeHTML(this.getAttribute("text") || "在这里修改文案")}</span>
      </div>`,
      `:host{display:none;pointer-events:none;}
       :host([open]:not([open='false'])){position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;}`,
    );

    if (open && iconType !== "loading" && duration > 0) {
      this.dismissTimer = setTimeout(() => {
        this.removeAttribute("open");
        this.dispatchEvent(new CustomEvent("v9-close", {
          bubbles: true,
          detail: { reason: "timeout" },
        }));
      }, duration);
    }
  }
}

let dialogSequence = 0;

class V9Dialog extends V9Element {
  static observedAttributes = [
    "open", "title", "body", "show-close", "show-body", "show-agreement",
    "agreement-state", "agreement-text", "agreement-href", "close-on-scrim",
  ];

  constructor() {
    super();
    this.dialogId = `v9-dialog-${++dialogSequence}`;
    this.wasOpen = false;
    this.restoreFocusTo = null;
    this.handleKeydown = (event) => {
      if (!this.wasOpen) return;
      if (event.key === "Escape") {
        event.preventDefault();
        this.requestClose("escape");
        return;
      }
      if (event.key !== "Tab") return;
      const focusable = this.focusableElements();
      if (!focusable.length) {
        event.preventDefault();
        this.shadowRoot.querySelector(".v9-dialog")?.focus();
        return;
      }
      const active = this.deepActiveElement();
      const index = focusable.indexOf(active);
      const next = event.shiftKey
        ? (index <= 0 ? focusable.at(-1) : focusable[index - 1])
        : (index < 0 || index === focusable.length - 1 ? focusable[0] : focusable[index + 1]);
      event.preventDefault();
      next.focus();
    };
  }

  connectedCallback() {
    this.addEventListener("keydown", this.handleKeydown);
    super.connectedCallback();
  }

  disconnectedCallback() {
    this.removeEventListener("keydown", this.handleKeydown);
    this.syncScrollLock(false);
  }

  syncScrollLock(open) {
    if (open) {
      document.documentElement.classList.add("v9-modal-open");
      document.body?.classList.add("v9-modal-open");
      return;
    }
    const anotherDialog = [...document.querySelectorAll("v9-dialog[open]")]
      .some((dialog) => dialog !== this && dialog.getAttribute("open") !== "false");
    if (!anotherDialog) {
      document.documentElement.classList.remove("v9-modal-open");
      document.body?.classList.remove("v9-modal-open");
    }
  }

  deepActiveElement() {
    let active = document.activeElement;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    return active;
  }

  focusableElements() {
    const result = [];
    const seen = new Set();
    const visit = (root) => {
      if (!root?.querySelectorAll) return;
      root.querySelectorAll("*").forEach((element) => {
        if (element.shadowRoot) visit(element.shadowRoot);
        if (element.tagName === "SLOT") element.assignedElements({ flatten: true }).forEach(visitElement);
        if (
          element.matches("button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex='-1'])") &&
          !element.hidden && element.getAttribute("aria-hidden") !== "true" && !seen.has(element)
        ) {
          seen.add(element);
          result.push(element);
        }
      });
    };
    const visitElement = (element) => {
      if (element.shadowRoot) visit(element.shadowRoot);
      visit(element);
    };
    visit(this.shadowRoot);
    this.querySelectorAll("*").forEach(visitElement);
    return result.filter((element) => !element.classList.contains("v9-modal__scrim"));
  }

  requestClose(reason) {
    if (!this.wasOpen) return;
    this.removeAttribute("open");
    this.dispatchEvent(new CustomEvent("v9-close", { bubbles: true, detail: { reason } }));
  }

  onAdaptiveLineHeightSync() {
    const copy = this.shadowRoot.querySelector(".v9-dialog__copy");
    const title = this.shadowRoot.querySelector(".v9-dialog__title");
    const body = this.shadowRoot.querySelector(".v9-dialog__body");
    const bothSingleLine = Boolean(
      copy && title && body &&
      !title.classList.contains("is-multiline") &&
      !body.classList.contains("is-multiline")
    );
    copy?.classList.toggle("is-single-line-pair", bothSingleLine);
  }

  render() {
    const requestedOpen = isTrue(this, "open");
    const actionGroup = [...this.children].find((child) =>
      child.localName === "v9-action-group" &&
      child.getAttribute("slot") === "actions" &&
      !child.hidden
    );
    const hasRequiredAction = Boolean(actionGroup?.querySelector("v9-button:not([hidden])"));
    const open = requestedOpen && hasRequiredAction;
    const opening = open && !this.wasOpen;
    const closing = !open && this.wasOpen;
    if (opening) this.restoreFocusTo = this.deepActiveElement();

    const showClose = isTrue(this, "show-close");
    const showBody = isTrue(this, "show-body", true);
    const showAgreement = isTrue(this, "show-agreement", true);
    const closeOnScrim = isTrue(this, "close-on-scrim");
    const titleId = `${this.dialogId}-title`;
    const bodyId = `${this.dialogId}-body`;
    const agreementState = normalize(this.getAttribute("agreement-state"), ["detail", "checked", "unchecked"], "detail");
    const agreementText = this.getAttribute("agreement-text") || "查看协议名称详情";
    const agreementHref = this.getAttribute("agreement-href") || "#";

    this.mount(
      `<div class="v9-modal" ${open ? "" : "hidden"}>
        <button class="v9-modal__scrim" type="button" tabindex="-1" aria-hidden="true"></button>
        <section class="v9-dialog" role="dialog" aria-modal="true" tabindex="-1"
          aria-labelledby="${titleId}" ${showBody ? `aria-describedby="${bodyId}"` : ""}>
          <div class="v9-dialog__panel">
            <div class="v9-dialog__content">
              ${showClose ? `<div class="v9-dialog__close"><button class="v9-dialog__close-button" type="button" aria-label="关闭弹窗"><v9-arrow size="l" color="grey" icon="close"></v9-arrow></button></div>` : ""}
              <div class="v9-dialog__header-media" data-region="header-media"><slot name="header-media"></slot></div>
              <div class="v9-dialog__main">
                <div class="v9-dialog__copy"><h2 class="v9-dialog__title v9-adaptive-line-height" id="${titleId}">${escapeHTML(this.getAttribute("title") || "")}</h2>${showBody ? `<p class="v9-dialog__body v9-adaptive-line-height" id="${bodyId}">${escapeHTML(this.getAttribute("body") || "")}</p>` : ""}</div>
                <div class="v9-dialog__content-image" data-region="content-image"><slot name="content-image"></slot></div>
              </div>
            </div>
            <div class="v9-dialog__agreement" ${showAgreement ? "" : "hidden"}><slot name="agreement"><v9-agreement state="${agreementState}" text="${escapeHTML(agreementText)}" href="${safeURL(agreementHref)}"></v9-agreement></slot></div>
            <slot name="actions"></slot>
          </div>
        </section>
      </div>`,
      `:host{display:contents;}[data-region][hidden]{display:none!important;}
       ::slotted(v9-agreement[slot='agreement']){display:inline-flex;max-width:100%;height:18px;line-height:0;}
       ::slotted(v9-action-group[slot='actions']){display:block;width:100%;flex:none;}`,
    );

    const syncMedia = () => {
      this.shadowRoot.querySelectorAll("[data-region]").forEach((region) => {
        const slot = region.querySelector("slot");
        region.hidden = slot.assignedNodes({ flatten: true }).every((node) =>
          node.nodeType === Node.TEXT_NODE ? !node.textContent.trim() : node.hidden,
        );
      });
    };
    this.shadowRoot.querySelectorAll("[data-region] slot").forEach((slot) =>
      slot.addEventListener("slotchange", syncMedia));
    syncMedia();

    if (requestedOpen && !hasRequiredAction) {
      queueMicrotask(() => {
        if (this.hasAttribute("open")) this.removeAttribute("open");
        this.dispatchEvent(new CustomEvent("v9-invalid", {
          bubbles: true,
          detail: { reason: "missing-actions" },
        }));
      });
    }

    if (closeOnScrim) this.shadowRoot.querySelector(".v9-modal__scrim").addEventListener("click", () => this.requestClose("scrim"));
    this.shadowRoot.querySelector(".v9-dialog__close-button")?.addEventListener("click", () => this.requestClose("close-button"));

    this.wasOpen = open;
    this.syncScrollLock(open);
    if (opening) {
      queueMicrotask(() => {
        const first = this.focusableElements()[0] || this.shadowRoot.querySelector(".v9-dialog");
        first?.focus();
      });
    }
    if (closing) {
      const target = this.restoreFocusTo;
      this.restoreFocusTo = null;
      queueMicrotask(() => target?.isConnected && target.focus?.());
    }
  }
}

/**
 * H5 身份登记：
 * - component: Figma 真实组件 + H5 封装 + 显式映射均已完成；
 * - pending: 一侧尚未正式发布，不得计为正式组件；
 * - primitive/internal: 组件内部原语或辅助结构；
 * - h5-only: 仅保留 H5 兼容实现，新映射交付不得使用。
 */
export const V9_COMPONENTS = Object.freeze({
  "v9-background-focus": { rootClass: "v9-background-focus", kind: "component" },
  "v9-appbar": { rootClass: "v9-appbar", kind: "component" },
  "v9-back": { rootClass: "v9-back", kind: "internal" },
  "v9-button": { rootClass: "v9-btn", kind: "component" },
  "v9-action-group": { rootClass: "v9-action-group", kind: "component" },
  "v9-tag": { rootClass: "v9-tag", kind: "component" },
  "v9-badge": { rootClass: "v9-badge", kind: "component" },
  "v9-selection-control": { rootClass: "v9-selection-control", kind: "component" },
  "v9-agreement": { rootClass: "v9-agreement", kind: "component" },
  "v9-info-icon": { rootClass: "v9-info-icon", kind: "component" },
  "v9-tooltip": { rootClass: "v9-tooltip", kind: "component" },
  "v9-loading": { rootClass: "v9-loading", kind: "component" },
  "v9-quantity-stepper": { rootClass: "v9-quantity-stepper", kind: "component" },
  "v9-alert": { rootClass: "v9-alert", kind: "component" },
  "v9-number": { rootClass: "v9-number", kind: "primitive" },
  "v9-metric-item": { rootClass: "v9-metric-item", kind: "component" },
  "v9-metric-group": { rootClass: "v9-metric-group", kind: "component" },
  "v9-metric-scroll": { rootClass: "v9-metric-scroll", kind: "component" },
  "v9-card": { rootClass: "v9-card", kind: "component" },
  "v9-cardheader": { rootClass: "v9-cardheader", kind: "component" },
  "v9-cardcontent": { rootClass: "v9-cardcontent", kind: "component" },
  "v9-task-sheet": { rootClass: "v9-task-sheet", kind: "component" },
  "v9-accent-card": { rootClass: "v9-accent-card", kind: "component" },
  "v9-entry-item": { rootClass: "v9-entry-item", kind: "component" },
  "v9-entry-group": { rootClass: "v9-entry-group", kind: "component" },
  "v9-pill-option": { rootClass: "v9-pill-option", kind: "component" },
  "v9-pill-option-group": { rootClass: "v9-pill-option-group", kind: "component" },
  "v9-option-tile": { rootClass: "v9-option-tile", kind: "component" },
  "v9-option-group": { rootClass: "v9-option-group", kind: "primitive" },
  "v9-warning-count": { rootClass: "v9-warning-count", kind: "component" },
  "v9-form-item": { rootClass: "v9-form-item", kind: "component" },
  "v9-form-item-group": { rootClass: "v9-form-item-group", kind: "component" },
  "v9-form-card": { rootClass: "v9-form-card", kind: "component" },
  "v9-address-group": { rootClass: "v9-address-group", kind: "component" },
  "v9-list-row": { rootClass: "v9-list-row", kind: "internal" },
  "v9-arrow": { rootClass: "v9-arrow", kind: "component" },
  "v9-textlink": { rootClass: "v9-textlink", kind: "component" },
  "v9-expandlink": { rootClass: "v9-expandlink", kind: "component" },
  "v9-status-overlay": { rootClass: "v9-overlay", kind: "component" },
  "v9-empty": { rootClass: "v9-empty", kind: "component" },
  "v9-tabs": { rootClass: "v9-tabs", kind: "component" },
  "v9-home-indicator": { rootClass: "v9-home-indicator", kind: "component" },
  "v9-toast-icon": { rootClass: "v9-toast-icon", kind: "component" },
  "v9-toast": { rootClass: "v9-toast", kind: "component" },
  "v9-dialog": { rootClass: "v9-dialog", kind: "component" },
});

const definitions = {
  "v9-background-focus": V9BackgroundFocus,
  "v9-arrow": V9Arrow,
  "v9-button": V9Button,
  "v9-action-group": V9ActionGroup,
  "v9-tag": V9Tag,
  "v9-badge": V9Badge,
  "v9-selection-control": V9SelectionControl,
  "v9-agreement": V9Agreement,
  "v9-info-icon": V9InfoIcon,
  "v9-tooltip": V9Tooltip,
  "v9-loading": V9Loading,
  "v9-quantity-stepper": V9QuantityStepper,
  "v9-alert": V9Alert,
  "v9-number": V9Number,
  "v9-metric-item": V9MetricItem,
  "v9-metric-group": V9MetricGroup,
  "v9-metric-scroll": V9MetricScroll,
  "v9-appbar": V9Appbar,
  "v9-back": V9Back,
  "v9-cardheader": V9CardHeader,
  "v9-card": V9Card,
  "v9-list-row": V9ListRow,
  "v9-cardcontent": V9CardContent,
  "v9-task-sheet": V9TaskSheet,
  "v9-accent-card": V9AccentCard,
  "v9-entry-item": V9EntryItem,
  "v9-entry-group": V9EntryGroup,
  "v9-pill-option": V9PillOption,
  "v9-pill-option-group": V9PillOptionGroup,
  "v9-option-tile": V9OptionTile,
  "v9-option-group": V9OptionGroup,
  "v9-warning-count": V9WarningCount,
  "v9-form-item": V9FormItem,
  "v9-form-item-group": V9FormItemGroup,
  "v9-form-card": V9FormCard,
  "v9-address-group": V9AddressGroup,
  "v9-textlink": V9TextLink,
  "v9-expandlink": V9ExpandLink,
  "v9-status-overlay": V9StatusOverlay,
  "v9-empty": V9Empty,
  "v9-tabs": V9Tabs,
  "v9-home-indicator": V9HomeIndicator,
  "v9-toast-icon": V9ToastIcon,
  "v9-toast": V9Toast,
  "v9-dialog": V9Dialog,
};

export function defineV9Components() {
  Object.entries(definitions).forEach(([name, constructor]) => {
    if (!customElements.get(name)) customElements.define(name, constructor);
  });
}

defineV9Components();
