# 更新日志

## v4.5.36 — 2026-11-04 · Option Tile / Warning Count 正式接入

- 两项源组件发布状态均为CURRENT，原Key与属性不变，已通过跨文件导入验证；源名称现为普通`Draft /`前缀，不再以隐藏前缀`_`开头。
- `v9-option-tile`与`v9-warning-count`由pending转为component；`v9-option-group`仍为primitive。45个运行元素中正式组件由39增至41。
- 同步Skill入口、组件规范、Node/Key索引、正式映射总表、运行时身份与校验；保留既有视觉、交互和Token，不修改Figma或业务页面。

## v4.5.35 — 2026-11-04 · Option Tile / Warning Count 待发布接入

- 新增Option Tile两种内容结构×三种状态规则，支持多选、取消及不可交互的Warning；新增独立警示计数。
- 新增H5封装`v9-option-tile`、`v9-option-group`、`v9-warning-count`，支持键盘操作、状态事件、合法列数与同排等高。
- 无副标题2–5列、有副标题2–3列，不提供单列；有副标题按内容自然增高，不固化示例78/84/104px高度。
- 按源稿保留标题14px／多行18px及副标题12/16，作为组件局部合同；不修改全局Token或通用行高。
- 记录Content/State、文本属性与源Key映射。用户已告知发布；2026-11-04复核接口仍返回UNPUBLISHED，测试文件跨文件导入返回not found，因此单项和计数暂登记pending（待发布同步核验），Group为无独立Figma Key的primitive；未修改Figma源件。
- 增加浏览器行为／尺寸回归并同步身份校验和Skill索引；Pill Option、Page、workflow及全局视觉原则保持不变。

## v4.5.34 — 2026-10-20 · 源状态对应与同状态视觉验收

- 在既有状态记录中对应继承区域的源状态，区分业务改动与视觉保留；缺失状态的推导明确标记，实质歧义沿用集中澄清，不增加PM必填表。
- 增加源稿与实际渲染的同状态视觉对照；差异须有需求或授权依据，代码校验不替代视觉验收，未能查看真实渲染须声明核对未完成。
- 仅更新workflow与本日志；不改组件、Token、运行时、映射或业务H5，不新增模式和参考文件。

## v4.5.33 — 2026-10-20 · PM展示、必要澄清与占位边界

- 出图前按页面展示“页面／弹层、对应原设计、本次处理、保持不变、样式依据、使用能力”，状态、占位说明和最后的待确认问题分开；技术追溯信息保留内部记录。
- 取消无条件整体批准门槛：明确要求和Skill规则不重问，Agent承担专业判断；仅澄清业务、意图、必需基准和授权范围问题，无问题直接执行，阻塞仅影响依赖部分。
- 允许最终文案、协议链接等登记占位并继续出图；区别待补充素材与未知业务规则，禁止伪造正式协议、真实链接或已完成交互，同步文案来源红线与验收。
- 增加10种项目选型速查；补充H5迁移叠加PRD业务修改的分范围记录与分别验收，仍保留三种模式。
- 仅修改SKILL入口、workflow、custom-rules、h5-migration与本日志；不改组件、Token、运行时、映射或页面，不新增参考文件。

## v4.5.32 — 2026-10-19 · 外部画板共用公共执行门槛

- 扩大workflow必读入口至所有页面及独立弹层产出、修改任务，明确直接写入MasterGo／Figma不能绕过公共流程。
- 在workflow开头增加首次产出前的确认门槛，核对页面与状态、修改范围、样式依据及交付方式；允许确认前只读取证，沿用已有确认。
- 区分目标平台与交付方式：链接或画板修改批准不自动取消H5及双附件；用户明确调整交付方式时，相应调整步骤与检查，保留需求确认和结果验证。
- 仅更新入口、工作流与版本记录，不新增模式、专项文件或工具拦截脚本；组件、Token、运行时和页面不变。

## v4.5.31 — 2026-10-16 · 按设计单元判型与原设计继承边界

- 保留Create、Local Edit、H5 Migration三种能力，按页面／独立弹层／授权区域分别判型；Local Edit明确为既有设计增量修改，支持PRD分析后的混合任务。
- 新页面及新增独立弹层默认9.0；旧页面和已有弹层的新状态沿用所属设计；延续式创建记录继承、升级及9.0补足范围。
- 将PRD与基准差异、文案、状态和样式依据合入出图前确认；缺失基准不当作新增，截图重建不自动获得重设计权限。
- 明确9.0数值、组件与Page规则的适用范围，允许有来源且隔离的原设计继承实现；所有实际调用的正式组件合同保持不变。
- 页面校验支持成对继承范围注释，只豁免对应旧空状态的替换要求，不跳过正式组件、运行时或资产检查；增加行为回归用例。
- 不改Token、组件外观、运行时、资产或Figma映射；未新增第四种模式或独立模式说明文档。

## v4.5.30 — 2026-10-14 · 视觉原则读取入口精简

- 将`SKILL.md`中的视觉读取说明由6条压缩为3条，只保留读取触发、`Local Edit`作用范围与非视觉任务排除。
- `Create`、`H5 Migration`与组件维护的具体路由继续由现有任务能力章节承担，不在视觉入口重复声明。
- 完整视觉判断顺序继续只保留在`references/visual-principles.md`，避免入口文件与参考文件重复维护。
- 本次不修改视觉原则正文、组件、Token、Page、运行时或Figma映射。

## v4.5.29 — 2026-10-14 · 全局视觉原则与轻量自查完善

- 将全局视觉判断收敛为8条核心原则：页面目标、主要焦点、业务层级、语义分组、构图密度、
  色彩与Surface、操作与导航、真实内容与状态适应性。
- 明确正式组件是实现手段而非页面结构起点；组件未覆盖时先排除变体、属性、Slot与嵌套方案，再使用
  “正式组件 + Token + 页面本地组合”，不得虚构正式组件。
- 新增8项轻量视觉自查，用真实页面和关键状态截图检查目标、焦点、层级、分组、构图、色彩、操作和
  完成度；默认只修正Issue，不要求在交付回复中逐项复述。
- 精确化视觉原则读取条件：需要新增、改变或审核可见界面关系时，在首次视觉选择前读取一次；同一任务
  不因页面、状态或组件数量重复读取，纯映射、打包及非视觉修复不读取。
- 训练历史、候选规则与大批正反例继续保留在正式Skill之外；本次不修改组件、Token、Page、H5运行时
  或Figma映射。

## v4.5.28 — 2026-10-13 · Tabs统一源与Line模式正式接入

- 回读主规范库Tabs发布Set（Node `274:2175`，Set Key
  `a681c138c3d45ba5171ab72ca575931f4aefa65d`）：Line与Card不再分属新旧两个源，Set共23个变体。
- Line增加Equal / Start选择合同：Equal服务同权稳定分栏；Start服务内容驱动的局部筛选，项间距24px；
  两者Indicator均为32px。
- Line增加Show Background布尔合同：默认白底，透明模式只在父级已有明确Surface且对比度稳定时使用；
  背景与Distribution独立判断，Card不受影响。
- 更新Tabs组件索引、Set Key、属性与维护规则，移除旧Line单变体Key和双源例外；第4项Label公开属性仍需
  Figma源补齐，暂以实例内可见文字层定向覆盖且禁止detach。
- Figma源中Line / amount=2 / Active=2 / Equal仍为375×40px，正式接入前须统一为42px并重新发布；
  H5不为单一异常增加特例。
- `<v9-tabs>`正式增加`distribution="equal|start"`与`show-background="true|false"`；默认保持Equal+白底，
  Card忽略两个Line专属属性。同步CSS布局、运行时属性、交互回归、Figma映射和自动校验。
- 本次不新增组件身份、Token或资产；正式组件数量保持39，Rounded仍不接入。

## v4.5.27 — 2026-10-12 · Button Weak 正式接入

- 回读主规范库 Button Set（Node `53:2666`）：`mode`新增已发布的`Weak`，与3种`statue`、3种`size`
  组成9个新变体，Set总数增至27；Set Key保持不变。
- `components.md`补充Weak的低强调语义、白色Surface与三状态颜色合同，并明确Weak全部使用
  PingFang SC Regular / 400，Primary与Subtle继续使用Semibold / 600。
- `visual-principles.md`把Weak更新为Figma与H5均已正式接入的低强调能力。
- 增加Weak的承载面硬限制：白色Surface必须位于非白背景上，禁止Weak直接放在白色背景；不允许
  用页面私有描边、阴影或品牌色补救。
- `v9-core.css`补齐Weak Default/Vistited/Disabled三状态，统一白色Surface与Regular / 400字重；
  `v9-components.js`正式接受 `variant="weak"`。
- `v9-figma-map.md`完成Weak的H5→Figma直映，并明确 `size="full"` 仍只支持Primary/Subtle。
- `validate-h5-runtime.mjs`增加Weak枚举、三状态样式、白色背景限制和Full-width边界校验。

## v4.5.26 — 2026-10-12 · 全局视觉原则与按需读取

- 新增 `references/visual-principles.md`，集中维护跨组件的视觉焦点、阅读顺序、品牌色预算、Surface与描边、
  重复元素权重、信息密度、分组节奏和截图审美自查，不再把全局审美判断混入单个组件合同。
- `SKILL.md` 增加条件化读取入口：Create完整出图、目标范围视觉迁移与视觉审核必读；Local Edit只在授权
  区域包含视觉决策时读取，且不得借审美优化修改锁定区域；纯Key、映射、非视觉运行时与打包任务不读。
- 固化“业务与范围 → 信息层级 → 视觉原则 → 正式组件 → Token → 页面回看”的判断顺序，并明确视觉原则
  只指导组合和选型，不能覆盖正式组件或Token合同。
- 本次不增加 `Weak` / 白色 Button 正式变体，不修改Figma组件、`components.md`、Token、H5 CSS、运行时或
  双端映射；低强调按钮仍需后续完成组件发布与三端接入。本版本为未打包工作版。

## v4.5.25 — 2026-10-12 · Accent Card 正式接入与 Entry Item 属性修正

- 主规范库已发布 `Accent Card / Single`、`Split`、`Grouped`：在 `components.md` 固化三种结构的选型、
  Slot 边界、可选属性、Grouped 四变体和标题字形条件；Grouped 的 Peer items 不绑定固定子项外观。
- 新增统一 `<v9-accent-card mode="single|split|grouped">` 正式运行时与组件局部 CSS，维护三种Figma
  Component Key、BOOLEAN/TEXT/Slot 映射；Single 圆环由CSS绘制，不添加SVG或全局Token。
- Single 的 Slot 内说明不再虚报为可用 TEXT 属性，保留 `Show Description` 与 `Main information` Slot；
  Entry Item 已发布文本属性由 `Description#27:12` 改为 `Description Text#27:12`，变体轴
  `Description=True/False` 不变，Entry Group 嵌套实例继续直接引用。
- H5 身份登记由41个元素/38个正式组件变为42/39，扩展运行时校验。此次不修改既有页面、
  通用 Token 或 Figma 组件视觉；完成校验并打包发布v4.5.25。

## v4.5.24 — 2026-09-20 · CellCard 动态 Slot 显隐

- 修复 `<v9-card>` 只监听 `slotchange`、未响应已挂载 Slot 子节点 `hidden` 切换的问题；
  展开/收起现在会同步 Content Region 的可见性与结构间距，断开连接或重渲染时清理观察器。
- 在 CellCard 合同中明确动态显隐规则，并加入展开→收起往返回归验证；不改变Figma映射、
  视觉参数或Token。完成校验并打包发布v4.5.24。

## v4.5.23 — 2026-09-15 · Driver Express Register Page编排补全

- 补充业务Page的显式组件编排：Hero与文本保持页面本地内容，Appbar、Action Button Group、
  Button Full-width、TextLink和Home Indicator使用当前正式H5组件，并明确主操作与手动上传兜底关系。
- 增加最小H5调用骨架和375×812参考几何；坐标只用于截图校准，实际H5保持自适应布局，不恢复固定模板、
  旧拆分运行时或整页绝对定位实现。
- 确认Benefit Title保留本Page专属28px字号：单行28px、多行42px；不扩展为全局Page Title字阶。
  同步扩展Runtime校验；本次不修改组件、Token、Figma映射、H5 CSS或组件运行时，完成校验并打包发布v4.5.23。

## v4.5.22 — 2026-09-15 · Driver Express Register Page与远程图片获取

- 在现有`pages/`结构中新增业务专属`Driver Express Register Page`，严格限定为“司机极速注册、
  复用既有资质、单一注册主操作、手动上传兜底、顶部Hero”同时成立时命中；不增加固定H5模板，
  不改变Focused Form Page及Create / Local Edit / H5 Migration的读取边界。
- 为Page增加可选同名`.assets.json`能力；司机Hero只登记HTTPS来源、SHA-256、1127×1260尺寸、语义描述、
  裁切与焦点信息，Skill不保存PNG二进制。
- 新增通用`fetch-page-assets.mjs`：仅在页面命中且确认使用对应图片时运行，将远程图片下载到H5工程，
  校验HTTPS、输出路径、20MB上限、MIME、Hash和PNG尺寸；最终仍由现有构建脚本内嵌，保证HTML离线运行。
- 扩展Page索引与Runtime校验，固定远程资产边界并拦截旧版拆分运行时和固定模板依赖。本次不修改
  Workflow、组件、Token、Figma映射、H5 CSS或组件运行时；完成校验并打包发布v4.5.22。

## v4.5.21 — 2026-09-14 · 三种页面能力路由与工作流按需拆分

- 页面任务统一按 `Create / Local Edit / H5 Migration` 三种能力判断：从0到1或整体重设计使用Create；
  基于原图、Figma或H5只修改点名内容使用Local Edit；既有可编辑H5在指定范围内整体符合9.0时使用
  H5 Migration。能力名称只用于内部路由，不要求用户先选择模式或填写固定PageSpec。
- Local Edit的原图保护、授权区域与维度、Color-only限制继续保留在公共 `workflow.md`，保证任何页面任务
  都先判断边界；不新增 `local-edit.md`，避免规则被按需读取机制跳过。
- `h5-migration.md`继续作为条件命中的专项流程；单个属性、单个组件、只读检查或仅要求输出H5不会误触发
  全面迁移。Page Pattern只服务Create完整页面或明确的整体重构，不因局部修改或迁移自动套用。
- 将原本集中在 `workflow.md` 的Figma页面写入和组件维护拆为 `figma-workflow.md` 与
  `component-maintenance.md`，仅在对应任务发生时读取；普通H5产出不再加载两套重流程。
- 更新运行时校验，固定三种能力、Page读取边界和两个按需工作流的文件职责。本次不修改组件视觉、Token、
  Figma Key、H5 CSS或运行时行为；当前为未打包工作版。

## v4.5.20 — 2026-09-11 · 既有H5合规迁移与Task Sheet正式化

- 页面修改不再强制命名为`New / Incremental`或填写固定PageSpec：已有页面直接以用户明确指定的页面、
  区域和维度为边界，只有范围复杂、含糊或可能牵连锁定区域时才按需列出边界确认。
- 新增按需读取的`references/h5-migration.md`。只有“可编辑既有H5 + 明确修改动作 + 指定范围整体符合9.0”
  同时成立时进入专项合规迁移；只读审查、H5交付格式和单属性修改不会自动扩大为全页迁移。
- 合规迁移新增模块盘点、正式组件替换、业务锁定、状态覆盖和迁移覆盖率验收；“保持现有格式”保留
  交付形式、业务内容和信息结构，不保护与9.0冲突的私有DOM或旧样式。
- `Task Sheet / Shell`完成四种结构状态视觉确认，`<v9-task-sheet>`由`pending`升级为正式
  `component`；正式组件总数由37增至38，Figma Set Key、H5属性、Slot、自动行数与间距合同不变。
- Figma已发布Set仍可搜索到旧的12px与12/24 Description，记录为源描述元数据漂移；正式合同继续以
  当前实例几何、确认后的16px及20/16px光学补偿为准。本次不修改Token、组件视觉或Page Pattern。

## v4.5.19-candidate — 2026-09-11 · Task Sheet / Shell 全状态候选

- 新增任务型底部容器 `Task Sheet / Shell` 候选合同：仅在地图、相机、扫描、轨迹等主场景需持续可见，
  且底部承载依附主场景的持续任务时命中；普通信息卡、一次性菜单、纯提交Footer与长表单不使用。
- 固化Figma源 `202:2121` 的两种 `Content Boundary`、可选Action及三个实例Slot；H5新增
  `<v9-task-sheet>`，通过 `Single / Multiline × Show Action true / false` 覆盖四个结构状态。
- 固化容器375px、顶部圆角30px、Level 4、四周主内容20px、Header→Content 16px；Single与
  Multiline分别使用20/16px Content→Action、10/8px标题→说明，以实际渲染行数做光学补偿。
- Task Sheet上下文中Cardheader标题使用20px，CardContent标题使用16px Medium与`#444444`；
  通用Cardheader与CardContent默认值不随之升级。麦克风等辅助能力仍作为Content Slot内Pattern，
  可使用正式CardContent Subtle分层，不增加Shell业务变体。
- 组件身份保持`pending`；Figma源Description残留“Header→Content 12px”列为转正式前维护项。
  本轮不修改Token、Workflow或Page Pattern文件，仅在Page索引增加Task Sheet优先路由提示。

## v4.5.18 — 2026-09-09 · Focused Form Page Agreement 双模式布局

- Focused Form Page的Agreement新增 `Content Bottom / Combined Fixed` 两种页面组合状态：首屏可容纳时
  位于内容区域底部并与按钮操作区分离；实际内容超出首屏时，与Action Button Group组成固定底部操作区。
- H5必须根据实际渲染高度判断模式，并在错误、折行、字段显隐、异步内容、字体加载或视口变化后重新测量；
  不得按字段数量或预估文案长度写死。
- 固化375px基准画布的单通栏主按钮组合区：顶部12px、Agreement 42px、间距12px、按钮50px、
  底部20px，共136px；Home Indicator 34px另计。其他按钮布局和Agreement折行按实际高度自然增高。
- Combined Fixed的正文滚动区必须预留组合区实际高度，确保最后一个字段、错误信息和说明可完整滚动到
  固定区上方。本次只更新Page Pattern与变更记录，不修改Agreement组件、Workflow、Token、H5 Runtime
  或Figma映射，尚未打包新版Skill。

## v4.5.17 — 2026-09-07 · 增量任务边界、反馈选型与多协议Agreement

- 页面产出增加 `New / Incremental` 任务模式；增量PageSpec必须记录基准页面、允许修改区域与维度、
  锁定范围和目标页面范围。仅允许Color时，不得连带修改布局、字号、间距、圆角、文案、组件结构或交互。
- 新增增量截图保护脚本：按允许区域比较同尺寸PNG，禁止锁定区域出现未声明像素变化，并可输出差异图。
- CardContent补充辅助入口的可观察选型条件；表单体系新增Form Item Error、Toast、Dialog之间的反馈选择规则，
  避免把可定位字段错误升级为页面级Toast。
- Agreement H5运行时由只识别一个 `《协议名称》` 修复为逐段识别全部协议名称；多协议支持自然折行，
  每个名称均使用Primary高亮，当前多个名称继续共用一个 `href`。
- 同步扩展H5 Runtime自动验证；本次不修改 `custom-rules.md`、Token、Figma组件、Figma映射或Page Pattern，
  尚未打包新版Skill。

## v4.5.16 — 2026-09-07 · Page Pattern 命中门槛与结构韧性

- 将Page Pattern从“关键词和正向信号匹配”收紧为四项硬门槛：任务匹配、最小有效内容、操作关系、
  结构韧性；任一项不通过时不再选择最接近的Page。
- 在Page索引新增删除测试、直接否决信号与“完整命中 / 部分命中 / 重复后沉淀”三档结果；部分命中
  默认使用正式组件、Token与页面本地布局自由组合，不补造PRD内容。
- 为Focused Form Page新增最小有效内容合同，明确排除纯启动/进入入口、“标题 + 短说明 + CTA”、
  操作不依赖正文以及依赖大面积空白维持版式的场景。
- 新增未命中回退、最少/常规/最多内容及短/基准/长视口验收，并将任务性质、操作依赖、相邻状态
  纳入PageSpec；未修改Token、正式组件、Figma映射或H5 Runtime。

## v4.5.15 — 2026-09-04 · Appbar None black 与 Form Mode 局部规则修正

- 修复H5运行时将 `None black` 错误继承为白色背景的问题；该变体现在固定为透明背景、黑色状态栏资产和
  黑色返回资产，适用于浅色背景图或 `background/Focus` 之上的无标题导航。
- 同步更新组件合同、Figma↔H5映射和运行时静态回归检查；调用方式仍为
  `<v9-appbar type="none-black" show-back>`，未新增变体、Token或Component Key。
- CellCard / Form Mode内部Cardheader副标题由14px改为Body Small 12px，单行12px、实际折行18px；
  主副标题间距由10px改为12px。通用Cardheader继续保持14px副标题与10px间距，未新增Cardheader变体。
- Form Mode的Cardheader到Form Item Group间距由4px改为8px；同步更新组件合同、Figma映射说明、
  H5上下文覆盖与运行时回归检查。
- 完成Token构建、Skill结构、H5 Runtime与页面验证后打包发布v4.5.15。

## v4.5.14 — 2026-09-03 · Page Pattern层与Focused Form Page

- 新增根目录 `pages/`：`_index.md`作为唯一轻量路由，按PageSpec只读取命中的Page文件；首个正式页面模式为
  `Focused Form Page`。Page Pattern不作为组件，不登记Figma Key或计入正式组件数量。
- 固化Focused Form Page的结构边界：Appbar支持多种正式形式且标题可选；Action Button Group支持
  Single、Inline、Stacked等正式形式，不限制为单按钮；Agreement可选。
- 固化页面关系：Appbar内容区结束到Page Title 20px、Title到Description 12px、Page Header到底部
  Main Content 32px；页面外边距保持全局12px，Page Header左侧28px并与卡片16px内边距后的内容轴对齐。
- 新增 `--v9-fz-headline-xl` 26px Token及Headline Extra Large 26/26、换行26/39规则，限定用于
  Page Pattern中的任务型页面标题；新增 `--v9-space-3xl` 32px以承载Page Header到Main Content的
  稳定大结构间距。
- `SKILL.md`增加Page按需读取入口；不修改Workflow，不复制组件合同；完成构建与验证后打包发布v4.5.14。

## v4.5.13 — 2026-09-03 · Page Background 与 Agreement 更新

- 在 `components.md` 集中新增Default、Focus、Immersive三种Page Background模式及选型规则；
  不新增 `backgrounds.md`，不把背景选型写入Workflow。
- 新增正式 `<v9-background-focus>`，映射主规范库 `background/Focus`（Node `175:3045`，
  Component Key `f422b4ea2accd5a8c0c6e8ef715a793ef3be9c69`），固化370px高度和确认后的Atmosphere SVG。
- Default继续使用页面Canvas底色；Immersive固化为全页180°渐变，二者均为页面样式，不计正式组件。
- Agreement从18/18更新为Body Medium 14/14；checked/unchecked自动高亮 `《协议名称》`，
  同步组件合同、Figma映射、H5 Runtime与自动验证。
- 身份更新为40个可运行自定义元素、37个双端正式组件；本次仅更新工作目录，未打包新版Skill。

## v4.5.12 — 2026-09-02 · Form Item 体系正式接入

- 回读主规范库已发布的 Form Item / Textual、Form Item / Control、Form Item Group 与
  CellCard / Form Mode；新增 `<v9-form-item>`、`<v9-form-item-group>`、`<v9-form-card>` 三个正式H5标签，
  身份更新为39个可运行自定义元素、36个双端正式组件。
- H5使用一个 `<v9-form-item>` 统一 `input/select/radio/checkbox`；映射到Figma时按 `interaction`
  分流到Textual或Control Set，保留两个源组件的真实变体与依赖。
- 固化Default/Error/Disabled、Empty/Filled、Checked、标题与Info 4px、标题区与内容最小20px、
  Input普通行14px、Select/Control普通行18px、Error间距12px与28px横向拉伸错误条；不接入Focus或Readonly。
- 新增任意数量、0间距且无外层Padding的Form Item Group；新增Header可选的CellCard / Form Mode，
  Header存在时与Group间距4px，Header关闭时不保留空白。具体选型只在组件合同维护，Workflow只保留通用选组件步骤；更新Figma映射、
  H5 Runtime与自动验证。全状态H5经用户确认后列入正式组件，并打包发布v4.5.12。

## v4.5.11 — 2026-08-26 · Pill Option 正式接入

- 回读主规范库已发布的 Pill Option、Select Group、Action Group 与 Horizontal Scroll Frame，新增
  `<v9-pill-option>` 和 `<v9-pill-option-group>` 两个正式H5标签；身份更新为36个自定义元素、
  33个双端正式组件。
- 固化 State × Context × Icon 8种单项状态、Required/Optional选择逻辑、Action即时操作、8px固定间距、
  超过4项单行横滑，以及纯白背景未选中态0.5px Outline规则。
- 默认Icon使用组件私有灰块占位，同时保留业务Icon Slot；未新增全局Token。旧
  `Pill Option Group / Legacy Amount Presets` 仅用于识别旧稿，不进入新页面映射。
- 更新组件合同、Figma映射、Workflow选型入口、H5 Runtime与自动验证，并打包为v4.5.11。

## v4.5.10 — 2026-08-26 · Tabs Card 正式接入

- 回读主规范库已发布 Tabs Set（Node `53:3106`，Set Key
  `ec3d82f380eef9aec11505f2617113f19fb82427`），正式接入Card的2项/3项、共5个状态；Line继续使用旧源，
  Rounded仍不接入。
- 扩展正式 `<v9-tabs>`：新增 `variant=card`、`panel-1/2/3`命名Slot、点击与键盘切换、
  `v9-change.detail.active`、ARIA选中关系，以及按所有面板实际最大高度自动统一容器高度。
- Card固定351px宽、43px Header、Noto Sans SC Medium 16/16等宽单行标签、16px Content Padding；
  全部Active状态统一Level 1阴影。Node `31:5168` 的三段超长文案作为省略极限测试，不新增变体。
- 固化Figma导出的Tabs曲面SVG资产，更新组件合同、Figma映射、Workflow与Runtime验证；
  复用既有Token，不新增Token。`v9-tabs`本身已是正式元素，因此身份数量仍为34个元素、31个双端正式组件。

## v4.5.9 — 2026-08-21 · Entry Item / Entry Group 正式接入

- 接入主规范库已发布的Entry Item（26变体，Set Key
  `b3a6aadac84920a3275e0abe8c484f25febab0c9`）与Entry Group（30变体，Set Key
  `92e4ea0fe8817c2103b977f0e8833f14ac18cd0e`），同步组件合同、直接依赖、Figma映射与H5运行时。
- 新增 `<v9-entry-item>` 与 `<v9-entry-group>`，实现Horizontal/Vertical、Pure/Subtle、
  30/40/50占位块、Whole Item/Trailing Button、List与Grid 2/3/4/5；自定义元素更新为34个，
  双端正式组件更新为31个。
- Entry Item默认视觉为色块占位，不新增图标资产；Subtle占位色 `#E4E8EC` 仅作为组件私有值，
  不进入全局Token。Entry Group同步A/B/C选型、非法Count和发布变体边界验证。
- 修正Entry Item Vertical在Whole Item按钮语义下被通用左对齐覆盖的问题；Icon、标题与说明现在显式
  共享水平中轴线并居中，Horizontal保持原左对齐。
- 主规范库CardContent当前仍有10个变体并保留Media Medium，因此本次不执行CardContent迁移；
  待Figma删除并重新发布后再同步Skill。本次完成运行时、映射、文档与H5验收后发布为v4.5.9。

## v4.5.8 发布同步 — 2026-08-19 · 最新9.0规范发布回读

- 回读主规范库 `KKuaHEUNwnenHwumr4a3Ta` 的最新发布结果，更新 Button、Action Button Group、
  Cardheader、CardContent、Alert、TextLink、ExpandLink、arrow、tag、StatusOverlay、Selection Control、
  Agreement、Dialog、Toast、CellCard / Shell、Address Group 与 Empty 的当前 Node、Component Key和公开属性。
- Dialog 已由 `CHANGED/pending` 升级为 `CURRENT/component`；当前32个自定义元素中有29个双端正式组件、
  1个primitive与2个internal。Dialog H5继续按实际行数自动选择标题↔正文16/10px，Figma主件暂固定10px。
- Alert 同步为 Default 42px、Small Link 42px、Small Pure 36px；Empty 同步为100×126px、插图↔文案12px、
  `Text#67:15`直接属性。Address Group保留16px两行间距，并记录Figma裁切不带省略号、H5保留省略。
- 全局Body字阶同步为16/14/12px，Level 4阴影同步为`0 -12px 32px / 8%`；14px组件局部合同重新绑定
  Body Medium，避免Body Large更新后误放大。
- 经用户确认，完成4.5.8工作源构建与验证，并生成新版Skill压缩包及全状态组件H5。

## v4.5.8 — 2026-08-19 · 组件间距、Agreement 与 Dialog 对齐校正

- Agreement `detail` 补齐18px灰色右箭头，文字与箭头保持2px间距并合并为同一18px高链接；
  checked / unchecked 的 Selection Control 与文案结构不变。
- Dialog 将内容、Agreement 与 Action Button Group 收入同一白色面板，面板下内边距改为20px，
  操作区宽335px；标题与正文均为实际单行时使用16px间距，否则10px。
- Dialog 取消无按钮组合：`Button#8:43` 必须为true，H5缺少有效actions时拒绝打开并派发
  `v9-invalid(reason=missing-actions)`。2026-08-19回读Figma源仍为`CHANGED`，因此运行时已更新但身份继续
  保持`pending`，待再次发布为`CURRENT`后再升级。
- Address Group 的 Default / Large 启点↔终点两行间距由8px调整为16px，复用既有
  `space/space/lg`；圆点、行内间距、字号、颜色和截断合同不变。
- ExpandLink 的L/M/S统一使用Arrow L / 18px，并为文字和宿主建立明确的18px中心对齐行盒。
- Number单位保持2px横向间距，XL/L向上2px、M/S向上1px；Metric Item复用对应Number Size，
  名称↔DataValue统一6px，使独立Number与Metric Item的数字/单位高度关系一致。
- CardContent标题↔默认描述改为10px、标题↔错误描述改为8px；CardHeader无副标题时标题、Tag、操作
  中心对齐，有副标题时操作与标题行顶部对齐；CellCard Header↔Content改为12px。
- 同步组件合同、Figma↔H5实现映射、最高优先级自定义规则、Workflow与运行时回归验证；未新增Token、
  组件Key或变体。
- 合并此前v4.5.7分支中4.5.8缺失的行为能力：Appbar恢复冒泡的`v9-back`事件；自包含构建器恢复
  经典`defer`脚本的`DOMContentLoaded`执行时序；多状态页面恢复画布外预览控制器合同及页面级、
  交付级验证。组件视觉样式继续以本版已确认结果为准。
- 完成运行时、页面、附件构建与Skill结构验证后重新打包v4.5.8，并保留合并前压缩包备份。
- 调整页面产出与组件维护职责：普通H5任务改为信任已发布Skill并直接选择`<v9-*>`，不再在出图前
  全量打开Figma规范库或制作Figma映射表；当前页面映射表只在按需Figma分支生成，规范库全量对比、
  组合组件直接依赖审计及Key/属性漂移修复统一移入组件维护事务。未修改组件样式、Token或运行时行为。

## v4.5.7 — 2026-08-19 · Appbar、Agreement 与 Alert 样式修正

- Appbar 全部8种类型取消底部灰色分割线与 inner shadow；页面层不得重新补线。
- Text / Text white 右侧“操作”统一为无下划线纯文字，保持16px单行行高与既有主题色。
- Icon Action 默认增加40×40黑色返回按钮，继续复用正式 `back-black.svg` 资产；显式
  `show-back="false"` 时仍可隐藏。
- Agreement 将 Selection Control 宿主与18/18文案固定为中心对齐视觉盒，消除内联行盒造成的偏移。
- Alert 按 Figma 12个正式变体恢复375/355px宽度、44/42/41px高度、12px圆角、类型色与默认显隐；
  左侧信息/警告图标和右侧类型箭头改用4个Figma原始SVG，不再输出字符 `i` / `!` 或灰色通用箭头。
- 同步组件合同、Figma↔H5实现映射、Workflow错误清单与运行时回归验证；未修改Token、组件Key或
  变体数量。

## v4.5.6 — 2026-08-18 · 按实际行数统一行高与组件间距

- 文字规则调整为按实际渲染行数判断：单行行高等于字号，多行行高等于字号×1.5；H5运行时通过
  实际布局测量切换，不再按文案长度猜测。同步Button、Appbar、TextLink、Tag、Agreement、Alert、
  Address、CardHeader、CardContent、Tabs、Metric Item与StatusOverlay的适用文字规格。
- 同步最新组件值：CardHeader标题↔Tag 8px、标题行↔副标题10px；CardContent Editorial 12px、
  Floating 8/4px、List 16px、Media 12/8px；Tabs上12px、下2px、文字↔Indicator 8px；Metric XL
  名称↔数值8px，XL/L/S数值↔Trend 9px（M为8px）。
- Action Button Group继续保持Fill、透明与`padding:0`；只有进入吸底`v9-footer`时才由外层提供
  上下20px、左右12px，普通页面流、CellCard Footer与Dialog不再误加20px。
- 同步组件合同、Figma映射、Workflow与运行时回归验证；保留v4.5.5的自包含HTML与源码ZIP双附件能力。

## v4.5.5 — 2026-08-17 · 自包含 HTML + 完整源码 ZIP 双附件交付

- 默认设计交付从本地H5地址调整为同名双附件：自包含单文件HTML用于对话内预览及下载后双击运行，
  完整ZIP保留预览文件、组件化源码、H5运行时、Token和全部离线组件资产。
- 新增`build-h5-deliverables.mjs`：从验证通过的组件化工程确定性内联页面CSS/JS、V9核心样式、
  Shadow DOM资源和本地图片/SVG，并以纯Node实现生成离线源码ZIP。
- 新增`validate-h5-deliverables.mjs`：拦截`127.0.0.1`、`localhost`、`file:///`、外部资源和项目外依赖，
  核对HTML组件运行时及ZIP源码/资产完整性。
- 更新SKILL入口、H5工作流、交付清单、错误清单和运行时回归验证；公开HTTPS与Figma仍为按需追加。
  本次不修改组件视觉、Figma映射、Token、Variable、`v9-core.css`或`v9-components.js`。

## v4.5.4 — 2026-08-14 · Badge 数字内边距与附着几何

- 数字型`count`与`overflow`改为左2px、右4px内边距，上下继续保留各1px的H5字形校正；
  中文`label-new`仍为左右4px、上下2px，Dot保持不变。
- “文字 + Badge”组合的可见边界关系调整为向左重叠文字2px、顶部高于24px文字行盒2px。
- 同步组件合同、Figma↔H5实现补偿说明、独立展示页和回归验证；全部复用既有2XS/XS Token，未新增Token。

## v4.5.3 — 2026-08-14 · Badge 宿主边界与文字附着关系

- 对照Figma Badge（Node `1:1536`）复核4种变体；颜色、尺寸、字体、内边距和圆角合同保持不变，
  count/overflow继续保留数字下移1px的H5光学校正。
- 修正`<v9-badge>`宿主继承父级文字行高造成的额外垂直空间，使宿主边界与14/24/18/10px可见变体边界一致。
- 补充文字右上角附着规则：Badge可见边界向左重叠文字2px、向上5px；该关系属于正式Tabs与Badge的
  页面组合，不虚构Tabs的Badge属性或Figma Slot。同步映射与运行时回归验证，未新增Token。

## v4.5.2 — 2026-08-14 · Tabs 文字行盒与 Indicator 分层

- 修正Tabs文字被16px固定行高压缩的问题：16px文字恢复24px正常行高，文字层高度与完整行盒一致。
- 将Item内部结构调整为24px文字层 + 2px间隔 + 4px独立Indicator层；未选中项同样保留Indicator层，
  避免切换状态时文字位置发生变化。组件总高375×42px及上8px、下4px、左右8px Padding保持不变。
- H5运行时新增明确的label与indicator内部节点，取消伪元素绝对定位；同步组件合同、Figma映射和回归验证。
  2px继续复用既有2XS Token，未新增Token。

## v4.5.1 — 2026-08-13 · Tabs Line 对齐修正

- 对照最新Figma `Tabs`（Node `1:1184`）修正Line变体：选中线从错误的 `bottom:-4px` 改为
  Item底部 `bottom:0`，恢复源组件要求的4px容器底部留白。
- H5 Shadow DOM 将 `.v9-tabs__item` 的 `font:inherit` 改为只继承字体家族，避免覆盖组件固定的
  16px字号与100%行高；选中/未选中字重和颜色规则保持不变。
- 更新Tabs组件合同、Figma↔H5几何映射与运行时回归验证；Rounded仍按既定范围暂不接入，未修改Token。

## v4.5.0 — 2026-08-13 · 最新9.0组件库迁移

- 将组件主来源切换到最新 `9.0规范`（fileKey `KKuaHEUNwnenHwumr4a3Ta`），逐项回读并更新
  Component / Component Set Key、Node、公开属性、直接依赖和 H5 显式映射；已发布且双端齐全的
  Address Group、Empty 升级为 `kind=component`，正式双端组件数更新为28。
- Action Button Group 按新源改为 Fill、透明、无内边距，保留10px内部间距；Secondary 保持162.5px
  Subtle右对齐。常规 Button 同步100/88/88px固定宽度，Alert补齐 action、position、图标/按钮显隐和
  操作事件映射。
- Dialog 切换到最新 Key 与 `#8:*` 属性名，但源组件回读仍为 `CHANGED`，因此如实保留
  `kind=pending`，未提前宣称完成发布。
- Tabs 按本次范围明确排除最新 Rounded 组件；H5运行时、规范与映射继续使用旧源 Line Tabs，未新增
  Rounded 属性、样式或 Key。未修改 Token、Variable 或生成值。
- 更新组件规范、Figma映射、Workflow、H5 CSS/运行时和一致性验证；新增当前主源、组件身份、
  Action Group容器合同、Button固定尺寸、Alert公开能力及 Rounded 排除项的回归检查。

## v4.4.15 — 2026-08-13 · Tag 宿主行盒修正

- 保留 `<v9-tag>` 公开 Web Component 宿主与 Shadow DOM 内部 `.v9-tag` 视觉节点的两层职责，不把组件
  退回页面手写 `span`。
- Tag 宿主改用 `inline-flex`、`line-height:0` 与 `vertical-align:middle`，消除继承父级16/24px行盒造成的
  额外2px高度；宿主尺寸、视觉边界与点击区域现在一致。
- 更新 Tag 组件合同、Figma边界映射和运行时回归验证；未修改Token、Figma变体、组件属性或内部视觉尺寸。

## v4.4.14 — 2026-08-11 · Empty 父容器尺寸来源约束

- 明确 Empty 与父容器的尺寸边界：`<v9-empty>` 始终保持100×128px；居中辅助容器默认只负责
  `display:grid` 与 `place-items:center`，不得自行增加固定 `height`、`min-height` 或额外Padding。
- 空状态区域的固定高度只有在 PRD、Figma 画板或正式组件合同明确给出时才允许设置；无来源时由
  Card Content Slot、列表可用区、剩余视口或父级布局自然提供。319×224px等页面结果不升级为组件规格。
- Workflow补充出图前未定义项确认、H5/Figma本地组合尺寸来源检查、交付自查和专属错误修复规则；
  Runtime验证新增文档合同防回退检查。未修改Token、Figma映射、H5组件DOM、CSS或固定资产。

## v4.4.13 — 2026-08-11 · Empty 单一 SVG 资产

- Empty固定插图由 `illustration.png` + `mask.svg` 收敛为单一
  `assets/components/empty/illustration.svg`；100×100px可见裁切封装在SVG内部，运行时不再加载独立mask。
- 更新 `<v9-empty>` 运行时和CSS，删除页面层裁切与mask依赖；组件公开属性、尺寸、8px图文间距、
  Figma Component Key和双端身份均未变化。
- 更新组件合同、Figma映射、Workflow与两类H5验证：单一SVG缺失或旧PNG/mask残留均直接失败；
  未新增Token、Variable或组件变体。

## v4.4.12 — 2026-08-11 · Empty 页面级组件调用门槛

- Empty组件合同明确禁止使用 `.empty-state`、普通`div`、文字加Padding或背景模拟空状态；页面必须
  真实调用 `<v9-empty>`，白色Surface继续由父级CellCard / Shell提供。
- 新增 `scripts/validate-h5-page.mjs`：扫描H5交付项目，发现空状态文案却未调用组件、存在
  `.empty-state`手工替代、缺少 `v9-core.css` / `v9-components.js` 或Empty源资产时直接失败。
- Workflow新增最终DOM验收：核对 `<v9-empty>`、Shadow DOM插图节点、图片加载状态与私有替代节点；
  明确组件库运行时验证不能替代页面级组件调用验证。
- 更新SKILL索引和H5自查入口，并把页面验证器纳入Skill自身一致性检查；未修改Token、Figma组件或映射。

## v4.4.11 — 2026-08-11 · StatusOverlay 正式图标资产与几何验证

- 将Figma StatusOverlay Node `1026:3723` 导出的 `success.svg`、`failed.svg` 纳入Skill固定资产；
  `<v9-status-overlay>` 改为按状态直接加载正式SVG，不再用运行时内联路径近似绘制。
- 运行时宿主固定35px高并贴合媒体框底部；进入CardContent Media Large的85px媒体宽度后，
  StatusOverlay最终结果为85×35px，左右和底部间距均为0，不新增尺寸变体或Token。
- 更新StatusOverlay组件合同、Figma映射和验证脚本；验证新增正式资产存在性、运行时资产绑定、
  内联路径禁用、35px高度与85×35px组合条件检查。

## v4.4.10 — 2026-08-11 · Empty 间距与卡片容器归属修正

- 按Figma当前源把Empty同步为100×128px：插图保持100×100px，图形与文字固定8px并复用
  `--v9-space-sm`；未新增Token、Variable、Text Style、变体或资产。
- 明确Empty自身不包含Surface。需要白色卡片时，由正式CellCard / Shell的Content Slot提供白底、
  16px Padding、16px圆角和阴影，再在Slot内居中Empty；父区域已有Surface时不重复嵌套Card。
- Figma Node `2173:1095` 当前发布状态为 `CHANGED`；H5封装与显式映射已同步，但重新发布并回读为
  `CURRENT` 前，`<v9-empty>` 如实登记为 `pending`。身份审计调整为26个component、3个pending。
- 同步更新组件规范、Figma映射、H5 CSS/运行时、Workflow验收、验证脚本与拍照质检H5空状态页面。

## v4.4.9 — 2026-08-11 · Empty 空状态双端组件

- 接入Figma正式Empty组件：Node `2173:1095`，Component Key
  `ca289fdd5dc6ad38a72f1d272f888af8fde83964`，发布状态 `CURRENT`；源组件为100×138px单一Component，
  只暴露 `Text#2173:0` 文本属性。
- 新增可直接调用的 `<v9-empty text="…">`，固定复用Figma导出的插图和遮罩资产；文本使用既有14px正文
  Token与 `--v9-text-secondary`，未新增Token、Variable、Text Style或变体。
- 新增 `.v9-empty-container` 布局辅助类；明确空状态组件只负责插图与文案，父容器负责水平、垂直居中，
  居中关系不得登记为Empty Variant，辅助类不得冒充正式组件。
- H5运行时将自身URL的版本查询参数同步给Shadow DOM内引用的 `v9-core.css`，避免组件脚本已更新但
  内部仍命中旧CSS缓存；该修正不改变组件公开属性或Token。
- 更新 `components.md`、`v9-figma-map.md`、`workflow.md`、H5 CSS/运行时与验证脚本；正式双端组件数
  从26增至27，可运行自定义元素从31增至32。

## v4.4.8 — 2026-08-10 · PRD 内容归属与 CardContent 描述承载

- Workflow只新增通用执行判断：PRD列表、编号和分点不直接等于多个UI节点；创建页面本地节点前，
  必须先检查现有组件公开属性、状态、Slot与嵌套，不写入CardContent专属条件。
- CardContent组件合同新增同一业务对象多条原因的承载规则：无独立操作、状态或图标时统一写入一个
  `description`并保留换行，不在组件外另建原因区、列表或多个重复段落。
- `<v9-cardcontent>` 新增 `description-tone=default|error`；Error复用既有`--v9-error`，多行文本使用
  `white-space:pre-line`，未新增Token、Figma Variant或Component Key。
- Figma映射明确多条说明仍写入同一DescriptionText；Error作为现有描述文字的颜色覆盖回读，
  不创建新变体或外置TEXT节点。
- 修正Cardheader Expand对齐：按钮显式使用中文字体、24px固定行盒，14px / 21px文字与18px Arrow L
  垂直居中；删除浏览器默认Arial和内联基线对齐的不确定性。
- 同步更新组件规范、双端映射、H5 CSS/运行时、Workflow验收与运行时验证脚本。

## v4.4.7 — 2026-08-10 · CardContent Media 默认占位与合法变体修正

- 修正 `components.md` 将 Media Large 错写为 `Action=Floating` 的冲突说明；当前发布的 Media
  Medium / Large 统一使用 `Action=None`，H5运行时对List与Media误传的Floating自动归一化为None。
- `<v9-cardcontent layout="media">` 在没有 `media-src` 时仍渲染既有尺寸的灰色媒体占位框，背景复用
  `--v9-surface-inset`，且不创建 `<img>`、不填充示例图片；只有显式传入业务图片时才渲染图片节点。
- CardContent验证页的4个Media变体移除示例图片填充，直接展示默认灰色占位；StatusOverlay继续通过
  `media-overlay`命名Slot叠加，不使用页面私有图片框。
- 同步更新CardContent组件合同、Figma映射、PRD选型与H5错误清单、运行时验证脚本；未新增Token、
  Variable、Component Key或固定图片资产。

## v4.4.6 — 2026-08-10 · CellCard 状态分层与 Cardheader Set 导入

- 明确 CellCard / Shell 的8个变体只控制 Header、Content、Footer Region 与 Slot；Cardheader、
  CardContent 和 Footer 正式组件分别维护自身状态，不得提升为 Shell Variant 或生成笛卡尔积组合。
- 工作流新增组合组件“全部状态”分层核对：外层合法变体、结构/显隐属性与 Slot、父组件明确暴露的
  嵌套状态、关键交互和可访问状态；保留既有业务状态矩阵，两者职责不混用。
- 只读回读确认 Cardheader Component Set Key `8778e924ba8176734e13ff29d1700f08ad8ddfa4`
  为 `CURRENT`、包含8个变体，且可通过 `importComponentSetByKeyAsync` 导入；删除旧的失效 Set Key
  与按单变体导入记录。
- 验车拍照页 Footer 间距与319px Fill、Cardheader TextLink M / Secondary、历史任务 CardContent
  Media + StatusOverlay、未完成状态矩阵等 Agent 实现问题继续沿用 v4.4.3–v4.4.5 已完成修复。
- 本次不修改 Token、Variable、H5 CSS/运行时、固定资产、`custom-rules.md` 或运行时验证脚本。

## v4.4.5 — 2026-08-10 · CellCard 子组件全状态与 CardContent Action

- CellCard H5验证页在Shell的8种Region组合之外，新增Cardheader 8个发布变体、ShowSubtitle显隐、
  CardContent 10个真实发布变体，以及标题、描述、Floating Button三个可见性属性示例。
- Cardheader Expand依赖的Arrow由S修正为L / 18px，与当前Figma源和Link操作保持一致。
- `<v9-cardcontent>` 补齐 `action=none|floating`、Floating Button文案与显隐、标题/描述显隐、
  List两行内容属性；Media继续复用现有图片框与StatusOverlay Slot。
- 映射明确只允许Figma源中存在的10个CardContent组合，不对Surface、Layout、Media size、Action
  做不存在的全排列；同步更新组件规范、Figma映射和运行时验证脚本。
- 下载Figma源媒体示例到H5验证页本地资产；未新增Token、Variable或Component Key，未打包Skill。

## v4.4.4 — 2026-08-10 · Card 隐藏 Region 间距修正

- 修正仅有Header + Footer时16px间距未生效的问题：Card DOM固定保留隐藏的Content Region，旧相邻兄弟
  选择器 `Header + Footer` 因中间仍存在Content节点而无法命中；运行时与兼容CSS改用可跨越隐藏Region的
  `Header ~ Footer`，同时保留Content + Footer的16px规则。
- 验证脚本新增无Content的Header + Footer选择器回归检查，并明确禁止重新使用依赖DOM相邻的旧实现。
- 本次只修正Card Shell的H5布局实现与验证；组件合同、Token、Figma Key、Variable、资产、
  `SKILL.md`、`custom-rules.md`均未变化。

## v4.4.3 — 2026-08-10 · Card Footer、Header Link 与历史任务状态合同

- Button Full-width 的H5宿主由固定335px改为Fill父级可用宽度：在Action Button Group中仍为335px，
  进入351px CellCard的319px Footer内容区时改为319px，恢复卡片右侧16px Padding；按钮高度、圆角、
  视觉类型与状态保持不变。
- 固化验车拍照卡片的操作区关系：Header + Footer或Content + Footer均由CellCard提供16px结构间距，
  不再通过按钮自身 `margin-top` 实现，避免重复叠加。
- Cardheader `Actiontype=Link` 的H5内部改为直接调用TextLink M / Secondary，继承18px Arrow L和
  22px对称行盒，删除旧的独立14px链接文字 + S Arrow拼装。
- CardContent H5补齐 `media-size=none|medium|large` 与 `media-overlay` 命名Slot；图片与状态统一通过
  CardContent Media + StatusOverlay复用，不再需要页面私有 `.photo-frame`。
- 页面工作流新增多状态/可展开内容状态矩阵，要求“可展开、默认展开、展开内容、StatusOverlay、
  失败原因、操作入口”分别确认和实现；禁止根据Overlay、Tag或失败原因是否存在推断展开能力。
- 同步更新 `components.md`、`v9-figma-map.md`、`workflow.md`、H5 CSS/运行时和验证脚本；
  未修改 `SKILL.md`、`custom-rules.md`、Token、Figma Component Key、Variable或固定资产。

## v4.4.2 — 2026-08-05 · 单一组件化产出链路

- 将 `SKILL.md` 的出图流程、任务路由与组件维护入口合并为“执行框架”：默认从 PRD 产出
  正确调用 `<v9-*>` 的组件化 H5，通过自查后才按需映射到 Figma。
- 删除独立“H5 运行入口”和快速决策树；CSS/JS 加载并入 PRD→H5 阶段，其他细节继续以
  `components.md` 与 `workflow.md` 为准。
- 将全局门槛压缩为 Token 唯一源、正式组件三项条件、H5 调用边界、页面本地组合、
  Figma 真实实例与文件职责六条；详细检查项保留在按需读取的 reference 中。
- 从 `SKILL.md`、`workflow.md` 和 `v9-figma-map.md` 移除“方式一/方式二”与 Figma 预览旁路；
  Figma 产物只允许按双端映射导入真实组件实例。
- 本次未修改 Token、Figma Component Key、H5 CSS/运行时、组件资产或视觉行为。

## v4.4.1 — 2026-08-05 · H5 路由与执行边界拆分

- 将 `SKILL.md` 的“任务路由”改为“任务类型与必读文件”，该区域只负责指明 H5、
  Figma 和组件维护任务所需加载的参考文件。
- 新增独立“H5 运行入口”，集中声明 `v9-core.css` 与 `v9-components.js` 的引入及职责。
- 将直接调用 `<v9-*>`、页面只传内容/属性/Slot、禁止复制内部 DOM 归入“核心门槛”；
  同时将 Figma 真实实例与页面本地组合边界从任务路由中移出。
- 精简“PRD → H5 → Figma”中重复的文件路由和运行时规则；本次未修改 Token、Figma 组件、
  H5 CSS/运行时、双端映射或视觉行为。

## v4.4 — 2026-08-05 · Skill 路由与组件维护工作流归位

- 精简 `SKILL.md`：移除 H5/Figma 具体实现步骤和长篇组件更新约定，只保留任务路由、规则优先级、
  Token 单一来源、正式组件三项门槛和页面本地组合边界。
- 将组件新增/修改完整流程归入 `workflow.md` 的独立“组件维护事务”，覆盖源组件确认、直接依赖审计、
  Token 决策、文件职责、Figma/H5/映射实现、组件身份判定、构建验证、CHANGELOG 与打包。
- 补全 `SKILL.md` 资源索引，新增 `v9-tokens.css`、`tokens-tables.md`、`assets/components/` 与
  `scripts/validate-h5-runtime.mjs`，并标明生成文件禁止手改、固定资产按组件目录复用。
- 为超过100行的 `workflow.md` 增加目录，并明确组件合同、精确映射与执行步骤分别以
  `components.md`、`v9-figma-map.md`、`workflow.md` 为唯一来源，减少跨文件重复。
- 本次只调整 Skill 信息架构；未修改 Figma 组件、Component Key、Token、Variable、Text Style、
  H5 CSS、运行时、组件资产或任何视觉与交互行为。

## v4.3 — 2026-07-31 · Trend 与 TextLink 视觉合同收口

- `_Metric/Trend` 将可见数字拆为独立值节点，数字 Padding 固定为上1px、右5px、下2px、左0，
  方向图形继续保持14×15px，胶囊总高继续保持15px。
- Trend Up 背景调整为组件局部 `#D6FFEE`；该颜色只用于本组件，不新增 Token 或 Figma Variable。
  Down 继续保持既有 Error 方向色和浅色背景。
- TextLink 的 L / M / S 继续统一使用18px Arrow L；H5 外层改为22px对称行盒，复用2XS在上下各增加2px，
  让文字与箭头保持垂直居中，不再只在底部形成额外高度。
- 保留 v4.2.1 的 Trend 非中文拦截，并同步更新 `components.md`、`v9-figma-map.md`、H5 CSS/运行时
  与验证脚本。未修改 `SKILL.md`、Token、Figma Component Key、Text Style 或公开组件属性。

## v4.2.2 — 2026-07-31 · TextLink 固定 L 箭头

- TextLink 的 L / M / S 三种文字尺寸统一使用 Arrow `size=L`（18px）；`size` 只控制文字字号，
  不再把 L 映射为 M 箭头、M/S 映射为 S 箭头。
- 同步更新 H5 运行时、CSS 合同注释、`components.md`、`v9-figma-map.md` 与验证脚本；
  ExpandLink、Cardheader 的箭头规则保持不变。
- 未新增或修改 Token、Figma Variable、Text Style、组件 Key 与 TextLink 公开属性。

## v4.2.1 — 2026-07-31 · Trend 非中文内容约束

- Metric Trend 可见值明确不支持中文；`trend-value` 与 Figma `_Metric/Trend.Value#103:0`
  只接受数字、英文和必要符号。“环比”“同比”“上升”“下降”等中文说明必须移到 Trend 外部。
- H5 运行时增加中文检测：`trend-value` 含中文时不渲染整个 Trend，并同步取消组件级6px间距；
  不自动删字、翻译或输出半截内容。
- Figma 写入流程增加前置拦截与交付自查；含中文时停止写入并要求提供非中文值，写入后仍回读可见结果。
- 更新 `components.md`、`v9-figma-map.md`、`workflow.md` 与运行时验证脚本；未修改 Token、
  Figma Variable、Text Style、组件 Key 或视觉规格。

## v4.2 — 2026-07-31 · Toast 双端正式组件

- 接入 Figma `Toast.Icon`（Node `2036:1010`，Set Key `a158150c…`）与
  `Tooltip/Toast/none`（Node `2036:1030`，Component Key `041e301f…`）；两者均已有正式发布 Key。
- 清理 Toast 主组件中隐藏、未绑定属性且来自未发布旧集合的 `Component 10` 实例；可见结构与公开属性
  不变，直接依赖只保留正式 `Toast.Icon`。该无视觉变化的清理使 Figma 状态暂为 `CHANGED`，
  需要在 Figma 再执行一次 Publish 才会进入公共库版本。
- 新增可直接调用的 `<v9-toast-icon>`，支持 warning / success / error / loading 四种18px状态；
  新 `<v9-toast>` 支持 `open`、`text`、`icon-type`、`duration`，包含固定内部 DOM、源资产、
  loading旋转、自动关闭、`v9-close` 事件和 live region。
- Toast 视觉改为当前 Figma 源：#222语义背景、反白文字、PingFang SC Medium 16/16、
  上下12px/左右16px Padding、8px gap、8px圆角、最大188px、无阴影；删除旧14/21、
  #333、10×20px和Level 5阴影实现。
- 固化 warning / success / error 的 Figma 原始SVG；loading源SVG含 `foreignObject + conic-gradient`
  且在部分浏览器不可见，改用同一Figma变体直接导出的18×18透明PNG，不手绘近似图形。
- `<v9-toast>` 从 `h5-only` 升级为 `component`，新增 `<v9-toast-icon kind=component>`；
  `V9_COMPONENTS` 现登记30个元素，其中26个双端正式组件。
- 更新 `components.md`、`v9-figma-map.md`、`workflow.md`、`custom-rules.md`、`shadows.md`、
  H5 CSS/运行时、资产与验证脚本。Toast 临时规则已从 `custom-rules.md` 迁入正式组件规范。
- 没有新增 Token、Figma Variable 或 Text Style；只移除 `--v9-shadow-5` 元数据中的 Toast 用途，
  Token 数值保持不变。
- 新增 `toast-components-h5` 验证页，覆盖4种图标、5种Toast展示状态、2秒自动关闭、
  loading持续展示、调用方关闭、事件和可访问属性；浏览器实测通过。

## v4.1.1 — 2026-07-30 · 手动创建条件前置

- 将工作流阶段一的3.2改为自包含规则：只有检查现有组件的变体、属性、Slot 与嵌套后仍不能满足，
  才允许手动创建并登记为“页面本地组合”。
- 保留 H5 与 Figma 分支中的详细约束；本次只消除主流程表述歧义，不修改组件身份、映射、Token、
  Figma Variable 或视觉实现。

## v4.1 — 2026-07-30 · Figma / H5 双端组件身份

- 正式组件改为“三项齐全”判定：Figma 已发布 Component / Component Set、H5 封装好的
  `<v9-*>`、以及可执行的显式映射；仅存在 H5 标签或 CSS 不再等同于正式组件。
- `V9_COMPONENTS.kind` 扩展为 `component / pending / primitive / internal / h5-only`。
  当前29个运行元素重新归类为24个双端正式组件、1个待发布、1个内部原语、2个内部辅助结构和
  1个H5兼容实现。
- `<v9-card>` 标记为 `pending`：CellCard / Shell 正式发布并回填 Key 前不计为双端正式组件；
  `<v9-number>` 保持 DataValue 内部原语；`<v9-back>` 与 `<v9-list-row>` 标记为内部结构；
  `<v9-toast>` 标记为 `h5-only`，禁止用于新的双端映射交付。
- 增加“页面本地组合”兜底：先检查变体、属性、Slot 与嵌套，仍不能满足时才允许使用正式组件、
  Token 和 Stack 手动组合；不得复制组件内部结构、虚构组件名或 Component Key。
- H5 与 Figma 交付记录必须分开列出正式组件和页面本地组合；稳定重复的本地组合只有在 Figma 主件、
  H5 封装和映射全部完成后才能升级为正式组件。
- 更新 `SKILL.md`、`components.md`、`workflow.md`、`v9-figma-map.md` 和运行时验证脚本；
  验证器新增身份数量、非正式元素分类及24个正式组件映射完整性检查。
- 本次未修改 Token、Figma Variable、正式 Component Key、Figma 源组件视觉或 H5 组件视觉。

## v4.0 — 2026-07-30 · H5 可直接调用组件运行时

- 新增 `assets/v9-components.js`，将原先只能复制 `.v9-*` class 与内部 DOM 的样式基座升级为
  `<v9-*>` Web Components 运行时。页面只传业务内容、变体属性与命名 Slot，组件内部模板、
  SVG、状态、可访问属性和固定对齐由运行时维护。
- 新增 `V9_COMPONENTS` 组件身份登记表，以 `component / primitive / internal` 区分正式组件、
  内部原语和辅助结构，禁止把 BEM Element、Modifier、布局 class 或 `v9-list-row` 等内部结构
  虚报为独立正式组件。
- Appbar 改为封装完整375×88结构，并固化 Figma 源返回、蜂窝、Wi-Fi、电池及右侧操作 SVG；
  系统状态区、返回按钮和标题不再由页面手拼。
- Cardheader 固定右侧 Link/Expand 与标题行顶边对齐；Metric Item 封装完整 DataValue 与 Trend，
  由组件自身保持6px；Card 自动折叠空 Header/Content/Footer Slot；Scrollable Metrics 固定
  18px Number 字体、居中与 tile 结构。
- 为 Button、Action Group、Tag、Badge、Selection Control、Agreement、Info、Tooltip、Loading、
  Quantity Stepper、Alert、Number、Metric、Appbar、Card、Cardheader、CardContent、TextLink、
  ExpandLink、StatusOverlay、Tabs、Home Indicator、Toast、Dialog 等提供直接调用入口；交互组件
  在运行时同步原生 disabled / ARIA 与 change/toggle/close 事件。
- `SKILL.md`、`components.md`、`workflow.md` 与 `v9-figma-map.md` 全面切换为
  “标签属性 → Figma 组件属性”映射；原 `.v9-*` class 保留为运行时内部实现及旧页面兼容层，
  不再是新页面首选 API。
- 新增运行时静态验证脚本与浏览器尺寸/对齐回归检查。Appbar 375×88、状态区左右定位、
  Cardheader 顶部对齐、Metric Trend 6px、空 Slot 折叠及 Scrollable 18px/居中均通过验证。
- 本次未新增或修改 Token、Figma Variable、Component Key 或 Figma 源组件。

## v3.9 — 2026-07-29 · CellCard Slot 与组合分层

- 将 CellCard 从“固定包含 Cardheader + CardContent + Button Full-width”调整为统一 Shell：
  Header、Content、Footer 作为使用区域，具体组件通过 Slot 合同进入，不再把业务结构做成
  CellCard Variant。
- 明确 CardContent 只是一种标准图文、列表和媒体内容组件，不等同于 Content Slot，也不是
  Metric、Address、Tag 等通用组件的父分类；规范不建立 `Content Modules` 所属目录。
- 增加自由组合、Content Pattern、Card Pattern 的升级边界：只统一间距和隐藏收拢、但组合不重复
  或顺序不稳定时继续自由组合；稳定且重复后才升级为 Pattern。
- 卡片内容关系统一使用既有4/8/16px Space Token：同一内容组4px、同一信息模块8px、不同结构区域
  16px；标准 Header ↔ Content 保持8px、Content ↔ Footer 保持16px。删除多模块固定24px旧规则。
- 六种既有卡片组合改为非穷举示例，不再描述为 CellCard 内置模式；Footer Slot 也不再限定为
  Button Full-width。
- H5 新增 `.v9-stack--group/module/section` 通用布局辅助 class，移除非正式
  `.v9-card__subtle`；`.v9-card__content` 明确为 Content Slot，标准图文继续使用
  `.v9-cardcontent`。
- Figma 文件 `7.22` 的 `CellCard / Unified`（Node `39:158`）登记为 Slot 草案。因尚无可跨文件
  导入的正式 Component Key，映射保持待发布；旧 Key `14733bed…` 标记为 Legacy，只用于既有
  固定结构，不得冒充 Slot 版 Shell。
- Alert 在351px CellCard 内使用 small 的规则归入 Alert 组件说明，不再放在 CellCard 自定义规则。
- 同步更新 `SKILL.md` 路由、H5/Figma 映射和结果级工作流自查。本次没有新增或修改 Token、
  Figma Variable，也没有修改 Figma 源文件。

## v3.8.1 — 2026-07-23 · Cardheader 单一入口

- 从 `v9-core.css` 移除旧 `.v9-card__header`、`.v9-card__title`、`.v9-card__subtitle`、
  `.v9-card__action` 与 `.v9-card__action--primary`，避免页面继续用外观相似结构冒充正式组件。
- Card 容器只保留 Surface、圆角、Padding、内容、Footer 与 Subtle 内容槽；标题区统一调用正式
  `.v9-cardheader` 及其子结构，并继续映射 Figma Cardheader 组件。
- 同步更新组件合同、H5 工作流与 Figma 映射；没有修改 Figma 组件、Token 或 Variable。

## v3.8 — 2026-07-23 · 数据规范归位与 Scrollable 18px

- 重新按职责整理数据规范：`SKILL.md` 只保留入口与阅读路由；`components.md` 记录组件结构和视觉
  合同；`workflow.md` 记录导入、嵌套写入与回读顺序；`v9-figma-map.md` 集中保存 Component Key、
  属性 Key 与 H5 精确实现；旧属性删除历史只保留在本更新日志。
- Scrollable Metrics 的前缀、整数、小数与英文值统一为18px Barlow Semi Condensed Bold、
  Auto 行高与0字距；单位保持14px Text Bold。该18px属于组件级紧凑合同，不扩充
  Metric Item 的 XL/L/M/S 四级核心字阶。
- Figma 同步更新 Scrollable Metrics 的 Standalone / Embedded 两个变体及10个嵌套 Metric Item；
  保持100px tile、12px tile Padding、8px tile gap、居中对齐和内容驱动高度。
- H5 在滚动 tile 内复用既有 `--v9-fz-headline-m` 的18px值，并继续通过 Number class 使用
  Barlow Semi Condensed Bold；没有新增 Text Style、Token 或 Figma Variable。
- `tokens.json`、派生 Token 文件与 `custom-rules.md` 均无变化。

## v3.7 — 2026-07-23 · 数据组件正式源同步与 Trend 6px

- 数据组件正式源切换到 `9.0规范 一致性测试` 的数据组件区（Node `2005:894`），更新
  `_Metric/Trend`、`Metric Item`、`Metric Group`、`Scrollable Metrics` 的 Node ID 与
  Component Set Key；旧 `数字test` Key 不再作为当前映射。
- Metric Item 的 Up/Down 与完整值块间距由4px调整为6px；6px保持组件局部规格，H5 使用既有
  4px + 2px Token 组合实现，不新增全局 Token 或 Figma Variable。
- 移除失效的 `Trend Value#61:26` 映射；16个 Up/Down 变体统一暴露嵌套 `_Metric/Trend`，
  可见趋势文案通过 `Value#103:0` 写入并回读验证。
- Metric Group 固化为 `Container=Standalone/Embedded × Count=1/2/3/4` 共8个变体，全部依赖
  新版 Metric Item；恢复内容驱动高度，清除旧实例尺寸覆盖造成的裁切。
- Scrollable Metrics 保持2个 Container 变体：Standalone 使用16px Padding、16px圆角和8px
  tile gap，Embedded 移除外层容器；100px Subtle tile 使用12px Padding、12px圆角，指标名称和
  数据居中，高度由内容自然撑开。
- H5 同步更新 Trend 6px 与滚动 tile 居中实现；`tokens.json`、派生 Token 文件和
  `custom-rules.md` 均无变化。

## v3.6 — 2026-07-23 · DataGroup 容器模式与组合规则

- 数据组新增 `Container = Standalone / Embedded` 调用模式：Standalone 保留背景、16px圆角与
  16px Padding；Embedded 只保留数据排列和 Grid gap，由父级 Card 提供容器。
- 明确 Cardheader 与数据组共同构成卡片时必须位于同一个父级 Card；禁止标题置于卡片外，也禁止
  Standalone 数据组直接嵌入完整 Card 形成双层 Surface、圆角或 Padding。
- H5 新增 `.v9-metric-group--embedded`、`.v9-metric-scroll--embedded`，Scrollable Metrics
  Standalone 同步补齐16px `scroll-padding-inline`；未新增 Token 或 Figma Variable。
- 修正 `workflow.md` 中继续使用旧 `.v9-card__header` 的示例，统一为正式 `.v9-cardheader`；
  增加正式 class 复用、组件高度、嵌入模式和滚动边缘的结果级自查。
- Metric Item 明确保持内容驱动高度；调用层不得以无规范来源的固定高度或 `min-height` 修正对齐，
  同组等高由 Group 容器统一处理。
- Figma 数据组源组件已正式暴露 `Container`：Metric Group 扩展为
  `Container=Standalone/Embedded × Count=1/2/3/4` 共8个变体；Scrollable Metrics 升级为
  `Container=Standalone/Embedded` 共2个变体。Figma 与 H5 现均直接映射 Container，不再由
  组合层临时重拼 Embedded。
- `custom-rules.md`、`tokens.json` 与派生 Token 文件均无变化。

## v3.5 — 2026-07-23 · 数据组件完整接入

### Figma 源与组件映射
- 接入 `数字test` 的 `_Metric/Trend`（Node `103:731`）、`Metric Item`（Node `61:320`）、
  `Metric Group`（Node `62:180`）与 `Scrollable Metrics`（Node `62:181`），登记组件级 Key、
  真实变体、文本/Boolean 属性、嵌套依赖及页面记录。
- 保留 `DataValue → DataItem → DataGroup` 的规范分层；DataValue 作为 Metric Item 内部逻辑层，
  不虚构独立 Figma Component Key。
- 明确四个源组件当前均为 `UNPUBLISHED`：正式发布前 Key 只用于源身份与未来映射，跨文件导入失败时
  不得手工重画。
- 记录源 API 限制：Metric Item 的 `Trend Value#61:26` 当前连接隐藏文本，写入可见趋势需修改嵌套
  `_Metric/Trend` 的 `Value#103:0`；Metric Group 的 Count 只控制数量，Size 与内容写入嵌套 Item。

### 数字与布局规则
- 修正货币前缀：数字前的 `¥` 与核心整数使用同一字号、Number 字族、Bold 700 和颜色；只有小数按
  XL→M、L→S、M→18、S→16降级。
- 18/16不新增 Number 基础 Token：H5只复用 `--v9-fz-headline-m/s` 的字号值，实际字体仍由
  Barlow Semi Condensed Bold Number 样式控制；Figma 对应 `Number/Auxiliary/M/S`。
- Metric Group 的 Count 不再映射字号；H5按1–4项等分并遵守375页面12px margin / 351px内容宽，
  不继承源探索文件的343px演示宽度或“4项=S”示例默认。
- 固化 Metric Item 的0px Label↔Value间距、4px Value↔Trend组件级间距，以及滚动数据的
  16px外层内边距、8px tile gap、12px tile内边距和圆角。

### H5、Token 与资产
- `v9-core.css` 新增 `.v9-metric-item`、`.v9-metric-trend`、`.v9-metric-group`、
  `.v9-metric-scroll` 及完整 Size/Trend/Count/Number/English 结构；新增源趋势矢量
  `assets/components/metric/trend-arrow.svg`。
- H5趋势颜色重新映射正式 Success/Error 与现有浅色 Surface，不接收源文件硬编码绿色。
- 本次没有新增、删除或改动 `tokens.json` / 正式 Figma Variable；拒绝同步源探索文件中的
  `Metric Primitives`、`Metric Tokens`、`data-affix-gap`，继续复用正式颜色、正文、圆角和
  2/8/12/16px Token。
- 同步更新 `SKILL.md`、`typography.md`、`components.md`、`workflow.md` 与
  `v9-figma-map.md`；`custom-rules.md` 无变化。

## v3.4.5 — 2026-07-22 · info-icon 与 Loading 状态模型修正

- 只读复核 Figma 当前源：info-icon 组件集只有 M/S 两个子组件；源 `status` 是固定单值的遗留属性名，不构成 Disabled 状态。
- info-icon H5 只保留 M/S 尺寸 class，移除 normal/disabled 状态 class；源资产统一归名为 `default.svg`。
- Loading 组件集只包含 normal、pull-up、pull-down 三个 type，根组件不存在 icon Boolean；三种状态固定显示加载图标，不再扩展为6种组合。
- 同步更新组件规范、H5↔Figma 映射、工作流自查、H5 CSS 和两个组件预览页；补充 info-icon 可触发但不独占 Tooltip、箭头对齐当前触发锚点的组合规则。
- 本次未修改 Token、Figma Variable、Component Key 或 Figma 源文件。

## v3.4.4 — 2026-07-22 · H5 错误清单信息归位

- 明确 H5 专属错误清单只收录可跨组件复用的执行错误；单组件视觉合同、精确实现补偿与修复历史分别归入组件规范、Figma 映射 / CSS 和更新日志。
- 从错误清单移除 Tooltip 的15×8箭头、1px合成层补偿及 Stepper 外层透明背景等组件专项实现，保留结果级自查和原有专项说明。
- 将 Stepper 暴露出的背景问题抽象为通用规则：不得给组件根容器添加源组件不存在的背景或装饰，并在白色、灰色和彩色背景下检查组件边界。
- 本次未修改 Token、Figma Variable、组件属性、Component Key 或 H5 样式实现。

## v3.4.3 — 2026-07-22 · Tooltip 浏览器合成层白缝修正

- 对 Figma 源截图与 H5 截图进行像素连通性扫描，定位到箭头 mask 与气泡独立合成时产生的1px抗锯齿白缝。
- top 箭头向下、bottom 箭头向上各重叠1px，保持15×8布局占位、方向、20px左右定位与气泡尺寸不变。
- 该1px只属于 Tooltip 的 H5 光学校正，不新增 Token 或 Figma Variable。

## v3.4.2 — 2026-07-22 · Tooltip 可见矢量贴边修正

- 通过 Figma 源截图与 H5 放大截图复核，确认问题不是 Auto Layout gap，而是7.07577px可见矢量在15×8区域内被默认居中。
- Tooltip 改用 Figma 原始向下箭头资产：`bottom-*` 贴箭头区域顶部，`top-*` 垂直翻转后贴区域底部；透明余量只保留在组件外缘，不再位于箭头与气泡之间。
- SVG 与 CSS 资源增加实现版本，避免浏览器继续复用旧箭头缓存。
- 本次未修改 Token、Figma Variable、Tooltip 尺寸、Component Key 或属性枚举。

## v3.4.1 — 2026-07-22 · Tooltip 与 Quantity Stepper H5 修正

- Tooltip 保留15×8占位和 Figma 源路径，裁去 SVG 画布底部透明余量，使四个方向的可见箭头与气泡边缘贴合。
- Quantity Stepper 外层背景由白色改为透明，背景统一由调用容器提供；default/min/max 与 disabled 行为不变。
- 同步更新 `components.md`、`v9-figma-map.md` 和 `workflow.md` 的结构说明、映射与自查项。
- 本次未新增或修改 Token、Figma Variable、组件属性或 Component Key。

## v3.4 — 2026-07-22 · info-icon、Tooltip、Loading 与 Quantity Stepper 接入

### Figma 源与组件映射
- 接入 `info-icon`（Node `1819:1116`，Set Key `56dde402…`）的 status×size 四个变体。
- 接入 `Tooltip`（Node `1819:1377`，Set Key `a3f134b0…`）的四个 arrow 变体与 `Text#295:0`。
- 接入 `Loading`（Node `1819:1402`，Set Key `aecb8b10…`）的三种 type、icon Boolean，并登记 `加载/加载` 直接依赖。
- 接入 `Quantity Stepper`（Node `1819:1286`，Set Key `ddd7c3c9…`）的 default/max/min、`value#149:4` 与1–99边界关系。

### H5 与源资产
- `v9-core.css` 新增 `.v9-info-icon`、`.v9-tooltip`、`.v9-loading`、`.v9-quantity-stepper` 及全部变体/状态实现。
- 固化 info、Tooltip 箭头、Loading 路径及 Stepper 加减号的 Figma 源 SVG；禁止字符或临时 CSS 重画。
- Loading 在 H5 运行层增加连续旋转和减少动态效果兼容；Stepper 使用原生按钮 disabled 与可访问状态。

### 文档、Token 与验证范围
- 同步更新 `SKILL.md`、`components.md`、`workflow.md` 与 `v9-figma-map.md` 的索引、选型、属性、依赖、错误检查和 H5↔Figma 映射。
- 复用现有颜色、字体、圆角与间距 Token；6px gap、288px最大宽度、22px步进器数字等保持组件局部规格，不新增 Token 或 Figma Variable。
- `custom-rules.md` 无变化。

## v3.3 — 2026-07-22 · Action Button Group 职责与状态继承澄清

- 将 Action Button Group 明确拆分为三层：`layout` 负责排列、Button Full-width `variant` 负责视觉主次、`state` 负责交互状态。
- `Primary` 与 `Secondary` 单按钮布局不再被理解为固定 Default 外观，均继承对应 Button Full-width 角色的有效状态。
- `Inline` 与 `Stacked` 固定为 Primary + Subtle；禁止两个相同视觉角色，但允许两个按钮同时处于 Default 等相同交互状态。
- 同步更新 `components.md`、`workflow.md` 与 `v9-figma-map.md`；H5 CSS、Token、Figma Variable 与 `custom-rules.md` 均无变化。

## v3.2 — 2026-07-22 · Dialog 操作区与退出路径规则

- 新增 Dialog 专属 Action Button Group 选型：1个按钮用 Primary；2个按钮都不超过4个字用 Inline；任意一个超过4个字用 Stacked。
- 明确 Dialog 不存在 Secondary-only 场景，不使用 Action Button Group `Secondary`。
- Close 默认隐藏；按钮已提供“取消、暂不选择、稍后”等非决策退出路径时不显示，仅在所有按钮都要求用户作出选择且没有退出路径时显示。
- Close 按操作语义而非固定关键词判断；布局按最终按钮文案计算。
- 同步更新 `components.md`、`workflow.md` 与 `v9-figma-map.md`；H5 CSS、Token 和 Figma Variable 均无变化。

## v3.1 — 2026-07-21 · Dialog 模态语义与 H5 呈现修正

- 将 Dialog 从“页面级对话面板”修正为“底部模态弹窗”：打开时使用遮罩覆盖并阻断背景，弹窗底部对齐。
- 明确 Figma Dialog Component 只表示可见弹窗内容；遮罩、焦点管理、Esc关闭、背景滚动锁定属于 H5 / 客户端运行层，不新增 Figma Component Key。
- H5 新增 `.v9-modal`、`.v9-modal__scrim`、`.v9-modal--contained` 与滚动锁定样式，`.v9-dialog` 继续保持源组件结构和两个可替换媒体槽。
- 同步更新 `components.md`、`workflow.md`、`v9-figma-map.md` 与 H5 示例；本次未新增或修改 Token。

## v3.0 — 2026-07-21 · Selection Control、Agreement 与 Dialog 完整接入

### Figma 源与组件规范
- 新增 `Selection Control`（Node `1819:980`、Set Key `d7454d67…`），登记 checkbox/radio 与4种 state 的8个有效组合；禁用继续保留在源组件的 `state` 枚举中。
- 新增 `Agreement`（Node `1819:1015`、Set Key `e3c84379…`），登记 detail/checked/unchecked、`Text#1980:0` 与 Selection Control 直接依赖。
- 新增 `Dialog`（Node `1819:1029`、Component Key `56e644ce…`），登记当前 Boolean/TEXT 属性、375px结构、Agreement 与 Stacked Action Button Group 依赖。

### 可替换媒体槽
- 将 Dialog 的 `Header Media` 与 `Content Image` 正式定义为可替换槽位，而不是固定插画或默认业务图片。
- Header Media 保持100×100px居中并默认 `contain`；Content Image 保持335×150px、12px圆角并默认 `cover`。
- Figma 通过对应 Boolean 显示槽位后覆盖内部图片填充/内容，禁止 detach、删除槽位、改尺寸或在实例外叠图；没有真实内容时保持隐藏。
- H5 只实现槽位容器、对齐和裁切，不写死示例图片；真实媒体由槽位子节点传入。

### H5、映射与流程
- `v9-core.css` 新增 Selection Control、Agreement、Dialog 样式；Selection Control 复用随 Skill 固化的 Figma 原始 SVG 资产。
- `v9-figma-map.md` 新增三个组件的 Key、属性、嵌套依赖及 Dialog 槽位替换合同。
- `workflow.md` 增加组件选型、Dialog 槽位自查与 H5/Figma 错误处理；`SKILL.md` 增加可替换媒体槽的维护约定。

### Token
- 本次没有新增、删除或改动 `tokens.json` / Figma Variable；颜色、2/8/10/12/20px间距与12/30px圆角复用现有 Token。
- 5/7.5/15px等值保持为 Dialog 源组件局部结构规格，不升级为跨组件 Token。

## v2.9 — 2026-07-21 · arrow、Badge 与底部 Status Bar 完整接入

### Figma 源与组件规范
- 将 `arrow` 当前源更新为 Node `1819:469`、Set Key `5309f92c…`，登记48个变体，并把颜色属性从旧 `arrowIcon` 修正为源组件中的 `arrow icon`。
- 新增 `Badge`（Node `1819:808`、Set Key `ec83c21f…`），覆盖 count、overflow、dot、label-new 四种类型；明确仅 count 开放文本覆盖。
- 将 Node `1819:817`、Set Key `4b259cf0…` 接入为底部 `Status Bar` / Home Indicator，登记 light/dark 主题、375×34容器、134×5横条和源组件定位。
- 区分底部 Home Indicator 与 App bar 内部44px顶部系统状态区，保留后者的 H5 兼容结构但移除其独立生产映射。

### H5 与映射
- `v9-figma-map.md` 更新三个组件的 Set Key、变体属性、文本属性、H5 class 和页面核对记录；不登记可由 Set Key + 属性获得的单个 Variant Key。
- `v9-core.css` 新增 Badge 四种类型，arrow 从字符占位升级为 `currentColor` 矢量蒙版，并将 Home Indicator 改为与源组件一致的容器、位置与主题颜色。
- Badge count / overflow 的 H5 数字向下光学校正1px：垂直内边距由 `0/2px` 等量改为 `1/1px`，14px外框、12px行高与总内边距保持不变。
- `workflow.md` 增加 Badge、arrow、Home Indicator 的选型、写入、自查和错误处理规则；同步消除顶部状态区与底部手势条的同名歧义。

### Token 与规则
- 本次没有新增、删除或改动 `tokens.json` / Figma Variable；三个组件全部复用现有颜色、2px/4px间距与 Full 圆角 Token。
- Badge 的12px Barlow Condensed Bold Italic 与10px“新”字样保留为组件局部规格，不升级为跨组件 Token。
- Badge 的1px H5位移是单一组件的字形补偿，不新增1px全局间距 Token，也不改变 Figma 源组件规格。
- Home Indicator 浅色主题从旧纯黑规则修正为 `on-surface default primary` / `--v9-text-primary` (#222222)，消除纯黑例外。
- Home Indicator 已成为正式源组件，因此从 `custom-rules.md` 删除完整专章；尺寸、主题、定位及底部操作区叠放方式统一归入 `components.md`。
- `SKILL.md` 新增信息迁移约定：用户规则被正式组件吸收后必须迁出 `custom-rules.md`，避免双处维护。

## v2.8 — 2026-07-21 · 组件规范进一步去实现化

### Action Button Group 规范收敛
- `components.md` 移除 Action Button Group 的局部 Figma 源记录、H5 Token/class、文本属性 Key、导入方法及代码示例，只保留布局、结构规格和设计使用规则。
- 将“结构与 Token”收敛为“结构规格”，保留375px页面级容器、20px内边距、10px按钮间距及对子按钮高度和圆角的继承关系。
- 使用规则只保留固定按钮组合、父子组件职责、Inline 等宽、长文案降级和页面级全宽使用范围。

### 映射归位
- `v9-figma-map.md` 集中保存源文件、Node、Component Set Key、layout/H5 class、文本属性 Key、导入方法、H5结构示例和10px映射说明。
- `SKILL.md` 明确设计 Token 来源可以进入组件规范；H5 Token 变量名、class 和 Figma 实现属性必须进入映射文件。
- 本次不改变 Token、Figma Variable、H5 CSS 或组件视觉效果。

## v2.7 — 2026-07-21 · 组件规范与实现映射拆分

### 文档职责统一
- `components.md` 的 Action Button Group 布局表只保留 layout、尺寸、内部结构与对齐，移除单个 Variant Key 和 H5 class。
- 将 Button Full-width 与常规 Button 的“变体样式”统一命名为“视觉与状态”，与 Action Button Group 的“布局变体”区分层级。
- 明确 `components.md` 负责设计规范，`v9-figma-map.md` 负责 Component Set Key、变体属性与 H5 class 的实现映射。

### 映射规则
- Action Button Group 继续通过有效 Component Set Key 导入并设置 `layout`，不登记或直接导入四个单独 Variant Key。
- 本次不改变 Token、Figma Variable、H5 CSS 或组件视觉效果。

## v2.6 — 2026-07-21 · Action Button Group 接入

### 组件与依赖
- 接入 Figma `Action Button Group`（Node `1819:445`，Set Key `a0c4f2cf…`），登记 Primary、Stacked、Inline、Secondary 四个 `layout` 变体及各自 Variant Key。
- 审计并同步直接依赖 `Button Full-width`：当前 Node `1819:420`、Set Key `d2fe2cb6…`，属性由旧 `Property 1/2` 更新为 `variant/state`，文字行高以 Figma 当前 Auto 为准。
- 在 `components.md` 增加源文件、页面、Node、Key、布局尺寸、内部按钮顺序、Token 与使用规则记录。

### Token 与 H5
- 新增 H5 `--v9-space-10: 10px`，映射 Figma 已有 `Number/Number10`，用于组件当前未绑定语义变量的按钮间距；不新增重复 Figma Variable。
- 将 `--v9-space-xl` 对齐 Figma `space/space/extra lg` 为20px，并新增 `--v9-space-2xl: 24px` 对齐 `space/space/extra  extra lg`。
- 新增 `.v9-action-group` 及4个 layout 修饰类，复用现有 Button Full-width、颜色与圆角 Token，还原375px容器、20px padding、10px gap、等宽与右对齐结构。

### 映射、流程与维护
- 更新 `v9-figma-map.md` 的 Button Full-width Key/属性，新增 Action Button Group H5↔Figma 映射与页面核对记录。
- 更新 `workflow.md` 的组件选型、错误检查和 Figma 导入说明；组合组件必须优先导入整体，禁止 detach 或手动重拼。
- 更新 `SKILL.md` 的维护事务约定：组合组件变更必须连带审计并同步直接依赖。

## v2.5 — 2026-07-20 · SKILL 主文件精简

### 渐进式披露
- 将 `SKILL.md` 中数据组件的2XS、8/12/16px和 Metric Token 细节移回专项 references，避免主文件重复具体规则。
- 主文件只保留 Token 维护原则：优先复用；仅当规范库缺失且需要跨组件复用时，才新增至 `tokens.json` 并同步正式 Figma Variables。
- `typography.md`、`spacing.md`、`components.md` 与 `workflow.md` 中的具体2XS和数据组件规则保持不变。

## v2.4 — 2026-07-20 · 2XS 间距复用

### Token 收敛
- 删除全局 `--v9-data-affix-gap` 和 Figma `space/data/affix gap` 建议，不为数字与单位重复创建2px变量。
- 将已有 Figma `space/space/2xs` 映射为 H5 `--v9-space-2xs`，数字单位间距直接消费该通用 Token。
- 保持四级 Number Token 不变；重新生成 `v9-tokens.css` 与 `tokens-tables.md`。

### 规范与实现
- 同步更新 `SKILL.md`、`typography.md`、`spacing.md`、`components.md`、`workflow.md` 和 `v9-core.css`。
- 明确只有数字单位间距未来需要脱离2XS独立变化时，才允许新增组件语义 Token。

## v2.3 — 2026-07-20 · 数据组件结构与 Token 收敛

### 规范归位
- 不新增 `data-display.md`；数据基础继续由 `references/typography.md` 管理，数据组件组合进入 `references/components.md`，间距数值与别名进入 `references/spacing.md` 和 `assets/tokens.json`。
- 从 `references/custom-rules.md` 删除重复的字体与数据规则，只保留正式规范文件的路由说明，避免多处维护。
- 更新 `SKILL.md`、`workflow.md` 与 `v9-figma-map.md` 的读取路径、检查项和维护约定。

### 数据组件结构
- 在 `components.md` 冻结 `DataValue → DataItem → DataGroup` 三层结构，覆盖 1–4 项、固定/横滑、Pure/Subtle、8/12/16px 组合间距与整组降级规则。
- 只保留结构与使用规则；正式 Figma Component Key、Node ID、变体属性和生产 H5 class 等待用户提供源组件后补充，不登记演示组件。
- 明确 Surface 只用于区分结构，不根据副标题、数据语义或数据数量推断。

### 数字与单位
- Number/XL、L、M、S 保持 36/30/27/24，行高从固定 100% 调整为 Auto，不新增 Number 行高 Token。
- `DataValue` 的值只允许数字或英文，不提供中文值类型。
- 单位使用指标名称字号、Text Bold 700、核心数字颜色，与数字保持 2px 并按基线对齐。
- H5 `.v9-number` 将2px仅用于数字与单位；货币前缀与数字连续排列。

### Token 收敛
- 保留四级 Number Token 与 `--v9-data-affix-gap`；为其补充 Figma 映射信息并重新生成 `v9-tokens.css`、`tokens-tables.md`。
- 2px单位间距对应 `space/data/affix gap`；数据组8/12/16px直接复用既有 `space/sm`、`space/md`、`space/lg`。
- 禁止在目标 Figma 文件中创建重复的 `Metric Primitives`、`Metric Tokens`、`color/text/label`、`text/size/metric-label` 等本地变量。

## v2.2 — 2026-07-20 · 四级数字规范与数据对齐

### 数字字阶
- 将原 Display 45/36/30/27 重构为 `Number/XL 36`、`Number/L 30`、`Number/M 27`、`Number/S 24`，同步 `tokens.json`、生成 CSS 和字体文档。
- 明确字号不按数据数量固定：先判断业务重要性和页面层级，再结合密度、最长值及可用空间；同组数据保持同级，溢出时整组降一级。

### 数字组合与对齐
- 明确 Barlow Semi Condensed Bold 为核心数字字体，Number 使用 100% 行高；正文和标题仍使用1.5倍行高。
- 新增整数、小数、货币符号与单位规则：小数按组合降级；单位保留在数字组件中，但不占四级核心字阶；单位与指标名称同字号、与数字同色，间距2px，整体基线对齐。
- 新增数据组对齐规则：居中时以“完整数据组合”居中；同组保持同一对齐轴；允许按阅读任务选择名称在上或数字在上。

### 数据结构
- 固化 Pure/Subtle 的结构判断：固定单行 1–4 项优先 Pure，横向滚动使用 Subtle，多层数据仅在结构不清时使用 Subtle。
- 固化 Grid gap：Pure 16px、同一 Subtle 内12px、独立 Subtle 之间8px；数据内部不再默认增加4px。

### H5 基座与工作流
- 新增 `.v9-number` 及 XL/L/M/S、integer/decimal/affix/unit 组合类。
- 更新出图自查和错误清单，覆盖数字字阶选型、同组一致、行高、单位字号/颜色/间距和基线。

## v2.1 — 2026-06-26 · 规范补全（来自拍照质检出图实践）

### 结构清理
- 删除根目录冗余副本 `components.md`、`custom-rules.md`，仅保留 `references/` 版，修复同一文件存两份导致的规则漂移。

### 补回上游规范
- `references/custom-rules.md` 新增“模块复用优先级规则（警示信息：副标题槽 vs Alert）”：警示/原因类信息优先复用副标题/描述槽与警示色，不默认新增 Alert。
- `references/components.md` Alert 节补充“Alert 是独立模块升级项，非警示默认样式”说明。

### 新增规则
- 新增链接、图标和操作样式规则：次级链接默认 Secondary 灰；箭头使用独立图标；CardHeader 操作对齐标题行；App bar 状态栏使用系统图标。
- `workflow.md` 增加“PRD 未定义项”确认和对应 H5 错误检查。

### 基座
- `assets/v9-core.css` 调整卡片次级操作颜色，并新增主操作修饰与独立图标元素类。

## v2.0 — 2026-06-26 · 引入 H5 链路与 Token 单一源头

### 流程
- 出图链路由 PRD→Figma 调整为 PRD→H5→（按需）Figma；H5 为默认交付物，Figma 改为按需。
- 写入 Figma 明确两种方式：AI 导入真实组件实例为主路径；插件转图层仅用于预览。

### 新增
- 新增 `assets/tokens.json`、`build-tokens.js`、`v9-tokens.css`、`v9-core.css` 和 `references/v9-figma-map.md`。

### 修改
- `SKILL.md` 增加三段式流程、组件更新操作约定、索引和决策树。
- `workflow.md` 重构为公共主干、H5执行分支和Figma执行分支。
- 颜色、字体、间距、阴影文档增加 Token 唯一源说明。

### 单一源头与防漂移
- 改颜色、间距、圆角、阴影：只改 `assets/tokens.json`，再运行 `node build-tokens.js`。
- 改组件：同步更新 `components.md`、`v9-figma-map.md` 与 `v9-core.css`。
