---
name: design-language
description: >
  9.0 设计规范 — 统一设计语言与风格规范。每当用户需要创建 UI 界面、网页、React 组件、HTML 页面、
  Figma 页面搭建、设计稿描述，或任何涉及视觉风格的任务时，必须使用此 skill 确保风格一致性。
  即使用户只是说"帮我做个界面"、"做个页面"、"搭建一下"也要触发。
  包含：全局视觉原则、颜色体系、字体规范、四级数字字阶、数据看板与指标卡对齐、间距圆角、阴影层级、
  组件规范、Page Background、CellCard / Shell、Form Item / Group / Card、Entry Item / Entry Group、Pill Option / Group、Tabs Line / Card、Address Group、操作按钮组、Selection Control、Agreement、Dialog、Badge、arrow、info-icon、Tooltip、
  Toast、Loading、Quantity Stepper、Task Sheet / Shell、Option Tile、Warning Count、底部 Home Indicator、Page Pattern、
  自定义规则、H5 组件库、新页面与独立弹层创建、既有设计增量修改、既有H5的9.0合规迁移、Figma 工作流。
---

# 9.0 设计规范

基于 Figma 设计稿 `9.0规范` 的完整设计系统。

**Figma 主源文件 Key**: `KKuaHEUNwnenHwumr4a3Ta`

> Tabs 已统一迁移到主规范库已发布 Set（Node `274:2175`）：Line 支持 Equal / Start 与白底 / 透明背景，
> Card 继续用于同一卡片内2–3组同级内容切换；两种Line分布与背景显隐已进入正式H5 Runtime，
> Rounded 仍不接入。

## 核心设计语言（快速参考）

> 数值唯一源为 `assets/tokens.json`，经 `assets/build-tokens.js` 生成 `assets/v9-tokens.css`。
> 下表仅为速览，勿手改派生文件；具体构建步骤见 `references/workflow.md`。

| 维度 | 规范 |
|------|------|
| 主色 | `#FF6435`（橙红）|
| 背景色 | `#F0F1F5`（全局）/ `#FFFFFF`（卡片）|
| 中文字体 | PingFang SC（回退：Noto Sans SC）|
| 数字/英文字体 | Barlow Semi Condensed |
| 圆角基准 | 4px 阶梯，Full = 1000px（胶囊形）|
| 间距网格 | 以4px为主网格；2XS = 2px用于精细间距；页面左右 margin = 12px |
| 行高规则 | 按实际渲染行数：单行=字号；多行=字号×1.5；组件运行时自动判定 |
| 阴影色基底 | `#0F284D` 不同透明度（5 级）|

---

## 参考文件索引

按需读取对应文件，不要一次性全部读取。

| 文件 | 内容 | 何时读取 |
|------|------|---------|
| `references/colors.md` | 颜色体系（数值源见 tokens.json）| 涉及颜色选取时 |
| `references/typography.md` | 字体与数据基础规范（Number/XL-L-M-S、单位、小数、对齐） | 涉及文本、数据看板、指标卡或字号选择时 |
| `references/spacing.md` | 间距与圆角 | 涉及布局间距、圆角设定时 |
| `references/shadows.md` | 阴影/层级 | 涉及卡片、弹窗、浮层阴影时 |
| `references/visual-principles.md` | 跨组件的页面目标、焦点层级、语义分组、构图密度、色彩Surface、操作关系与轻量视觉自查 | 本次任务需要新增、改变或审核可见界面关系时，在首次视觉选择前读取一次 |
| `references/components.md` | 组件与Page Background规范、CellCard Slot/组合分层、数据组件结构及 Figma 组件级 Key 索引；不混入单变体 Key 映射 | 使用任何 UI 组件或确定页面背景模式时（必读）|
| `references/custom-rules.md` | ⭐ 自定义规则（**优先级最高**，规范红线唯一真相）| 有疑问或冲突时优先查阅 |
| `references/workflow.md` | 三种页面能力的公共边界、H5产出、自查与交付 | 所有页面及独立弹层的设计产出、修改任务，包括直接写入外部画板（必读）|
| `references/h5-migration.md` | 既有H5升级为9.0的专项迁移流程、范围与验收 | 用户明确要求把可编辑的既有H5或指定区域整体改为符合9.0时 |
| `references/figma-workflow.md` | 页面写入Figma的导入、实例、字体、回读与截图验证 | 用户要求写入Figma或形成双端页面交付时 |
| `references/component-maintenance.md` | 组件新增、修改、下线、依赖审计与Figma/H5/映射同步 | 维护组件或发现三端漂移时 |
| `references/v9-figma-map.md` | H5 ↔ Figma 的 Component Set Key、变体属性与 class 实现映射 | 将 H5 按需映射到 Figma 时（必读）|
| `pages/_index.md` | Page Pattern轻量路由；通过硬门槛后只读取完整命中的Page文件 | 生成或整体重构完整页面并需要判断是否存在可复用页面结构时 |
| `assets/tokens.json` | token 唯一数值源（改值只改这）| 改颜色/字号/间距/圆角/阴影时 |
| `assets/build-tokens.js` | 构建脚本（生成 v9-tokens.css 与文档表格）| 改完 tokens.json 后运行 |
| `assets/v9-tokens.css` | tokens.json 生成的 H5 Token CSS；由 v9-core.css 自动引入，禁止手改 | 核对构建产物或排查 H5 Token 时 |
| `assets/tokens-tables.md` | tokens.json 生成的 Token 查询表，禁止手改 | 查询 Token 名称、用途和值时 |
| `assets/v9-core.css` | H5 组件样式与结构实现，引用 v9-tokens.css | 生成或维护 H5 时引入 |
| `assets/v9-components.js` | H5 组件运行时（可直接调用的 `<v9-*>` 自定义元素、内部模板与交互） | 生成或维护 H5 时与 v9-core.css 一起引入 |
| `assets/components/` | H5 正式组件依赖的源 SVG、PNG 等固定资产，按组件目录复用 | 组件涉及图标、图片、Spinner 等固定资产时 |
| `scripts/validate-h5-runtime.mjs` | H5 自定义元素、组件身份、映射与运行时合同验证 | 修改 H5 组件、映射或发布新版 Skill 时运行 |
| `scripts/test-option-tile.mjs` | Option Tile / Warning Count 浏览器行为与布局回归 | 修改此组件状态、交互或布局时运行 |
| `scripts/validate-h5-page.mjs` | H5 页面组件调用门槛；拦截 `.empty-state` 等手工替代并核对 Empty 运行时与资产 | 生成或修改 H5 页面后运行 |
| `scripts/test-design-scopes.mjs` | 混合设计范围回归：旧空状态保护、9.0组件合同和范围标记错误 | 修改范围校验逻辑或发布相关规则升级时运行 |
| `scripts/validate-incremental-page.mjs` | 既有页面局部修改的截图保护校验；只允许已声明区域出现像素变化并输出差异图 | 基于既有页面局部修改且有可比基准截图时运行；文件名为兼容保留 |
| `scripts/build-h5-deliverables.mjs` | 从验证通过的组件化工程生成自包含单文件 HTML 与完整离线源码 ZIP | H5 页面验收通过后、交付附件前运行 |
| `scripts/validate-h5-deliverables.mjs` | 检查 HTML 无本地服务/绝对路径/外部资源依赖，并核对 ZIP 源码与资产完整性 | 生成双附件后运行 |
| `CHANGELOG.md` | 版本变更记录 | 核对升级内容或发布新版 Skill 时 |

---

## 执行框架

### 优先级顺序

1. **`custom-rules.md`** — 用户自定义规则，最高优先级，覆盖所有默认值（规范红线只在此处定义）
2. `visual-principles.md` — 在授权范围内决定跨组件的主次、组合与视觉选择，不声明未发布组件
3. 各专项规范文件（colors / typography / spacing / shadows / components）— 落实正式合同与具体数值
4. 通用设计常识

`visual-principles.md` 指导“选择什么视觉关系”，正式组件和 Token 决定“允许怎样实现”；前者不能覆盖
后者的结构、状态或数值合同。现有能力不能满足时，仍须走 `components.md` 的页面本地组合边界。

### 视觉原则读取

- 本次任务需要新增、改变或审核可见界面关系时，在首次视觉选择前读取一次
  `references/visual-principles.md`；同一任务内不因页面、状态或组件数量重复读取。
- `Local Edit` 仅在授权区域发生可见变化时读取，视觉原则只能作用于授权区域，不得成为修改锁定区域
  或整体重新美化原页面的理由。
- 纯映射、Key或属性修正、文档措辞、非视觉运行时修复、校验、打包，以及不涉及布局或视觉判断的
  单纯业务文案替换不读取。

### 任务能力路由

按页面、独立弹层或明确授权区域分别判断能力；同一PRD可混合命中，不给整个任务强制分配单一模式。
先确定要保护什么，再记录该设计单元的样式依据；这是内部执行路由，不要强制用户填写模式名或固定PageSpec。

| 能力 | 命中条件 | 默认保护 | 专项读取 |
|------|----------|----------|----------|
| `Create`（创建／重新设计） | 新增独立页面或弹层，或明确要求整体重新设计 | PRD要求及明确指定的继承元素；默认9.0，延续升级须明确继承范围 | 完整页面需要判断Page Pattern时读`pages/_index.md`；弹层不套整页Pattern |
| `Local Edit`（既有设计增量修改） | 基于已有设计增删改模块、字段或状态；范围可由用户直接指定，也可由PRD对照确认 | 无关模块和未授权维度；新增和修改部分与所属设计统一 | 读取`references/workflow.md`，不为原页面重套Page或整体迁移 |
| `H5 Migration`（9.0合规迁移） | 可编辑既有H5 + 明确修改动作 + 整个文件或指定范围整体符合9.0 | 业务内容、数据、状态含义、操作结果与范围外内容 | 额外读`references/h5-migration.md` |

截图、MasterGo、Figma、H5只是证据格式，不决定模式；材料中没展示不等于产品中不存在。
新增独立弹层可按`Create`采用9.0，其内部状态跟随弹层；旧页面新增错误等状态仍属`Local Edit`。
“新画板”不自动等于新增页面。完整判型、内容确认和基准缺失处理只查`references/workflow.md`。
有既有材料不等于`Local Edit`：“参考原图重新设计”属于`Create`，明确要求继承的风格与元素仍受保护。有H5文件也不等于
`H5 Migration`：仅检查、仅把H5作为交付格式，或只改颜色、字号、单个组件时仍按检查或`Local Edit`处理。
同时出现“整体符合9.0”与“只改指定范围”时，在该窄范围内执行`H5 Migration`，范围外保持锁定。

#### 页面产出

所有页面及独立弹层的产出、修改任务，包括直接写入MasterGo／Figma，必须先读取并执行
`references/workflow.md`的公共流程；不得因工具或交付平台不同跳过。
先展示按页面梳理的处理范围与状态，待澄清问题统一放在最后；只确认影响业务、意图或授权范围的
缺失与冲突，无待确认项时直接执行。最终文案、协议链接等可按workflow记录占位，不阻塞出图；
不得用占位替代业务规则。PM不需重新批准Skill既定规则或代替Agent选择组件。

三种能力共用`references/workflow.md`，同一任务读取一次、逐设计单元应用；凡本次产出或授权修改包含视觉决策，再按上面的规则先读
`references/visual-principles.md`。`Create`只在生成或整体重构完整页面时按需读
`pages/_index.md`；`Local Edit`不重新套Page；`H5 Migration`不因为迁移整页就自动套Page，
除非用户同时明确要求重新设计页面结构。部分命中或没有合适Page时按正式组件与Token自由组合，
不得强行套用最接近的模板。

1. **PRD → 组件化 H5（设计源）**
   读取 `references/components.md` 与 `references/workflow.md` 的公共主干、H5 分支；
   统一加载 `assets/v9-core.css` 与 `assets/v9-components.js`，调用已登记的 `<v9-*>`
   实现9.0区域；原设计保留／继承区域按已确认基准实现并标明来源，不强制替换为9.0。生成可验证的 H5。仅交付 H5 时不读取 `v9-figma-map.md`、不打开 Figma 主规范库做全量核对，
   也不生成独立的 Figma 组件映射表；H5 源码保留实际组件选择结果。
2. **H5 自查**
   按 `references/workflow.md` 的 H5 验收规则核对组件调用、Token、文案、交互、可访问性与可映射性；
   对交付项目运行 `node scripts/validate-h5-page.mjs <H5项目目录>`，不得只验证组件库本身。
   既有页面局部修改且具备同尺寸基准截图时，再按变更区域清单运行 `validate-incremental-page.mjs`；
   该校验只保护范围，不替代新增区域内的视觉判断。
3. **HTML + ZIP 双附件（默认交付物）**
   从同一个验证通过的组件化工程生成 `<项目名>.html` 与 `<项目名>.zip`：HTML 必须自包含、
   可在对话中直接预览且下载后双击运行；ZIP 必须保留组件化源码、运行时、Token 与全部离线资产。
   已确认的状态矩阵包含两个及以上页面/业务状态时，HTML 还必须提供位于375px业务画布之外的
   预览控制器；控制器只用于审阅，不登记为正式组件或进入Figma映射。具体规则见 workflow。
   最终回复同时提供两个附件链接；`127.0.0.1`、`file:///`、公开 HTTPS 均不得代替双附件。
4. **H5 → Figma（按需）**
   仅在需要进入设计源或形成双端交付时，增加读取 `references/v9-figma-map.md`
   与 `references/figma-workflow.md`；先从确认后的 H5 生成当前页面组件映射表，再将 `<v9-*>` 语义映射为
   真实 Figma 组件实例。不得用 H5 转普通图层代替组件映射。

#### 组件维护

新增、修改组件或发现 Figma、H5、映射不一致时，读取 `references/components.md`、
`references/v9-figma-map.md` 与 `references/component-maintenance.md`。变体、状态、
Slot、直接依赖或交互合同不明确时，先向用户确认，再执行修改。主规范库组件列表与 Skill 的全量
对比、组合组件直接依赖审计、Key或属性漂移修复都只在本事务执行，不作为普通页面出图前置步骤。

### 全局门槛

1. `assets/tokens.json` 是 Token 唯一数值源；`assets/v9-tokens.css` 与
   `assets/tokens-tables.md` 是生成文件，禁止手改。
2. 只有 Figma 已发布组件、H5 `<v9-*>` 封装与显式双端映射三项齐全，才能登记为
   `V9_COMPONENTS.kind=component`。
3. 采用9.0的区域必须调用可用的已登记 `<v9-*>`，不得复制组件内部 DOM；公开属性、状态、
   Slot 与内部边界以 `references/components.md` 为准。原设计继承实现不冒充9.0正式组件，具体范围见`workflow.md`。
4. 9.0区域在现有组件能力无法满足时，才允许按 `references/workflow.md` 建立“页面本地组合”；
   继承范围按已确认基准复用／重建。两种实现均不得冒充正式组件。
5. H5 映射到 Figma 时必须使用真实组件实例，不得用普通图层转换或页面本地组合
   冒充正式组件映射。
6. `references/visual-principles.md` 管跨组件视觉判断，`references/components.md` 管组件合同，
   `references/v9-figma-map.md` 管双端映射，
   `references/workflow.md` 管页面与H5执行，`references/figma-workflow.md` 管Figma页面写入，
   `references/component-maintenance.md` 管组件维护，`assets/tokens.json` 管 Token 数值。
7. 页面默认交付必须同时包含自包含 HTML 与完整源码 ZIP；本地测试地址、公开网站与 Figma
   只作为按需追加产物，不得成为唯一交付方式。
8. 已确认状态矩阵包含两个及以上页面/业务状态时，自包含 HTML 必须显式提供预览控制器和稳定
   状态地址；控制器位于375px业务画布外，不得冒充业务组件或改变业务页面结构。
