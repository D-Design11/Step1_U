# Trade-off Analysis Capability

**适用 Skill 版本：`design-review V2.9.1`**

这是按需加载的跨维度决策能力，不是用户单独调用的完整 Skill。由 `design-review` 在 Check Results 生成并检测到真实冲突后读取。Review Context Alignment 中的策略妥协由前置校验直接记录，不因 `partially_aligned` 自动加载本能力；只有正式 Check Results 产生跨维度冲突时才使用。

## 1. 触发条件

仅当符合以下条件之一时使用：

- 同一 `design_point` 的不同维度结果支持相反结论。
- 符合明确需求会损害用户任务、认知效率、操作安全、视觉无障碍或规范一致性。
- 修复体验问题需要改变明确 PRD 或业务规则。

普通缺失、普通错误或单维度问题不触发本能力。

## 2. 输入

```yaml
tradeoff_id: T-01
design_point: 好单标签展示范围
review_context: Review Target、Design Basis 与 Review Mode 摘要
requirements_evidence: PRD 与正式业务材料摘要
linked_check_results:
  - check_id: explicit-requirement-coverage
    dimension_id: D2
    status: 符合
    evidence: [PRD 要求多个订单页面展示好单标签]
  - check_id: redundancy-and-interference
    dimension_id: D3
    status: 不符合
    evidence: [历史详情页主要任务为查询记录，标签重复抢占注意]
linked_issue_ids: [R-03]
```

输入必须引用已有 Check Results，不重新发明目标或证据。

## 3. 分析步骤

1. **定义冲突**：分别写明两侧目标、约束和支持证据。
2. **确认是否真实冲突**：判断两侧是否作用于同一设计点、同一用户阶段；可同时符合时不算取舍。
3. **识别不可协商项**：明确安全、合规、资金、核心业务规则或用户核心任务中有证据支持的硬约束。
4. **识别可调空间**：检查位置、时机、范围、频次、强度、层级、文案和交互方式是否可调整。
5. **比较方案**：至少比较“按原要求保留”“按体验建议删除/调整”“按任务阶段差异化”中的适用方案。
6. **给出结论**：说明保留什么、调整什么、牺牲什么，以及为什么。
7. **确定权限边界**：若结论需要改变明确 PRD 或业务规则，标记需产品/业务决策，不能由审查者单方面决定。

## 4. 决策原则

- 先保护有证据支持的不可逆风险与用户核心任务。
- 业务曝光强度应匹配用户任务阶段；关键决策节点可以强化，非决策节点应降低干扰。
- 优先寻找按场景、层级、频次或强度差异化的方案，避免“全部保留/全部删除”的假二选一。
- 不用个人审美推翻明确要求，也不因 PRD 已写就忽略体验损害。
- 规范例外必须比较“遵循原规范”“采用例外方案”和“降低偏离程度”的影响；设计方已声明例外不代表审查者必须接受。
- 证据不足以比较方案时，结论为 `insufficient_evidence`，列出验证方式。

## 5. 输出

```yaml
tradeoff_id: T-01
design_point: 好单标签展示范围
status: resolved | requires_product_decision | insufficient_evidence
conflict:
  side_a: 符合多页面曝光要求
  side_b: 保持非决策页面任务聚焦
non_negotiables: [关键接单决策节点必须强化好单感知]
adjustable_factors: [页面范围, 展示强度, 重复频次]
decision: 决策节点完整展示，非决策详情页弱化或移除
rationale: 曝光价值随任务阶段下降，差异化展示可保留目标同时降低信息噪音
sacrifice: 放弃所有订单页面同等强度曝光
authority: requires_product_decision
linked_check_ids: [explicit-requirement-coverage, redundancy-and-interference]
linked_issue_ids: [R-03]
actions:
  - 产品确认“多页面展示”是否允许按任务阶段分级
  - 设计补充决策页、执行页和历史页的标签强度规则
```

Trade-off Decision 是独立结论层，不替代原始 Check Results，也不删除关联 Issue。Action 必须引用 `T-xx`，方便追踪决策来源。
