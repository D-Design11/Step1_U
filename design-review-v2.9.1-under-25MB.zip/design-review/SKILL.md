---
name: design-review
description: 基于可视化材料审查数字产品的 UI、UX、可见交互流程、Landing Page 和设计交付物，先检查评审输入完整性，再基于 PRD 的业务背景、目标和产品方案校验设计方声明的 Review Context 与设计策略；策略满足或存在可追踪妥协时继续审查，不满足核心需求时阻断。随后抽取 Requirements Evidence、生成 Validation Scope，自动加载 Skill 内适用的 Design Standard Reference，并交叉验证需求、设计稿、规范及历史版本，输出有证据、分优先级、可执行的视觉设计审查报告。用于页面、流程或功能评审，全新设计、局部优化、重构、设计走查、交付前质检、规范一致性检查、体验问题分析，以及用户要求“评审设计稿”“设计质检”“检查页面/流程”“比较改版前后”时；支持图片、PDF、原型截图、页面链接或结构化设计说明。
---

# 设计审查 · V2.9.1

**当前版本：`V2.9.1`**

版本号用于人工发布、报告追踪与兼容性管理；Skill 的稳定机器标识保持为 `design-review`，避免调用路径和历史引用失效。

版本记录见 [references/version-history.md](references/version-history.md)。

## 总规则

只基于**已完成评审上下文校验的 Review Context、正式材料抽取的 Requirements Evidence、Material Analysis、AI 生成的 Validation Scope 和实际加载的 Design Standard Evidence**执行正式设计审查。Review Context 描述设计方声明的设计策略、评审对象、设计关系、评审方式和主动规范例外；PRD 已明确的业务事实由 Skill 抽取，不要求设计师重复确认。

Design Standard Reference 是 Skill 的系统级评审资产。根据 Review Target、Material Analysis 和 Validation Scope 自动选择并加载；设计师无需重复上传已有规范。加载规范是证据准备动作，不是准入校验；是否符合、未覆盖、主动例外或违反规范，只能在正式 Checks 中判断。

评审上下文校验必须先判断设计策略是否承接 PRD 的业务背景、核心目标和产品方案：`aligned` 正常继续；`partially_aligned` 记录未覆盖目标、妥协、风险和决策权限后继续；`not_aligned` 阻断正式设计审查。不要把“设计实现得精致”误当成“设计策略正确”。

先执行 Review Context Intake。缺少当前设计、设计策略、评审层级、对象名称、设计关系、Flow 边界或其他会改变策略的阻断项时，必须集中追问并等待用户补全；不要猜测后直接评审。次要业务事实或增强材料缺失进入 `limited`，说明受限能力并请求补充，不默认阻断整个评审。

## MVP 审查边界

当前版本只审查用户能够从屏幕直接感知的视觉设计及其可见交互表达。

纳入审查：

- 页面结构、信息组织、视觉层级、文案和内容表达。
- 组件、色彩、字体、间距、对齐、图标及可见状态。
- 可见的操作入口、状态反馈、流程表达和操作安全提示。
- 小屏、长文本、多标签、动态字号、极端数据等视觉适配。
- 对比度、颜色冗余、文字可读性、可见点击目标等视觉无障碍表现。

不纳入审查：

- TTS、声音、语音播报等听觉体验。
- 震动等触觉反馈。
- 读屏语义、读屏顺序、键盘/焦点实现等非视觉辅助技术。
- 后端逻辑、算法策略、数据准确性、性能和其他技术实现质量。

非视觉需求不得形成 Issue、Question、Action，也不得因证据不足而影响审查结论。它们属于 Skill 的固定能力边界，除非用户明确要求说明，否则不要在报告结论中重复展示。

## 读取参考资料

- 每次审查先完整读取 [references/review-context.md](references/review-context.md)，执行 Review Context Intake、Builder、Material Analysis、Requirements Evidence、Review Context Alignment Validation、Scope Generation 与 Readiness Validation。
- 每次审查读取 [references/design-standard-reference.md](references/design-standard-reference.md)，在 Validation Scope 生成后选择适用的系统规范；司机端通用评审按需读取 [references/driver-design-guidelines-9.0.pdf](references/driver-design-guidelines-9.0.pdf)，行中场景同时读取 [references/driver-in-trip-guidelines.pdf](references/driver-in-trip-guidelines.pdf)。
- Review Readiness Validation 为 `ready`，或用户已接受限制的 `limited` 后读取 [references/review-criteria.md](references/review-criteria.md)，执行其中注册的全部 Checks。
- 仅在 Check Results 证明存在跨维度冲突时读取 [capabilities/trade-off-analysis.md](capabilities/trade-off-analysis.md)；没有冲突时不加载。
- 输出正式报告前读取 [references/report-template.md](references/report-template.md)。
- 默认生成独立、离线可读的 HTML 报告；读取 [references/html-report.md](references/html-report.md)，并参考 [assets/html-report-template.html](assets/html-report-template.html)。只有用户明确要求纯文本时才只在对话中输出。
- 用户提供可确认版本更新或适用范围更准确的官方规范时，记录替代关系并以更新、更具体的正式规范为准；用户偏好和通用参考不能冒充团队规则。

## 架构

```text
Context Layer
  ├── Review Context Intake → 补充请求循环
  ├── Review Context Builder
  ├── Material Analysis + Requirements Evidence
  ├── Review Context Alignment Validation
  └── Validation Scope Generation + Readiness Validation
Evidence Layer
  ├── Requirements Evidence
  ├── Material Analysis
  └── Design Standard Reference → Design Standard Evidence
Core Review
  └── D1–D5 Dimensions → Checks → Check Results
Supporting Quality
  └── D6 视觉适配与交付 Checks
Decision Capabilities
  └── Conflict Detection → Trade-off Analysis（按需）
Output
  └── Issues / Trade-off Decisions / Actions / HTML Report
```

检查维度属于核心审查；冲突检测属于主流程；取舍分析位于独立 capability；最终决策仍由本 Skill 报告。不要要求用户单独调用取舍能力。

## 工作流

### 1. Review Context Intake

先检查用户消息、附件和链接是否包含启动本次评审所需的信息：

- 所有评审必须有可读取的当前设计材料、设计方声明或确认的 Design Strategy、Review Target 层级和名称、Design Basis Relationship，以及能证明业务背景、核心目标和产品方案的 PRD 或等价正式需求材料。
- Flow 必须有起点和终点。
- `review_mode` 无法可靠推断且会改变策略时必须询问。
- `delivery_qa` 必须同时有目标设计和实现证据。

缺少阻断项时，一次性列出全部“必须补充”内容、原因和用户需要采取的动作，然后暂停。缺少 PRD、历史基线、旧方案或部分状态时，列为“建议补充”，说明受限能力；询问用户补充材料或接受 `limited` 继续。系统规范已覆盖时不得要求设计师重复上传；只有规范未覆盖、主动突破规范、特殊平台或现有规范被明确指出已过期时才请求补充。用户补充后重新执行完整 Intake。

不要要求用户填写页面清单、baseline、Requirements Evidence 或 Validation Scope。详细规则见 [references/review-context.md](references/review-context.md)。

### 2. Review Context Builder

按 [references/review-context.md](references/review-context.md) 从用户说明、提交信息和设计材料建立最小 Review Context：

- `design_strategy.statement` 说明设计方准备用什么体验策略承接需求；不能从 PRD 或待评设计反向编造。
- `review_target.level` 只使用 `page`、`flow` 或 `feature`；`name` 是对象集合名称，不是页面清单。
- Flow 只填写起点和终点，不要求设计师逐页列举。
- `design_basis.relationship` 只使用 `from_scratch`、`local_optimization` 或 `redesign`。
- `review_mode` 使用 `new_design`、`local_change` 或 `delivery_qa`。
- 用户明确给出的关注点和边界只记录为 `scope_constraints`。
- 用户主动突破现有规范时，将规则、理由、预期收益和风险控制记录为可选的 `design_exceptions`；没有例外时保持为空。
- 只询问会改变评审层级、设计关系、评审方式或 Flow 边界的缺失信息。

不要在 Review Context 中填写 baseline、页面清单或业务事实，也不要要求设计师确认 PRD 已明确的用户、目标、状态、触发事件和业务规则。若设计策略只能推断且推断会影响校验结论，必须请设计方确认后继续。

### 3. Material Analysis 与 Requirements Evidence

- 从设计稿、原型、线上截图和实现材料中识别当前设计、页面、状态、节点、设计点和可用 baseline。
- baseline 可来自独立材料或设计稿内嵌的前后对比；由 Skill 判断是否需要比较及比较维度。
- 从 PRD、流程图、业务规则和其他正式材料抽取用户、问题、目标、状态、触发、规则、价值与期望行动，保留 Requirements Source Trace。
- 不用待评设计反向证明业务事实；PRD 已明确时直接采用，不重复询问设计师。
- PRD 局部缺失或冲突只影响相关 Checks；只有核心目标、关键规则或主要任务整体无法识别时才阻断。

### 4. 评审上下文校验

基于 Requirements Evidence 校验 Review Context，而不是用 Review Context 改写 PRD：

- `strategy_alignment`：设计策略是否支持核心业务目标和产品解决方案。
- `scope_alignment`：Review Target 是否覆盖需求要求解决的主要对象和任务边界。
- `relationship_alignment`：设计关系与实际变化、历史能力和评审模式是否一致。

输出 `aligned`、`partially_aligned` 或 `not_aligned`：

- `aligned`：策略、对象和关系能够支持核心需求，继续生成 Validation Scope。
- `partially_aligned`：覆盖核心方向但对部分目标有明确妥协，记录已覆盖目标、未覆盖目标、妥协理由、风险和决策权限后继续；这些记录进入报告，但不自动转成设计 Issue。
- `not_aligned`：策略方向与核心目标冲突、完全无法覆盖核心需求，或评审对象与需求目标严重错位；将 Readiness 设为 `blocked`，停止正式设计审查并要求重新澄清策略。

阻断必须有 PRD 证据且谨慎使用。策略不完整但仍覆盖核心方向时优先判定 `partially_aligned`，不要因表达不够理想就阻断。

### 5. Validation Scope Generation

基于 Review Context、Material Analysis、Requirements Evidence 和设计约束生成 Validation Scope：

- `page`：目标页面及其可见状态进入范围。
- `flow`：从起点到终点识别页面、状态、节点和闭环关系。
- `feature`：识别功能入口、相关页面、关键 Flow 和能力关系。
- `from_scratch`：当前方案全部可见内容和需求证明必要的关键状态、任务路径进入范围。
- `local_optimization`：`change_scope + impact_scope - unrelated_historical_issues`。
- `redesign`：新方案整体和原有关键能力迁移进入范围；有可靠 baseline 时执行比较。
- `delivery_qa`：本次交付对象、相关状态、实现证据和规范进入范围。
- `change_scope`、`impact_scope`、`excluded_scope` 均显式输出并记录理由、证据和限制。

Validation Scope 必须由 Skill 生成。用户提供的边界只作为约束，不代替影响分析；不要要求用户编写最终 Scope。

### 6. Design Standard Reference Loading

在 Validation Scope 生成后按 [references/design-standard-reference.md](references/design-standard-reference.md) 准备规范证据：

- 根据 Review Target、Material Analysis 和 Validation Scope 选择适用规范，不要求设计师上传 Skill 已包含的规范。
- 司机端通用设计加载 9.0 通用规范；涉及接乘客、等乘客、送乘客、行中订单卡、主操作条或更多操作页时，同时加载行中专项规范。
- 生成 Design Standard Evidence，记录实际读取的规范、适用范围、覆盖状态、冲突和 `design_exceptions`。
- 专项规范优先于通用规范；用户提供的更新且更具体的官方规范可以替代系统资产，但必须记录版本和适用范围。
- 规范未覆盖时标记 `uncovered`，不自动阻断评审，也不自动形成 Issue。

这里只加载和整理证据，不判断设计是否符合规范，不创建 Design Standard Validation 阶段。

### 7. Review Readiness Validation

按 [references/review-context.md](references/review-context.md) 输出：

- `ready`：评审上下文为 `aligned` 或 `partially_aligned`，且对象、策略和 Scope 足以支持正式结论。
- `limited`：部分比较、归因或 Checks 受材料限制；先请求用户补充或确认接受限制，再继续正式评审并逐项记录限制。
- `blocked`：评审上下文为 `not_aligned`，或评审对象 / Flow 边界不明确、策略冲突未解决、核心 Scope 无法生成，或 PRD / 设计材料整体不足以支持正式结论。

`partially_aligned` 不等于 `limited`：前者是有证据的设计策略妥协，后者是材料或能力限制。策略部分满足但材料充分时，Readiness 仍可为 `ready`。

仅 `blocked` 暂停。此时只输出已识别的 Review Context、Intake 阻断项、Material Analysis、Requirements Evidence、Scope Draft、缺失或冲突字段、范围限制及必须补充的材料；不要输出设计结论、正式 Check Results、P0–P3 或网页报告。

### 8. 建立审查契约

Readiness 为 `ready` 或 `limited` 后记录：

- Review Context 及策略限制。
- 评审上下文校验结果，以及 `partially_aligned` 时的策略妥协、风险和权限边界。
- Material Analysis 和 Requirements Source Trace。
- AI 生成的 Validation Scope、生成理由、证据和限制。
- Design Standard Evidence：实际加载的系统规范、适用范围、覆盖状态、冲突和主动规范例外。
- 审查对象：页面、流程、组件、版本和平台。
- 材料角色：`审查上下文`、`需求依据`、`稳定规范`、`审查对象`、`历史版本` 或 `补充说明`。
- 可用证据与审查限制。
- Change Scope、Impact Scope 和 Excluded Scope。

不要因文件名或视觉相似度自动互换材料角色。无法读取、分辨率不足或被裁切的内容记录为限制。

### 9. 建立需求追踪

将每项属于 MVP 视觉审查边界的明确需求映射到页面、控件、文案、状态或流程节点，并标记：

- `符合`：有明确证据。
- `部分符合`：主要承载存在，但条件、状态或反馈不完整。
- `不符合`：有充分证据表明缺失或冲突。
- `证据不足`：依赖的需求事实存在缺失或冲突，或设计 / 实现材料不足以判断。
- `不适用`：与 Requirements Evidence 和审查范围无关，并说明原因。

禁止凭常识补写 PRD，也不要把个人偏好包装成需求。范围外的非视觉要求不进入需求追踪，不产生缺失状态。

### 10. 生成 Check Results

按以下顺序执行 [references/review-criteria.md](references/review-criteria.md) 的全部 Checks：

1. D1 业务目标与场景符合性：为什么做。
2. D2 需求与规则符合性：明确要求做什么。
3. D3 信息架构与认知效率：做出来是否有效。
4. D4 交互反馈与操作安全。
5. D5 视觉与规范符合性。
6. D6 适配、视觉无障碍与交付完整性。

Check 是最小判断单元。每个 Check 生成结构化 Check Result，包括语义化 `check_id`、关联 `design_points`、五态结果、Finding Trace、确定性和关联项；不适用不等于省略。Finding Trace 必须区分判断依据、设计观察和 Scope 关系；所有业务正确性判断必须引用 Requirements Evidence 的正式来源。依赖规范的 Check 还必须引用 Design Standard Evidence，并记录 `compliant`、`uncovered`、`intentional_exception` 或 `violation`；规范关系状态不替代五态结论。

目标层级重点：

- Page：页面任务、信息组织、视觉层级、可见状态和操作入口。
- Flow：从 Review Target 边界识别的状态变化、页面连续性、任务闭环和操作负担。
- Feature：PRD 证明的用户问题与价值主张、功能入口、关键 Flow、信任与转化路径。

模式重点：

- `new_design`：需求覆盖、端到端路径、关键状态、信息层级和新模式可学习性。
- `local_change`：变更目标、前后版本、能力回归和全局一致性；没有旧版时不声称改善或退化。
- `delivery_qa`：规范、组件、状态、标注、适配、内容准确性和实现完整性。

### 11. 派生已发现问题与待补充材料

先生成全部 Check Results，再派生问题：

- `部分符合`、`不符合`形成 Issue 候选；相同根因归并为一个 `R-xx`，报告中称为“已发现问题”。
- `证据不足`形成或关联 `Q-xx`；相同材料缺口归并，报告中称为“待补充材料”。
- `符合`与`不适用`通常不产生问题。

不要让 Dimension 或 Check 与 Issue 一一绑定。一个 Issue 可以聚合多个 Checks，多条证据不足结果也可以归并为一项待补充材料。内部保留 ID 和关联关系，报告正文不要求读者理解 `R-xx`、`Q-xx` 或关联 Checks。

### 12. 检测冲突并按需执行取舍分析

按 `design_points` 关联不同维度的 Check Results。若符合明确要求与信息效率、操作安全、视觉规范或视觉无障碍结果产生方向冲突，标记 `tradeoff_candidate` 并读取 [capabilities/trade-off-analysis.md](capabilities/trade-off-analysis.md)。

输出独立的 `T-xx` Trade-off Decision，明确冲突双方、不可协商项、可调空间、决策、牺牲项和权限边界。若建议需要改变明确 PRD 或业务规则，必须标为 `requires_product_decision`，不能由审查者单方面决定。

### 13. 归并与定级

合并同一根因造成的重复症状，按用户影响定级：

- `P0 阻断`：核心任务无法完成，或存在严重安全、合规、资金风险。
- `P1 严重`：核心任务高概率失败、关键需求缺失或造成不可逆错误。
- `P2 重要`：明显增加理解或操作成本，影响非核心路径或一致性。
- `P3 建议`：低风险优化或打磨项。

证据不足不列为已发现问题，而是归并为待补充材料；不能通过提高优先级弥补不确定性。

### 14. Review Report

内部先完成全部审查项和归并判断；报告展示顺序面向阅读与决策，不照搬内部推理顺序。首屏先给总体结论与数据概览：

- `通过`：未发现必须修改的问题，当前设计可以进入下一阶段。
- `修改后通过`：存在明确的必须修改项，但方案方向和核心流程成立；完成报告指定修改后无需重新评审。
- `不通过，需重新评审`：核心目标、关键流程、关键信息表达或方案合理性存在重大问题；修改后必须重新提交评审。

审查结论只表达推进决策，不描述审查范围、限制条件、未覆盖项或待补充材料。若输入材料整体不足以支持这三种结论，应在 Review Readiness Validation 阶段判定为 `blocked`，不生成正式报告。

按 [references/report-template.md](references/report-template.md) 依次展示总体结论、关键发现、后续行动、前后对比、审查背景、评审上下文校验、范围与材料、维度总览和需求追踪；全量审查项放入附录，网页默认折叠。`partially_aligned` 的策略妥协必须可见，但不计入 Check Result 数量。

首屏必须说明数据从属关系：

- 五态审查结果合计为审查项总数：`不符合 + 部分符合 + 证据不足 + 符合 + 不适用`。
- 已发现问题由不符合或部分符合结果按根因归并。
- 待补充材料由证据不足结果按共同材料缺口归并。
- 已发现问题与待补充材料不参与审查项总数合计。

数据展示按关注优先：非零关注数据在前，零值关注项其次，符合和不适用最后。审查项总数作为结果分布的父级信息写在分组标题或关系说明中，不得作为首张数据卡抢在关注数据之前。正文统一使用“审查项、符合、部分符合、不符合、证据不足、已发现问题、待补充材料”等中文名称；后续行动不展示关联 Checks 或内部来源编号。

若没有发现问题，区分“符合”和“证据不足”，不要制造问题填充报告；没有冲突时省略取舍章节。

生成网页后，在本地浏览器检查桌面与窄屏布局、图片加载、正文可读性、表格折行、图片放大和打印样式。最终 HTML 与相对路径图片放在同一报告目录，不依赖在线字体或外部脚本。

## 审查原则

- 证据优先级：PRD 与正式业务材料 > 适用的团队设计规范 > 设计稿直接证据 > 用户补充说明 > 通用启发式 > 审查者偏好。专项规范优先于通用规范；更新且适用范围更准确的正式版本优先于旧版。
- 明确指出证据冲突，不自行决定业务取舍。
- Flow 条件需求同时引用 Requirements Evidence 中的触发条件与界面表现证据。
- Feature 价值目标同时引用 Requirements Evidence 中的目标用户 / 用户问题与页面价值表达证据。
- PRD 是输入约束，不是整体设计正确性的唯一标准；只审查其中属于 MVP 视觉边界的要求，D2 符合不覆盖 D1、D3–D6 的异常结果。
- Validation Scope 由 Skill 生成；用户提供的范围只作为约束。局部改造只报告本次变更或受其影响的问题，不翻出无关历史问题。
- Requirements Source Trace 说明业务事实来源；Material Analysis 说明设计对象和 baseline 识别；Finding Trace 说明判断依据、设计观察和 Scope 关系，三者不得混用。
- 评审上下文校验比较“设计方声明的策略”与 Requirements Evidence；不得从 PRD 复制出策略，也不得从最终设计效果反向证明策略正确。
- 不同维度产生冲突时给出可追踪的 Trade-off Decision，不用单一维度结论静默覆盖另一维度。
- “未提供”不等于“未设计”；局部需求事实或设计证据缺失在依赖它们的审查项中使用“证据不足”，只有核心评审契约无法建立时才阻断。
- 精确规范结论必须有可测量证据或明确规范。
- 规范未覆盖不等于设计不符合；主动规范例外不等于自动通过。例外必须在正式 Check 中结合业务依据、预期收益和风险控制判断。
- 建议描述预期结果和约束，避免“调大、调亮、优化一下”等空泛表述。
