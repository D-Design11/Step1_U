# 设计审查维度与 Checks · V2.9.1

**适用 Skill 版本：`design-review V2.9.1`**

## 目录

1. 核心数据模型与 Check Result
2. D1-D5 Core Review
3. D6 Supporting Quality
4. 问题派生、冲突检测与根因归并

仅在 Review Context Alignment 为 `aligned` 或 `partially_aligned`，且 Review Readiness Validation 为 `ready`，或用户已接受限制的 `limited` 后使用本文件。

## 1. 核心数据模型

```text
Dimension
  └── Check
        └── Check Result
              ├── 异常结果 → 已发现问题 / 待补充材料
              ├── 跨维度冲突 → Trade-off Decision
              └── Issue / Decision → Action
```

- **Dimension**：定义一组稳定的审查关注点。
- **Check**：最小判断单元，使用稳定语义 ID，不使用展示型层级编号充当身份。
- **Check Result**：一次审查中某个 Check 的状态、证据和关联对象。
- **Issue**：由一个或多个已确认的异常结果归并产生，报告中称为“已发现问题”，不与 Check 一一对应。
- **Question**：设计或实现证据不足时产生的内部追溯对象，报告中称为“待补充材料”。
- **Trade-off Decision**：不同维度对同一设计点产生冲突时的决策层结论。
- **Action**：由 Issue 或 Trade-off Decision 派生的处理动作。

内部先生成全量 Check Results，再汇总 Issues、Questions、Trade-off Decisions 和 Actions。报告正文先展示关键发现与行动，全量审查项放在附录。

## 2. Check Result 结构

每个适用的 Check 都产生一条结果：

```yaml
dimension_id: D2
check_id: explicit-requirement-coverage
check: PRD 明确要求是否被正确承载
design_points: [好单标签-历史订单详情页]
applicability: applicable
status: 符合
evidence:
  - PRD REQ-003 要求订单相关页面展示好单标签
  - 历史订单详情页已展示标签
finding_trace:
  basis: PRD REQ-003
  observation: 历史订单详情页已展示标签
  scope_relation: impact_scope
standard_trace: null                  # 仅依赖规范的 Check 填写
certainty: high
issue_ids: []
question_ids: []
```

必填字段：`dimension_id`、`check_id`、`design_points`、`applicability`、`status`、`evidence`、`finding_trace`、`certainty`、`issue_ids`、`question_ids`。依赖规范的 Check 额外填写 `standard_trace`。

`finding_trace` 必须包含：

- `basis`：需求、规则、规范或明确标注为通用原则的判断依据。
- `observation`：设计稿、流程、原型或实现材料中实际观察到的证据。
- `scope_relation`：该设计点属于 `change_scope`、`impact_scope` 或 `excluded_scope` 的哪一类，以及原因。

属于 `excluded_scope` 的历史问题不能派生 Issue；若它与新设计形成冲突，应重新归入有证据支持的 `impact_scope` 后再判断。

五态结果：

- `符合`：有充分证据证明达到要求。
- `部分符合`：主要承载存在，但存在已确认的不完整或偏差。
- `不符合`：有充分证据证明缺失、冲突或目标无法成立。
- `证据不足`：Check 适用，但依赖的 Requirements Evidence 存在缺失或冲突，或范围内视觉设计 / 可见交互材料不足以判断。
- `不适用`：与 Requirements Evidence、Review Target 或 Validation Scope 无关，并说明理由。

结果、问题优先级和证据确定性分别记录。`P0–P3` 只用于已发现问题；证据不足产生待补充材料，不强行定级。

`standard_trace` 结构：

```yaml
standard_trace:
  reference: driver-in-trip-guidelines
  rule: 行中平台型组件占用屏幕高度不超过 540px
  relation: violation               # compliant | uncovered | intentional_exception | violation
  exception_assessment: null
```

规范关系状态描述设计点与适用规范的关系，不替代五态结果。`uncovered` 不自动等于证据不足或不符合；`intentional_exception` 不自动等于符合。

## 3. Core Review

### D1. 业务目标与场景符合性

回答“为什么做，以及是否在正确上下文中支持目标”。

D1 检查实际设计方案是否支持业务目标；前置的 Review Context Alignment 检查设计方声明的策略是否合理。两者不能互相替代：策略满足不代表实现满足，策略部分满足也不自动令 D1 失败。

- `target-context-fit`：设计表现是否命中 Requirements Evidence 证明的目标用户、业务对象、场景 / 入口、状态与触发条件。
- `business-goal-support`：方案是否有效支持核心业务目标，而不只是完成元素清单。
- `user-decision-path-fit`：方案是否把信息与能力放在用户认知或决策路径中的正确节点。

Flow 重点使用当前状态、触发事件和前后步骤；Feature 重点使用用户问题、入口、价值主张和转化目标。

### D2. 需求与规则符合性

回答“PRD 明确要求做什么，以及业务约束是否被正确承载”。本维度是约束检查，不独立代表整体设计正确。

- `explicit-requirement-coverage`：PRD 中属于 MVP 视觉边界的信息、操作、状态和可见反馈是否准确完整地实现。
- `business-rule-correctness`：资格、权限、时间、金额、对象、顺序和条件等业务规则是否正确。
- `boundary-condition-coverage`：需求明确或流程证明必要的边界条件与分支是否覆盖。

PRD 被完整实现时，本维度可以符合；若实现方式损害当前任务或认知效率，由 D3 等维度记录，并进入冲突检测。

### D3. 信息架构与认知效率

回答“做出来是否对当前用户任务有效”。

- `information-task-fit`：信息是否出现在用户需要理解或决策的位置，与当前页面主要任务相关。
- `information-priority`：信息分组、阅读顺序和视觉主次是否支持用户决策顺序。
- `redundancy-and-interference`：是否存在重复、无关或过度强调的信息，抢占当前页面核心任务。
- `content-clarity-consistency`：概念、标题、标签、按钮、数字、单位、时间和格式是否清楚一致。

Feature 特别检查价值主张、卖点、信任依据和承诺边界；Flow 特别检查当前阶段需要的信息与认知负担。

### D4. 可见交互反馈与操作安全

回答“用户能否安全、可预期地完成行动”。

- `action-discoverability`：操作是否可发现，主次行动和当前状态是否匹配，隐藏手势是否有替代入口。
- `task-flow-closure`：入口、关键步骤、结果与下一步是否闭环，退出和返回是否可预期。
- `feedback-and-recovery`：屏幕上可见的操作反馈、错误解释、重试、撤销和中断恢复是否及时明确；不检查语音或触觉反馈。
- `operation-safety`：驾驶、资金、身份、位置或不可逆操作是否降低误触并提供必要保护。

### D5. 视觉与规范符合性

回答“视觉表达与既有设计体系是否一致、有效”。

- `component-pattern-consistency`：组件结构、样式、状态和行为是否复用稳定模式。
- `visual-hierarchy-consistency`：字号、字重、颜色、间距、对齐、容器、图标和留白是否稳定表达层级。
- `semantic-cue-redundancy`：关键状态是否避免只依赖颜色、位置或隐藏手势表达，并提供可见文字、图形或其他视觉冗余线索。

执行本维度前使用 Design Standard Evidence：

- `compliant`：有明确规范与设计证据证明一致；可支持相关 Check 判为符合，但不能覆盖其他维度异常。
- `uncovered`：适用规范没有对应规则；不自动形成 Issue，改用 PRD、当前用户任务和明确标注的通用原则判断设计质量。
- `intentional_exception`：设计方主动声明突破规范；检查被突破规则、业务依据、预期收益、风险控制及是否有更低成本替代方案，再决定五态结果。
- `violation`：有明确、适用且可核对的规范证据证明不一致，且不存在成立的例外；形成部分符合或不符合候选。

专项规范优先于通用规范。规范之间存在无法解决的版本或规则冲突时，将依赖该规则的 Check 标记为证据不足并列出冲突。没有已加载的适用规范或测量证据时，不能声称违反团队规范。

## 4. Supporting Quality

### D6. 适配、视觉无障碍与交付完整性

- `device-content-adaptation`：设备、安全区、系统栏、长内容、多语言、动态字号和极端数据是否适配。
- `visual-accessibility-and-inclusion`：对比度、颜色冗余、文字可读性、可见点击目标和包容性视觉表达是否符合必要要求。
- `visual-delivery-completeness`：页面、组件、可见状态、跳转、内容规则、截断、刷新、动效和视觉资源是否足以实现与验收。

TTS、声音、震动、读屏语义与顺序、键盘/焦点实现、后端逻辑、算法、数据准确性和性能不属于当前 Checks；不得将它们记录为 `证据不足` 或派生待补充材料。

D6 依赖字号、设备、容器、组件状态或交付规则时，同样引用 Design Standard Evidence 并记录 `standard_trace`；规范未覆盖的极端场景仍可依据可见布局证据和用户任务风险判断。

## 5. 已发现问题与待补充材料派生

- `部分符合` 或 `不符合`：形成 Issue 候选；按根因归并后建立 `R-xx`，报告中显示为已发现问题。
- `证据不足`：建立或关联 `Q-xx`；按共同材料缺口归并，报告中显示为待补充材料。
- `符合`、`不适用`：通常不产生 Issue；但符合结果仍可能参与跨维度冲突分析。

一个 Issue 可以关联多个 Checks；一项待补充材料也可以对应多个证据不足结果。不要把每条异常机械转换成独立问题或材料项。

## 6. 跨维度冲突检测

对 `design_points` 相同或高度相关的结果执行冲突检测。出现以下任一信号，标记 `tradeoff_candidate: true`：

1. D2 为符合，但 D3、D4 或 D5 为部分符合/不符合。
2. 符合某项明确要求会降低当前任务聚焦、认知效率、操作安全或视觉可访问性。
3. 修复体验问题会违反明确 PRD、业务规则或其他不可协商约束。
4. 两个 Checks 对同一设计点导出方向相反且不能同时符合的建议。

冲突不是普通 Issue 的同义词。检测到候选后，按需读取 `capabilities/trade-off-analysis.md`，形成设计决策；没有冲突时不要加载该能力。

## 7. 根因归并示例

若按钮文案、结果标题和错误提示都因“结果状态模型未定义”而异常，只建立一个 Issue。若“好单标签”符合多页面曝光要求但干扰非决策页主要任务，则保留 D2 的符合结果、记录 D3 的异常结果，并生成一条 Trade-off Decision，而不是简单判定“PRD 错”或“删除标签”。
