# Design Review Skill 版本记录

本文件记录正式发布版本及核心改动。新版本追加在顶部；机器标识始终保持为 `design-review`。

## 目录

- 当前版本：V2.9.1
- V2.9 历史版本
- V2.8 历史版本
- V2.7 历史版本
- 早期未编号版本

## V2.9.1

- **发布日期**：2026-08-10
- **状态**：当前版本
- **检查维度版本**：设计审查维度与 Checks · V2.9.1

### 核心改动

1. **设计规范升级为系统级 Reference**
   - 内置司机端 9.0 通用设计规范和司机端行中专项规范，按 Review Target、Material Analysis 与 Validation Scope 自动选择。
   - 系统已有且适用的规范不再要求设计师重复上传；行中场景同时使用通用规范和专项规范。
   - 专项规范优先于通用规范，更新且适用范围更准确的正式规范可替代系统资产并记录替代关系。

2. **分离规范加载与规范判断**
   - 增加 Design Standard Evidence，记录实际读取的规范、覆盖范围、覆盖缺口与冲突。
   - 加载规范属于正式 Checks 前的证据准备，不新增 Design Standard Validation 准入阶段。
   - 规范符合性继续由 D5、D6 等实际依赖规范的 Checks 判断，符合规范不替代业务和体验结论。

3. **增加规范关系与例外模型**
   - 规范关系使用 `compliant`、`uncovered`、`intentional_exception`、`violation`。
   - `uncovered` 不自动等于不符合或证据不足；`intentional_exception` 不自动等于符合。
   - Review Context 增加可选 `design_exceptions`，记录被突破规则、理由、预期收益和风险控制。

4. **更新报告追溯**
   - 报告的判断依据与材料展示系统规范、通用/专项角色、覆盖状态和替代关系。
   - 依赖规范的审查项增加规范来源、具体规则和关系状态。
   - 规范未覆盖作为覆盖信息呈现，不自动生成设计问题。

### 兼容性变化

- 20 个语义化 Check IDs 保持不变。
- Review Context 移除 `design_constraints.design_system`，新增可选 `design_exceptions`。
- Check Result 对依赖规范的检查新增 `standard_trace`。
- 新增 `design_standard_evidence`，不参与 Review Context Alignment，也不单独决定 Review Readiness。

### 主要文件

- `SKILL.md`
- `references/design-standard-reference.md`
- `references/driver-design-guidelines-9.0.pdf`
- `references/driver-in-trip-guidelines.pdf`
- `references/review-context.md`
- `references/review-criteria.md`
- `references/report-template.md`
- `references/html-report.md`
- `capabilities/trade-off-analysis.md`
- `agents/openai.yaml`

## V2.9.0

- **发布日期**：2026-08-04
- **状态**：历史版本
- **检查维度版本**：设计审查维度与 Checks · V2.9.0

### 核心改动

1. **Review Context 增加 Design Strategy**
   - 设计方声明准备用什么体验策略承接需求，Review Target 继续承担 Design Scope，Design Basis 继续描述改动关系。
   - 设计策略必须来自设计方说明、提交标注或经设计方确认的推断，禁止从 PRD 或最终设计效果反向编造。
   - 缺少会影响正式校验的设计策略时，Intake 将其作为阻断项集中追问。

2. **增加评审上下文校验阶段**
   - 基于 PRD 的业务背景、核心目标和产品方案，校验 Strategy Alignment、Scope Alignment 与 Relationship Alignment。
   - `aligned` 正常继续；`partially_aligned` 保留未覆盖目标、妥协、风险和权限边界后继续；`not_aligned` 阻断正式设计审查。
   - 阻断只用于核心方向冲突、核心需求完全未覆盖或严重范围错位，避免因策略表达不完整而过度拒绝评审。

3. **区分策略妥协与材料限制**
   - `partially_aligned` 表示有证据的设计策略妥协，`limited` 表示材料或能力限制，两者互不替代。
   - 策略部分满足但材料充分时，Review Readiness 仍可为 `ready`。
   - 策略妥协不自动生成 Issue、P0–P3 或 Check Result；D1–D6 继续独立审查实际设计实现。

4. **更新报告与取舍边界**
   - 正式报告增加“评审上下文校验”；`partially_aligned` 时独立展示设计策略妥协。
   - 策略妥协不计入审查项分布和已发现问题数量。
   - Trade-off Analysis 仍只在正式 Check Results 产生跨维度冲突时按需加载。

### 兼容性变化

- Review Context 新增必需的 `design_strategy`。
- 新增 `review_context_alignment`，状态为 `aligned`、`partially_aligned` 或 `not_aligned`。
- 20 个语义化 Check IDs、Issue、Question、Trade-off 与 Action 关联结构保持兼容。
- V2.8.x 的 Review Context 需要补充或确认 Design Strategy 后才能进入正式审查。

### 主要文件

- `SKILL.md`
- `references/review-context.md`
- `references/review-criteria.md`
- `references/report-template.md`
- `references/html-report.md`
- `capabilities/trade-off-analysis.md`
- `assets/html-report-template.html`
- `agents/openai.yaml`

## V2.8.1

- **发布日期**：2026-08-03
- **状态**：历史版本
- **检查维度版本**：设计审查维度与 Checks · V2.8.1

### 核心改动

1. **增加 Review Context Intake**
   - 正式分析前检查当前设计、Review Target、Design Basis、Flow 边界和交付质检证据。
   - 缺少阻断项时集中追问并等待补全，不允许 AI 用猜测启动正式评审。
   - 用户补充后重新执行完整 Intake，避免只校验单个新增字段。

2. **区分阻断项与限制项**
   - 缺少当前设计、评审对象、设计关系或 Flow 边界时设为 `blocked`。
   - 缺少 PRD、历史基线、旧方案、团队规范或部分状态时通常设为 `limited`。
   - `limited` 先请求补充或确认接受限制，再继续评审，并在报告中记录受限能力。

3. **规范补充请求**
   - 一次性区分“必须补充”和“建议补充”，说明缺失材料及其对结论的影响。
   - 不追问可从现有材料可靠推断的信息，也不要求用户填写页面清单、baseline、Requirements Evidence 或 Validation Scope。

### 兼容性变化

- Review Context 数据字段与 V2.8.0 兼容。
- 新增 `intake_validation`、`blocking_gaps` 和 `limiting_gaps`。
- `limited` 正式报告需要记录用户已接受的限制。

### 主要文件

- `SKILL.md`
- `references/review-context.md`
- `references/report-template.md`
- `references/html-report.md`
- `references/review-criteria.md`
- `capabilities/trade-off-analysis.md`
- `assets/html-report-template.html`
- `agents/openai.yaml`

## V2.8.0

- **发布日期**：2026-08-03
- **状态**：历史版本
- **检查维度版本**：设计审查维度与 Checks · V2.8.0

### 核心改动

1. **重新定义 Review Context**
   - Review Context 从“已确认业务事实”改为最小设计评审配置层。
   - `review_target.level` 只保留 `page`、`flow`、`feature`；Flow 只填写起点和终点，不要求逐页列举。
   - `design_basis.relationship` 只保留 `from_scratch`、`local_optimization`、`redesign`。
   - Review Context 不再要求填写 baseline、页面清单或 PRD 已明确的业务事实。

2. **增加 Requirements Evidence 与 Material Analysis**
   - 用户、目标、状态、触发、规则和期望行动由 Skill 从 PRD 与正式业务材料抽取，不要求设计师重复确认。
   - 当前设计、页面、状态、节点、历史版本和线上截图由 Material Analysis 识别。
   - 是否需要比较及比较维度改为 AI 推理结果。

3. **调整准入与范围生成**
   - Readiness 改为 `ready`、`limited`、`blocked`；只有 `blocked` 暂停正式评审。
   - 局部需求事实或设计证据缺失只影响依赖它们的 Checks，不默认阻断整个 Review。
   - Validation Scope 同时使用 Review Target、Design Basis、Review Mode、Requirements Evidence 和 Material Analysis。

4. **拆分追踪职责**
   - Requirements Source Trace 记录业务事实来源。
   - Material Analysis 记录设计对象、材料角色、baseline 和比较能力。
   - Finding Trace 记录判断依据、设计观察和 Scope 关系。

### 兼容性变化

- 这是 Review Context 数据模型的不兼容升级。
- `review_type` 替换为 `review_target.level`，并新增 `page` 层级。
- 移除 `context_status`、业务事实确认字段、`context_trace` 和手工 baseline 字段。
- 新增 `design_basis.relationship`、Requirements Evidence、Material Analysis 和 `limited` readiness。
- 20 个语义化 Check IDs、Issue、Question、Trade-off 与 Action 关联结构保持兼容。

### 主要文件

- `SKILL.md`
- `references/review-context.md`
- `references/review-criteria.md`
- `references/report-template.md`
- `references/html-report.md`
- `capabilities/trade-off-analysis.md`
- `assets/html-report-template.html`
- `agents/openai.yaml`

## V2.7.30

- **发布日期**：2026-07-30
- **状态**：历史版本
- **检查维度版本**：设计审查维度与 Checks · V2.7.30

### 核心改动

1. **收敛 MVP 审查边界**
   - 当前版本只审查屏幕可直接感知的视觉设计和可见交互表达。
   - 保留页面结构、信息层级、组件规范、可见状态、视觉适配和视觉无障碍检查。
   - TTS、声音、触觉、读屏、键盘/焦点实现、后端、算法、数据准确性和性能不再进入 Checks、Questions 或结论。

2. **固定审查结论**
   - 正式报告只允许“通过”“修改后通过”“不通过，需重新评审”。
   - 结论只表达推进决策，不描述审查范围、限制条件、未覆盖项或待确认信息。
   - 材料不足时在 Context & Scope Validation 阶段阻断，不生成“信息不足，暂不判定”的正式报告。

3. **调整视觉质量 Checks**
   - D4 明确只检查可见的反馈与恢复表达。
   - D6 调整为“适配、视觉无障碍与交付完整性”。
   - `accessibility-and-inclusion` 更新为 `visual-accessibility-and-inclusion`。
   - `delivery-completeness` 更新为 `visual-delivery-completeness`。

4. **优化报告阅读结构与中文命名**
   - 报告改为先展示总体结论、关键发现和后续行动，再展示范围、依据与全量审查项。
   - 全量审查项移入默认折叠的附录，内部判断顺序仍保持先完成审查项再归并问题。
   - 五态中文名称统一为“符合、部分符合、不符合、证据不足、不适用”。
   - Issue 和 Question 的读者侧名称统一为“已发现问题”和“待补充材料”。
   - 首屏明确审查项分布与结果归纳的从属关系，非零关注数据优先展示。
   - 后续行动不再展示关联 Checks、`Q-xx` 或内部来源编号。

### 兼容性变化

- Check 总数仍为 20。
- `check_id`、Issue、Question、Trade-off 与 Action 的内部关联结构保持兼容；本次仅调整中文状态值和报告展示契约。
- 两个 D6 Check ID 发生语义化迁移：
  - `accessibility-and-inclusion` → `visual-accessibility-and-inclusion`
  - `delivery-completeness` → `visual-delivery-completeness`
- Review Context、Validation Scope、Issue、Trade-off 与 Action 结构保持兼容。

### 主要文件

- `SKILL.md`
- `references/review-criteria.md`
- `references/report-template.md`
- `references/html-report.md`
- `capabilities/trade-off-analysis.md`
- `agents/openai.yaml`

## V2.7.29

- **发布日期**：2026-07-29
- **状态**：历史版本
- **检查维度版本**：设计审查维度与 Checks · V2.7.29

### 核心改动

1. **拆分上下文输入与 AI 推理产物**
   - Review Context 只承载需要抽取或确认的业务事实、材料与历史基线。
   - Validation Scope 改为 Skill 根据 Review Mode、设计变化、影响关系和历史基线自动生成。

2. **增加 Validation Scope Generation**
   - 新设计将页面内全部可见内容及相关关键状态纳入范围。
   - 局部改造采用 `Change Scope + Impact Scope - Unrelated Historical Issues`。
   - 用户提供的范围只作为 `scope_constraints`，不直接代替 AI 的影响分析。

3. **拆分 Context Trace 与 Finding Trace**
   - Context Trace 记录 Review Context 字段的来源和置信状态。
   - Finding Trace 记录每个判断的依据、设计观察和 Validation Scope 关系。
   - 报告将 Review Context、Review Scope 和正式判断依据分区展示。

4. **调整正式审查入口与报告契约**
   - 工作流调整为：Context Builder → 用户确认业务事实 → Validation Scope Generation → Context & Scope Validation → Checks。
   - Context 或 Scope 未达到 `ready` 时，只输出 Draft、Trace、范围限制和待补充材料，不进入正式问题判断。
   - Check Result 将 `finding_trace` 作为必填字段；报告全量展示 Scope 关系，过滤与本次变化无关的历史问题。

### 兼容性变化

- 20 个语义化 Check IDs 与 V2.7.28 保持一致。
- 原 `scope.included/excluded` 不再作为 Review Context 必填字段；用户范围改记为 `scope_constraints`。
- Check Result 增加 `finding_trace`；Issue、Question 与 Trade-off 数据结构保持兼容。

### 主要文件

- `SKILL.md`
- `references/review-context.md`
- `references/review-criteria.md`
- `capabilities/trade-off-analysis.md`
- `references/report-template.md`
- `references/html-report.md`
- `assets/html-report-template.html`
- `agents/openai.yaml`

## V2.7.28

- **发布日期**：2026-07-28
- **状态**：历史版本
- **检查维度版本**：设计审查维度与 Checks · V2.7.28

### 核心改动

1. **完成生产能力与评估资产隔离**
   - Skill 目录只保留 Review Context、正式 Checks、取舍分析与报告生成。
   - 原有黄金数据和评估规范已迁出，不再参与生产 Skill 的读取或运行。

2. **同步版本标记**
   - Skill、检查维度、取舍能力、报告模板与 UI 元数据统一升级为 `V2.7.28`。
   - 机器标识继续保持为 `design-review`。

### 兼容性变化

- 20 个语义化 Check IDs 与 V2.7.22 保持一致。
- Review Context、Check Result、Issue、Question 与 Trade-off 数据结构保持兼容。

### 主要文件

- `SKILL.md`
- `references/review-context.md`
- `references/review-criteria.md`
- `capabilities/trade-off-analysis.md`
- `references/report-template.md`
- `references/html-report.md`
- `assets/html-report-template.html`
- `agents/openai.yaml`

## V2.7.22

- **发布日期**：2026-07-22
- **状态**：历史版本
- **检查维度版本**：设计审查维度与 Checks · V2.7.22

### 核心改动

1. **增加 Review Context 前置层**
   - 增加 Review Context Builder 与 Context Validation。
   - Context 未确认或校验未通过时暂停正式评审，不输出问题等级或正式报告。

2. **区分两类评审上下文**
   - Flow Review：关注状态、触发事件、前后步骤和任务闭环。
   - Feature Review：关注用户问题、入口、价值主张、信任和转化目标。
   - `review_type` 与新设计、局部修改、交付质检等 `review_mode` 分离。

3. **重构检查数据模型**
   - 采用 `Dimension → Check → Check Result → Issue/Question → Action`。
   - Check 成为最小判断单元，并使用稳定语义 ID。
   - 正式检查由原 18 个层级编号检查项调整为 20 个语义化 Checks。

4. **重构核心检查维度**
   - D1：业务目标与场景符合性，回答“为什么做”。
   - D2：需求与规则符合性，回答“明确要求做什么”。
   - D3：信息架构与认知效率，回答“做出来是否有效”。
   - D4：交互反馈与操作安全。
   - D5：视觉与规范符合性。
   - D6：适配、无障碍与交付完整性。

5. **问题改为 Check Result 的派生物**
   - `部分满足`、`未满足`形成 Issue 候选并按根因归并。
   - `无法验证`形成 Question，不使用 P0–P3 强行定级。
   - 报告不再把 Check 与 Issue 一一绑定。

6. **增加跨维度取舍能力**
   - 增加 Conflict Detection 和按需加载的 Trade-off Analysis capability。
   - 当满足需求会损害信息效率、操作安全、规范或无障碍时，生成独立 `T-xx` 决策记录。
   - 明确冲突双方、不可协商项、可调空间、决策、牺牲项和权限边界。

7. **重构报告结构**
   - 报告先展示已确认 Review Context 与 Validation。
   - 全量展示 Check Results 后，再聚合 Issues、Trade-off Decisions 和 Actions。
   - 报告记录 `Skill 版本`，便于结果追踪。

8. **明确生产能力边界**
   - Skill 目录只保留设计审查流程、判断规则、取舍能力与报告生成。
   - 与正式审查无关的质量评估资产不参与 Skill 运行，降低上下文噪声和非业务信息干扰。

### 兼容性变化

- 原层级编号不再作为稳定检查身份；外部消费者与历史报告应迁移到语义化 `check_id`。
- Context 未确认时不再生成“信息不足版正式报告”，而是输出 Draft Context 和待确认项后暂停。
- 旧报告若需要与新版本比较，应先映射旧检查项与 V2.7.22 的语义化 Checks。

### 主要文件

- `SKILL.md`
- `references/review-context.md`
- `references/review-criteria.md`
- `capabilities/trade-off-analysis.md`
- `references/report-template.md`
- `references/html-report.md`

## 早期未编号版本

V2.7.22 之前的修改未建立正式版本号，不进行追溯编号。其内容已合并进入 V2.7.22；后续版本从本记录继续维护。
