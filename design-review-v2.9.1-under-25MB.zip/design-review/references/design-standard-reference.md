# Design Standard Reference

本文件是 `design-review` 的系统级设计规范目录。规范属于 Skill 的稳定评审资产，默认由 Skill 根据评审对象自动选择和加载；设计师不需要在每次评审时重复上传已有规范。

## 1. 规范资产

### 司机端 9.0 通用设计规范

- 文件：[driver-design-guidelines-9.0.pdf](driver-design-guidelines-9.0.pdf)
- 适用范围：司机端通用页面、Flow、Feature、组件和视觉交付。
- 主要内容：颜色、字体和字号、数字与金额格式、图标、文案、栅格、圆角、阴影、按钮、导航、弹窗、表单、标签、卡片、提示、加载、反馈及常见组件模式。
- 加载条件：评审对象属于司机端，且需要判断通用视觉语言、组件复用、内容格式或视觉适配时加载。

### 司机端行中专项规范

- 文件：[driver-in-trip-guidelines.pdf](driver-in-trip-guidelines.pdf)
- 适用范围：司机处于接乘客、等乘客、送乘客等行中阶段的主页面、更多操作页及相关组件。
- 主要内容：行中整体框架、核心操作区、驾驶场景组件限高、场景卡片、接/等/送订单卡片、字号放大适配、主操作条、即时操作卡片、更多操作页和订单详情卡片。
- 加载条件：Review Target、Requirements Evidence 或 Material Analysis 证明设计涉及行中页面、行中订单卡片、主操作条、更多操作页或相关状态时加载。
- 依赖关系：加载本规范时同时加载司机端 9.0 通用设计规范，用于补充通用视觉和组件规则。

## 2. 选择与优先级

1. 先根据 Review Target、Material Analysis 和 Validation Scope 选择规范，不因文件名相似就加载无关资产。
2. 行中专项规范与通用规范同时适用时，专项规则优先；专项未覆盖的内容回落到通用规范。
3. 用户提供了可确认版本更新、适用范围更准确的官方规范时，以更新且更具体的正式规范为准，并记录替代关系。
4. 用户偏好、竞品做法或通用启发式不能覆盖正式规范。
5. 规范之间存在版本或规则冲突且无法确定优先级时，记录冲突并将相关 Check 标记为 `证据不足`；不要静默选择。

## 3. 加载与判断边界

- **加载规范是证据准备动作**：在正式 Checks 前读取适用规范，建立 Design Standard Evidence。
- **规范判断属于正式审查**：只有 D5、D6 或其他实际依赖规范的 Check 才判断设计与规范的关系。
- 不创建独立的 Design Standard Validation 准入阶段。
- 未覆盖不等于不符合。规范没有对应规则时，标记 `uncovered`，再依据 PRD、当前用户任务和明确标注的通用原则进行审查。
- 符合规范不等于整体设计通过；D1-D4、D6 的异常仍需独立保留。

## 4. 规范关系状态

对依赖规范的设计点记录以下状态之一：

- `compliant`：设计与适用规范一致。
- `uncovered`：已加载规范未覆盖该设计点；不自动形成 Issue。
- `intentional_exception`：设计方主动声明偏离规范，并提供规则、理由、预期收益和风险控制；在正式 Check 中判断例外是否成立。
- `violation`：有明确、适用且可核对的规范证据证明设计不符合，且不存在已接受的合理例外。

状态只描述设计与规范的关系，不替代 Check 的五态结论。

## 5. 设计师何时需要补充

只有以下情况才请求额外信息：

1. 当前业务、平台或设备不在系统规范覆盖范围内，需要补充适用标准或新模式依据。
2. 设计主动突破现有规范，需要在 Review Context 的 `design_exceptions` 中声明。
3. 用户明确指出系统规范已过期或不适用，需要提供新版正式规范或版本说明。

不得要求设计师重复上传本目录已经包含且适用的规范。

## 6. Design Standard Evidence

正式审查前生成：

```yaml
design_standard_evidence:
  selected_references:
    - id: driver-design-guidelines-9.0
      role: general
      source: references/driver-design-guidelines-9.0.pdf
      applicability: applicable
    - id: driver-in-trip-guidelines
      role: scene_specific
      source: references/driver-in-trip-guidelines.pdf
      applicability: applicable
  coverage:
    status: covered                  # covered | partially_covered | uncovered | conflicting
    covered_design_points: []
    uncovered_design_points: []
    conflicts: []
  design_exceptions: []
```

Design Standard Evidence 记录实际读取的规范、适用范围、覆盖缺口和冲突。它是正式 Check 的依据，不参与 Review Context Alignment，也不单独决定 Review Readiness。
