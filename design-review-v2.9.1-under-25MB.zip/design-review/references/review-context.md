# Review Context、评审上下文校验、Requirements Evidence、Validation Scope 与 Design Standard Evidence

## 目录

1. Review Context Intake
2. Review Context 职责与结构
3. Builder、Material Analysis 与 Requirements Evidence
4. Review Context Alignment Validation
5. Validation Scope 与 Design Standard Evidence
6. Review Readiness Validation 与 Trace 职责

Review Context 回答“设计方准备用什么策略解决问题、评审什么层级的设计对象、当前设计与既有方案是什么关系、采用什么评审方式、是否主动突破规范”；评审上下文校验回答“该策略和对象是否合理承接 PRD”；Requirements Evidence 回答“PRD 和正式业务材料规定了什么”；Validation Scope 回答“本次哪些设计点可以进入正式结论”；Design Standard Evidence 回答“本次实际采用了哪些系统规范、覆盖到哪里”。五者必须分开，不让设计师重复确认 PRD 已明确的业务事实，不要求设计师重复上传系统已有规范，也不让 Review Context 膨胀成人工填写的 Scope。

生命周期：

```text
用户说明 + 设计材料 + PRD / 正式业务材料
  → Review Context Intake
  → 完整：继续 / 不完整：集中追问并等待补充
  → Review Context Builder
  → Material Analysis + Requirements Evidence
  → Review Context Alignment Validation
      → aligned / partially_aligned：继续
      → not_aligned：阻断并重新澄清策略
  → AI 生成 Validation Scope
  → 按 Scope 选择 Design Standard Reference，生成 Design Standard Evidence
  → Review Readiness Validation
  → 正式 Design Review + Finding Trace
```

## 1. Review Context Intake

在分析设计和生成 Scope 之前，先检查当前提交是否足以启动评审。完整检查面向用户实际提供的消息、附件和链接，不要求用户机械填写 YAML。

### 阻断项

以下任一项缺失且无法从当前输入可靠推断时，设为 `blocked`，必须追问并等待补充：

- 至少一份清晰、可读取的当前设计或当前实现材料。
- `design_strategy.statement`：设计方声明本次准备用什么体验策略承接需求；允许从设计方提交说明或设计标注中提取，但不能从 PRD 或最终设计效果反向编造。
- 至少一份能够证明业务背景、核心目标和产品解决方案的 PRD 或等价正式需求材料；缺少这些事实时无法完成评审上下文校验。
- `review_target.level`：`page`、`flow` 或 `feature`。
- `review_target.name` 或等价的人类可读对象名称。
- `design_basis.relationship`：`from_scratch`、`local_optimization` 或 `redesign`。
- Flow 的 `boundary.start` 和 `boundary.end`。
- 无法可靠推断且会改变评审策略的 `review_mode`。
- `delivery_qa` 所需的目标设计与实现证据。

### 限制项

以下材料缺失时通常设为 `limited`，先说明受限能力并请求补充，不默认阻断全部评审：

- 缺少完整 PRD，但其他正式需求材料已足以证明业务背景、核心目标和产品方案：可以完成评审上下文校验，但详细规则与需求覆盖能力受限。
- `local_optimization` 缺少旧版设计或线上截图：不能判断是否改善、退化或引入回归。
- `redesign` 缺少旧方案：不能完整判断原有能力是否丢失或迁移。
- `delivery_qa` 的关键验收对象依赖系统未覆盖的专项规范，且用户没有提供适用的正式补充规范：只限制对应规范验收 Checks，不自动阻断其他审查。
- 缺少部分状态、适配尺寸或实现证据：只限制依赖这些材料的 Checks。

如果缺失材料使核心目标、关键规则、主要任务或评审对象整体无法识别，则从 `limited` 升级为 `blocked`。

### 追问规则

1. 先检查用户消息、附件、设计稿可见内容和已有材料，能可靠推断的字段不要重复询问。
2. 一次性汇总当前所有阻断项，使用“必须补充”标题，逐项说明需要什么以及为什么。
3. 将非阻断材料放在“建议补充”下，并明确不补充会失去哪些判断能力。
4. 不要求用户填写页面清单、baseline、Requirements Evidence 或 Validation Scope。
5. `blocked` 时暂停，不执行 Material Analysis 之后的正式评审，也不输出设计问题或优先级。
6. `limited` 时询问用户是补充材料，还是接受限制继续；用户已明确要求直接评审时可以继续，但必须在报告中记录限制。
7. 用户补充或修正后，重新执行完整 Intake；不要只校验刚补充的单个字段。
8. 用户无法提供阻断项时，说明无法进行正式设计评审；不要用猜测补齐后继续。

统一输出：

```yaml
intake_validation:
  readiness: blocked                 # ready | limited | blocked
  inferred_fields: []
  blocking_gaps:
    - item: review_target.level
      reason: 无法确定按页面、流程还是功能级策略评审
      request: 请说明本次评审对象属于页面、Flow 还是 Feature
  limiting_gaps:
    - item: baseline_material
      reason: 无法判断局部优化是否改善或引入回归
      request: 建议补充原设计稿或线上截图
  next_action: 等待用户补充全部阻断项
```

## 2. Review Context 职责

Review Context 是设计方对本次设计意图与评审配置的最小结构化声明，只保留会改变评审策略的信息：

1. `design_strategy`：准备用什么体验策略承接业务目标和产品方案。
2. `review_target`：评审什么层级的对象，即 Design Scope。
3. `design_basis.relationship`：当前设计与既有方案是什么关系。
4. `review_mode`：本次采用什么评审方式。
5. 必要的提交阶段、范围约束、实现约束、主动规范例外和策略信息缺口。

Review Context 不承载：

- 页面、状态、节点和组件的完整清单。
- 历史版本、线上截图或 baseline 的位置声明。
- 是否需要比较、比较哪些维度等 AI 判断。
- 目标用户、用户问题、业务目标、业务状态、触发事件、业务规则、价值主张、期望行动、转化目标和成功指标。
- 最终 Change、Impact 和 Excluded Scope。

## 3. Review Context 结构

```yaml
schema_version: review-context-vnext

review_context:
  design_strategy:
    statement: 通过缩短确认路径并前置关键费用信息，降低司机提现决策成本
    source: designer_statement          # designer_statement | submission_annotation | confirmed_inference
    explicit_tradeoffs: []              # 设计方已知且主动声明的目标妥协

  review_target:
    level: flow                       # page | flow | feature
    name: 司机提现流程
    location:
      product: 司机端
      platform: multi_platform
      module: 收入
    boundary:
      start: 进入提现入口              # flow 必填
      end: 提现结果展示                # flow 必填

  review_mode: local_change           # new_design | local_change | delivery_qa

  design_basis:
    relationship: local_optimization  # from_scratch | local_optimization | redesign
    description: 优化提现流程的信息层级，保留原有任务路径

  submission_stage: design_review     # exploration | design_review | pre_delivery | delivery_acceptance

  scope_constraints:
    requested_focus: [提现金额确认]
    explicitly_included: []
    explicitly_excluded: []

  design_constraints:
    device_or_viewport: []
    implementation_constraints: []
    fixed_design_decisions: []

  design_exceptions:
    - standard_reference: null
      rule: null
      rationale: null
      expected_benefit: null
      risk_control: null

  unresolved_review_context: []
```

### `design_strategy`

- `statement` 是设计方对“准备用什么体验策略解决 PRD 问题”的声明，不是 PRD 目标复述，也不是页面元素清单。
- `source` 必须可追踪。仅接受设计方直接说明、提交标注，或经设计方确认的 AI 推断。
- `explicit_tradeoffs` 记录设计方已知的主动妥协；它是校验输入，不代表 AI 已认可该取舍。
- 不要从 PRD 自动生成一条看似正确的策略再自行校验，也不要根据最终稿视觉效果反推策略。

### `review_target`

- `level: page`：评审一个独立页面；页面自身构成基本入口。
- `level: flow`：评审跨页面或跨状态的任务过程；`boundary.start` 和 `boundary.end` 必填。
- `level: feature`：评审一个完整功能或产品能力，可以包含多个页面和多个 Flow。

`name` 是人类可读的集合名称，不是页面名称清单。即使 Flow 包含多个页面，也不要要求提交者逐页填写；由 Material Analysis 识别实际页面、状态和节点。

### `design_basis.relationship`

- `from_scratch`：全新设计，没有基于既有方案继续修改；重点检查方案完整性、关键路径、状态覆盖和规范符合性。
- `local_optimization`：保留既有设计结构或主要能力，仅优化部分设计点；重点检查变化、连带影响、回归和问题归因。
- `redesign`：重新组织既有方案的结构、路径或主要表达；重点检查新方案是否成立，以及原有关键能力是否丢失。

“全新设计”描述设计关系，不等于产品历史上绝对不存在相似页面。不要根据是否发现旧版材料自动改写 `relationship`。

### `review_mode`

- `new_design`：评审方案方向、需求覆盖、完整路径和新模式可学习性。
- `local_change`：聚焦本次明确变化及其连带影响，排除无关历史问题。
- `delivery_qa`：评审交付对象与设计、规范、状态和标注的一致性。

`relationship` 回答“设计怎样产生”，`review_mode` 回答“本次怎样评”。若两者冲突且会改变 Scope，例如 `from_scratch + local_change`，将其记录到 `unresolved_review_context` 并请求澄清；不要静默选择。

### `design_exceptions`

- 仅在设计方主动突破已知规范时填写；没有例外时使用空数组。
- 每项说明被突破的规范及规则、为什么突破、预期收益和风险控制。
- 这是设计方声明，不代表例外已经被审查认可。
- 不要求设计方在此上传已有规范；规范文件由 Skill 的 Design Standard Reference 自动提供。
- 规范未覆盖的新模式不等于主动例外，应在 Design Standard Evidence 中标记 `uncovered`。

## 4. Builder 规则

- 从用户说明、提交信息和设计材料中抽取 Review Context；允许 AI 推断，但记录推断及其影响。
- 优先从设计方说明和提交标注提取 `design_strategy`；只有推断不影响校验结论时才可直接采用，否则必须请设计方确认。
- 不用 PRD 目标文本冒充设计策略，不用待评设计反向证明策略。
- 只向提交者询问会改变评审层级、设计关系、评审模式或 Flow 边界的缺失信息。
- 不要求设计师确认 PRD 已明确的业务事实。
- 不要求设计师列举多页面 Flow 或 Feature 中的所有页面。
- 不要求设计师填写 baseline；旧版、新版、线上截图和内嵌前后对比由 Material Analysis 自动识别。
- `scope_constraints` 只是提交者的边界约束，不等于最终 Validation Scope。
- 只在设计方明确声明偏离规范时记录 `design_exceptions`；不要根据视觉差异替设计方编造例外理由。
- Builder 阶段不输出设计问题、Check Results 或 P0–P3。

## 5. Material Analysis

分析用户实际提供的设计稿、原型、线上截图、实现截图和说明材料，生成：

```yaml
material_analysis:
  review_targets: []
  discovered_objects:
    pages: []
    states: []
    flow_nodes: []
    design_points: []
  baseline_detected:
    available: false
    sources: []
    source_type: null                 # live_screenshot | historical_design | embedded_comparison | approved_design
    confidence: null
  comparison_required: false
  comparison_dimensions: []
  limitations: []
```

规则：

- 不因文件名或视觉相似度自动互换当前设计、旧版、线上实现和批准方案的角色。
- baseline 可以来自独立截图、历史设计或同一设计稿中的前后对比。
- `comparison_required` 和比较维度由 Skill 根据 `relationship`、`review_mode`、材料角色和变化影响生成，不要求设计师填写。
- 无可靠 baseline 时记录归因限制，不声称改善、退化、新增或历史遗留。

## 6. Requirements Evidence

业务事实由 PRD、业务规则、流程图和其他正式需求材料提供。Skill 负责抽取和引用，不要求设计师逐项确认：

```yaml
requirements_evidence:
  user: []
  user_problem: []
  business_goals: []
  expected_actions: []
  states: []
  triggers: []
  business_rules: []
  value_propositions: []
  conversion_goals: []
  source_trace:
    - fact: 提现完成后展示结果状态
      source: PRD-流程说明
      status: sourced                 # sourced | conflicting | missing
```

规则：

- 优先采用 PRD 和正式业务材料，不用待评设计反向证明业务状态、触发条件或业务目标。
- PRD 已明确时直接采用并记录来源，不重复询问设计师。
- PRD 未说明但不影响某个 Check 时继续评审。
- PRD 缺失或冲突且会改变某个业务判断时，将受影响 Check 标记为证据不足或不适用，并形成产品/业务待补充材料；不要把设计师的临时回答自动升级为正式业务规则。
- 只有核心目标、关键规则或主要任务整体无法识别，导致正式结论不可靠时，才阻断整个评审。

## 7. Review Context Alignment Validation

评审上下文校验基于 Requirements Evidence，验证设计方声明的策略与对象是否足以支持后续正式设计评审。它不是检查业务背景真假，也不是提前审查视觉实现。

```yaml
review_context_alignment:
  status: partially_aligned           # aligned | partially_aligned | not_aligned
  checks:
    strategy_alignment:
      status: partially_aligned
      evidence: [PRD 目标与设计策略的对应关系]
    scope_alignment:
      status: aligned
      evidence: [Review Target 对主要需求对象的覆盖]
    relationship_alignment:
      status: aligned
      evidence: [设计关系、材料与 Review Mode 一致]
  aligned_requirements: []
  compromised_requirements: []
  compromise_rationale: []
  risks: []
  authority: review_can_proceed       # review_can_proceed | requires_product_decision | blocked
  next_action: continue_review
```

### 状态

- `aligned`：设计策略、对象和设计关系能够有效支持 PRD 核心目标与产品方案，继续评审。
- `partially_aligned`：核心方向成立，但部分目标被弱化、延后或交由其他方案承担；继续评审，同时保留覆盖项、未覆盖项、妥协理由、风险与决策权限。
- `not_aligned`：策略与核心目标方向冲突、完全无法覆盖核心需求，或评审对象与需求目标严重错位；阻断正式评审并要求重新澄清。

### 校验规则

1. 先比较业务背景与核心问题，再比较业务目标和产品解决方案；不要只做关键词匹配。
2. `strategy_alignment` 判断“准备怎么解决”是否承接“为什么做、需要做什么”。
3. `scope_alignment` 判断 Review Target 是否覆盖需求主要影响范围，不要求设计方手工列页面清单。
4. `relationship_alignment` 判断 `from_scratch`、`local_optimization`、`redesign` 与材料和评审方式是否一致。
5. 设计策略只是部分手段但仍支持核心方向时，判为 `partially_aligned`，不要轻易阻断。
6. 只有核心冲突、核心需求完全未覆盖或严重范围错位时使用 `not_aligned`，并引用正式 PRD 证据。
7. `partially_aligned` 产生 Context Trade-off 记录，不自动产生 Issue、P0–P3 或 Check Result；正式设计稿仍需由 D1–D6 独立判断。
8. 若妥协需要改变明确 PRD、业务规则或核心目标，标记 `requires_product_decision`，不能由审查者单方面批准。

## 8. Validation Scope Generation

Validation Scope 是 AI 生成的评审计划，不是用户输入答案：

```text
Validation Scope
= Change Scope
+ Impact Scope
- Unrelated Historical Issues
```

```yaml
validation_scope:
  discovered_objects:
    pages: []
    states: []
    flow_nodes: []
    affected_design_points: []
  change_scope: []
  impact_scope: []
  excluded_scope: []
  limitations: []
```

生成规则：

- `page`：从目标页面及其可见状态生成范围。
- `flow`：从 `boundary.start` 到 `boundary.end` 识别页面、状态、节点和闭环关系。
- `feature`：识别功能入口、相关页面、关键 Flow 和能力关系，不默认扩张到材料未证明相关的外部系统。
- `from_scratch`：纳入当前方案全部可见内容及需求证明必要的关键状态和任务路径。
- `local_optimization`：明确变化进入 `change_scope`；受空间、层级、路径、状态、任务或安全影响的内容进入 `impact_scope`；无关历史问题进入 `excluded_scope`。
- `redesign`：将新方案整体及原有关键能力迁移纳入范围；发现可靠 baseline 时执行能力与体验比较。
- `delivery_qa`：以本次交付对象、相关状态、实现证据和设计规范为范围。
- `change_scope`、`impact_scope`、`excluded_scope` 必须显式输出；为空时说明原因。
- 用户提供的 `scope_constraints` 只作为约束，不能替代 AI 的影响分析。

## 9. Design Standard Evidence

Design Standard Reference 是 Skill 系统资产，不是设计师每次提交的 Review Context 输入。Validation Scope 生成后，按 [design-standard-reference.md](design-standard-reference.md) 选择并加载适用规范：

```yaml
design_standard_evidence:
  selected_references:
    - id: driver-design-guidelines-9.0
      role: general
      source: references/driver-design-guidelines-9.0.pdf
      applicability: applicable
  coverage:
    status: covered                  # covered | partially_covered | uncovered | conflicting
    covered_design_points: []
    uncovered_design_points: []
    conflicts: []
  design_exceptions: []
```

规则：

- 加载规范是证据准备动作，不是独立的评审准入或 Design Standard Validation。
- 司机端通用对象加载 9.0 通用规范；行中页面、订单卡片、主操作条和更多操作页同时加载行中专项规范。
- 专项规范优先于通用规范；更新且适用范围更准确的正式规范可以替代系统资产，但必须记录来源和替代关系。
- 规范未覆盖时标记 `uncovered`，不自动生成 Issue，也不自动把 Readiness 降为 `limited`；只有缺少规范使关键交付验收无法形成可靠结论时，才影响相关 Check 或 Readiness。
- `design_exceptions` 原样保留设计方声明，正式 D5/D6 Check 再判断例外是否合理。
- Design Standard Evidence 不参与 Review Context Alignment；规范符合性属于正式审查。

## 10. Review Readiness Validation

```yaml
review_context_validation:
  readiness: ready                   # ready | limited | blocked
  alignment_status: aligned          # aligned | partially_aligned | not_aligned
  intake_validation:
    blocking_gaps: []
    limiting_gaps: []
  missing_strategy_fields: []
  strategy_limitations: []
  selected_review_strategy:
    target_level: flow
    review_mode: local_change
    relationship: local_optimization
    comparison_mode: baseline_comparison
    scope_generation_mode: change_and_impact
    attribution_capability: full
    review_emphasis: []
```

状态规则：

- `ready`：评审对象、策略和 Scope 足以支持正式结论。
- `limited`：可以正式评审，但部分比较、归因或 Check 受材料限制；先请求补充或确认接受限制，再在对应结果和报告限制中明确。
- `blocked`：`alignment_status` 为 `not_aligned`，或无法识别评审对象 / Flow 边界、无法选择评审策略、无法生成核心 Scope，或 PRD / 设计材料整体不足以支持正式结论。

`partially_aligned` 描述策略妥协，`limited` 描述材料或能力限制；两者互不替代。策略部分满足且材料充分时，Readiness 可以为 `ready`。

仅 `blocked` 暂停正式审查。此时只输出已识别的 Review Context、Intake 阻断项、Material Analysis、Requirements Evidence、Scope Draft、缺失或冲突字段、范围限制和必须补充的材料；不要输出正式结论、Check Results、P0–P3 或 HTML 报告。

## 11. Trace 职责

- **Review Context Alignment Trace**：记录设计策略与 PRD 背景、目标和产品方案的对应关系、妥协与风险。
- **Requirements Source Trace**：记录从 PRD 和正式业务材料抽取的事实及来源状态。
- **Material Analysis**：记录设计对象、材料角色、baseline 和可比较性的识别结果。
- **Design Standard Evidence**：记录系统规范的选择、适用范围、覆盖状态、冲突和设计方声明的规范例外。
- **Finding Trace**：记录每个 Check Result 的判断依据、设计观察及其与 Validation Scope 的关系。

五者不能合并为笼统的 `source_trace`。业务来源不能替代设计问题证据；设计观察也不能反向证明业务事实；规范证据不能替代整体体验判断；评审上下文校验不能替代 D1 对实际设计方案的判断。
