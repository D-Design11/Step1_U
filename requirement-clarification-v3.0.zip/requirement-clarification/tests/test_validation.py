"""Exercise scenario boundaries and handoff integrity, not report wording."""
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('validator', ROOT / 'scripts/validate_output.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class ValidationTests(unittest.TestCase):
    def fixture(self, automatic=True):
        return json.loads((ROOT / 'tests' / ('valid-automatic-generation.json' if automatic else 'valid-design-precheck.json')).read_text())

    def test_auto_pass_with_missing_content_and_no_goals(self):
        self.assertEqual(module.validate(self.fixture()), [])

    def test_human_intermediate_allowed(self):
        self.assertEqual(module.validate(self.fixture(False)), [])

    def test_automatic_rejects_all_human_statuses(self):
        for status in ('准入', '修改后可开始设计', '无法开始设计'):
            with self.subTest(status=status):
                d = self.fixture(); d['admission']['status'] = status
                self.assertTrue(module.validate(d))

    def test_human_rejects_automatic_statuses(self):
        for status in ('通过', '不通过'):
            d = self.fixture(False); d['admission']['status'] = status
            self.assertTrue(module.validate(d))

    def test_auto_failure_requires_issue_and_stops_handoff(self):
        d = self.fixture(); d['admission'].update(status='不通过', handoff_ready=False)
        d['requirement_context']['completeness'] = 'partial'
        self.assertTrue(module.validate(d))
        d['issues'] = self.fixture(False)['issues']
        self.assertEqual(module.validate(d), [])
        d['admission']['handoff_ready'] = True
        self.assertTrue(module.validate(d))

    def test_content_conflict_is_nonblocking_but_requires_trace(self):
        d = self.fixture()
        c = {'item':'样例内容差异', 'statements':[{'text':'表述A','source_ref':'测试材料A'}, {'text':'表述B','source_ref':'测试材料B'}], 'affected_objects':['已有展示区域'], 'nonblocking_reason':'仅显示文字，无互斥动作或状态', 'source_refs':['测试材料A','测试材料B']}
        d['generation_handoff']['content_conflicts'] = [c]
        self.assertEqual(module.validate(d), [])
        del c['nonblocking_reason']
        self.assertTrue(module.validate(d))

    def test_human_pass_requires_goals(self):
        d = self.fixture(False); d['admission'].update(status='准入',handoff_ready=True)
        d['issues']=[]; d['precheck_report']['pending_confirmation_ids']=[]
        d['requirement_context']['completeness']='complete'
        self.assertEqual(module.validate(d), [])
        d['requirement_context']['目标与成功标准']['目标指标值']=None
        self.assertTrue(module.validate(d))

    def test_profile_payloads_not_interchangeable(self):
        d=self.fixture();d['precheck_report']={'pending_confirmation_ids':[]}
        self.assertTrue(module.validate(d))

    def test_old_version_rejected(self):
        d=self.fixture();d['schema_version']='2.0'
        self.assertTrue(module.validate(d))

    def test_schema_enforces_scenario_statuses(self):
        try:
            from jsonschema import Draft202012Validator
        except ImportError:
            self.skipTest("optional jsonschema dependency is not installed")
        schema=json.loads((ROOT/'references/requirement-context.schema.json').read_text())
        Draft202012Validator.check_schema(schema)
        v=Draft202012Validator(schema)
        for auto in (True, False):
            d=self.fixture(auto);self.assertEqual(list(v.iter_errors(d)), [])
            d['admission']['status']='修改后可开始设计' if auto else '通过'
            self.assertTrue(list(v.iter_errors(d)))

if __name__ == '__main__':
    unittest.main()
