#!/usr/bin/env python3
"""Validate v3 requirement-clarification JSON and profile invariants."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


STATUSES = {"自动化设计生成": {"通过", "不通过"}, "设计接口人预审": {"准入", "修改后可开始设计", "无法开始设计"}}
SCENARIOS = {"自动化设计生成", "设计接口人预审"}
DIMENSIONS = ("需求背景与问题", "目标与成功标准", "设计范围与边界", "目标用户与业务场景", "用户任务", "内容与体验逻辑")
ISSUE_DIMENSIONS = {*DIMENSIONS, "输入可用性", "跨维度一致性"}
ROOT_COMMON = {"schema_version", "admission", "issues", "requirement_context", "internal_review"}
ADMISSION_KEYS = {"status", "application_scenario", "summary", "handoff_ready", "next_action"}
ISSUE_KEYS = {"id", "level", "dimension", "issue_type", "title", "facts", "confirmation_required", "source_refs"}


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def nonempty(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def validate(document: object) -> list[str]:
    errors: list[str] = []
    require(isinstance(document, dict), "root must be an object", errors)
    if not isinstance(document, dict):
        return errors

    require(document.get("schema_version") == "3.0", "schema_version must be '3.0'", errors)
    admission = document.get("admission")
    require(isinstance(admission, dict), "admission must be an object", errors)
    if not isinstance(admission, dict):
        return errors

    scenario = admission.get("application_scenario")
    status = admission.get("status")
    passed = status == ("通过" if scenario == "自动化设计生成" else "准入")
    require(set(admission) == ADMISSION_KEYS, "admission keys are invalid", errors)
    expected_profile = "generation_handoff" if scenario == "自动化设计生成" else "precheck_report"
    forbidden_profile = "precheck_report" if scenario == "自动化设计生成" else "generation_handoff"
    require(scenario in SCENARIOS, "application_scenario is invalid", errors)
    require(status in STATUSES.get(scenario, set()), "admission.status is invalid", errors)
    require(set(document) == ROOT_COMMON | {expected_profile}, f"root keys must match the {scenario} profile", errors)
    require(forbidden_profile not in document, f"{forbidden_profile} is not allowed for {scenario}", errors)
    require(admission.get("handoff_ready") is passed, "handoff_ready must match the scenario passing result", errors)
    require(nonempty(admission.get("summary")), "admission.summary is required", errors)
    require(nonempty(admission.get("next_action")), "admission.next_action is required", errors)

    issues = document.get("issues")
    require(isinstance(issues, list), "issues must be an array", errors)
    issue_ids: set[str] = set()
    if isinstance(issues, list):
        require((not issues) if passed else bool(issues), "issues must be empty for 准入 and non-empty otherwise", errors)
        for index, issue in enumerate(issues):
            path = f"issues[{index}]"
            require(isinstance(issue, dict), f"{path} must be an object", errors)
            if not isinstance(issue, dict):
                continue
            require(set(issue) == ISSUE_KEYS, f"{path} keys are invalid", errors)
            issue_id = issue.get("id")
            require(isinstance(issue_id, str) and bool(re.fullmatch(r"ISSUE-[0-9]{3}", issue_id)), f"{path}.id is invalid", errors)
            require(issue_id not in issue_ids, f"duplicate issue id: {issue_id}", errors)
            issue_ids.add(issue_id)
            require(issue.get("level") in {"需修改", "阻断"}, f"{path}.level is invalid", errors)
            require(issue.get("dimension") in ISSUE_DIMENSIONS, f"{path}.dimension is invalid", errors)
            require(issue.get("issue_type") in {"冲突", "缺失", "歧义"}, f"{path}.issue_type is invalid", errors)
            for key in ("title", "facts"):
                require(nonempty(issue.get(key)), f"{path}.{key} is required", errors)
            require(isinstance(issue.get("confirmation_required"), list) and bool(issue.get("confirmation_required")), f"{path}.confirmation_required is required", errors)
            require(isinstance(issue.get("source_refs"), list) and bool(issue.get("source_refs")), f"{path}.source_refs is required", errors)
        if status == "修改后可开始设计":
            require(all(i.get("level") == "需修改" for i in issues if isinstance(i, dict)), "修改后可开始设计 cannot contain 阻断 issues", errors)
        if status == "无法开始设计":
            require(any(i.get("level") == "阻断" for i in issues if isinstance(i, dict)), "无法开始设计 requires a 阻断 issue", errors)

    context = document.get("requirement_context")
    require(isinstance(context, dict), "requirement_context must be an object", errors)
    if isinstance(context, dict):
        require(set(context) == {"completeness", *DIMENSIONS}, "requirement_context must keep six dimensions", errors)
        require(context.get("completeness") == ("complete" if passed else "partial"), "requirement_context.completeness does not match status", errors)
        scope = context.get("设计范围与边界")
        require(isinstance(scope, dict), "设计范围与边界 must be an object", errors)
        if isinstance(scope, dict):
            objects = scope.get("交付对象")
            require(isinstance(objects, list), "交付对象 must be an array", errors)
            if passed:
                require(bool(objects), "准入 requires at least one 交付对象", errors)
            nature = scope.get("设计性质")
            if isinstance(nature, dict) and scenario == "自动化设计生成":
                require(nature.get("值") != "改版重构", "自动化设计生成 cannot use 改版重构", errors)
        goals = context.get("目标与成功标准")
        if scenario == "设计接口人预审" and status == "准入" and isinstance(goals, dict):
            for key in ("目标", "成功衡量指标", "目标指标值"):
                require(goals.get(key) is not None and goals.get(key) != "", f"预审准入 requires 目标与成功标准.{key}", errors)

    if scenario == "自动化设计生成":
        handoff = document.get("generation_handoff")
        require(isinstance(handoff, dict) and set(handoff) == {"content_gaps", "content_conflicts"}, "generation_handoff must contain content_gaps and content_conflicts", errors)
        if isinstance(handoff, dict):
            conflicts = handoff.get("content_conflicts")
            require(isinstance(conflicts, list), "content_conflicts must be an array", errors)
            if isinstance(conflicts, list):
                for conflict in conflicts:
                    require(isinstance(conflict, dict), "content conflict must be an object", errors)
                    if not isinstance(conflict, dict):
                        continue
                    require(set(conflict) == {"item", "statements", "affected_objects", "nonblocking_reason", "source_refs"}, "content conflict keys are invalid", errors)
                    for key in ("item", "nonblocking_reason"):
                        require(nonempty(conflict.get(key)), f"content conflict {key} is required", errors)
                    for key in ("affected_objects", "source_refs"):
                        value = conflict.get(key)
                        require(isinstance(value, list) and bool(value) and all(nonempty(v) for v in value), f"content conflict {key} is required", errors)
                    statements = conflict.get("statements")
                    require(isinstance(statements, list) and len(statements) >= 2, "conflict requires at least two sourced statements", errors)
                    if isinstance(statements, list):
                        for statement in statements:
                            require(isinstance(statement, dict) and set(statement) == {"text", "source_ref"} and all(nonempty(v) for v in statement.values()), "invalid conflict statement", errors)
            gaps = handoff.get("content_gaps")
            require(isinstance(gaps, list), "content_gaps must be an array", errors)
            if isinstance(gaps, list):
                for index, gap in enumerate(gaps):
                    path = f"generation_handoff.content_gaps[{index}]"
                    require(isinstance(gap, dict), f"{path} must be an object", errors)
                    if isinstance(gap, dict):
                        require(set(gap) == {"item", "status", "location", "source_refs"}, f"{path} keys are invalid", errors)
                        require(gap.get("status") in {"缺少", "无默认值"}, f"{path}.status is invalid", errors)
    else:
        report = document.get("precheck_report")
        require(isinstance(report, dict) and set(report) == {"pending_confirmation_ids"}, "precheck_report must contain only pending_confirmation_ids", errors)
        if isinstance(report, dict):
            pending = report.get("pending_confirmation_ids")
            require(isinstance(pending, list), "pending_confirmation_ids must be an array", errors)
            if isinstance(pending, list):
                require(set(pending) == issue_ids, "pending_confirmation_ids must exactly match issue ids", errors)

    internal = document.get("internal_review")
    require(isinstance(internal, dict) and set(internal) == {"source_trace"}, "internal_review must contain only source_trace", errors)
    if isinstance(internal, dict):
        trace = internal.get("source_trace")
        require(isinstance(trace, list), "source_trace must be an array", errors)
        if passed:
            require(bool(trace), "准入 requires source_trace", errors)
        if isinstance(trace, list):
            for index, item in enumerate(trace):
                path = f"source_trace[{index}]"
                require(isinstance(item, dict), f"{path} must be an object", errors)
                if isinstance(item, dict):
                    require(set(item) == {"target_path", "source_locator", "source_excerpt_or_summary"}, f"{path} keys are invalid", errors)
                    require(str(item.get("target_path", "")).startswith("/requirement_context/"), f"{path}.target_path is invalid", errors)
    return errors


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: validate_output.py OUTPUT.json", file=sys.stderr)
        return 2
    try:
        document = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"INVALID: {exc}", file=sys.stderr)
        return 1
    errors = validate(document)
    if errors:
        for error in errors:
            print(f"INVALID: {error}", file=sys.stderr)
        return 1
    print("VALID")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
