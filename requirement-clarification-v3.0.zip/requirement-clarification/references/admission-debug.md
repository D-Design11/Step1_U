# 统一判断记录与 Regression Debug

## 使用方式

所有审核先记录候选缺失、冲突与歧义，再聚合最终结论，保存独立的 `admission-debug.json`。记录的是可核对事实、判定字段和简短依据，不是逐步思维过程。保留被证据消除、被判范围外和非阻断的候选项，避免只留下支持最终结论的事项；同根因合并，不凭空制造候选项，无候选时数组为空。

普通模式遵循原有输出。显式 `mode: admission_debug`、Regression Debug 或跨 Agent 回归排查时，额外提供记录文件链接；有两份实际结果时才给分歧摘要，单次运行不推测另一平台的判断。开关只改变诊断可见性，同一 Profile、同一输入的结论和问题集合应相同。

## 固定结构 · 1.0

下面是字段模板，不是审核样例。每项所有字段都必须保留；布尔字段填 true/false，不使用 Yes/No 或字符串布尔值。

```text
debug_version: "1.0"
application_scenario: 自动化设计生成 | 设计接口人预审
input_context:
  skill_revision: 当前技能修订标识或文件摘要；不可取得时 null
  materials: [{source: 文件/提交消息标识, revision: 版本/摘要或 null,
               read_status: 已读取 | 部分读取 | 不可访问}]
  scope: [本次交付对象]
requirement_items:
  - id: CAND-001（按来源出现顺序编号）
    item: 缺失/冲突/歧义候选项
    in_scope: boolean
    evidence_source: [实际查阅的章节/页码/提交声明/规则位置]
    evidence_status: 已明确 | 缺失 | 冲突 | 歧义 | 不可访问
    affects_design_decision: boolean
    requires_product_rule_creation: boolean
    reusable_existing_rule:
      status: 有 | 无 | 未知 | 不适用
      source_refs: [可核对的既有规则位置]
      applicability: 规则内容及适用依据，非“有”时可为 null
    can_continue: boolean
    classification: blocker | non-blocker
    reason: 简短判定依据；阻断时明确被迫决定的产品行为
    issue_id: 对应业务 JSON 的 ISSUE-xxx；无需 PM 处理时 null
final_decision:
  result: 当前 Profile 的结果
  blockers: [classification 为 blocker 的候选 ID]
```

`evidence_status` 表示核对全部有效上下文后的状态，不仅是 PRD 是否写明。`缺失`须基于已查阅材料；读取失败用`不可访问`，不把解析失败当成原文缺失。`evidence_source`记录已查范围，不编造“缺失句子”；没有可核对位置时为空，并在 reason 中注明限制。

`reusable_existing_rule.status=有`只用于证据明确且足以解决本候选缺口的规则，必须填写 source_refs 和 applicability；仅覆盖部分问题时，候选应聚焦仍未解决的缺口。`未知`表示未证实，不等于有或无。不能凭常识补造产品既有规则。

## 逐项判定与聚合

1. 先核对范围、来源优先级及可继承规则；已解决或范围外候选为 non-blocker。设计常规表达可沿用共享责任边界，不必凭空寻找产品规则。
2. `affects_design_decision`表示是否影响本次设计选择；影响布局或文案也可为 true，不能据此直接阻断。
3. `requires_product_rule_creation`表示核对证据后，继续完成本次交付是否仍必须自行决定未确定的产品语义或行为。只有能指出这种必要决定时为 true；范围外、已解决或可保留内容缺口继续时为 false。
4. `can_continue`表示无需代做产品决定即可继续设计，不表示信息完整或已获人工准入；在本记录中等于 `not requires_product_rule_creation`。因此 non-blocker 仍可对应人工的“需修改”。
5. `classification=blocker`当且仅当 `in_scope=true`、`affects_design_decision=true`、`requires_product_rule_creation=true`、`can_continue=false`且无已解决缺口的可继承规则。字段矛盾时先复核证据和判断，不直接聚合。
6. 自动化：有 Blocker 为“不通过”，无则“通过”；issues 只包含 Blocker，level 为“阻断”。人工：有 Blocker 为“无法开始设计”；无 Blocker 但有 Profile 要求补充的事项为“修改后可开始设计”；其余“准入”。人工非阻断问题 level 为“需修改”。

交付前核对：final_decision.result 与业务 JSON 一致；blockers 恰好列出全部阻断候选；每个业务 issue 必须通过 issue_id 对应唯一候选，每个非 null issue_id 必须在业务 JSON 存在；阻断候选必须对应“阻断”issue，非阻断候选不得对应“阻断”issue。不得先选通过/不通过再反填字段。

## 跨 Agent 回归

固定 Skill 文件及 references、PRD 原文件、提交时范围声明、补充材料和 Profile，在两端使用相同的 `mode: admission_debug`。记录实际可取得的版本或摘要，不把未知版本写成相同。先比较读取状态与证据，再按事项语义及来源对齐候选（不依赖序号），依次比较设计影响、规则创造必要性、继承依据、can_continue、classification，最后比较聚合结果。

case3 中已实名字段可编辑性、错误后处理、身份证 X/x、多端覆盖只作为待核对候选，不预设为 Blocker。可编辑性或错误处理只有在范围内且继续设计确实必须选择未定义行为时才阻断；X/x 有明确适用规则时引用，未知时仍检查是否必须代做产品决定；多端覆盖先核对提交范围，不追加未要求的端。必须读取 case3 原始材料后才能给出实际期望结果，不能用历史报告或本段提示代替 PRD。
